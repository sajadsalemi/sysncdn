SyncDB Build 43c  (includes 43b)

43c - two UI bugs reported from the Connections tab:
  * "Set DEST" coloured the row yellow SRC+DEST and the connection kept appearing
    as [SOURCE] in tab 2. An explicit click now decides the colour: DEST = DEST.
  * Tabs 2/3 kept the previous connection's database and table list after the
    connection was changed. They now reload for the new connection (and ticked
    tables are not lost when you simply re-enter the tab).

43b - a four-part name that carries an IP, e.g.
      FROM [172.21.61.105].[HRSStaffing].[dbo].[view_ReportVezarat]
  is read by SyncDB itself. It used to pick the connection by comparing the server
  name as text, so the IP never matched the connection saved under its DNS name and
  it logged in with the SOURCE connection's credentials -> "Invalid object name".
  The server is now matched by connection name, by server name and by IP address,
  and the log and the error name the connection and the login that was used.

Build: run SyncDB\build.bat (csc.exe v4.0.30319).
Full notes: SyncDB\BUILD_INFO.txt  -  Persian: SyncDB\CHANGES_fa.txt
