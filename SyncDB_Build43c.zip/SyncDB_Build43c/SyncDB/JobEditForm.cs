using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Newtonsoft.Json.Linq;

namespace SyncDB
{
    /// <summary>SSMS-like New Job dialog: left pages General / Steps / Schedules.</summary>
    public class JobEditForm : Form
    {
        private SyncJob job;
        private ListBox lstPages;
        private Panel panelHost;

        // ---- Previous / Next between the JOBS of the list (the window is never closed) ----
        private List<SyncJob> _jobs;          // the live job list (config.Jobs)
        private int _jobPos = -1;             // which job of that list is on screen
        private Button _btnJobPrev, _btnJobNext;

        /// <summary>Position of the job on screen inside the list given to the constructor.</summary>
        public int JobPos { get { return _jobPos; } }

        /// <summary>Called to store the job on screen (index in the list). Returns false if it could not be saved.</summary>
        public Func<SyncJob, int, bool> CommitJob;

        // General
        private TextBox txtName, txtDescription;
        private CheckBox chkEnabled;
        private NumericUpDown numCmdTimeout;
        private CheckBox chkAtomicRefill;
        private CheckBox chkConfirmBefore;
        private CheckBox chkAutoSyncLatest;
        private CheckBox chkApplyFieldChanges;
        private CheckBox chkDryRunOnly;
        private CheckBox chkAutoTune;
        private CheckBox chkRecycle;
        private TextBox txtRecycleSchema;
        private NumericUpDown numRecycleHours;
        private Button btnSafetyHelp;

        // Steps
        private ListView lvSteps;
        private NumericUpDown numPos;
        private bool _stepsLoading;
        private Panel stepsPanel;

        // Schedules (SSMS-style)
        private ComboBox cbSchedule;
        private CheckBox chkAsyncUseSeconds, chkAsyncRestrictDays, chkAsyncRestrictTime;
        private NumericUpDown numInterval, numHour, numMinute, numMonthlyDay, numEveryMonths;
        private CheckBox[] chkWeekDays;   // 0=Sun .. 6=Sat
        private Panel schedPanel;
        private Label lblInterval, lblWeekDays, lblSchedTip;
        private FlowLayoutPanel weekDaysPanel, monthlyDayRow, monthlyRelRow;
        private GroupBox grpFreq, grpDaily, grpDuration;
        private RadioButton rbOnceAt, rbEveryHours;
        private bool _dailyRadioSync;
        private RadioButton rbMonthDay, rbMonthRel;
        private ComboBox cbMonthOrdinal, cbMonthWeekday;
        private NumericUpDown numMonthRelEvery;
        private NumericUpDown numSubHours, numEndHour, numEndMinute;
        private Control oncePanel, everyPanel;
        private DateTimePicker dtSchedStart, dtSchedEnd;
        private RadioButton rbNoEndDate, rbEndDate;
        private NumericUpDown _numStartH, _numStartM;

        private Panel generalPanel;

        public JobEditForm(SyncJob job) : this(job, null, -1) { }

        public JobEditForm(SyncJob job, List<SyncJob> jobs, int pos)
        {
            this.job = job ?? new SyncJob();
            this.job.EnsureSteps();
            _jobs = jobs;
            _jobPos = pos;
            BuildUi();
            LoadGeneral();
            LoadStepsList();
            LoadSchedule();
            ShowPage(0);
            Theme.Apply(this);
        }

        public SyncJob ResultJob { get { return job; } }

        private int JobCount { get { return _jobs != null ? _jobs.Count : 0; } }

        /// <summary>Save the job on screen and load the previous / next job into the SAME window.</summary>
        private void NavJob(int dir)
        {
            if (_jobs == null || _jobPos < 0) return;
            int target = _jobPos + dir;
            if (target < 0 || target >= _jobs.Count) return;

            if (!SaveGeneral()) return;          // a wrong field keeps this job on screen
            SaveSchedule();
            job.RenumberSteps();
            if (CommitJob != null && !CommitJob(job, _jobPos)) return;

            _jobPos = target;
            SyncJob nx = _jobs[target];
            job = nx != null ? nx.Clone() : new SyncJob();
            job.EnsureSteps();

            LoadGeneral();
            LoadStepsList();
            LoadSchedule();
            ShowPage(0);
            lstPages.SelectedIndex = 0;
            UpdateJobNavUi();
            try { txtName.Focus(); txtName.SelectAll(); } catch { }
        }

        /// <summary>Window title and the state of the two job buttons for the current position.</summary>
        private void UpdateJobNavUi()
        {
            Text = "Job — " + (string.IsNullOrEmpty(job.Name) ? "New Job" : job.Name)
                 + (_jobPos >= 0 && JobCount > 1 ? "   (" + (_jobPos + 1) + " / " + JobCount + ")" : "");
            if (_btnJobPrev != null) _btnJobPrev.Enabled = _jobPos > 0;
            if (_btnJobNext != null) _btnJobNext.Enabled = _jobPos >= 0 && _jobPos < JobCount - 1;
        }

        private void BuildUi()
        {
            Text = "Job — " + (string.IsNullOrEmpty(job.Name) ? "New Job" : job.Name)
                 + (_jobPos >= 0 && JobCount > 1 ? "   (" + (_jobPos + 1) + " / " + JobCount + ")" : "");
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(860, 640);
            MinimumSize = new Size(780, 560);
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            MinimizeBox = false;
            ShowInTaskbar = false;

            // left nav
            Panel left = new Panel
            {
                Dock = DockStyle.Left,
                Width = 150,
                BackColor = Color.FromArgb(240, 240, 245),
                Padding = new Padding(4)
            };
            Label navTitle = new Label
            {
                Text = "Select a page",
                Dock = DockStyle.Top,
                Height = 28,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font(Font, FontStyle.Bold),
                Padding = new Padding(6, 0, 0, 0)
            };
            lstPages = new ListBox
            {
                Dock = DockStyle.Fill,
                IntegralHeight = false,
                BorderStyle = BorderStyle.None,
                BackColor = Color.FromArgb(240, 240, 245),
                Font = new Font(Font.FontFamily, 10f),
                ItemHeight = 28
            };
            lstPages.Items.AddRange(new object[] { "  General", "  Steps", "  Schedules" });
            lstPages.SelectedIndexChanged += (s, e) =>
            {
                if (lstPages.SelectedIndex >= 0) ShowPage(lstPages.SelectedIndex);
            };
            left.Controls.Add(lstPages);
            left.Controls.Add(navTitle);

            // bottom buttons
            Panel bottom = new Panel { Dock = DockStyle.Bottom, Height = 48, Padding = new Padding(8) };
            FlowLayoutPanel bf = new FlowLayoutPanel
            {
                Dock = DockStyle.Right,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = false,
                AutoSize = true
            };
            Button btnCancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Width = 90, Height = 28 };
            Button btnOk = new Button { Text = "OK", Width = 90, Height = 28 };
            btnOk.Click += (s, e) =>
            {
                if (!SaveGeneral()) return;
                SaveSchedule();
                job.RenumberSteps();
                DialogResult = DialogResult.OK;
                Close();
            };
            bf.Controls.Add(btnCancel);
            bf.Controls.Add(btnOk);
            bottom.Controls.Add(bf);
            AcceptButton = btnOk;
            CancelButton = btnCancel;

            // Previous / Next job — saves this job and loads the next one into this same window
            if (_jobPos >= 0 && JobCount > 1)
            {
                FlowLayoutPanel jf = new FlowLayoutPanel
                {
                    Dock = DockStyle.Left,
                    FlowDirection = FlowDirection.LeftToRight,
                    WrapContents = false,
                    AutoSize = true
                };
                _btnJobPrev = new Button { Text = "◀ Previous job", Width = 110, Height = 28 };
                _btnJobNext = new Button { Text = "Next job ▶", Width = 110, Height = 28 };
                _btnJobPrev.Enabled = _jobPos > 0;
                _btnJobNext.Enabled = _jobPos < JobCount - 1;
                _btnJobPrev.Click += (s, e) => NavJob(-1);
                _btnJobNext.Click += (s, e) => NavJob(+1);
                jf.Controls.Add(_btnJobPrev);
                jf.Controls.Add(_btnJobNext);
                bottom.Controls.Add(jf);
            }

            panelHost = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12) };

            BuildGeneralPanel();
            BuildStepsPanel();
            BuildSchedPanel();

            Controls.Add(panelHost);
            Controls.Add(bottom);
            Controls.Add(left);
        }

        private void ShowPage(int index)
        {
            panelHost.Controls.Clear();
            if (index == 0) panelHost.Controls.Add(generalPanel);
            else if (index == 1) panelHost.Controls.Add(stepsPanel);
            else panelHost.Controls.Add(schedPanel);
            if (lstPages.SelectedIndex != index) lstPages.SelectedIndex = index;
        }

        private void BuildGeneralPanel()
        {
            generalPanel = new Panel { Dock = DockStyle.Fill };
            TableLayoutPanel t = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2 };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            txtName = new TextBox();
            txtDescription = new TextBox { Multiline = true, Height = 100, ScrollBars = ScrollBars.Vertical };
            chkEnabled = new CheckBox { Text = "Enabled", AutoSize = true, Checked = true };
            chkEnabled.CheckedChanged += (s, e) =>
            {
                UpdateSchedEnabled();
                UpdateSchedSummary();
            };

            int r = 0;
            Action<string, Control> add = (label, c) =>
            {
                t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                t.Controls.Add(new Label { Text = label, AutoSize = true, Margin = new Padding(3, 8, 8, 3) }, 0, r);
                c.Dock = DockStyle.Fill;
                t.Controls.Add(c, 1, r);
                r++;
            };
            add("Name:", txtName);
            add("Description:", txtDescription);
            add("", chkEnabled);

            // Safety options (all default inactive / unchecked)
            // Left column: "Safety:" + small square ? button for help
            FlowLayoutPanel safetyLeft = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0) };
            safetyLeft.Controls.Add(new Label { Text = "Safety:", AutoSize = true, Margin = new Padding(3, 8, 4, 3) });
            btnSafetyHelp = new Button
            {
                Text = "?",
                Width = 22,
                Height = 22,
                FlatStyle = FlatStyle.System,
                Margin = new Padding(2, 5, 0, 0),
                TabStop = false
            };
            btnSafetyHelp.Click += (s, e) =>
            {
                string help =
                    "Confirm before DELETE / TRUNCATE / DROP:\r\n" +
                    "   Shows a confirmation dialog before any destructive statement on the destination.\r\n\r\n" +
                    "Auto sync latest changes:\r\n" +
                    "   Analyzes Source/Dest and pours only newer rows (watermark / delta). Ignores DELETE/TRUNCATE/DROP — does not wipe Dest.\r\n\r\n" +
                    "Also apply field / column changes on Destination:\r\n" +
                    "   Adds missing columns on Dest before syncing.\r\n\r\n" +
                    "Dry run only (analyze, do not write):\r\n" +
                    "   Analyzes and logs only — no data is written.\r\n\r\n" +
                    "Auto-tune resources:\r\n" +
                    "   Picks buffer (RAM/Disk), threads and RAM limit from available resources. Does not add columns.";
                MessageBox.Show(this, help, "Safety options help", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            safetyLeft.Controls.Add(btnSafetyHelp);

            chkConfirmBefore = new CheckBox { Text = "Confirm before DELETE / TRUNCATE / DROP", AutoSize = true, Checked = false };
            chkAutoSyncLatest = new CheckBox { Text = "Auto sync latest changes (ignore DELETE/TRUNCATE/DROP — no wipe)", AutoSize = true, Checked = false };
            chkApplyFieldChanges = new CheckBox { Text = "Also apply field / column changes on Destination", AutoSize = true, Checked = false };
            chkDryRunOnly = new CheckBox { Text = "Dry run only (analyze, do not write)", AutoSize = true, Checked = false };
            chkAutoTune = new CheckBox { Text = "Auto-tune resources (CPU / cache / disk — no new fields)", AutoSize = true, Checked = false };

            FlowLayoutPanel safetyChecks = new FlowLayoutPanel
            {
                AutoSize = true,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                Margin = new Padding(0)
            };
            safetyChecks.Controls.Add(chkConfirmBefore);
            safetyChecks.Controls.Add(chkAutoSyncLatest);
            safetyChecks.Controls.Add(chkApplyFieldChanges);
            safetyChecks.Controls.Add(chkDryRunOnly);
            safetyChecks.Controls.Add(chkAutoTune);

            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(safetyLeft, 0, r);
            t.Controls.Add(safetyChecks, 1, r);
            r++;

            // Recycle / backup for accidental Delete / Update
            chkRecycle = new CheckBox { Text = "Keep deleted/updated rows in recycle table (recoverable)", AutoSize = true, Checked = false };
            txtRecycleSchema = new TextBox { Text = "bakuid", Width = 120 };
            numRecycleHours = new NumericUpDown { Minimum = 0, Maximum = 8760, Value = 24, Width = 80 };
            // Keep this card inside the editor width: the retention control used to be pushed
            // past the right edge, so its label/value were not visible on smaller windows.
            FlowLayoutPanel recycleRow = new FlowLayoutPanel
            {
                AutoSize = true, WrapContents = false, FlowDirection = FlowDirection.TopDown,
                Margin = new Padding(0)
            };
            FlowLayoutPanel recycleTop = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0) };
            recycleTop.Controls.Add(chkRecycle);
            recycleTop.Controls.Add(new Label { Text = "  Schema:", AutoSize = true, Margin = new Padding(12, 6, 4, 0) });
            recycleTop.Controls.Add(txtRecycleSchema);
            FlowLayoutPanel recycleKeep = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0, 3, 0, 0) };
            recycleKeep.Controls.Add(new Label { Text = "Keep (hours, 0=forever):", AutoSize = true, Margin = new Padding(3, 6, 4, 0) });
            recycleKeep.Controls.Add(numRecycleHours);
            recycleRow.Controls.Add(recycleTop);
            recycleRow.Controls.Add(recycleKeep);
            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(new Label { Text = "Recycle:", AutoSize = true, Margin = new Padding(3, 8, 8, 3) }, 0, r);
            t.Controls.Add(recycleRow, 1, r);
            r++;

            // how long ONE statement may run before SQL Server is told to give up (0 = no limit).
            // 300 s used to be fixed in the code: a long INSERT died at 5 minutes with no way to change it.
            numCmdTimeout = new NumericUpDown { Minimum = 0, Maximum = 86400, Value = 0, Width = 90, Increment = 30 };
            FlowLayoutPanel toRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0) };
            toRow.Controls.Add(numCmdTimeout);
            toRow.Controls.Add(new Label
            {
                Text = "0 = no limit. Raise it when a long INSERT / SELECT stops with \"Timeout expired\".",
                AutoSize = true, ForeColor = SystemColors.GrayText, Margin = new Padding(8, 6, 0, 0)
            });
            add("Command timeout (sec):", toRow);

            chkAtomicRefill = new CheckBox
            {
                Text = "Protect refills: \"DELETE FROM t\" + the next \"INSERT INTO t\" run as ONE transaction",
                AutoSize = true, Checked = false
            };
            add("", chkAtomicRefill);
            Label refillTip = new Label
            {
                AutoSize = true, ForeColor = SystemColors.GrayText,
                Text = "   With this on, a failed or timed-out INSERT rolls the DELETE back, so the table is never left empty.\r\n"
                     + "   Turn it off only for very large tables (one transaction = more transaction log).",
                Margin = new Padding(0, 0, 0, 6)
            };
            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(refillTip, 0, r);
            t.SetColumnSpan(refillTip, 2);
            r++;

            Label tip = new Label
            {
                AutoSize = true,
                ForeColor = SystemColors.GrayText,
                Text = "Connections (Source / Destination) are chosen in the main window tabs.\r\n" +
                       "Steps define what this job runs (Transfer or T-SQL).\r\n" +
                       "Auto sync latest changes: analyzes Source/Dest and pours only newer rows (watermark / delta). Ignores DELETE/TRUNCATE/DROP. Does not wipe Dest.\r\n" +
                       "Also apply field changes: adds missing columns on Dest before syncing.\r\n" +
                       "Dry run: analyzes and logs only — no data is written.\r\n" +
                       "Auto-tune: picks buffer (RAM/Disk), threads and RAM limit from available resources. Does not add columns.",
                Margin = new Padding(0, 16, 0, 0)
            };
            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(tip, 0, r);
            t.SetColumnSpan(tip, 2);

            generalPanel.Controls.Add(t);
        }

        private void BuildStepsPanel()
        {
            stepsPanel = new Panel { Dock = DockStyle.Fill };
            Label title = new Label
            {
                Text = "Job step list:",
                Dock = DockStyle.Top,
                Height = 24,
                Font = new Font(Font, FontStyle.Bold)
            };

            lvSteps = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                HideSelection = false,
                GridLines = true,
                CheckBoxes = true,
                AllowDrop = true
            };
            lvSteps.ItemChecked += (s, e) =>
            {
                if (_stepsLoading) return;
                JobStep st = e.Item.Tag as JobStep;
                if (st == null) return;
                st.Enabled = e.Item.Checked;
                if (e.Item.SubItems.Count > 5) e.Item.SubItems[5].Text = st.Enabled ? Lang.T("Yes") : Lang.T("NO (skipped)");
                e.Item.ForeColor = st.Enabled ? SystemColors.ControlText : Color.Gray;
            };
            lvSteps.ItemDrag += (s, e) => { ListViewItem di = e.Item as ListViewItem; if (di == null) return; di.Selected = true; lvSteps.DoDragDrop(di, DragDropEffects.Move); };
            lvSteps.DragEnter += (s, e) => { e.Effect = e.Data.GetDataPresent(typeof(ListViewItem)) ? DragDropEffects.Move : DragDropEffects.None; };
            lvSteps.DragOver += (s, e) => { e.Effect = e.Data.GetDataPresent(typeof(ListViewItem)) ? DragDropEffects.Move : DragDropEffects.None; };
            lvSteps.DragDrop += (s, e) =>
            {
                ListViewItem dragged = e.Data.GetData(typeof(ListViewItem)) as ListViewItem;
                if (dragged == null) return;
                Point pt = lvSteps.PointToClient(new Point(e.X, e.Y));
                ListViewItem target = lvSteps.GetItemAt(5, pt.Y);
                int to = target != null ? target.Index : lvSteps.Items.Count - 1;
                JobStep st = dragged.Tag as JobStep;
                int from = job.Steps.IndexOf(st);
                if (st == null || from < 0 || to < 0 || to == from) return;
                job.Steps.RemoveAt(from);
                job.Steps.Insert(to, st);
                job.RenumberSteps();
                LoadStepsList();
                lvSteps.Items[to].Selected = true;
            };
            lvSteps.Columns.Add("Step", 50);
            lvSteps.Columns.Add("Name", 160);
            lvSteps.Columns.Add("Type", 110);
            lvSteps.Columns.Add("On Success", 120);
            lvSteps.Columns.Add("On Fail", 120);
            lvSteps.Columns.Add("Use", 90);
            lvSteps.DoubleClick += (s, e) => EditSelectedStep();
            ContextMenuStrip scm = new ContextMenuStrip();
            scm.Items.Add("Enable (Use on)", null, (s, e) => SetUseSelected(true));
            scm.Items.Add("Disable (Use off)", null, (s, e) => SetUseSelected(false));
            scm.Items.Add(new ToolStripSeparator());
            scm.Items.Add("Select all", null, (s, e) => SetUseAll(true));
            scm.Items.Add("Select none", null, (s, e) => SetUseAll(false));
            scm.Items.Add(new ToolStripSeparator());
            scm.Items.Add("Move up", null, (s, e) => MoveStep(-1));
            scm.Items.Add("Move down", null, (s, e) => MoveStep(1));
            lvSteps.ContextMenuStrip = scm;
            lvSteps.SelectedIndexChanged += (s, e) =>
            {
                if (numPos != null && lvSteps.SelectedItems.Count > 0)
                    numPos.Value = Math.Min(numPos.Maximum, lvSteps.SelectedItems[0].Index + 1);
            };

            FlowLayoutPanel bar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 76, WrapContents = true };
            Button btnNew = new Button { Text = "New...", Width = 80 };
            Button btnEdit = new Button { Text = "Edit", Width = 70 };
            Button btnDel = new Button { Text = "Delete", Width = 70 };
            Button btnUp = new Button { Text = "↑", Width = 36 };
            Button btnDown = new Button { Text = "↓", Width = 36 };
            Button btnUse = new Button { Text = "Use on/off", Width = 90 };
            btnUse.Click += (s, e) => ToggleUseSelected();
            btnNew.Click += (s, e) =>
            {
                JobStep step = new JobStep();
                step.StepId = job.Steps.Count + 1;
                step.Name = "Step " + step.StepId;
                MiniWaitForm wait = null;
                try
                {
                    wait = MiniWaitForm.ShowWait(this, Lang.Fa ? "در حال باز کردن Step…" : "Opening step…");
                    StepEditForm f = new StepEditForm(step);
                    if (wait != null) { try { wait.Close(); wait.Dispose(); } catch { } wait = null; }
                    using (f)
                    {
                        if (f.ShowDialog(this) == DialogResult.OK)
                        {
                            job.Steps.Add(f.ResultStep);
                            job.RenumberSteps();
                            LoadStepsList();
                        }
                    }
                }
                finally
                {
                    if (wait != null) { try { wait.Close(); wait.Dispose(); } catch { } }
                }
            };
            btnEdit.Click += (s, e) => EditSelectedStep();
            btnDel.Click += (s, e) =>
            {
                if (lvSteps.SelectedItems.Count == 0) return;
                JobStep st = lvSteps.SelectedItems[0].Tag as JobStep;
                if (st == null) return;
                if (MessageBox.Show("Delete step \"" + st.Name + "\"?", "Confirm", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
                job.Steps.Remove(st);
                job.RenumberSteps();
                LoadStepsList();
            };
            btnUp.Click += (s, e) => MoveStep(-1);
            btnDown.Click += (s, e) => MoveStep(1);

            bar.Controls.Add(btnNew);
            bar.Controls.Add(btnEdit);
            bar.Controls.Add(btnDel);
            bar.Controls.Add(btnUse);
            bar.Controls.Add(new Label { Text = "  Move:", AutoSize = true, Margin = new Padding(12, 8, 3, 0) });
            bar.Controls.Add(btnUp);
            bar.Controls.Add(btnDown);
            // Position # is display-only; reorder only with ↑ ↓
            numPos = new NumericUpDown { Minimum = 1, Maximum = 1000, Value = 1, Width = 50, Margin = new Padding(12, 5, 3, 3), ReadOnly = true, Enabled = false };
            Button btnAll = new Button { Text = "Select all", Width = 85 };
            Button btnNone = new Button { Text = "Select none", Width = 90 };
            btnAll.Click += (s, e) => SetUseAll(true);
            btnNone.Click += (s, e) => SetUseAll(false);
            bar.Controls.Add(new Label { Text = "#", AutoSize = true, Margin = new Padding(8, 8, 2, 0) });
            bar.Controls.Add(numPos);
            bar.Controls.Add(btnAll);
            bar.Controls.Add(btnNone);

            stepsPanel.Controls.Add(lvSteps);
            stepsPanel.Controls.Add(bar);
            stepsPanel.Controls.Add(title);
        }

        private void EditSelectedStep()
        {
            if (lvSteps.SelectedItems.Count == 0) return;
            JobStep st = lvSteps.SelectedItems[0].Tag as JobStep;
            if (st == null) return;
            int idx = job.Steps.IndexOf(st);
            if (idx < 0) return;
            EditStepAt(idx);
        }

        /// <summary>Open the step editor. ◀ Previous / Next ▶ inside it walk through the steps of the job
        /// without closing the window - each one is saved into job.Steps as you move on.</summary>
        private void EditStepAt(int idx)
        {
            if (idx < 0 || idx >= job.Steps.Count) return;
            JobStep cur = job.Steps[idx];
            if (cur == null) return;

            MiniWaitForm wait = null;
            try
            {
                wait = MiniWaitForm.ShowWait(this, Lang.Fa ? "در حال باز کردن Step…" : "Opening step…");
                StepEditForm f = new StepEditForm(cur.CloneForEdit(), job.Steps, idx);
                if (wait != null) { try { wait.Close(); wait.Dispose(); } catch { } wait = null; }
                using (f)
                {
                    f.ShowDialog(this);
                    // the dialog writes straight into job.Steps (on OK and on every Previous / Next),
                    // so the list is refreshed either way
                    job.RenumberSteps();
                    LoadStepsList();
                }
            }
            finally
            {
                if (wait != null) { try { wait.Close(); wait.Dispose(); } catch { } }
            }
        }

        private void MoveStep(int delta)
        {
            if (lvSteps.SelectedItems.Count == 0) return;
            JobStep st = lvSteps.SelectedItems[0].Tag as JobStep;
            int idx = job.Steps.IndexOf(st);
            if (idx >= 0) MoveStepTo(idx + delta);
        }

        private void MoveStepTo(int neu)
        {
            if (lvSteps.SelectedItems.Count == 0) return;
            JobStep st = lvSteps.SelectedItems[0].Tag as JobStep;
            int idx = job.Steps.IndexOf(st);
            neu = Math.Max(0, Math.Min(job.Steps.Count - 1, neu));
            if (idx < 0 || neu == idx) return;
            job.Steps.RemoveAt(idx);
            job.Steps.Insert(neu, st);
            job.RenumberSteps();
            LoadStepsList();
            lvSteps.Items[neu].Selected = true;
            lvSteps.EnsureVisible(neu);
        }

        private void ReselectSteps(System.Collections.Generic.List<int> keep)
        {
            foreach (int k in keep) if (k < lvSteps.Items.Count) lvSteps.Items[k].Selected = true;
        }

        private void SetUseSelected(bool v)
        {
            System.Collections.Generic.List<int> keep = new System.Collections.Generic.List<int>();
            foreach (ListViewItem it in lvSteps.SelectedItems)
            {
                JobStep st = it.Tag as JobStep;
                if (st != null) { st.Enabled = v; keep.Add(it.Index); }
            }
            LoadStepsList();
            ReselectSteps(keep);
        }

        private void ToggleUseSelected()
        {
            bool anyOn = false;
            foreach (ListViewItem it in lvSteps.SelectedItems)
            {
                JobStep st = it.Tag as JobStep;
                if (st != null && st.Enabled) anyOn = true;
            }
            SetUseSelected(!anyOn);
        }

        private void SetUseAll(bool v)
        {
            foreach (JobStep st in job.Steps) st.Enabled = v;
            LoadStepsList();
        }

        private void BuildSchedPanel()
        {
            schedPanel = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(12, 10, 12, 10) };

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 1,
                Padding = new Padding(0),
                Margin = new Padding(0)
            };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            int row = 0;
            Action<Control> addRow = (c) =>
            {
                root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                root.Controls.Add(c, 0, row);
                row++;
            };
            Action<string> addHeader = (title) =>
            {
                Label h = new Label
                {
                    Text = title,
                    AutoSize = true,
                    Font = new Font("Segoe UI Semibold", 9f),
                    Margin = new Padding(0, 10, 0, 2),
                    Padding = new Padding(0)
                };
                Panel line = new Panel
                {
                    Height = 1,
                    Dock = DockStyle.Top,
                    BackColor = Color.FromArgb(200, 200, 210),
                    Margin = new Padding(0, 0, 0, 6)
                };
                Panel wrap = new Panel { AutoSize = true, Margin = new Padding(0, 4, 0, 2) };
                // stack header then line
                FlowLayoutPanel box = new FlowLayoutPanel
                {
                    AutoSize = true,
                    FlowDirection = FlowDirection.TopDown,
                    WrapContents = false,
                    Margin = new Padding(0),
                    Padding = new Padding(0)
                };
                box.Controls.Add(h);
                Panel lineHost = new Panel { Height = 1, Width = 640, BackColor = Color.FromArgb(200, 200, 210), Margin = new Padding(0, 2, 0, 6) };
                box.Controls.Add(lineHost);
                addRow(box);
            };

            // ----- Schedule type + Recurs every -----
            TableLayoutPanel top = new TableLayoutPanel
            {
                AutoSize = true,
                ColumnCount = 2,
                Margin = new Padding(0, 0, 0, 4)
            };
            top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
            top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            cbSchedule = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 340, DropDownWidth = 360 };
            cbSchedule.Items.AddRange(new object[]
            {
                "Manual only",
                "Every N minutes",
                "Every N hours",
                "Daily",
                "Weekly",
                "Monthly",
                "Async - every change (Insert/Update/Delete)"
            });
            cbSchedule.SelectedIndex = 0;
            cbSchedule.SelectedIndexChanged += (s, e) => { UpdateSchedEnabled(); UpdateSchedSummary(); };

            numInterval = new NumericUpDown { Minimum = 1, Maximum = 10000, Value = 1, Width = 55 };
            chkAsyncUseSeconds = new CheckBox { Text = "Every", AutoSize = true, Checked = true, Margin = new Padding(0, 4, 6, 0) };
            chkAsyncUseSeconds.CheckedChanged += (s, e) => { UpdateSchedEnabled(); UpdateSchedSummary(); };
            FlowLayoutPanel intervalRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0) };
            intervalRow.Controls.Add(chkAsyncUseSeconds);
            intervalRow.Controls.Add(numInterval);
            intervalRow.Controls.Add(new Label { Text = "  day(s)", AutoSize = true, Margin = new Padding(4, 5, 0, 0), Name = "lblIntervalUnit" });
            numInterval.ValueChanged += (s, e) => UpdateSchedSummary();

            lblInterval = new Label { Text = "Recurs every:", AutoSize = true, Margin = new Padding(0, 6, 8, 0) };
            top.Controls.Add(new Label { Text = "Schedule type:", AutoSize = true, Margin = new Padding(0, 6, 8, 0) }, 0, 0);
            top.Controls.Add(cbSchedule, 1, 0);
            top.Controls.Add(lblInterval, 0, 1);
            top.Controls.Add(intervalRow, 1, 1);
            addRow(top);

            // ----- Frequency (weekly days / monthly) -----
            addHeader("Frequency");

            // Weekly days on one row
            lblWeekDays = new Label { Text = "On days:", AutoSize = true, Margin = new Padding(0, 4, 8, 0) };
            weekDaysPanel = new FlowLayoutPanel
            {
                AutoSize = true,
                WrapContents = true,
                FlowDirection = FlowDirection.LeftToRight,
                Margin = new Padding(0)
            };
            string[] dayNames = new string[] { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
            int[] displayToMask = new int[] { 1, 2, 3, 4, 5, 6, 0 };
            chkWeekDays = new CheckBox[7];
            for (int i = 0; i < 7; i++)
            {
                int maskBit = displayToMask[i];
                chkWeekDays[maskBit] = new CheckBox
                {
                    Text = dayNames[i],
                    AutoSize = true,
                    Margin = new Padding(0, 2, 12, 2),
                    Tag = maskBit
                };
                chkWeekDays[maskBit].CheckedChanged += (s, e) => UpdateSchedSummary();
                weekDaysPanel.Controls.Add(chkWeekDays[maskBit]);
                if (i == 3) weekDaysPanel.SetFlowBreak(chkWeekDays[maskBit], true);   // Mon-Thu on row 1, Fri-Sun on row 2
            }
            FlowLayoutPanel weekBlock = new FlowLayoutPanel
            {
                AutoSize = true,
                WrapContents = true,
                FlowDirection = FlowDirection.LeftToRight,
                Margin = new Padding(0, 0, 0, 4),
                Name = "weekBlock"
            };
            weekBlock.Controls.Add(lblWeekDays);
            weekBlock.Controls.Add(weekDaysPanel);
            addRow(weekBlock);

            // Async-only restriction toggles (so seconds can run freely unless the user opts in)
            chkAsyncRestrictDays = new CheckBox { Text = "Restrict to selected days", AutoSize = true, Margin = new Padding(0, 4, 16, 4) };
            chkAsyncRestrictTime = new CheckBox { Text = "Restrict to time window", AutoSize = true, Margin = new Padding(0, 4, 16, 4) };
            chkAsyncRestrictDays.CheckedChanged += (s, e) => { UpdateSchedEnabled(); UpdateSchedSummary(); };
            chkAsyncRestrictTime.CheckedChanged += (s, e) => { UpdateSchedEnabled(); UpdateSchedSummary(); };
            FlowLayoutPanel asyncRestrictRow = new FlowLayoutPanel
            {
                AutoSize = true,
                WrapContents = false,
                Margin = new Padding(0, 2, 0, 4),
                Name = "asyncRestrictRow"
            };
            asyncRestrictRow.Controls.Add(chkAsyncRestrictDays);
            asyncRestrictRow.Controls.Add(chkAsyncRestrictTime);
            addRow(asyncRestrictRow);

            // Monthly options — radios forced exclusive
            numMonthlyDay = new NumericUpDown { Minimum = 1, Maximum = 31, Value = 1, Width = 48 };
            numEveryMonths = new NumericUpDown { Minimum = 1, Maximum = 12, Value = 1, Width = 48 };
            cbMonthOrdinal = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 75 };
            cbMonthOrdinal.Items.AddRange(new object[] { "first", "second", "third", "fourth", "last" });
            cbMonthOrdinal.SelectedIndex = 0;
            cbMonthWeekday = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 95 };
            cbMonthWeekday.Items.AddRange(new object[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" });
            cbMonthWeekday.SelectedIndex = 1;
            numMonthRelEvery = new NumericUpDown { Minimum = 1, Maximum = 12, Value = 1, Width = 48 };

            rbMonthDay = new RadioButton { Text = "Day", AutoSize = true, Checked = true, Margin = new Padding(0, 3, 4, 2) };
            rbMonthRel = new RadioButton { Text = "The", AutoSize = true, Margin = new Padding(0, 3, 4, 2) };
            rbMonthDay.CheckedChanged += (s, e) =>
            {
                if (rbMonthDay.Checked)
                {
                    if (rbMonthRel != null && rbMonthRel.Checked) rbMonthRel.Checked = false;
                    UpdateMonthlyUi();
                    UpdateSchedSummary();
                }
            };
            rbMonthRel.CheckedChanged += (s, e) =>
            {
                if (rbMonthRel.Checked)
                {
                    if (rbMonthDay != null && rbMonthDay.Checked) rbMonthDay.Checked = false;
                    UpdateMonthlyUi();
                    UpdateSchedSummary();
                }
            };

            monthlyDayRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0, 2, 0, 2) };
            monthlyDayRow.Controls.Add(rbMonthDay);
            monthlyDayRow.Controls.Add(numMonthlyDay);
            monthlyDayRow.Controls.Add(new Label { Text = " of every ", AutoSize = true, Margin = new Padding(2, 5, 2, 0) });
            monthlyDayRow.Controls.Add(numEveryMonths);
            monthlyDayRow.Controls.Add(new Label { Text = " month(s)", AutoSize = true, Margin = new Padding(2, 5, 0, 0) });

            monthlyRelRow = new FlowLayoutPanel { AutoSize = true, WrapContents = true, Margin = new Padding(0, 2, 0, 2) };
            monthlyRelRow.Controls.Add(rbMonthRel);
            monthlyRelRow.Controls.Add(cbMonthOrdinal);
            monthlyRelRow.Controls.Add(cbMonthWeekday);
            monthlyRelRow.Controls.Add(new Label { Text = " of every ", AutoSize = true, Margin = new Padding(2, 5, 2, 0) });
            monthlyRelRow.Controls.Add(numMonthRelEvery);
            monthlyRelRow.Controls.Add(new Label { Text = " month(s)", AutoSize = true, Margin = new Padding(2, 5, 0, 0) });

            numMonthlyDay.ValueChanged += (s, e) => UpdateSchedSummary();
            numEveryMonths.ValueChanged += (s, e) => UpdateSchedSummary();
            numMonthRelEvery.ValueChanged += (s, e) => UpdateSchedSummary();
            cbMonthOrdinal.SelectedIndexChanged += (s, e) => UpdateSchedSummary();
            cbMonthWeekday.SelectedIndexChanged += (s, e) => UpdateSchedSummary();

            addRow(monthlyDayRow);
            addRow(monthlyRelRow);

            // ----- Daily frequency -----
            addHeader("Daily frequency");

            numHour = new NumericUpDown { Minimum = 0, Maximum = 23, Value = 2, Width = 48 };
            numMinute = new NumericUpDown { Minimum = 0, Maximum = 59, Value = 0, Width = 48 };
            numSubHours = new NumericUpDown { Minimum = 1, Maximum = 24, Value = 1, Width = 48 };
            numEndHour = new NumericUpDown { Minimum = 0, Maximum = 23, Value = 23, Width = 48 };
            numEndMinute = new NumericUpDown { Minimum = 0, Maximum = 59, Value = 59, Width = 48 };
            _numStartH = new NumericUpDown { Minimum = 0, Maximum = 23, Value = 2, Width = 48 };
            _numStartM = new NumericUpDown { Minimum = 0, Maximum = 59, Value = 0, Width = 48 };

            rbOnceAt = new RadioButton { Text = "Occurs once at:", AutoSize = true, Checked = true, Margin = new Padding(0, 3, 8, 3) };
            rbEveryHours = new RadioButton { Text = "Occurs every:", AutoSize = true, Margin = new Padding(0, 3, 8, 3) };
            // The two radios live in different rows (different parents), so WinForms does not make them
            // exclusive by itself. Force exactly one of them to be checked.
            rbOnceAt.CheckedChanged += (s, e) =>
            {
                if (_dailyRadioSync) return;
                if (rbOnceAt.Checked)
                {
                    _dailyRadioSync = true;
                    try { rbEveryHours.Checked = false; } finally { _dailyRadioSync = false; }
                }
                else if (!rbEveryHours.Checked)
                {
                    _dailyRadioSync = true;
                    try { rbOnceAt.Checked = true; } finally { _dailyRadioSync = false; }
                }
                UpdateDailyFreqUi(); UpdateSchedSummary();
            };
            rbEveryHours.CheckedChanged += (s, e) =>
            {
                if (_dailyRadioSync) return;
                if (rbEveryHours.Checked)
                {
                    _dailyRadioSync = true;
                    try { rbOnceAt.Checked = false; } finally { _dailyRadioSync = false; }
                }
                else if (!rbOnceAt.Checked)
                {
                    _dailyRadioSync = true;
                    try { rbEveryHours.Checked = true; } finally { _dailyRadioSync = false; }
                }
                UpdateDailyFreqUi(); UpdateSchedSummary();
            };

            numHour.ValueChanged += (s, e) =>
            {
                try { _numStartH.Value = numHour.Value; } catch { }
                UpdateSchedSummary();
            };
            numMinute.ValueChanged += (s, e) =>
            {
                try { _numStartM.Value = numMinute.Value; } catch { }
                UpdateSchedSummary();
            };
            _numStartH.ValueChanged += (s, e) =>
            {
                try { numHour.Value = _numStartH.Value; } catch { }
                UpdateSchedSummary();
            };
            _numStartM.ValueChanged += (s, e) =>
            {
                try { numMinute.Value = _numStartM.Value; } catch { }
                UpdateSchedSummary();
            };
            numSubHours.ValueChanged += (s, e) => UpdateSchedSummary();
            numEndHour.ValueChanged += (s, e) => UpdateSchedSummary();
            numEndMinute.ValueChanged += (s, e) => UpdateSchedSummary();

            FlowLayoutPanel onceRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0, 2, 0, 2) };
            onceRow.Controls.Add(rbOnceAt);
            onceRow.Controls.Add(numHour);
            onceRow.Controls.Add(new Label { Text = " : ", AutoSize = true, Margin = new Padding(2, 5, 2, 0) });
            onceRow.Controls.Add(numMinute);
            onceRow.Controls.Add(new Label { Text = "  (HH:MM)", AutoSize = true, Margin = new Padding(6, 5, 0, 0), ForeColor = SystemColors.GrayText });

            FlowLayoutPanel everyRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0, 2, 0, 2) };
            everyRow.Controls.Add(rbEveryHours);
            everyRow.Controls.Add(numSubHours);
            everyRow.Controls.Add(new Label { Text = " hour(s)", AutoSize = true, Margin = new Padding(4, 5, 10, 0) });
            everyRow.Controls.Add(new Label { Text = "Starting at:", AutoSize = true, Margin = new Padding(4, 5, 4, 0) });
            everyRow.Controls.Add(_numStartH);
            everyRow.Controls.Add(new Label { Text = " : ", AutoSize = true, Margin = new Padding(2, 5, 2, 0) });
            everyRow.Controls.Add(_numStartM);
            everyRow.Controls.Add(new Label { Text = "   Ending at:", AutoSize = true, Margin = new Padding(10, 5, 4, 0) });
            everyRow.Controls.Add(numEndHour);
            everyRow.Controls.Add(new Label { Text = " : ", AutoSize = true, Margin = new Padding(2, 5, 2, 0) });
            everyRow.Controls.Add(numEndMinute);

            oncePanel = onceRow;
            everyPanel = everyRow;
            // keep group refs non-null for enable logic (invisible hosts)
            grpDaily = new GroupBox { Visible = false, Enabled = true };
            grpFreq = new GroupBox { Visible = false, Enabled = true };
            grpDuration = new GroupBox { Visible = false, Enabled = true };

            addRow(onceRow);
            addRow(everyRow);

            // ----- Duration -----
            addHeader("Duration");

            dtSchedStart = new DateTimePicker { Format = DateTimePickerFormat.Short, Width = 130, Value = DateTime.Today };
            dtSchedEnd = new DateTimePicker { Format = DateTimePickerFormat.Short, Width = 130, Value = DateTime.Today.AddYears(1), Enabled = false };
            rbNoEndDate = new RadioButton { Text = "No end date", AutoSize = true, Checked = true, Margin = new Padding(12, 4, 8, 2) };
            rbEndDate = new RadioButton { Text = "End date:", AutoSize = true, Margin = new Padding(0, 4, 6, 2) };
            rbNoEndDate.CheckedChanged += (s, e) =>
            {
                if (rbNoEndDate.Checked) dtSchedEnd.Enabled = false;
                UpdateSchedSummary();
            };
            rbEndDate.CheckedChanged += (s, e) =>
            {
                if (rbEndDate.Checked) dtSchedEnd.Enabled = true;
                UpdateSchedSummary();
            };
            dtSchedStart.ValueChanged += (s, e) => UpdateSchedSummary();
            dtSchedEnd.ValueChanged += (s, e) => UpdateSchedSummary();

            FlowLayoutPanel startRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0, 2, 0, 2) };
            startRow.Controls.Add(new Label { Text = "Start date:", AutoSize = true, Margin = new Padding(0, 5, 8, 0) });
            startRow.Controls.Add(dtSchedStart);

            FlowLayoutPanel endRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0, 2, 0, 2) };
            endRow.Controls.Add(rbEndDate);
            endRow.Controls.Add(dtSchedEnd);
            endRow.Controls.Add(rbNoEndDate);

            addRow(startRow);
            addRow(endRow);

            // ----- Summary -----
            addHeader("Summary");
            lblSchedTip = new Label
            {
                AutoSize = true,
                MaximumSize = new Size(680, 0),
                Margin = new Padding(0, 2, 0, 8),
                ForeColor = SystemColors.ControlText,
                Text = ""
            };
            addRow(lblSchedTip);

            schedPanel.Controls.Add(root);

            try
            {
                if (MinimumSize.Width < 780) MinimumSize = new Size(780, 560);
                if (ClientSize.Width < 820) Size = new Size(860, 640);
            }
            catch { }

            UpdateSchedEnabled();
            UpdateSchedSummary();
        }

        private void UpdateMonthlyUi()
        {
            bool month = cbSchedule != null && cbSchedule.SelectedIndex == 5;
            bool dayMode = rbMonthDay == null || rbMonthDay.Checked;
            if (numMonthlyDay != null) numMonthlyDay.Enabled = month && dayMode;
            if (numEveryMonths != null) numEveryMonths.Enabled = month && dayMode;
            if (cbMonthOrdinal != null) cbMonthOrdinal.Enabled = month && !dayMode;
            if (cbMonthWeekday != null) cbMonthWeekday.Enabled = month && !dayMode;
            if (numMonthRelEvery != null) numMonthRelEvery.Enabled = month && !dayMode;
            if (rbMonthDay != null) rbMonthDay.Enabled = month;
            if (rbMonthRel != null) rbMonthRel.Enabled = month;
        }

        private static void SetScheduleInputsEnabled(Control root, bool enabled)
        {
            if (root == null) return;
            foreach (Control c in root.Controls)
            {
                if (c is CheckBox || c is ComboBox || c is NumericUpDown ||
                    c is DateTimePicker || c is RadioButton)
                    c.Enabled = enabled;
                if (c.HasChildren) SetScheduleInputsEnabled(c, enabled);
            }
        }

        private void UpdateSchedEnabled()
        {
            int i = cbSchedule != null ? cbSchedule.SelectedIndex : 0;
            // 0 Manual, 1 min, 2 hours, 3 Daily, 4 Weekly, 5 Monthly
            bool interval = (i == 1 || i == 2 || i == 3 || i == 4 || i == 6);
            bool isAsync = (i == 6);
            bool dailyFreq = (i == 3 || i == 4 || i == 5 || i == 6);
            bool week = (i == 4 || i == 6);
            bool month = (i == 5);
            bool recurring = (i >= 3 && i <= 5);

            // Show Async restriction toggles only in Async mode
            if (chkAsyncRestrictDays != null) chkAsyncRestrictDays.Visible = isAsync;
            if (chkAsyncRestrictTime != null) chkAsyncRestrictTime.Visible = isAsync;
            if (chkAsyncRestrictDays != null && chkAsyncRestrictDays.Parent != null)
                chkAsyncRestrictDays.Parent.Visible = isAsync;

            // For Async, days/time are only active when the user checks the restrict boxes
            if (isAsync)
            {
                week = chkAsyncRestrictDays != null && chkAsyncRestrictDays.Checked;
                dailyFreq = chkAsyncRestrictTime != null && chkAsyncRestrictTime.Checked;
            }

            // Seconds / interval checkbox (mainly meaningful for Async)
            bool useSeconds = !isAsync || (chkAsyncUseSeconds != null && chkAsyncUseSeconds.Checked);
            if (chkAsyncUseSeconds != null)
            {
                chkAsyncUseSeconds.Visible = isAsync;
                chkAsyncUseSeconds.Enabled = isAsync;
            }
            if (numInterval != null) numInterval.Enabled = interval && useSeconds;
            if (lblInterval != null) lblInterval.Enabled = interval;
            if (numInterval != null && numInterval.Parent != null)
            {
                foreach (Control c in numInterval.Parent.Controls)
                {
                    if (c is Label && c.Name == "lblIntervalUnit")
                    {
                        if (i == 6) c.Text = "  second(s) check";
                        else if (i == 1) c.Text = "  minute(s)";
                        else if (i == 2) c.Text = "  hour(s)";
                        else if (i == 3) c.Text = "  day(s)";
                        else if (i == 4) c.Text = "  week(s)";
                        else c.Text = "  (N)";
                        c.Enabled = interval;
                    }
                }
            }

            // Weekly block
            if (weekDaysPanel != null)
            {
                Control weekParent = weekDaysPanel.Parent;
                if (weekParent != null) weekParent.Visible = week;
                weekDaysPanel.Visible = week;
            }
            if (lblWeekDays != null) { lblWeekDays.Visible = week; lblWeekDays.Enabled = week; }
            if (chkWeekDays != null)
                for (int d = 0; d < 7; d++)
                    if (chkWeekDays[d] != null) { chkWeekDays[d].Enabled = week; chkWeekDays[d].Visible = week; }

            if (monthlyDayRow != null) monthlyDayRow.Visible = month;
            if (monthlyRelRow != null) monthlyRelRow.Visible = month;
            UpdateMonthlyUi();

            // Daily frequency rows
            if (rbOnceAt != null)
            {
                Control p = rbOnceAt.Parent;
                if (p != null) p.Enabled = dailyFreq;
            }
            if (rbEveryHours != null)
            {
                Control p = rbEveryHours.Parent;
                if (p != null) p.Enabled = dailyFreq;
            }
            if (grpDaily != null) grpDaily.Enabled = dailyFreq;
            if (grpFreq != null) grpFreq.Enabled = week || month;
            if (grpDuration != null) grpDuration.Enabled = recurring || i == 1 || i == 2;

            // Duration controls
            if (dtSchedStart != null)
            {
                bool durOn = recurring || i == 1 || i == 2;
                dtSchedStart.Enabled = durOn;
                if (rbEndDate != null) rbEndDate.Enabled = durOn;
                if (rbNoEndDate != null) rbNoEndDate.Enabled = durOn;
                if (dtSchedEnd != null) dtSchedEnd.Enabled = durOn && rbEndDate != null && rbEndDate.Checked;
            }

            UpdateDailyFreqUi();
            // Stop job (disable) must also disable every schedule/Async input. The
            // values remain visible, but their checked state cannot affect anything
            // until the main Enabled checkbox is turned on again.
            if (chkEnabled != null && !chkEnabled.Checked)
                SetScheduleInputsEnabled(schedPanel, false);
        }

        private void UpdateDailyFreqUi()
        {
            bool on = grpDaily != null && grpDaily.Enabled;
            bool once = (rbOnceAt == null) || rbOnceAt.Checked;
            bool every = !once;

            if (rbOnceAt != null) rbOnceAt.Enabled = on;
            if (rbEveryHours != null) rbEveryHours.Enabled = on;

            // Only toggle numeric fields — never disable the row/panel (would lock the radios)
            if (numHour != null) numHour.Enabled = on && once;
            if (numMinute != null) numMinute.Enabled = on && once;

            if (numSubHours != null) numSubHours.Enabled = on && every;
            if (_numStartH != null) _numStartH.Enabled = on && every;
            if (_numStartM != null) _numStartM.Enabled = on && every;
            if (numEndHour != null) numEndHour.Enabled = on && every;
            if (numEndMinute != null) numEndMinute.Enabled = on && every;
        }

        /// <summary>Always Persian: صبح (0-11) or شب (12-23).</summary>
        private static string TimePeriod(int hour)
        {
            hour = ((hour % 24) + 24) % 24;
            return hour < 12 ? "صبح" : "شب";
        }

        private void UpdateSchedSummary()
        {
            if (lblSchedTip == null || cbSchedule == null) return;
            try
            {
                int i = cbSchedule.SelectedIndex;
                if (i <= 0)
                {
                    lblSchedTip.Text = "Manual only — run from the main window or service command.";
                    return;
                }
                if (i == 6)
                {
                    string extra = "";
                    if (chkAsyncRestrictDays != null && chkAsyncRestrictDays.Checked)
                        extra += " | days restricted";
                    if (chkAsyncRestrictTime != null && chkAsyncRestrictTime.Checked)
                        extra += " | time window on";
                    string secPart = (chkAsyncUseSeconds != null && chkAsyncUseSeconds.Checked)
                        ? "every " + (int)numInterval.Value + " second(s)"
                        : "on normal scheduler poll";
                    lblSchedTip.Text = "Async: checks " + secPart + " for INSERT / UPDATE / DELETE." + extra;
                    return;
                }
                if (i == 1)
                {
                    lblSchedTip.Text = "Occurs every " + (int)numInterval.Value + " minute(s).";
                    return;
                }
                if (i == 2)
                {
                    lblSchedTip.Text = "Occurs every " + (int)numInterval.Value + " hour(s).";
                    return;
                }

                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                if (i == 3)
                    sb.Append("Occurs every ").Append((int)numInterval.Value).Append(" day(s)");
                else if (i == 4)
                {
                    sb.Append("Occurs every ").Append((int)numInterval.Value).Append(" week(s) on ");
                    string[] names = new string[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
                    bool first = true;
                    for (int d = 0; d < 7; d++)
                    {
                        if (chkWeekDays != null && chkWeekDays[d] != null && chkWeekDays[d].Checked)
                        {
                            if (!first) sb.Append(", ");
                            sb.Append(names[d]);
                            first = false;
                        }
                    }
                    if (first) sb.Append("(no day selected)");
                }
                else if (i == 5)
                {
                    if (rbMonthRel != null && rbMonthRel.Checked)
                    {
                        string ord = cbMonthOrdinal != null && cbMonthOrdinal.SelectedItem != null
                            ? cbMonthOrdinal.SelectedItem.ToString() : "first";
                        string wd = cbMonthWeekday != null && cbMonthWeekday.SelectedItem != null
                            ? cbMonthWeekday.SelectedItem.ToString() : "Monday";
                        int every = numMonthRelEvery != null ? (int)numMonthRelEvery.Value : 1;
                        sb.Append("Occurs the ").Append(ord).Append(" ").Append(wd)
                          .Append(" of every ").Append(every).Append(" month(s)");
                    }
                    else
                    {
                        sb.Append("Occurs every month on day ").Append((int)numMonthlyDay.Value);
                        if (numEveryMonths != null && (int)numEveryMonths.Value > 1)
                            sb.Append(" of every ").Append((int)numEveryMonths.Value).Append(" month(s)");
                    }
                }

                bool everyH = rbEveryHours != null && rbEveryHours.Checked;
                int sh = (int)numHour.Value, sm = (int)numMinute.Value;
                string period = TimePeriod(sh);
                if (everyH)
                {
                    int eh = (int)numEndHour.Value;
                    sb.Append(" every ").Append((int)numSubHours.Value).Append(" hour(s) between ")
                      .Append(sh.ToString("00")).Append(":").Append(sm.ToString("00")).Append(" ").Append(period)
                      .Append(" and ")
                      .Append(eh.ToString("00")).Append(":").Append(((int)numEndMinute.Value).ToString("00")).Append(" ").Append(TimePeriod(eh));
                }
                else
                {
                    sb.Append(" at ").Append(sh.ToString("00")).Append(":").Append(sm.ToString("00")).Append(" ").Append(period);
                }

                if (dtSchedStart != null)
                    sb.Append(". Schedule will be used starting on ").Append(dtSchedStart.Value.ToString("yyyy/MM/dd"));
                if (rbEndDate != null && rbEndDate.Checked && dtSchedEnd != null)
                    sb.Append(" until ").Append(dtSchedEnd.Value.ToString("yyyy/MM/dd"));
                sb.Append(".");
                lblSchedTip.Text = sb.ToString();
            }
            catch
            {
                lblSchedTip.Text = "";
            }
        }

        private void LoadSchedule()
        {
            int si = (int)job.Schedule;
            if (si < 0) si = 0;
            if (si > 6) si = 0;
            cbSchedule.SelectedIndex = si;
            numInterval.Value = Math.Max(1, Math.Min(10000, job.IntervalValue < 1 ? 1 : job.IntervalValue));
            numHour.Value = Math.Max(0, Math.Min(23, job.DailyHour));
            numMinute.Value = Math.Max(0, Math.Min(59, job.DailyMinute));
            numMonthlyDay.Value = Math.Max(1, Math.Min(31, job.MonthlyDay < 1 ? 1 : job.MonthlyDay));
            if (rbOnceAt != null && rbEveryHours != null)
            {
                if (job.DailyFreq == DailyFreqKind.EveryNHours) rbEveryHours.Checked = true;
                else rbOnceAt.Checked = true;
            }
            if (numSubHours != null) numSubHours.Value = Math.Max(1, Math.Min(24, job.SubIntervalHours < 1 ? 1 : job.SubIntervalHours));
            if (numEndHour != null) numEndHour.Value = Math.Max(0, Math.Min(23, job.EndHour));
            if (numEndMinute != null) numEndMinute.Value = Math.Max(0, Math.Min(59, job.EndMinute));
            if (_numStartH != null) _numStartH.Value = Math.Max(0, Math.Min(23, job.DailyHour));
            if (_numStartM != null) _numStartM.Value = Math.Max(0, Math.Min(59, job.DailyMinute));

            // Monthly mode
            if (job.MonthlyMode == MonthlyModeKind.Relative)
            {
                if (rbMonthRel != null) rbMonthRel.Checked = true;
            }
            else
            {
                if (rbMonthDay != null) rbMonthDay.Checked = true;
            }
            int months = job.IntervalValue >= 1 ? job.IntervalValue : 1;
            if (numEveryMonths != null) numEveryMonths.Value = Math.Max(1, Math.Min(12, months));
            if (numMonthRelEvery != null) numMonthRelEvery.Value = Math.Max(1, Math.Min(12, months));
            if (cbMonthOrdinal != null)
            {
                int o = job.MonthlyRelativeOrdinal;
                if (o < 1 || o > 5) o = 1;
                cbMonthOrdinal.SelectedIndex = o - 1;
            }
            if (cbMonthWeekday != null)
            {
                int w = job.MonthlyRelativeWeekday;
                if (w < 0 || w > 6) w = 1;
                cbMonthWeekday.SelectedIndex = w;
            }

            int mask = job.EffectiveWeekDaysMask();
            for (int d = 0; d < 7; d++)
                if (chkWeekDays[d] != null)
                    chkWeekDays[d].Checked = (mask & (1 << d)) != 0;

            // Duration
            if (chkAsyncUseSeconds != null) chkAsyncUseSeconds.Checked = job.AsyncUseSeconds;
            if (chkAsyncRestrictDays != null) chkAsyncRestrictDays.Checked = job.AsyncRestrictDays;
            if (chkAsyncRestrictTime != null) chkAsyncRestrictTime.Checked = job.AsyncRestrictTime;

            if (dtSchedStart != null)
                dtSchedStart.Value = job.ScheduleStartDate.HasValue ? job.ScheduleStartDate.Value.Date : DateTime.Today;
            if (job.ScheduleNoEndDate || !job.ScheduleEndDate.HasValue)
            {
                if (rbNoEndDate != null) rbNoEndDate.Checked = true;
                if (dtSchedEnd != null) { dtSchedEnd.Value = DateTime.Today.AddYears(1); dtSchedEnd.Enabled = false; }
            }
            else
            {
                if (rbEndDate != null) rbEndDate.Checked = true;
                if (dtSchedEnd != null) { dtSchedEnd.Value = job.ScheduleEndDate.Value.Date; dtSchedEnd.Enabled = true; }
            }

            UpdateSchedEnabled();
            UpdateSchedSummary();
        }

        private void SaveSchedule()
        {
            job.Schedule = (ScheduleKind)cbSchedule.SelectedIndex;
            job.DailyHour = (int)numHour.Value;
            job.DailyMinute = (int)numMinute.Value;
            job.MonthlyDay = (int)numMonthlyDay.Value;
            job.DailyFreq = (rbEveryHours != null && rbEveryHours.Checked) ? DailyFreqKind.EveryNHours : DailyFreqKind.OnceAt;
            job.SubIntervalHours = numSubHours != null ? (int)numSubHours.Value : 1;
            job.EndHour = numEndHour != null ? (int)numEndHour.Value : 23;
            job.EndMinute = numEndMinute != null ? (int)numEndMinute.Value : 59;

            if (job.Schedule == ScheduleKind.Monthly)
            {
                job.MonthlyMode = (rbMonthRel != null && rbMonthRel.Checked)
                    ? MonthlyModeKind.Relative : MonthlyModeKind.DayOfMonth;
                if (job.MonthlyMode == MonthlyModeKind.Relative)
                {
                    job.IntervalValue = numMonthRelEvery != null ? (int)numMonthRelEvery.Value : 1;
                    job.MonthlyRelativeOrdinal = cbMonthOrdinal != null ? cbMonthOrdinal.SelectedIndex + 1 : 1;
                    job.MonthlyRelativeWeekday = cbMonthWeekday != null ? cbMonthWeekday.SelectedIndex : 1;
                }
                else
                {
                    job.IntervalValue = numEveryMonths != null ? (int)numEveryMonths.Value : 1;
                }
            }
            else
                job.IntervalValue = (int)numInterval.Value;

            int mask = 0;
            int first = -1;
            for (int d = 0; d < 7; d++)
            {
                if (chkWeekDays[d] != null && chkWeekDays[d].Checked)
                {
                    mask |= (1 << d);
                    if (first < 0) first = d;
                }
            }
            if (mask == 0 && job.Schedule == ScheduleKind.Weekly)
            {
                mask = 1 << 1;
                first = 1;
                if (chkWeekDays[1] != null) chkWeekDays[1].Checked = true;
            }
            job.WeekDaysMask = mask;
            job.WeekDay = first >= 0 ? first : 1;

            if (dtSchedStart != null) job.ScheduleStartDate = dtSchedStart.Value.Date;
            job.ScheduleNoEndDate = rbNoEndDate == null || rbNoEndDate.Checked;
            if (!job.ScheduleNoEndDate && dtSchedEnd != null)
                job.ScheduleEndDate = dtSchedEnd.Value.Date;
            else
                job.ScheduleEndDate = null;

            job.AsyncUseSeconds = chkAsyncUseSeconds == null || chkAsyncUseSeconds.Checked;
            job.AsyncRestrictDays = chkAsyncRestrictDays != null && chkAsyncRestrictDays.Checked;
            job.AsyncRestrictTime = chkAsyncRestrictTime != null && chkAsyncRestrictTime.Checked;

            // For Async always arm the next check strictly in the future by IntervalValue seconds
            if (job.Schedule == ScheduleKind.RealtimeAsync)
            {
                int sec = job.IntervalValue < 1 ? 1 : job.IntervalValue;
                job.NextRunUtc = DateTime.UtcNow.AddSeconds(sec);
            }
            else
                job.NextRunUtc = JobScheduler.ComputeNextRunUtc(job, DateTime.UtcNow);
        }

        private void LoadGeneral()
        {
            txtName.Text = job.Name ?? "";
            txtDescription.Text = job.Description ?? "";
            chkEnabled.Checked = job.Enabled;
            if (numCmdTimeout != null)
                numCmdTimeout.Value = Math.Max(0, Math.Min(86400, job.CommandTimeoutSec < 0 ? 0 : job.CommandTimeoutSec));
            if (chkAtomicRefill != null) chkAtomicRefill.Checked = job.AtomicRefill;
            if (chkConfirmBefore != null) chkConfirmBefore.Checked = job.ConfirmBeforeDangerous;
            if (chkAutoSyncLatest != null) chkAutoSyncLatest.Checked = job.AutoSyncLatest;
            if (chkApplyFieldChanges != null) chkApplyFieldChanges.Checked = job.ApplyFieldChanges;
            if (chkDryRunOnly != null) chkDryRunOnly.Checked = job.DryRunOnly;
            if (chkAutoTune != null) chkAutoTune.Checked = job.AutoTuneResources;
            if (chkRecycle != null) chkRecycle.Checked = job.EnableRecycleBin;
            if (txtRecycleSchema != null) txtRecycleSchema.Text = string.IsNullOrWhiteSpace(job.RecycleSchema) ? "bakuid" : job.RecycleSchema;
            if (numRecycleHours != null) numRecycleHours.Value = Math.Max(0, Math.Min(8760, job.RecycleRetentionHours));
        }

        private bool SaveGeneral()
        {
            string n = (txtName.Text ?? "").Trim();
            if (n.Length == 0)
            {
                MessageBox.Show("Job name is required.");
                ShowPage(0);
                return false;
            }
            job.Name = n;
            job.Description = txtDescription.Text ?? "";
            job.Enabled = chkEnabled.Checked;
            if (numCmdTimeout != null) job.CommandTimeoutSec = (int)numCmdTimeout.Value;
            if (chkAtomicRefill != null) job.AtomicRefill = chkAtomicRefill.Checked;
            if (chkConfirmBefore != null) job.ConfirmBeforeDangerous = chkConfirmBefore.Checked;
            if (chkAutoSyncLatest != null) job.AutoSyncLatest = chkAutoSyncLatest.Checked;
            if (chkApplyFieldChanges != null) job.ApplyFieldChanges = chkApplyFieldChanges.Checked;
            if (chkDryRunOnly != null) job.DryRunOnly = chkDryRunOnly.Checked;
            if (chkAutoTune != null) job.AutoTuneResources = chkAutoTune.Checked;
            if (chkRecycle != null) job.EnableRecycleBin = chkRecycle.Checked;
            if (txtRecycleSchema != null)
            {
                string sch = (txtRecycleSchema.Text ?? "").Trim();
                job.RecycleSchema = sch.Length == 0 ? "bakuid" : sch;
            }
            if (numRecycleHours != null) job.RecycleRetentionHours = (int)numRecycleHours.Value;
            return true;
        }

        private void LoadStepsList()
        {
            _stepsLoading = true;
            lvSteps.Items.Clear();
            foreach (JobStep s in job.Steps)
            {
                ListViewItem it = new ListViewItem(s.StepId.ToString());
                it.SubItems.Add(s.Name ?? "");
                it.SubItems.Add(Lang.T(s.TypeText()));
                it.SubItems.Add(Lang.T(JobStep.ActionText(s.OnSuccess)));
                it.SubItems.Add(Lang.T(JobStep.ActionText(s.OnFailure)));
                it.SubItems.Add(s.Enabled ? Lang.T("Yes") : Lang.T("NO (skipped)"));
                if (!s.Enabled) it.ForeColor = Color.Gray;
                it.Checked = s.Enabled;
                it.Tag = s;
                lvSteps.Items.Add(it);
            }
            _stepsLoading = false;
        }


    }

    // ---- Step editor dialog ----
    public class StepEditForm : Form
    {
        private JobStep step;
        private TextBox txtName, txtSql, txtDeleteWhere, txtKeyColumns, txtIncrementalCol;
        private RadioButton rbKeyIdxNonclustered, rbKeyIdxUniqueNc, rbKeyIdxClusteredPk;
        private CheckBox chkChangeTracking;
        private CheckBox chkCdc;
        private CheckBox chkDeltaRv;
        private CheckBox chkDeltaCol;
        private CheckBox chkDeltaHash;
        private ComboBox cbDeltaMethod; // kept for load/save compatibility, hidden
        private ComboBox txtSrcTable, txtDstTable;      // drop-down of the tables of the Source / Dest database (can also be typed)
        private string _srcTableTyped = "";   // last known text (survives empty Items / WinForms Text bug)
        private string _dstTableTyped = "";
        private AppConfig _cfg;
        private int _loadSeq;
        private ComboBox cbType, cbDatabase, cbMode, cbOnSuccess, cbOnFail;
        private CheckBox chkWriteMode;      // off = Write mode locked on "Append (INSERT only)"
        private System.Collections.Generic.List<ConnectionProfile> _connList;
        private NumericUpDown numBatch, numRetry, numRetryMin, numThreads, numDelay;
        private CheckBox chkContinueOnErr;
        private NumericUpDown numSourceThreads;
        private CheckBox chkDestMT, chkSrcMT;
        private ComboBox cbIdxMode;
        private NumericUpDown numIdxDays;
        private Label lblIdxLast;
        private ComboBox cbPriority, cbBuffer;
        private RadioButton chkBufAuto, chkBufRam, chkBufStream, chkBufDisk;
        private CheckBox chkCacheLiteDb, chkCacheLevelDb, chkCacheFaster;
        private NumericUpDown numRamLimit;
        private Panel transferPanel;

        // Web API fields
        private TextBox txtApiUrl, txtApiToken, txtApiUser, txtApiPass, txtApiHeaders, txtApiBody, txtApiAuthUrl, txtApiKeyHeader;
        private TextBox txtApiPath, txtPageParam, txtPageSizeParam;
        private ComboBox cbApiMethod, cbApiAuth;
        private NumericUpDown numPageSize, numMaxPages;
        private CheckBox chkApiIgnoreCert;
        private TableLayoutPanel apiPanel;
        private Label lblApi;
        private bool _uiReady;

        // ---- Previous / Next between the steps of the job (like SSMS) ----
        // The window is NOT closed: the step on screen is saved and the next one is loaded into the
        // same dialog, so moving through the steps of a job never sends you back to the job window.
        private System.Collections.Generic.List<JobStep> _steps;  // the live step list of the job (null = single step)
        private int _stepPos = -1;      // 0-based position of this step in that list (-1 = brand new step)
        private Button _btnPrev, _btnNext;
        private bool _shownHooked;      // Shown handler must be attached only once, not on every LoadData

        public StepEditForm(JobStep step) : this(step, null, -1) { }

        public StepEditForm(JobStep step, System.Collections.Generic.List<JobStep> steps, int pos)
        {
            this.step = step ?? new JobStep();
            _steps = steps;
            _stepPos = pos;
            BuildUi();
            LoadData();
            Theme.Apply(this);
            CompactSqlButtons();
        }

        public JobStep ResultStep { get { return step; } }

        private int StepCount { get { return _steps != null ? _steps.Count : 0; } }

        /// <summary>Write the step on screen back into the job's list.</summary>
        private void CommitStep()
        {
            if (_steps != null && _stepPos >= 0 && _stepPos < _steps.Count) _steps[_stepPos] = step;
        }

        /// <summary>Save this step and load the previous / next one into the SAME window.</summary>
        private void NavTo(int dir)
        {
            if (_steps == null || _stepPos < 0) return;
            int target = _stepPos + dir;
            if (target < 0 || target >= _steps.Count) return;
            if (!SaveData()) return;      // a wrong field keeps the step on screen, same as OK

            CommitStep();
            _stepPos = target;
            JobStep nx = _steps[target];
            step = nx != null ? nx.CloneForEdit() : new JobStep();

            _uiReady = false;
            LoadData();                   // fills every control from the new step
            UpdateNavUi();
            try { LoadTableLists(); } catch { }
            try { if (txtName != null) { txtName.Focus(); txtName.SelectAll(); } } catch { }
        }

        /// <summary>Title and the enabled state of the two nav buttons for the current position.</summary>
        private void UpdateNavUi()
        {
            Text = "Job Step — " + (step.Name ?? "New")
                 + (_stepPos >= 0 && StepCount > 1 ? "   (" + (_stepPos + 1) + " / " + StepCount + ")" : "");
            if (_btnPrev != null) _btnPrev.Enabled = _stepPos > 0;
            if (_btnNext != null) _btnNext.Enabled = _stepPos >= 0 && _stepPos < StepCount - 1;
        }

        private void BuildUi()
        {
            Text = "Job Step — " + (step.Name ?? "New")
                 + (_stepPos >= 0 && StepCount > 1 ? "   (" + (_stepPos + 1) + " / " + StepCount + ")" : "");
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterParent;
            // never taller than the screen, otherwise the OK / Previous / Next row falls below the taskbar
            int wantH = 760;
            try
            {
                Rectangle wa = Screen.PrimaryScreen.WorkingArea;
                if (wantH > wa.Height - 30) wantH = Math.Max(520, wa.Height - 30);
            }
            catch { }
            Size = new Size(760, wantH);
            MinimumSize = new Size(640, 520);
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            MinimizeBox = false;
            ShowInTaskbar = false;

            Panel bottom = new Panel { Dock = DockStyle.Bottom, Height = 56, Padding = new Padding(10, 8, 10, 8) };
            FlowLayoutPanel bf = new FlowLayoutPanel
            {
                Dock = DockStyle.Right,
                FlowDirection = FlowDirection.RightToLeft,
                AutoSize = true,
                WrapContents = false
            };
            Button btnCancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Width = 100, Height = 32 };
            Button btnOk = new Button { Text = "OK", Width = 100, Height = 32 };
            btnOk.Click += (s, e) =>
            {
                if (!SaveData()) return;
                CommitStep();
                DialogResult = DialogResult.OK;
                Close();
            };
            bf.Controls.Add(btnCancel);
            bf.Controls.Add(btnOk);
            bottom.Controls.Add(bf);
            AcceptButton = btnOk;
            CancelButton = btnCancel;

            // Previous / Next — save this step and load the one before / after it into this same window
            if (_stepPos >= 0 && StepCount > 1)
            {
                FlowLayoutPanel nf = new FlowLayoutPanel
                {
                    Dock = DockStyle.Left,
                    FlowDirection = FlowDirection.LeftToRight,
                    AutoSize = true,
                    WrapContents = false
                };
                _btnPrev = new Button { Text = "◀ Previous", Width = 96, Height = 32 };
                _btnNext = new Button { Text = "Next ▶", Width = 96, Height = 32 };
                _btnPrev.Enabled = _stepPos > 0;
                _btnNext.Enabled = _stepPos < StepCount - 1;
                _btnPrev.Click += (s, e) => NavTo(-1);
                _btnNext.Click += (s, e) => NavTo(+1);
                nf.Controls.Add(_btnPrev);
                nf.Controls.Add(_btnNext);
                bottom.Controls.Add(nf);
            }

            Panel body = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(12) };
            TableLayoutPanel t = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2 };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            int r = 0;
            Action<string, Control> add = (label, c) =>
            {
                t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                t.Controls.Add(new Label { Text = label, AutoSize = true, Margin = new Padding(3, 8, 8, 3) }, 0, r);
                c.Dock = DockStyle.Fill;
                c.Margin = new Padding(3, 4, 3, 4);
                t.Controls.Add(c, 1, r);
                r++;
            };

            txtName = new TextBox();
            cbType = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cbType.Items.AddRange(new object[] { "Transfer (Source → Dest)", "T-SQL on Source", "T-SQL on Destination", "Web API → Destination" });
            cbType.SelectedIndex = 0;
            cbType.SelectedIndexChanged += (s, e) => UpdateTypeUi();

            txtSql = new TextBox
            {
                Multiline = true,
                Height = 160,
                ScrollBars = ScrollBars.Both,
                Font = new Font("Consolas", 10f),
                WordWrap = false,
                AcceptsReturn = true,
                AcceptsTab = true,
                MaxLength = int.MaxValue
            };

            // transfer fields
            transferPanel = new Panel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Dock = DockStyle.Fill };
            TableLayoutPanel tt = new TableLayoutPanel { Dock = DockStyle.Top, ColumnCount = 2, AutoSize = true };
            tt.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160));
            tt.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            txtSrcTable = NewTableCombo();
            txtDstTable = NewTableCombo();
            // Keep last successfully-read text so SaveData still works when Items is empty (WinForms bug)
            EventHandler captureSrc = (s, e) =>
            {
                try
                {
                    string captured = SafeComboText(txtSrcTable);
                    if (!string.IsNullOrWhiteSpace(captured)) _srcTableTyped = captured;
                }
                catch { }
            };
            EventHandler captureDst = (s, e) =>
            {
                try
                {
                    string captured = SafeComboText(txtDstTable);
                    if (!string.IsNullOrWhiteSpace(captured)) _dstTableTyped = captured;
                }
                catch { }
            };
            txtSrcTable.TextChanged += captureSrc;
            txtDstTable.TextChanged += captureDst;
            txtSrcTable.Leave += captureSrc;
            txtDstTable.Leave += captureDst;
            txtSrcTable.TextUpdate += captureSrc;
            txtDstTable.TextUpdate += captureDst;
            txtDstTable.BackColor = Color.FromArgb(232, 242, 255);
            txtDstTable.ForeColor = Color.FromArgb(20, 55, 110);
            txtDstTable.Font = new Font("Segoe UI Semibold", 9.5f);
            cbMode = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cbMode.SelectedIndexChanged += (s, e) => UpdateTypeUi();
            cbMode.Items.AddRange(new object[] {
                "Append (INSERT only)",
                "Truncate + INSERT (full reload)",
                "DELETE + INSERT",
                "Merge UPSERT (INSERT+UPDATE)",
                "Sync changes AUTO (INSERT+UPDATE+DELETE)",
                "Drop into (DROP table + INSERT)"
            });
            cbMode.SelectedIndex = 0;
            txtDeleteWhere = new TextBox();
            txtKeyColumns = new TextBox();
            txtIncrementalCol = new TextBox();
            numBatch = new NumericUpDown { Minimum = 0, Maximum = 1000000, Value = 500, Width = 90 };
            int tr = 0;
            Action<string, Control> addT = (label, c) =>
            {
                tt.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                Label lb = new Label
                {
                    Text = label,
                    AutoSize = false,
                    Dock = DockStyle.Fill,
                    TextAlign = ContentAlignment.MiddleLeft,
                    Margin = new Padding(0, 4, 4, 0),
                    AutoEllipsis = false
                };
                tt.Controls.Add(lb, 0, tr);
                c.Dock = DockStyle.Fill;
                tt.Controls.Add(c, 1, tr);
                tr++;
            };
            addT("Source table", txtSrcTable);
            Panel destWrap = new Panel { Height = 28, MinimumSize = new Size(100, 28) };
            Button btnNewDest = new Button { Text = "New…", Width = 58, Dock = DockStyle.Right };
            Button btnSameSrc = new Button { Text = "← Source", Width = 72, Dock = DockStyle.Right };
            txtDstTable.Dock = DockStyle.Fill;
            btnNewDest.Click += (s, e) =>
            {
                string name = PromptTableName(SafeComboText(txtDstTable));
                if (string.IsNullOrWhiteSpace(name) && !string.IsNullOrWhiteSpace(_dstTableTyped))
                    name = PromptTableName(_dstTableTyped);
                if (!string.IsNullOrWhiteSpace(name))
                {
                    _dstTableTyped = name.Trim();
                    SafeSetComboText(txtDstTable, _dstTableTyped);
                }
            };
            btnSameSrc.Click += (s, e) =>
            {
                string srcName = SafeComboText(txtSrcTable);
                if (string.IsNullOrWhiteSpace(srcName)) srcName = _srcTableTyped;
                if (string.IsNullOrWhiteSpace(srcName))
                {
                    MessageBox.Show(Lang.Fa
                        ? "اول Source table را انتخاب یا تایپ کنید."
                        : "Set Source table first.", "Dest table");
                    return;
                }
                _dstTableTyped = srcName.Trim();
                SafeSetComboText(txtDstTable, _dstTableTyped);
            };
            try
            {
                var tipSame = new ToolTip();
                tipSame.SetToolTip(btnSameSrc, Lang.Fa
                    ? "نام Dest را برابر Source بگذار (مثلاً dbo.department_attribute_map)"
                    : "Copy Source table name into Dest table");
            }
            catch { }
            destWrap.Controls.Add(txtDstTable);
            destWrap.Controls.Add(btnSameSrc);
            destWrap.Controls.Add(btnNewDest);
            addT("Dest table *", destWrap);

            // Write mode is OFF by default - tick the box to change it, otherwise it stays
            // "Append (INSERT only)" and the drop-down is greyed out.
            Panel modeWrap = new Panel { Height = 26, MinimumSize = new Size(100, 26) };
            chkWriteMode = new CheckBox
            {
                Text = "",
                Width = 20,
                Dock = DockStyle.Left,
                Margin = new Padding(0),
                Padding = new Padding(0)
            };
            chkWriteMode.CheckedChanged += (s, e) =>
            {
                // unticking puts it back to "Append (INSERT only)" so the greyed-out box shows what will run
                if (_uiReady && !chkWriteMode.Checked && cbMode != null) cbMode.SelectedIndex = 0;
                UpdateTypeUi();
            };
            cbMode.Dock = DockStyle.Fill;
            modeWrap.Controls.Add(cbMode);
            modeWrap.Controls.Add(chkWriteMode);
            try
            {
                ToolTip ttMode = new ToolTip();
                ttMode.SetToolTip(chkWriteMode, Lang.Fa
                    ? "برای تغییر Write mode تیک بزنید. بدون تیک: Append (فقط INSERT)"
                    : "Tick to change the Write mode. Unticked = Append (INSERT only).");
            }
            catch { }
            addT("Write mode", modeWrap);
            addT("DELETE WHERE", txtDeleteWhere);
            addT("Key columns", txtKeyColumns);
            // One radio group — each option is a complete index kind
            FlowLayoutPanel keyIdxRow = new FlowLayoutPanel
            {
                AutoSize = true,
                WrapContents = true,
                FlowDirection = FlowDirection.LeftToRight,
                Margin = new Padding(0),
                Padding = new Padding(0)
            };
            rbKeyIdxNonclustered = new RadioButton
            {
                Text = "Nonclustered",
                AutoSize = true,
                Checked = true,
                Margin = new Padding(0, 1, 8, 1)
            };
            rbKeyIdxUniqueNc = new RadioButton
            {
                Text = "Unique",
                AutoSize = true,
                Margin = new Padding(0, 1, 8, 1)
            };
            rbKeyIdxClusteredPk = new RadioButton
            {
                Text = Lang.Fa ? "Clustered+Unique (PK)" : "Clustered+Unique (PK)",
                AutoSize = true,
                Margin = new Padding(0, 1, 4, 1)
            };
            keyIdxRow.Controls.Add(rbKeyIdxNonclustered);
            keyIdxRow.Controls.Add(rbKeyIdxUniqueNc);
            keyIdxRow.Controls.Add(rbKeyIdxClusteredPk);
            try
            {
                ToolTip tipK = new ToolTip();
                tipK.SetToolTip(rbKeyIdxNonclustered, Lang.Fa
                    ? "CREATE NONCLUSTERED INDEX — تکرار مجاز"
                    : "CREATE NONCLUSTERED INDEX — duplicates allowed");
                tipK.SetToolTip(rbKeyIdxUniqueNc, Lang.Fa
                    ? "CREATE UNIQUE NONCLUSTERED INDEX — بدون تکرار"
                    : "CREATE UNIQUE NONCLUSTERED INDEX");
                tipK.SetToolTip(rbKeyIdxClusteredPk, Lang.Fa
                    ? "CREATE UNIQUE CLUSTERED INDEX — شبیه Primary Key"
                    : "CREATE UNIQUE CLUSTERED INDEX — PK-style");
            }
            catch { }
            addT(Lang.Fa ? "نوع ایندکس Key" : "Key index type", keyIdxRow);
            addT("Last changes col", txtIncrementalCol);
            chkChangeTracking = new CheckBox {
                Text = "Change Tracking (SQL Server) — delta without date column",
                AutoSize = true
            };
            addT("", WithWarnIcon(chkChangeTracking, false));
            chkCdc = new CheckBox {
                Text = "CDC (Change Data Capture) — net INSERT/UPDATE/DELETE when enabled on source",
                AutoSize = true
            };
            addT("", WithWarnIcon(chkCdc, true));
            // Smart Delta methods as independent enable/disable checkboxes (can combine)
            FlowLayoutPanel deltaFlags = new FlowLayoutPanel
            {
                AutoSize = true,
                WrapContents = true,
                FlowDirection = FlowDirection.LeftToRight,
                Margin = new Padding(0)
            };
            chkDeltaRv = new CheckBox
            {
                Text = "RV (rowversion)",
                AutoSize = true,
                Checked = false,
                Margin = new Padding(0, 2, 12, 2)
            };
            chkDeltaCol = new CheckBox
            {
                Text = "COL (incremental col)",
                AutoSize = true,
                Checked = false,
                Margin = new Padding(0, 2, 12, 2)
            };
            chkDeltaHash = new CheckBox
            {
                Text = "HASH",
                AutoSize = true,
                Checked = false,
                Margin = new Padding(0, 2, 12, 2)
            };
            deltaFlags.Controls.Add(chkDeltaRv);
            deltaFlags.Controls.Add(chkDeltaCol);
            deltaFlags.Controls.Add(chkDeltaHash);
            addT("Smart Delta methods", deltaFlags);
            Label deltaTip = new Label
            {
                AutoSize = true,
                ForeColor = SystemColors.GrayText,
                Text = "All off by default. Tick only what you want. Order when enabled: Change Tracking → CDC → RV → COL → HASH. HASH is heavy on large tables.",
                Margin = new Padding(0, 0, 0, 4)
            };
            // tip row under methods
            tt.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tt.Controls.Add(new Label { Text = "", AutoSize = true }, 0, tr);
            tt.Controls.Add(deltaTip, 1, tr);
            tr++;
            cbDeltaMethod = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Visible = false, Height = 1 };
            cbDeltaMethod.Items.AddRange(new object[] { "Auto", "RV", "COL", "HASH" });
            cbDeltaMethod.SelectedIndex = 0;
            addT("Batch size (rows)", numBatch);
            numThreads = new NumericUpDown { Minimum = 0, Maximum = 64, Value = 0 };
            numDelay = new NumericUpDown { Minimum = 0, Maximum = 60000, Value = 0 };
            cbPriority = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cbPriority.Items.AddRange(new object[] { "Low", "Normal", "High" });
            cbPriority.SelectedIndex = 1;
            chkDestMT = new CheckBox { Text = "Multi-thread DEST ON  (unticked = 1 writer)", AutoSize = true, Checked = true };
            chkDestMT.CheckedChanged += (s, e) => UpdateTypeUi();
            addT("", chkDestMT);
            addT("   DEST threads (0=Auto)", numThreads);
            numSourceThreads = new NumericUpDown { Minimum = 0, Maximum = 64, Value = 0 };
            chkSrcMT = new CheckBox { Text = "Multi-thread SOURCE ON  (unticked = 1 reader)", AutoSize = true, Checked = true };
            chkSrcMT.CheckedChanged += (s, e) => UpdateTypeUi();
            addT("", chkSrcMT);
            addT("   SOURCE threads (0=Auto)", numSourceThreads);
            Label lblSrcHint = new Label
            {
                Text = "SOURCE readers: 0 = Auto (big tables only), 1 = single reader. >1 splits the read by key hash (RAM mode, plain table / SELECT without ORDER BY).",
                AutoSize = true, ForeColor = SystemColors.GrayText, MaximumSize = new Size(430, 0)
            };
            addT("", lblSrcHint);
            cbIdxMode = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cbIdxMode.Items.AddRange(new object[] {
                "Off",
                "After every run (only if the table has indexes)",
                "Every N days (message in log/result)"
            });
            cbIdxMode.SelectedIndex = 0;
            cbIdxMode.SelectedIndexChanged += (s, e) => UpdateTypeUi();
            numIdxDays = new NumericUpDown { Minimum = 1, Maximum = 3650, Value = 7 };
            lblIdxLast = new Label { Text = "", AutoSize = true, ForeColor = SystemColors.GrayText };
            addT("Rebuild indexes (DEST)", cbIdxMode);
            addT("... every N days", numIdxDays);
            addT("", lblIdxLast);
            // 0 = Auto (CPU cores; heavier tables use more writers)
            addT("Delay (ms)", numDelay);
            addT("Priority", cbPriority);
            // Memory mode: radio buttons (exactly one choice)
            cbBuffer = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Visible = false, Height = 1 };
            cbBuffer.Items.AddRange(new object[] { "Auto", "RAM", "Stream", "Disk" });
            cbBuffer.SelectedIndex = 0;
            chkBufAuto = new RadioButton { Text = "Auto", AutoSize = true, Checked = true, Margin = new Padding(0, 2, 10, 2) };
            chkBufRam = new RadioButton { Text = "RAM", AutoSize = true, Margin = new Padding(0, 2, 10, 2) };
            chkBufStream = new RadioButton { Text = "Stream", AutoSize = true, Margin = new Padding(0, 2, 10, 2) };
            chkBufDisk = new RadioButton { Text = "Disk", AutoSize = true, Margin = new Padding(0, 2, 10, 2) };
            EventHandler bufClick = (s, e) =>
            {
                RadioButton src = s as RadioButton;
                if (src == null || !src.Checked) return;
                if (chkBufAuto.Checked) cbBuffer.SelectedIndex = 0;
                else if (chkBufRam.Checked) cbBuffer.SelectedIndex = 1;
                else if (chkBufStream.Checked) cbBuffer.SelectedIndex = 2;
                else cbBuffer.SelectedIndex = 3;
            };
            chkBufAuto.CheckedChanged += bufClick;
            chkBufRam.CheckedChanged += bufClick;
            chkBufStream.CheckedChanged += bufClick;
            chkBufDisk.CheckedChanged += bufClick;
            FlowLayoutPanel memRow = new FlowLayoutPanel
            {
                AutoSize = true, WrapContents = true, FlowDirection = FlowDirection.LeftToRight, Margin = new Padding(0)
            };
            memRow.Controls.Add(chkBufAuto);
            memRow.Controls.Add(chkBufRam);
            memRow.Controls.Add(chkBufStream);
            memRow.Controls.Add(chkBufDisk);
            numRamLimit = new NumericUpDown { Minimum = 16, Maximum = 65536, Value = 256, Width = 70 };
            FlowLayoutPanel ramRow = new FlowLayoutPanel
            {
                AutoSize = true, WrapContents = false, FlowDirection = FlowDirection.LeftToRight, Margin = new Padding(0)
            };
            ramRow.Controls.Add(new Label { Text = "RAM limit (MB):", AutoSize = true, Margin = new Padding(0, 6, 6, 0) });
            ramRow.Controls.Add(numRamLimit);
            addT("Memory mode", memRow);
            addT("", ramRow);
            try
            {
                ToolTip tipRam = new ToolTip();
                tipRam.SetToolTip(numRamLimit, "When Memory mode is Auto: tables estimated above this many MB use Disk buffer instead of RAM.");
            }
            catch { }

            // Cache providers (local) — multi-select checkboxes
            chkCacheLiteDb = new CheckBox { Text = "LiteDB (general / light)", AutoSize = true, Checked = true, Margin = new Padding(0, 2, 12, 2) };
            chkCacheLevelDb = new CheckBox { Text = "LevelDB (fast)", AutoSize = true, Margin = new Padding(0, 2, 12, 2) };
            chkCacheFaster = new CheckBox { Text = "FASTER (very fast)", AutoSize = true, Margin = new Padding(0, 2, 12, 2) };
            FlowLayoutPanel cacheRow = new FlowLayoutPanel
            {
                AutoSize = true, WrapContents = true, FlowDirection = FlowDirection.LeftToRight, Margin = new Padding(0)
            };
            cacheRow.Controls.Add(chkCacheLiteDb);
            cacheRow.Controls.Add(chkCacheLevelDb);
            cacheRow.Controls.Add(chkCacheFaster);
            addT("Cache provider", cacheRow);
            Label cacheTip = new Label
            {
                AutoSize = true,
                ForeColor = SystemColors.GrayText,
                Text = "LiteDB: general cache. LevelDB / FASTER: high-speed key-value (optional).",
                Margin = new Padding(0, 0, 0, 2),
                MaximumSize = new Size(420, 0)
            };
            tt.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tt.Controls.Add(new Label { Text = "", AutoSize = true }, 0, tr);
            tt.Controls.Add(cacheTip, 1, tr);
            tr++;

            transferPanel.Controls.Add(tt);

            // Web API fields
            apiPanel = new TableLayoutPanel { ColumnCount = 2, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink };
            apiPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            apiPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            txtApiUrl = new TextBox();
            cbApiMethod = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cbApiMethod.Items.AddRange(new object[] { "GET", "POST", "PUT", "PATCH" });
            cbApiMethod.SelectedIndex = 0;
            cbApiMethod.SelectedIndexChanged += (s, e) => UpdateTypeUi();
            cbApiAuth = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cbApiAuth.Items.AddRange(new object[] { "None", "Bearer token", "Basic (user/password)", "API Key (header)" });
            cbApiAuth.SelectedIndex = 0;
            cbApiAuth.SelectedIndexChanged += (s, e) => UpdateTypeUi();
            txtApiToken = new TextBox();
            txtApiAuthUrl = new TextBox();
            txtApiKeyHeader = new TextBox { Text = "ApiKey" };
            txtApiUser = new TextBox();
            txtApiPass = new TextBox { UseSystemPasswordChar = true };
            txtApiHeaders = new TextBox { Multiline = true, Height = 56, ScrollBars = ScrollBars.Vertical, WordWrap = false, AcceptsReturn = true };
            txtApiBody = new TextBox { Multiline = true, Height = 70, ScrollBars = ScrollBars.Both, WordWrap = false, AcceptsReturn = true, Font = new Font("Consolas", 9.5f) };
            txtApiPath = new TextBox();
            txtPageParam = new TextBox();
            txtPageSizeParam = new TextBox();
            numPageSize = new NumericUpDown { Minimum = 0, Maximum = 1000000, Value = 0, Width = 90 };
            numMaxPages = new NumericUpDown { Minimum = 1, Maximum = 1000000, Value = 1000, Width = 90 };
            chkApiIgnoreCert = new CheckBox { Text = "Ignore SSL certificate errors", AutoSize = true };
            int ar = 0;
            Action<string, Control> addA = (label, c) =>
            {
                apiPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                apiPanel.Controls.Add(new Label { Text = label, AutoSize = true, Margin = new Padding(0, 6, 6, 0) }, 0, ar);
                c.Dock = DockStyle.Fill;
                apiPanel.Controls.Add(c, 1, ar);
                ar++;
            };
            addA("URL", txtApiUrl);
            addA("Method", cbApiMethod);
            addA("Auth URL (get token)", txtApiAuthUrl);
            addA("Authentication", cbApiAuth);
            addA("Token / API Key", txtApiToken);
            addA("API Key header name", txtApiKeyHeader);
            addA("User / Email", txtApiUser);
            addA("Password", txtApiPass);
            addA("Headers (Name: Value)", txtApiHeaders);
            addA("POST body", txtApiBody);
            addA("JSON path to array", txtApiPath);
            addA("Page param", txtPageParam);
            addA("Page-size param", txtPageSizeParam);
            addA("Page size", numPageSize);
            addA("Max pages", numMaxPages);
            addA("", chkApiIgnoreCert);

            FlowLayoutPanel apiActions = new FlowLayoutPanel
            {
                AutoSize = true, WrapContents = true, FlowDirection = FlowDirection.LeftToRight, Margin = new Padding(0)
            };
            Button btnTestApi = new Button { Text = "Test API", AutoSize = true, Margin = new Padding(0, 2, 8, 2) };
            Button btnRunSql = new Button { Text = "Run to SQL Server", AutoSize = true, Margin = new Padding(0, 2, 8, 2) };
            Button btnImportCurl = new Button { Text = "Import cURL...", AutoSize = true, Margin = new Padding(0, 2, 8, 2) };
            Button btnExportCurl = new Button { Text = "Save cURL...", AutoSize = true, Margin = new Padding(0, 2, 8, 2) };
            btnTestApi.Click += (s, e) => TestApiConnection();
            btnRunSql.Click += (s, e) => RunApiToSqlServer();
            btnImportCurl.Click += (s, e) => ImportFromCurl();
            btnExportCurl.Click += (s, e) => ExportCurlFile();
            apiActions.Controls.Add(btnTestApi);
            apiActions.Controls.Add(btnRunSql);
            apiActions.Controls.Add(btnImportCurl);
            apiActions.Controls.Add(btnExportCurl);
            addA("Actions", apiActions);
            Label apiAuthTip = new Label
            {
                AutoSize = true,
                ForeColor = SystemColors.GrayText,
                MaximumSize = new Size(520, 0),
                Text = Lang.Fa
                    ? "رفرش توکن: Authentication=Bearer + Auth URL + User/Password → هر بار اجرا/تست توکن جدید می‌گیرد؛ اگر 401 شود یک‌بار دوباره رفرش می‌کند. جدول مقصد: اگر نباشد خودکار ساخته می‌شود. Batch size = چند ردیف‌چند ردیف بریزد."
                    : "Token refresh: Bearer + Auth URL + User/Password → new token each run/test; on HTTP 401 retries once. Dest table is auto-created if missing. Batch size = insert chunk size."
            };
            addA("", apiAuthTip);

            cbOnSuccess = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cbOnSuccess.Items.AddRange(new object[] { "Go to the next step", "Quit the job reporting success", "Quit the job reporting failure" });
            cbOnSuccess.SelectedIndex = 0;
            cbOnFail = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cbOnFail.Items.AddRange(new object[] { "Go to the next step", "Quit the job reporting success", "Quit the job reporting failure" });
            cbOnFail.SelectedIndex = 2;

            numRetry = new NumericUpDown { Minimum = 0, Maximum = 20, Value = 0, Width = 60 };
            numRetryMin = new NumericUpDown { Minimum = 0, Maximum = 1440, Value = 0, Width = 60 };
            chkContinueOnErr = new CheckBox { Text = "T-SQL script: if one statement / table fails, log it at once and continue with the next one (all failures are reported at the end)", AutoSize = true };

            // Database / connection (SSMS-style) — which connection this step uses
            cbDatabase = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            _connList = new System.Collections.Generic.List<ConnectionProfile>();
            try
            {
                AppConfig cfg = AppConfig.Load();
                _cfg = cfg;
                cbDatabase.Items.Add("(default: Source / Dest from main window)");
                _connList.Add(null);
                if (cfg != null && cfg.Connections != null)
                {
                    foreach (ConnectionProfile cp in cfg.Connections)
                    {
                        string label = (cp.Name ?? "conn");
                        if (!string.IsNullOrWhiteSpace(cp.Database)) label += "  [" + cp.Database + "]";
                        if (!string.IsNullOrWhiteSpace(cp.Server)) label += "  @ " + cp.Server;
                        cbDatabase.Items.Add(label);
                        _connList.Add(cp);
                    }
                }
            }
            catch
            {
                cbDatabase.Items.Add("(default: Source / Dest from main window)");
                _connList.Add(null);
            }
            if (cbDatabase.Items.Count > 0) cbDatabase.SelectedIndex = 0;
            cbDatabase.SelectedIndexChanged += (s, e) => { if (IsHandleCreated) LoadTableLists(); };

            add("Step name:", txtName);
            add("Type:", cbType);
            add("Database:", cbDatabase);
            add("Command (T-SQL / SELECT):", BuildSqlCommandBox());
            add("Transfer options:", transferPanel);
            lblApi = new Label { Text = "Web API options:", AutoSize = true, Margin = new Padding(3, 8, 8, 3) };
            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(lblApi, 0, r);
            apiPanel.Dock = DockStyle.Fill;
            apiPanel.Margin = new Padding(3, 4, 3, 4);
            t.Controls.Add(apiPanel, 1, r);
            r++;
            add("On success:", cbOnSuccess);
            add("On failure:", cbOnFail);

            FlowLayoutPanel retry = new FlowLayoutPanel { AutoSize = true };
            retry.Controls.Add(new Label { Text = "Retry attempts", AutoSize = true, Margin = new Padding(0, 6, 6, 0) });
            retry.Controls.Add(numRetry);
            retry.Controls.Add(new Label { Text = "  Interval (min)", AutoSize = true, Margin = new Padding(12, 6, 6, 0) });
            retry.Controls.Add(numRetryMin);
            add("Retry:", retry);
            add("On error:", chkContinueOnErr);

            Label tip = new Label
            {
                AutoSize = true,
                ForeColor = SystemColors.GrayText,
                MaximumSize = new Size(680, 0),
                Text =
                      "Transfer: Source + Dest table *  |  T-SQL: فقط Command  |  API: Dest table * + URL (+ Auth/JSON path)\r\n" +
                      "اگر Dest نباشد ساخته می‌شود  ·  Threads 0=Auto  ·  Merge=Key columns  ·  Incremental/CT/CDC=فقط آخرین تغییرات\r\n" +
                      "Web API: Command استفاده نمی‌شود  ·  OK پایین = ذخیره Step"
            };
            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(tip, 0, r);
            t.SetColumnSpan(tip, 2);

            body.Controls.Add(t);
            Controls.Add(body);
            Controls.Add(bottom);
            _uiReady = true;
        }


        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);
        private const int EM_SETCUEBANNER = 0x1501;
        private static System.Windows.Forms.Timer _tableFilterTimer;
        private static ComboBox _tableFilterBox;
        private static bool _tableFilterBusy;

        /// <summary>Table name combo with debounced contains-search (type "dep" -> matching tables).</summary>
        private string PromptTableName(string suggested)
        {
            if (string.IsNullOrWhiteSpace(suggested)) suggested = "dbo.NewTable";
            using (Form dlg = new Form())
            {
                dlg.Text = Lang.Fa ? "جدول جدید" : "New table";
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.ClientSize = new Size(420, 130);
                dlg.MaximizeBox = false;
                dlg.MinimizeBox = false;
                dlg.ShowInTaskbar = false;
                Label tip = new Label
                {
                    Left = 12, Top = 12, Width = 390, Height = 36,
                    Text = Lang.Fa
                        ? "نام جدول مقصد را وارد کنید. اگر وجود نداشته باشد هنگام اجرا از روی خروجی API ساخته می‌شود."
                        : "Enter destination table name. If missing, it is created from API output on run."
                };
                TextBox tb = new TextBox { Left = 12, Top = 52, Width = 390, Text = suggested };
                Button ok = new Button { Text = "OK", Left = 230, Top = 90, Width = 80, DialogResult = DialogResult.OK };
                Button cancel = new Button { Text = Lang.Fa ? "انصراف" : "Cancel", Left = 320, Top = 90, Width = 80, DialogResult = DialogResult.Cancel };
                dlg.Controls.Add(tip);
                dlg.Controls.Add(tb);
                dlg.Controls.Add(ok);
                dlg.Controls.Add(cancel);
                dlg.AcceptButton = ok;
                dlg.CancelButton = cancel;
                Theme.Apply(dlg);
                if (dlg.ShowDialog(this) != DialogResult.OK) return null;
                return (tb.Text ?? "").Trim();
            }
        }

        private static ComboBox NewTableCombo()
        {
            ComboBox cb = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDown,
                AutoCompleteMode = AutoCompleteMode.None,
                AutoCompleteSource = AutoCompleteSource.None,
                MaxDropDownItems = 14,
                IntegralHeight = true
            };
            cb.TextUpdate += (s, e) =>
            {
                _tableFilterBox = (ComboBox)s;
                if (_tableFilterTimer == null)
                {
                    _tableFilterTimer = new System.Windows.Forms.Timer();
                    _tableFilterTimer.Interval = 120;
                    _tableFilterTimer.Tick += (s2, e2) =>
                    {
                        _tableFilterTimer.Stop();
                        ApplyTableFilter(_tableFilterBox);
                    };
                }
                _tableFilterTimer.Stop();
                _tableFilterTimer.Start();
            };
            return cb;
        }

        private static void ApplyTableFilter(ComboBox box)
        {
            if (box == null || box.IsDisposed || _tableFilterBusy) return;
            List<string> all = box.Tag as List<string>;
            if (all == null || all.Count == 0) return;

            string q = SafeComboText(box);
            int selStart = box.SelectionStart;
            string ql = q.Trim().ToLowerInvariant();

            _tableFilterBusy = true;
            try
            {
                List<string> filtered = new List<string>();
                if (ql.Length == 0)
                {
                    int n = Math.Min(all.Count, 150);
                    for (int i = 0; i < n; i++) filtered.Add(all[i]);
                }
                else
                {
                    foreach (string x in all)
                    {
                        if (x != null && x.ToLowerInvariant().IndexOf(ql) >= 0)
                        {
                            filtered.Add(x);
                            if (filtered.Count >= 150) break;
                        }
                    }
                }

                box.BeginUpdate();
                try
                {
                    box.Items.Clear();
                    foreach (string x in filtered) box.Items.Add(x);
                }
                finally { box.EndUpdate(); }

                try { box.SelectedIndex = -1; } catch { }
                SafeSetComboText(box, q);
                if (selStart < 0) selStart = q.Length;
                if (selStart > q.Length) selStart = q.Length;
                box.SelectionStart = selStart;
                box.SelectionLength = 0;

                if (filtered.Count > 0)
                {
                    try
                    {
                        if (!box.DroppedDown) box.DroppedDown = true;
                        try { box.SelectedIndex = -1; } catch { }
                        SafeSetComboText(box, q);
                        box.SelectionStart = selStart;
                        box.SelectionLength = 0;
                    }
                    catch { }
                }
            }
            finally { _tableFilterBusy = false; }
        }

        /// <summary>Connection used to list tables: the step's own Database choice, else the global Source / Dest.</summary>
        /// <summary>
        /// Connection used only to populate the Source/Dest table dropdowns.
        /// Source list always comes from the global Source connection.
        /// Dest list uses the step Database choice (if set) else global Dest.
        /// (Previously both lists used Database and Source tables disappeared from the Source combo.)
        /// </summary>
        // =====================================================================
        //  T-SQL command box:  Open... / Select All / Copy / Paste / Parse   (small buttons beside the box, like SSMS)
        // =====================================================================
        private FlowLayoutPanel _sqlBtns;
        private ToolTip _tips = new ToolTip { AutoPopDelay = 20000, InitialDelay = 300 };
        private bool _parsing;
        private string _lastSqlDir = "";

        private Control BuildSqlCommandBox()
        {
            TableLayoutPanel wrap = new TableLayoutPanel
            {
                ColumnCount = 2,
                RowCount = 1,
                Height = 160,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Margin = new Padding(0),
                Padding = new Padding(0)
            };
            wrap.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            wrap.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 76));
            wrap.RowStyles.Add(new RowStyle(SizeType.Absolute, 160));

            txtSql.Dock = DockStyle.Fill;
            txtSql.Margin = new Padding(0, 0, 4, 0);
            wrap.Controls.Add(txtSql, 0, 0);

            _sqlBtns = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                Margin = new Padding(0),
                Padding = new Padding(0)
            };
            _sqlBtns.Controls.Add(MakeSqlButton("Open...",
                Lang.Fa ? "باز کردن فایل اسکریپت (.sql) داخل کادر دستور" : "Load a script file (.sql) into the command box",
                (s, e) => OpenSqlFile()));
            _sqlBtns.Controls.Add(MakeSqlButton("Select All",
                Lang.Fa ? "انتخاب کل متن دستور" : "Select the whole command",
                (s, e) => { txtSql.Focus(); txtSql.SelectAll(); }));
            _sqlBtns.Controls.Add(MakeSqlButton("Copy",
                Lang.Fa ? "کپی متن انتخاب‌شده (اگر چیزی انتخاب نیست، کل دستور)" : "Copy the selection (whole command if nothing is selected)",
                (s, e) => CopySql()));
            _sqlBtns.Controls.Add(MakeSqlButton("Paste",
                Lang.Fa ? "چسباندن متن کلیپ‌بورد" : "Paste the clipboard text",
                (s, e) => { txtSql.Focus(); txtSql.Paste(); }));
            _sqlBtns.Controls.Add(MakeSqlButton("Parse",
                Lang.Fa ? "بررسی نحو (Syntax) دستور بدون اجرا؛ اگر خطا از کپی/پیست باشد خودکار اصلاح و دوباره Parse می‌شود"
                        : "Check the syntax without running it; if the error comes from copy/paste the text is cleaned and parsed again",
                (s, e) => ParseSqlCommand()));
            wrap.Controls.Add(_sqlBtns, 1, 0);
            return wrap;
        }

        private Button MakeSqlButton(string text, string tip, EventHandler click)
        {
            Button b = new Button { Text = text, Width = 70, Height = 24, Margin = new Padding(0, 0, 0, 3), TabStop = true };
            b.Click += click;
            _tips.SetToolTip(b, tip);
            return b;
        }

        /// <summary>Theme forces 30 px high buttons - make these five small (called after Theme.Apply).</summary>
        private void CompactSqlButtons()
        {
            if (_sqlBtns == null) return;
            foreach (Control c in _sqlBtns.Controls)
            {
                Button b = c as Button;
                if (b == null) continue;
                b.MinimumSize = Size.Empty;
                b.Size = new Size(70, 24);
                b.Padding = new Padding(0);
                b.Font = new Font(b.Font.FontFamily, 8f);
            }
        }

        private void CopySql()
        {
            try
            {
                if (txtSql.SelectionLength > 0) { txtSql.Copy(); return; }
                if ((txtSql.Text ?? "").Length > 0) Clipboard.SetText(txtSql.Text);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Copy"); }
        }

        private static string ReadSqlFileText(string path)
        {
            byte[] raw = File.ReadAllBytes(path);
            string text;
            bool bom = (raw.Length >= 2 && ((raw[0] == 0xFF && raw[1] == 0xFE) || (raw[0] == 0xFE && raw[1] == 0xFF)))
                    || (raw.Length >= 3 && raw[0] == 0xEF && raw[1] == 0xBB && raw[2] == 0xBF);
            if (bom)
            {
                using (StreamReader sr = new StreamReader(new MemoryStream(raw), Encoding.UTF8, true))
                    text = sr.ReadToEnd();                               // UTF-8 / UTF-16 with BOM (SSMS "Unicode")
            }
            else
            {
                try { text = new UTF8Encoding(false, true).GetString(raw); }   // UTF-8 without BOM
                catch (Exception) { text = Encoding.Default.GetString(raw); }  // ANSI (e.g. Windows-1256)
            }
            return text.Replace("\r\n", "\n").Replace("\r", "\n").Replace("\n", "\r\n");
        }

        private void OpenSqlFile()
        {
            try
            {
                using (OpenFileDialog dlg = new OpenFileDialog())
                {
                    dlg.Title = Lang.Fa ? "باز کردن فایل SQL" : "Open SQL file";
                    dlg.Filter = Lang.Fa
                        ? "فایل‌های SQL (*.sql)|*.sql|فایل‌های متنی (*.txt)|*.txt|همه فایل‌ها (*.*)|*.*"
                        : "SQL files (*.sql)|*.sql|Text files (*.txt)|*.txt|All files (*.*)|*.*";
                    dlg.FilterIndex = 1;
                    dlg.DefaultExt = "sql";
                    dlg.CheckFileExists = true;
                    if (_lastSqlDir.Length > 0 && Directory.Exists(_lastSqlDir)) dlg.InitialDirectory = _lastSqlDir;
                    if (dlg.ShowDialog(this) != DialogResult.OK) return;

                    _lastSqlDir = Path.GetDirectoryName(dlg.FileName) ?? "";
                    if (new FileInfo(dlg.FileName).Length > 50L * 1024 * 1024)
                    {
                        MessageBox.Show(Lang.Fa ? "فایل بیش از ۵۰ مگابایت است و داخل کادر دستور باز نمی‌شود."
                                                : "The file is larger than 50 MB and cannot be loaded into the command box.", "Open", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if ((txtSql.Text ?? "").Trim().Length > 0)
                    {
                        DialogResult dr = MessageBox.Show(
                            Lang.Fa ? "متن فعلی دستور با محتوای فایل جایگزین شود؟" : "Replace the current command with the contents of the file?",
                            "Open", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (dr != DialogResult.Yes) return;
                    }
                    txtSql.Text = ReadSqlFileText(dlg.FileName);
                    txtSql.SelectionStart = 0;
                    txtSql.SelectionLength = 0;
                    txtSql.ScrollToCaret();
                    txtSql.Focus();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Open", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        /// <summary>Same connection rules as the engine: T-SQL on Dest -> Dest, otherwise Source; a chosen "Database" overrides T-SQL steps.</summary>
        private string ResolveSqlParseConn()
        {
            if (_cfg == null) return "";
            int ti = cbType != null ? cbType.SelectedIndex : 0;
            if ((ti == (int)StepType.SqlOnSource || ti == (int)StepType.SqlOnDest)
                && cbDatabase != null && _connList != null && cbDatabase.SelectedIndex > 0 && cbDatabase.SelectedIndex < _connList.Count)
            {
                ConnectionProfile cp = _connList[cbDatabase.SelectedIndex];
                if (cp != null)
                {
                    string cs = cp.BuildConnectionString();
                    if (!string.IsNullOrEmpty(cs)) return cs;
                }
            }
            return ((ti == (int)StepType.SqlOnDest) ? _cfg.ResolveDestConnectionString() : _cfg.ResolveSourceConnectionString()) ?? "";
        }

        private void SetSqlBusy(bool busy)
        {
            _parsing = busy;
            if (_sqlBtns != null) _sqlBtns.Enabled = !busy;
            Cursor = busy ? Cursors.WaitCursor : Cursors.Default;
        }

        private void ParseSqlCommand()
        {
            if (_parsing) return;
            const string caption = "Parse Command Text";
            string sql = txtSql.Text ?? "";
            if (sql.Trim().Length == 0)
            {
                MessageBox.Show(Lang.Fa ? "دستوری برای بررسی وجود ندارد." : "There is nothing to parse - the command is empty.",
                    caption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string cs = ResolveSqlParseConn();
            SetSqlBusy(true);
            Task.Run(() =>
            {
                Engine.SqlParseResult first = null, second = null;
                string fixedSql = null;
                List<string> notes = new List<string>();
                try
                {
                    first = Engine.ParseSql(cs, sql);
                    if (!first.Ok && !first.ConnectError)
                    {
                        // maybe the text was damaged by copy/paste (curly quotes, ``` lines, hidden characters) - repair and try again
                        string cleaned = Engine.AutoFixSql(sql, notes);
                        if (notes.Count > 0 && !string.Equals(cleaned, sql, StringComparison.Ordinal))
                        {
                            fixedSql = cleaned;
                            second = Engine.ParseSql(cs, cleaned);
                        }
                    }
                }
                catch (Exception ex)
                {
                    first = new Engine.SqlParseResult { ConnectError = true, Message = ex.Message };
                }
                if (IsDisposed || !IsHandleCreated) return;
                try { BeginInvoke(new Action(() => FinishParse(first, fixedSql, notes, second))); }
                catch { }
            });
        }

        private void FinishParse(Engine.SqlParseResult first, string fixedSql, List<string> notes, Engine.SqlParseResult second)
        {
            SetSqlBusy(false);
            const string caption = "Parse Command Text";
            if (first == null) return;

            if (first.ConnectError)
            {
                MessageBox.Show((Lang.Fa ? "اتصال برقرار نشد؛ دستور بررسی نشد.\r\n\r\n" : "Could not connect - the command was not parsed.\r\n\r\n") + first.Message,
                    caption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (first.Ok)
            {
                MessageBox.Show("The command was successfully parsed.", caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string head = Lang.Fa ? "خطای نحوی (Syntax) در دستور:\r\n\r\n" : "Syntax error in the command:\r\n\r\n";
            string errs = first.Message;
            if (errs.Length > 1500) errs = errs.Substring(0, 1500) + " ...";

            if (second != null && second.Ok && fixedSql != null)
            {
                StringBuilder nb = new StringBuilder();
                foreach (string n in notes) nb.Append("  • ").Append(Lang.T(n)).Append("\r\n");
                DialogResult dr = MessageBox.Show(
                    head + errs + "\r\n\r\n"
                    + (Lang.Fa ? "پاک‌سازی خودکار:\r\n" : "Automatic clean-up:\r\n") + nb
                    + "\r\n"
                    + (Lang.Fa ? "متن اصلاح‌شده بدون خطا Parse شد. روی کادر دستور اعمال شود؟"
                               : "The cleaned text parses without errors. Apply it to the command box?"),
                    caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    txtSql.Text = fixedSql;
                    txtSql.SelectionStart = 0;
                    txtSql.SelectionLength = 0;
                    txtSql.ScrollToCaret();
                    MessageBox.Show("The command was successfully parsed.", caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else GoToSqlLine(first.ErrorLine);
                return;
            }

            MessageBox.Show(head + errs
                + (fixedSql != null ? "\r\n\r\n" + (Lang.Fa ? "پاک‌سازی خودکار هم مشکل را برطرف نکرد؛ خط خطا را در کادر دستور اصلاح کنید."
                                                            : "Automatic clean-up could not fix it - please correct the highlighted line.") : ""),
                caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
            GoToSqlLine(first.ErrorLine);
        }

        private void GoToSqlLine(int line)
        {
            try
            {
                if (line < 1) return;
                int idx = txtSql.GetFirstCharIndexFromLine(line - 1);
                if (idx < 0) return;
                string[] lines = txtSql.Lines;
                int len = (line - 1 < lines.Length) ? lines[line - 1].Length : 0;
                txtSql.Focus();
                txtSql.Select(idx, len);
                txtSql.ScrollToCaret();
            }
            catch { }
        }

        // =====================================================================
        //  Yellow warning icon next to Change Tracking / CDC  ->  requirements + example script
        // =====================================================================
        private Control WithWarnIcon(CheckBox box, bool cdc)
        {
            FlowLayoutPanel row = new FlowLayoutPanel
            {
                AutoSize = true,
                WrapContents = false,
                FlowDirection = FlowDirection.LeftToRight,
                Margin = new Padding(0)
            };
            box.Margin = new Padding(3, 3, 2, 3);
            row.Controls.Add(box);

            Label icon = new Label
            {
                AutoSize = false,
                Size = new Size(22, 20),
                Margin = new Padding(2, 3, 0, 0),
                Cursor = Cursors.Hand,
                BackColor = Color.Transparent,
                TabStop = false
            };
            icon.Paint += (s, e) =>
            {
                Graphics g = e.Graphics;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                Rectangle r = ((Label)s).ClientRectangle;
                PointF[] tri = new PointF[]
                {
                    new PointF(r.Width / 2f, 1.5f),
                    new PointF(r.Width - 1.5f, r.Height - 2f),
                    new PointF(1.5f, r.Height - 2f)
                };
                using (SolidBrush fill = new SolidBrush(Color.FromArgb(255, 200, 0)))
                using (Pen pen = new Pen(Color.FromArgb(170, 110, 0), 1.4f))
                {
                    pen.LineJoin = System.Drawing.Drawing2D.LineJoin.Round;
                    g.FillPolygon(fill, tri);
                    g.DrawPolygon(pen, tri);
                }
                using (Font f = new Font("Segoe UI", 8.5f, FontStyle.Bold))
                using (SolidBrush tb = new SolidBrush(Color.FromArgb(70, 40, 0)))
                using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                    g.DrawString("!", f, tb, new RectangleF(0, 4, r.Width, r.Height - 4), sf);
            };
            icon.Click += (s, e) => ShowDeltaHelp(cdc);
            _tips.SetToolTip(icon, Lang.Fa
                ? (cdc ? "هشدار / راهنما: پیش‌نیازهای CDC و کد نمونه (کلیک کنید)" : "هشدار / راهنما: پیش‌نیازهای Change Tracking و کد نمونه (کلیک کنید)")
                : (cdc ? "Warning / help: CDC requirements + example script (click)" : "Warning / help: Change Tracking requirements + example script (click)"));
            row.Controls.Add(icon);
            return row;
        }

        private void ShowDeltaHelp(bool cdc)
        {
            bool fa = Lang.Fa;
            string title = cdc ? "CDC (Change Data Capture)" : "Change Tracking (CT)";

            string info;
            if (!cdc)
            {
                info = fa
                    ? "پیش‌نیازها (روی دیتابیس و جدول «مبدأ» انجام شود):\r\n" +
                      "• Change Tracking باید هم روی دیتابیس و هم روی هر جدول مبدأ روشن باشد.\r\n" +
                      "• جدول حتماً Primary Key داشته باشد (SyncDB با کلید به CHANGETABLE وصل می‌شود).\r\n" +
                      "• Recovery Model: هر مدلی (Simple / Full / Bulk-logged) جواب می‌دهد؛ Full اجباری نیست.\r\n" +
                      "• CHANGE_RETENTION را بیشتر از فاصلهٔ اجرای جاب بگذارید؛ وگرنه تغییرات پاک می‌شوند و باید بار کامل انجام شود.\r\n" +
                      "• اولین اجرا بار کامل است؛ اجراهای بعدی فقط تغییرات را می‌برند."
                    : "Requirements (done on the SOURCE database / table):\r\n" +
                      "• Change Tracking must be ON for the database and for every source table.\r\n" +
                      "• The table needs a PRIMARY KEY (SyncDB joins CHANGETABLE on the key).\r\n" +
                      "• Recovery model: any (Simple / Full / Bulk-logged) works - Full is NOT required.\r\n" +
                      "• Keep CHANGE_RETENTION longer than the gap between job runs, otherwise changes are cleaned up and a full load is needed.\r\n" +
                      "• The first run is a full load; later runs copy only the changes.";
            }
            else
            {
                info = fa
                    ? "پیش‌نیازها (روی دیتابیس و جدول «مبدأ» انجام شود):\r\n" +
                      "• SQL Server Agent باید روشن باشد (Job های capture / cleanup)؛ در نسخهٔ Express وجود ندارد. نسخه: Enterprise/Developer یا Standard از 2016 SP1 به بعد.\r\n" +
                      "• CDC باید روی دیتابیس (sp_cdc_enable_db) و روی هر جدول (sp_cdc_enable_table) روشن شود؛ با @supports_net_changes = 1 که Primary Key یا Unique Index لازم دارد.\r\n" +
                      "• نام Capture Instance را تغییر ندهید (پیش‌فرض schema_table مثل dbo_Person) چون SyncDB همین نام را می‌خواند.\r\n" +
                      "• Recovery Model: Simple / Full / Bulk-logged همه کار می‌کنند؛ Full اجباری نیست. فقط یادتان باشد لاگ تا خواندن توسط capture آزاد نمی‌شود؛ روی دیتابیس بزرگ Agent را روشن نگه دارید و حجم لاگ را ببینید (در محیط عملیاتی معمولاً Full + بکاپ لاگ).\r\n" +
                      "• فقط برای «جدول» مبدأ (نه SQL دلخواه). اولین اجرا بار کامل است و بعدش Net Changes از آخرین LSN."
                    : "Requirements (done on the SOURCE database / table):\r\n" +
                      "• SQL Server Agent must be running (capture / cleanup jobs) - not available in Express. Edition: Enterprise/Developer, or Standard from 2016 SP1.\r\n" +
                      "• CDC must be enabled on the database (sp_cdc_enable_db) and on every table (sp_cdc_enable_table) with @supports_net_changes = 1, which needs a PRIMARY KEY or a unique index.\r\n" +
                      "• Keep the default capture instance name (schema_table, e.g. dbo_Person) - SyncDB reads exactly that name.\r\n" +
                      "• Recovery model: Simple / Full / Bulk-logged all work - Full is NOT required. Note the log cannot be reused until the capture job has read it, so on big databases keep Agent running and watch the log size (production usually = Full + log backups).\r\n" +
                      "• Plain Source table only (not custom SQL). First run is a full load, then net changes since the last LSN.";
            }

            string script = cdc
                ? "-- === Example: enable CDC (run on the SOURCE server) ===\r\n" +
                  "USE [YourDatabase];\r\n" +
                  "GO\r\n" +
                  "-- Optional - NOT required (usual for production): ALTER DATABASE [YourDatabase] SET RECOVERY FULL;\r\n" +
                  "\r\n" +
                  "-- 1) database level (sysadmin)\r\n" +
                  "EXEC sys.sp_cdc_enable_db;\r\n" +
                  "GO\r\n" +
                  "-- 2) table level (db_owner) - SQL Server Agent must be running\r\n" +
                  "EXEC sys.sp_cdc_enable_table\r\n" +
                  "     @source_schema        = N'dbo',\r\n" +
                  "     @source_name          = N'YourTable',\r\n" +
                  "     @role_name            = NULL,\r\n" +
                  "     @supports_net_changes = 1;   -- needs a PRIMARY KEY (or @index_name = unique index)\r\n" +
                  "GO\r\n" +
                  "-- 3) check\r\n" +
                  "SELECT name, recovery_model_desc, is_cdc_enabled FROM sys.databases WHERE name = DB_NAME();\r\n" +
                  "SELECT s.name AS [schema], t.name AS [table], t.is_tracked_by_cdc\r\n" +
                  "FROM sys.tables t JOIN sys.schemas s ON s.schema_id = t.schema_id WHERE t.is_tracked_by_cdc = 1;\r\n" +
                  "SELECT capture_instance FROM cdc.change_tables;   -- must look like dbo_YourTable\r\n"
                : "-- === Example: enable Change Tracking (run on the SOURCE server) ===\r\n" +
                  "-- Optional - NOT required (usual for production): ALTER DATABASE [YourDatabase] SET RECOVERY FULL;\r\n" +
                  "\r\n" +
                  "-- 1) database level\r\n" +
                  "ALTER DATABASE [YourDatabase]\r\n" +
                  "SET CHANGE_TRACKING = ON (CHANGE_RETENTION = 7 DAYS, AUTO_CLEANUP = ON);\r\n" +
                  "GO\r\n" +
                  "USE [YourDatabase];\r\n" +
                  "GO\r\n" +
                  "-- 2) table level (the table must have a PRIMARY KEY)\r\n" +
                  "ALTER TABLE dbo.YourTable ENABLE CHANGE_TRACKING WITH (TRACK_COLUMNS_UPDATED = OFF);\r\n" +
                  "GO\r\n" +
                  "-- 3) check\r\n" +
                  "SELECT name, recovery_model_desc FROM sys.databases WHERE name = DB_NAME();\r\n" +
                  "SELECT * FROM sys.change_tracking_databases WHERE database_id = DB_ID();\r\n" +
                  "SELECT OBJECT_SCHEMA_NAME(object_id) AS [schema], OBJECT_NAME(object_id) AS [table] FROM sys.change_tracking_tables;\r\n" +
                  "SELECT CHANGE_TRACKING_CURRENT_VERSION() AS current_version;\r\n";

            using (Form dlg = new Form())
            {
                dlg.Text = (fa ? "راهنما — " : "Help — ") + title;
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.MaximizeBox = false;
                dlg.MinimizeBox = false;
                dlg.ShowInTaskbar = false;
                dlg.ClientSize = new Size(700, 600);

                Label head = new Label
                {
                    Left = 14, Top = 12, Width = 672, Height = 24,
                    Text = "⚠  " + title,
                    Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(150, 95, 0)
                };
                Label body = new Label { Left = 14, Top = 42, Width = 672, Height = 230, Text = info };
                Label codeTitle = new Label
                {
                    Left = 14, Top = 278, Width = 672, Height = 20,
                    Text = fa ? "کد نمونه (قابل کپی):" : "Example script (copy-able):"
                };
                TextBox code = new TextBox
                {
                    Left = 14, Top = 300, Width = 672, Height = 244,
                    Multiline = true,
                    ReadOnly = true,
                    ScrollBars = ScrollBars.Both,
                    WordWrap = false,
                    Font = new Font("Consolas", 9.5f),
                    RightToLeft = RightToLeft.No,
                    Text = script,
                    BackColor = Color.White
                };
                Button copy = new Button { Text = fa ? "کپی کد" : "Copy script", Left = 14, Top = 556, Width = 120, Height = 30 };
                copy.Click += (s, e) =>
                {
                    try { Clipboard.SetText(script); copy.Text = fa ? "کپی شد ✓" : "Copied ✓"; }
                    catch (Exception ex) { MessageBox.Show(ex.Message, "Copy"); }
                };
                Button close = new Button { Text = fa ? "بستن" : "Close", Left = 566, Top = 556, Width = 120, Height = 30, DialogResult = DialogResult.OK };
                dlg.Controls.Add(head);
                dlg.Controls.Add(body);
                dlg.Controls.Add(codeTitle);
                dlg.Controls.Add(code);
                dlg.Controls.Add(copy);
                dlg.Controls.Add(close);
                dlg.AcceptButton = close;
                dlg.CancelButton = close;
                Theme.Apply(dlg);
                code.RightToLeft = RightToLeft.No;
                code.SelectionStart = 0;
                code.SelectionLength = 0;
                dlg.ShowDialog(this);
            }
        }

        private string ResolveListConn(bool asSource)
        {
            if (_cfg == null) return "";
            if (asSource)
                return _cfg.ResolveSourceConnectionString() ?? "";
            // Dest side: optional override from Database combo
            if (cbDatabase != null && _connList != null && cbDatabase.SelectedIndex > 0 && cbDatabase.SelectedIndex < _connList.Count)
            {
                ConnectionProfile cp = _connList[cbDatabase.SelectedIndex];
                if (cp != null)
                {
                    string cs = cp.BuildConnectionString();
                    if (!string.IsNullOrEmpty(cs)) return cs;
                }
            }
            return _cfg.ResolveDestConnectionString() ?? "";
        }

        /// <summary>Reads the table names in the background and fills the Source table / Dest table drop-downs.</summary>
        private void LoadTableLists()
        {
            int seq = ++_loadSeq;
            string srcCs = ResolveListConn(true), dstCs = ResolveListConn(false);
            Task.Run(() =>
            {
                List<string> src = null, dst = null;
                try { if (!string.IsNullOrEmpty(srcCs)) src = Engine.ListTablesAndViews(srcCs); } catch { }
                try
                {
                    if (!string.IsNullOrEmpty(dstCs))
                        dst = (dstCs == srcCs && src != null) ? src : Engine.ListTablesAndViews(dstCs);
                }
                catch { }
                if (IsDisposed || !IsHandleCreated) return;
                try
                {
                    BeginInvoke(new Action(() =>
                    {
                        if (seq != _loadSeq || IsDisposed) return;
                        FillTables(txtSrcTable, src, false);
                        // Merge source table names into dest suggestions so user can pick the same name
                        // even when the table does not exist on Dest yet (will be created on first run).
                        List<string> dstMerged = dst;
                        if (src != null && src.Count > 0)
                        {
                            System.Collections.Generic.HashSet<string> seen = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
                            dstMerged = new List<string>();
                            if (dst != null)
                            {
                                foreach (string x in dst)
                                {
                                    if (x == null) continue;
                                    dstMerged.Add(x);
                                    string n = x;
                                    int sp = n.IndexOf("] ");
                                    if (n.StartsWith("[") && sp > 0) n = n.Substring(sp + 2);
                                    seen.Add(n);
                                }
                            }
                            foreach (string x in src)
                            {
                                if (x == null) continue;
                                string n = x;
                                int sp = n.IndexOf("] ");
                                if (n.StartsWith("[") && sp > 0) n = n.Substring(sp + 2);
                                if (seen.Add(n))
                                    dstMerged.Add(x); // keep original tag format
                            }
                        }
                        FillTables(txtDstTable, dstMerged, true);
                    }));
                }
                catch { }
            });
        }

        private static void FillTables(ComboBox cb, List<string> items, bool tablesOnly)
        {
            if (cb == null || items == null) return;
            string keep = SafeComboText(cb);
            List<string> all = new List<string>();
            cb.BeginUpdate();
            cb.Items.Clear();
            foreach (string x in items)
            {
                if (tablesOnly && x.StartsWith("[VIEW] ")) continue;
                string n = x;
                int sp = n.IndexOf("] ");
                if (n.StartsWith("[") && sp > 0) n = n.Substring(sp + 2);
                all.Add(n);
                cb.Items.Add(n);
            }
            cb.Tag = all;   // full list for live search filter
            cb.EndUpdate();
            SafeSetComboText(cb, keep);
        }

        private static void SetCueBanner(Control tb, string text)
        {
            if (!(tb is TextBox) || !tb.IsHandleCreated) return;
            try { SendMessage(tb.Handle, EM_SETCUEBANNER, (IntPtr)1, text ?? ""); } catch { }
        }

        private void UpdateTypeUi()
        {
            if (!_uiReady || cbType == null) return;
            int ti = cbType.SelectedIndex;
            if (ti < 0) ti = 0;
            bool transfer = ti == 0;
            bool api = ti == 3;
            // BOTH T-SQL types get the linked-server bypass in Engine.ExecuteStep (SqlOnSource and
            // SqlOnDest), so their statements really are converted to a Transfer by SyncDB and the
            // write / RAM / CPU options below do apply. "T-SQL on Source" used to grey them all out.
            bool sqlAny = ti == 1 || ti == 2;
            bool writeOpts = transfer || api || sqlAny;

            if (transferPanel != null) transferPanel.Enabled = writeOpts;
            if (txtSrcTable != null) txtSrcTable.Enabled = transfer; // only pure Transfer uses Source table field
            if (txtDstTable != null) txtDstTable.Enabled = transfer || api; // T-SQL dest table is inside Command
            if (chkWriteMode != null) chkWriteMode.Enabled = writeOpts;
            if (cbMode != null) cbMode.Enabled = writeOpts && chkWriteMode != null && chkWriteMode.Checked;
            if (txtDeleteWhere != null) txtDeleteWhere.Enabled = writeOpts;
            int modeIdx = (cbMode != null) ? cbMode.SelectedIndex : 0;
            bool needsKeys = (modeIdx == 3 || modeIdx == 4); // Merge or Sync changes AUTO
            // Key columns always editable when write options on; required only at run for Merge/Sync
            if (txtKeyColumns != null)
            {
                txtKeyColumns.Enabled = writeOpts;
                if (rbKeyIdxNonclustered != null)
                {
                    rbKeyIdxNonclustered.Enabled = writeOpts;
                    if (rbKeyIdxUniqueNc != null) rbKeyIdxUniqueNc.Enabled = writeOpts;
                    if (rbKeyIdxClusteredPk != null) rbKeyIdxClusteredPk.Enabled = writeOpts;
                }
                try
                {
                    SetCueBanner(txtKeyColumns, needsKeys
                        ? (Lang.Fa ? "پیشنهادی برای Merge/Sync — مثلاً id (ایندکس خودکار)" : "Recommended for Merge/Sync — e.g. id (auto index)")
                        : (Lang.Fa ? "اختیاری — اگر پر شود ایندکس روی Dest ساخته می‌شود" : "Optional — if set, index is created on Dest"));
                }
                catch { }
            }
            if (txtIncrementalCol != null) txtIncrementalCol.Enabled = writeOpts;
            if (chkChangeTracking != null) chkChangeTracking.Enabled = writeOpts;
            if (chkCdc != null) chkCdc.Enabled = writeOpts;
            if (chkDeltaRv != null) chkDeltaRv.Enabled = writeOpts;
            if (chkDeltaCol != null) chkDeltaCol.Enabled = writeOpts;
            if (chkDeltaHash != null) chkDeltaHash.Enabled = writeOpts;
            if (chkDestMT != null) chkDestMT.Enabled = writeOpts;
            if (chkSrcMT != null) chkSrcMT.Enabled = writeOpts && !api;
            if (numThreads != null) numThreads.Enabled = writeOpts && (chkDestMT == null || chkDestMT.Checked);
            if (numSourceThreads != null) numSourceThreads.Enabled = writeOpts && !api && (chkSrcMT == null || chkSrcMT.Checked);
            if (cbIdxMode != null) cbIdxMode.Enabled = writeOpts;
            if (numIdxDays != null && cbIdxMode != null) numIdxDays.Enabled = writeOpts && cbIdxMode.SelectedIndex == 2;
            if (numBatch != null) numBatch.Enabled = writeOpts;
            if (numDelay != null) numDelay.Enabled = writeOpts;
            if (cbPriority != null) cbPriority.Enabled = writeOpts;
            if (cbBuffer != null) cbBuffer.Enabled = writeOpts;
            if (numRamLimit != null) numRamLimit.Enabled = writeOpts;
            if (chkBufAuto != null)
            {
                chkBufAuto.Enabled = writeOpts;
                chkBufRam.Enabled = writeOpts;
                chkBufStream.Enabled = writeOpts;
                chkBufDisk.Enabled = writeOpts;
            }
            if (chkCacheLiteDb != null)
            {
                chkCacheLiteDb.Enabled = writeOpts;
                chkCacheLevelDb.Enabled = writeOpts;
                chkCacheFaster.Enabled = writeOpts;
            }
            if (txtSql != null) txtSql.Enabled = !api;
            if (_sqlBtns != null) _sqlBtns.Enabled = !api;
            if (lblApi != null) lblApi.Visible = api;
            if (apiPanel != null) apiPanel.Visible = api;

            if (cbApiMethod != null && txtApiBody != null)
            {
                bool post = cbApiMethod.SelectedIndex >= 1; // POST/PUT/PATCH
                txtApiBody.Enabled = post;
            }

            int au = (cbApiAuth != null) ? cbApiAuth.SelectedIndex : 0;
            bool bearer = (au == 1);
            bool basic = (au == 2);
            bool apikey = (au == 3);
            if (txtApiToken != null) txtApiToken.Enabled = bearer || apikey;
            if (txtApiKeyHeader != null) txtApiKeyHeader.Enabled = apikey;
            if (txtApiUser != null) txtApiUser.Enabled = basic || bearer;
            if (txtApiPass != null) txtApiPass.Enabled = basic || bearer;
            if (txtApiAuthUrl != null) txtApiAuthUrl.Enabled = api && (bearer || au == 0);
            if (basic)
            {
                if (txtApiUser != null) txtApiUser.Enabled = true;
                if (txtApiPass != null) txtApiPass.Enabled = true;
                if (txtApiToken != null) txtApiToken.Enabled = false;
                if (txtApiKeyHeader != null) txtApiKeyHeader.Enabled = false;
            }
            if (api)
            {
                SetCueBanner(txtDstTable, "مثلاً dbo.MyTable — اگر نباشد ساخته می‌شود");
                SetCueBanner(txtApiUrl, "http://server/api/v2/...");
                SetCueBanner(txtApiAuthUrl, "http://server/api/v2/user/session");
                SetCueBanner(txtApiToken, "Bearer token یا API Key");
                SetCueBanner(txtApiKeyHeader, "ApiKey یا X-Api-Key");
                SetCueBanner(txtApiUser, "email یا username");
                SetCueBanner(txtApiPath, "data   یا  data.items");
                SetCueBanner(txtApiHeaders, "Name: Value  (هر خط یک هدر)");
                SetCueBanner(txtKeyColumns, "Id یا Code,Id");
                SetCueBanner(txtIncrementalCol, "ModifiedDate یا UpdateDate");
            }
            else
            {
                SetCueBanner(txtDstTable, "مثلاً dbo.MyTable");
                SetCueBanner(txtKeyColumns, "Id یا Code,Id  (برای Merge)");
                SetCueBanner(txtIncrementalCol, "ModifiedDate — فقط آخرین تغییرات");
            }
        }


        private int _apiPreviewMaxRows = 10;

        /// <summary>Save step fields, then execute API→SQL Server (writes destination). Separate from Test API.</summary>
        private void RunApiToSqlServer()
        {
            if (!SaveData()) return;
            if (step.Type != StepType.ApiToDest)
            {
                MessageBox.Show(this,
                    Lang.Fa ? "نوع Step باید Web API → Destination باشد." : "Step type must be Web API → Destination.",
                    "SQL Server", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(step.ApiUrl) || string.IsNullOrWhiteSpace(step.DestTable))
            {
                MessageBox.Show(this,
                    Lang.Fa ? "URL و جدول مقصد الزامی است." : "URL and destination table are required.",
                    "SQL Server", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (MessageBox.Show(this,
                    Lang.Fa
                        ? ("داده‌ها از API خوانده و در SQL Server نوشته می‌شوند.\r\n"
                           + "Batch size (هر بار چند ردیف نوشته شود) = " + step.BatchSize + "\r\n"
                           + "Max pages (چند صفحه از API) = " + step.ApiMaxPages + "\r\n"
                           + "ادامه؟")
                        : ("Data will be read from the API and written to SQL Server.\r\n"
                           + "Batch size (rows per SQL write) = " + step.BatchSize + "\r\n"
                           + "Max pages (API pages to fetch) = " + step.ApiMaxPages + "\r\n"
                           + "Continue?"),
                    "Run to SQL Server", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;
            try
            {
                Cursor = Cursors.WaitCursor;
                AppConfig cfg = _cfg ?? AppConfig.Load();
                SyncJob j = new SyncJob();
                j.Id = System.Guid.NewGuid().ToString("N");
                j.Name = "API→SQL " + (step.Name ?? "step");
                j.Enabled = true;
                j.CommandTimeoutSec = 300;
                j.EnsureSteps();
                j.Steps.Clear();
                JobStep one = step; // already saved into this.step
                one.Enabled = true;
                j.Steps.Add(one);
                RunResult r = Engine.ExecuteJob(j, cfg, "test");
                MessageBox.Show(this,
                    (r.Ok ? (Lang.Fa ? "موفق\r\n" : "OK\r\n") : (Lang.Fa ? "خطا\r\n" : "Failed\r\n"))
                    + (r.Message ?? "") + "\r\nRows=" + r.Rows,
                    "Run to SQL Server",
                    MessageBoxButtons.OK,
                    r.Ok ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Run to SQL Server", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { try { Cursor = Cursors.Default; } catch { } }
        }

        private void TestApiConnection()
        {
            string url = (txtApiUrl.Text ?? "").Trim();
            if (url.Length == 0)
            {
                MessageBox.Show(this, Lang.Fa ? "ابتدا URL را وارد کنید." : "Enter the URL first.",
                    "Test API", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                Cursor = Cursors.WaitCursor;
                string method = cbApiMethod.SelectedItem != null ? cbApiMethod.SelectedItem.ToString() : "GET";
                System.Net.HttpWebRequest req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(url);
                req.Method = method;
                req.Timeout = 60000;
                req.ReadWriteTimeout = 60000;
                req.UserAgent = "SyncDB-Test/1.0";
                if (chkApiIgnoreCert != null && chkApiIgnoreCert.Checked)
                    System.Net.ServicePointManager.ServerCertificateValidationCallback = (a, b, c, d) => true;
                int auth = cbApiAuth != null ? cbApiAuth.SelectedIndex : 0;
                string bearerTok = (txtApiToken != null ? txtApiToken.Text : null) ?? "";
                // Same as job run: Auth URL + user/pass → refresh token before test
                if (!string.IsNullOrWhiteSpace(txtApiAuthUrl != null ? txtApiAuthUrl.Text : null) &&
                    (auth == 1 || auth == 0) &&
                    (!string.IsNullOrWhiteSpace(txtApiUser != null ? txtApiUser.Text : null) ||
                     !string.IsNullOrWhiteSpace(txtApiPass != null ? txtApiPass.Text : null)))
                {
                    try
                    {
                        // reuse engine path via temporary step fields
                        JobStep tmp = new JobStep();
                        tmp.ApiAuthUrl = (txtApiAuthUrl.Text ?? "").Trim();
                        tmp.ApiUser = txtApiUser != null ? (txtApiUser.Text ?? "") : "";
                        tmp.ApiPassword = txtApiPass != null ? (txtApiPass.Text ?? "") : "";
                        tmp.ApiIgnoreCert = chkApiIgnoreCert != null && chkApiIgnoreCert.Checked;
                        tmp.ApiAuth = auth == 1 ? ApiAuthType.Bearer : ApiAuthType.None;
                        tmp.ApiToken = bearerTok;
                        tmp.ApiMethod = method;
                        tmp.ApiUrl = url;
                        // Call through a one-shot: duplicate minimal token fetch by reflecting engine is hard;
                        // inline same JSON login as Engine.TryFetchApiToken
                        string authUrl = tmp.ApiAuthUrl;
                        System.Net.HttpWebRequest ar = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(authUrl);
                        ar.Method = "POST";
                        ar.ContentType = "application/json";
                        ar.Accept = "application/json";
                        ar.Timeout = 30000;
                        if (tmp.ApiIgnoreCert)
                            ar.ServerCertificateValidationCallback = delegate { return true; };
                        string abody = "{\"email\":\"" + (tmp.ApiUser ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"") +
                            "\",\"password\":\"" + (tmp.ApiPassword ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"") +
                            "\",\"username\":\"" + (tmp.ApiUser ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"}";
                        byte[] ab = Encoding.UTF8.GetBytes(abody);
                        ar.ContentLength = ab.Length;
                        using (Stream ast = ar.GetRequestStream()) ast.Write(ab, 0, ab.Length);
                        using (System.Net.HttpWebResponse aresp = (System.Net.HttpWebResponse)ar.GetResponse())
                        using (StreamReader asr = new StreamReader(aresp.GetResponseStream(), Encoding.UTF8))
                        {
                            string aj = asr.ReadToEnd() ?? "";
                            try
                            {
                                JToken root = JToken.Parse(aj);
                                string[] keys = new string[] { "token", "Token", "access_token", "accessToken", "bearerToken", "BearerToken", "jwt", "id_token" };
                                foreach (string k in keys)
                                {
                                    JToken jt = root[k];
                                    if (jt != null && jt.Type == JTokenType.String && !string.IsNullOrWhiteSpace(jt.ToString()))
                                    { bearerTok = jt.ToString(); break; }
                                }
                            }
                            catch { }
                        }
                        if (!string.IsNullOrWhiteSpace(bearerTok) && txtApiToken != null)
                            txtApiToken.Text = bearerTok; // show refreshed token in UI
                    }
                    catch { /* keep existing token */ }
                }
                if (auth == 1 && !string.IsNullOrWhiteSpace(bearerTok))
                    req.Headers["Authorization"] = "Bearer " + bearerTok.Trim();
                else if (auth == 2 && !string.IsNullOrWhiteSpace(txtApiUser.Text))
                {
                    string pair = (txtApiUser.Text ?? "") + ":" + (txtApiPass.Text ?? "");
                    req.Headers["Authorization"] = "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(pair));
                }
                else if (auth == 3 && !string.IsNullOrWhiteSpace(txtApiToken.Text))
                {
                    string hn = string.IsNullOrWhiteSpace(txtApiKeyHeader.Text) ? "ApiKey" : txtApiKeyHeader.Text.Trim();
                    req.Headers[hn] = txtApiToken.Text.Trim();
                }
                if (txtApiHeaders != null && !string.IsNullOrWhiteSpace(txtApiHeaders.Text))
                {
                    foreach (string line in txtApiHeaders.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        int c = line.IndexOf(':');
                        if (c <= 0) continue;
                        string hk = line.Substring(0, c).Trim();
                        string hv = line.Substring(c + 1).Trim();
                        if (hk.Length == 0) continue;
                        if (string.Equals(hk, "Content-Type", StringComparison.OrdinalIgnoreCase))
                            req.ContentType = hv;
                        else
                            try { req.Headers[hk] = hv; } catch { }
                    }
                }
                if (method != "GET" && method != "HEAD" && txtApiBody != null && !string.IsNullOrEmpty(txtApiBody.Text))
                {
                    if (string.IsNullOrEmpty(req.ContentType)) req.ContentType = "application/json; charset=utf-8";
                    byte[] data = Encoding.UTF8.GetBytes(txtApiBody.Text);
                    req.ContentLength = data.Length;
                    using (Stream rs = req.GetRequestStream())
                        rs.Write(data, 0, data.Length);
                }

                string body = "";
                int code = 0;
                string status = "";
                bool ok = false;
                try
                {
                    using (System.Net.HttpWebResponse resp = (System.Net.HttpWebResponse)req.GetResponse())
                    {
                        code = (int)resp.StatusCode;
                        status = resp.StatusDescription;
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                            body = sr.ReadToEnd() ?? "";
                        ok = true;
                    }
                }
                catch (System.Net.WebException wex)
                {
                    System.Net.HttpWebResponse er = wex.Response as System.Net.HttpWebResponse;
                    if (er != null)
                    {
                        code = (int)er.StatusCode;
                        status = er.StatusDescription;
                        try
                        {
                            using (StreamReader sr = new StreamReader(er.GetResponseStream(), Encoding.UTF8))
                                body = sr.ReadToEnd() ?? "";
                        }
                        catch { body = wex.Message; }
                    }
                    else
                    {
                        body = wex.Message;
                        status = wex.Status.ToString();
                    }
                    ok = false;
                }

                ShowApiTestResult(ok, code, status, body);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, (Lang.Fa ? "خطا در ارتباط:\r\n" : "Connection error:\r\n") + ex.Message,
                    "Test API", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { try { Cursor = Cursors.Default; } catch { } }
        }

        /// <summary>Show HTTP result as a grid (preview). Full JSON can be saved to a file.</summary>
        private void ShowApiTestResult(bool ok, int code, string status, string body)
        {
            using (Form dlg = new Form())
            {
                dlg.Text = (ok ? "OK" : "Error") + "  HTTP " + code + " " + (status ?? "");
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.Size = new Size(920, 580);
                dlg.MinimizeBox = false;
                dlg.ShowIcon = false;

                Panel top = new Panel { Dock = DockStyle.Top, Height = 40 };
                Label hdr = new Label
                {
                    AutoSize = true, Left = 10, Top = 10,
                    Text = (ok ? (Lang.Fa ? "موفق — " : "OK — ") : (Lang.Fa ? "خطا — " : "Failed — "))
                        + "HTTP " + code + " " + (status ?? "")
                };
                Label lblPrev = new Label { Text = Lang.Fa ? "پیش‌نمایش ردیف:" : "Preview rows:", AutoSize = true, Left = 420, Top = 12 };
                NumericUpDown numPrev = new NumericUpDown { Minimum = 1, Maximum = 5000, Value = Math.Max(1, Math.Min(5000, _apiPreviewMaxRows)), Width = 60, Left = 520, Top = 8 };
                Button btnApplyPrev = new Button { Text = Lang.Fa ? "اعمال" : "Apply", Width = 70, Left = 590, Top = 7 };
                top.Controls.Add(hdr);
                top.Controls.Add(lblPrev);
                top.Controls.Add(numPrev);
                top.Controls.Add(btnApplyPrev);

                DataGridView grid = new DataGridView
                {
                    Dock = DockStyle.Fill,
                    ReadOnly = true,
                    AllowUserToAddRows = false,
                    AllowUserToDeleteRows = false,
                    AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells,
                    BackgroundColor = Color.White,
                    RowHeadersVisible = false
                };
                TextBox tbRaw = new TextBox
                {
                    Dock = DockStyle.Fill, Multiline = true, ScrollBars = ScrollBars.Both,
                    Font = new Font("Consolas", 9.5f), WordWrap = false, ReadOnly = true, Visible = false
                };

                Panel bottom = new Panel { Dock = DockStyle.Bottom, Height = 48 };
                Label tip = new Label { AutoSize = true, Left = 12, Top = 14, Text = "" };
                Button btnSave = new Button { Text = Lang.Fa ? "ذخیره همه در فایل…" : "Save all to file...", Width = 150, Left = 520, Top = 10 };
                Button btnClose = new Button { Text = Lang.Fa ? "بستن" : "Close", Width = 90, Left = 680, Top = 10, DialogResult = DialogResult.OK };
                btnSave.Click += (s, e) => SaveTextFile(body ?? "", "api_response.json");
                bottom.Controls.Add(tip);
                bottom.Controls.Add(btnSave);
                bottom.Controls.Add(btnClose);

                Action fill = () =>
                {
                    _apiPreviewMaxRows = (int)numPrev.Value;
                    DataTable table = null;
                    int totalRows = 0;
                    string parseNote = "";
                    try
                    {
                        string jpath = (txtApiPath != null ? txtApiPath.Text : null);
                        table = JsonToPreviewTable(body, jpath, _apiPreviewMaxRows, out totalRows, out parseNote);
                    }
                    catch (Exception ex) { parseNote = ex.Message; }

                    hdr.Text = (ok ? (Lang.Fa ? "موفق — " : "OK — ") : (Lang.Fa ? "خطا — " : "Failed — "))
                        + "HTTP " + code + " " + (status ?? "")
                        + (totalRows > 0
                            ? (Lang.Fa
                                ? ("  |  " + totalRows + " ردیف (نمایش تا " + _apiPreviewMaxRows + ")")
                                : ("  |  " + totalRows + " rows (show max " + _apiPreviewMaxRows + ")"))
                            : "");

                    if (table != null && table.Columns.Count > 0)
                    {
                        tbRaw.Visible = false;
                        grid.Visible = true;
                        grid.DataSource = table;
                        tip.Text = totalRows > _apiPreviewMaxRows
                            ? (Lang.Fa
                                ? ("فقط " + _apiPreviewMaxRows + " ردیف در جدول. بقیه در فایل.")
                                : ("Only " + _apiPreviewMaxRows + " rows in grid. Rest in file."))
                            : (Lang.Fa ? "برای پاسخ کامل خام، ذخیره کنید." : "Save file for full raw response.");
                    }
                    else
                    {
                        grid.Visible = false;
                        tbRaw.Visible = true;
                        tbRaw.Text = string.IsNullOrEmpty(body) ? parseNote : body;
                        tip.Text = Lang.Fa ? "پاسخ جدول نیست؛ متن خام." : "Not a table; raw text.";
                    }
                };
                btnApplyPrev.Click += (s, e) => fill();
                fill();

                dlg.Controls.Add(grid);
                dlg.Controls.Add(tbRaw);
                dlg.Controls.Add(top);
                dlg.Controls.Add(bottom);
                dlg.AcceptButton = btnClose;
                Theme.Apply(dlg);
                dlg.ShowDialog(this);
            }
        }
        private static DataTable JsonToPreviewTable(string json, string jsonPath, int maxRows, out int totalRows, out string note)
        {
            totalRows = 0;
            note = "";
            DataTable dt = new DataTable();
            if (string.IsNullOrWhiteSpace(json)) { note = "empty body"; return dt; }

            List<JObject> allRows;
            try
            {
                allRows = Engine.ParseApiBodyToObjects(json, jsonPath);
            }
            catch (Exception ex)
            {
                note = ex.Message;
                return dt;
            }
            totalRows = allRows.Count;
            List<JObject> rows = new List<JObject>();
            for (int i = 0; i < allRows.Count && rows.Count < maxRows; i++)
                rows.Add(allRows[i]);

            HashSet<string> cols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            List<string> colList = new List<string>();
            foreach (JObject o in rows)
                foreach (JProperty pr in o.Properties())
                    if (cols.Add(pr.Name)) colList.Add(pr.Name);
            foreach (string c in colList)
                dt.Columns.Add(c, typeof(string));
            foreach (JObject o in rows)
            {
                DataRow dr = dt.NewRow();
                foreach (string c in colList)
                {
                    JToken v = o[c];
                    if (v == null || v.Type == JTokenType.Null) dr[c] = "";
                    else if (v.Type == JTokenType.String || v.Type == JTokenType.Integer || v.Type == JTokenType.Float || v.Type == JTokenType.Boolean)
                        dr[c] = v.ToString();
                    else
                        dr[c] = v.ToString(Newtonsoft.Json.Formatting.None);
                }
                dt.Rows.Add(dr);
            }
            note = "ok";
            return dt;
        }

        private void SaveTextFile(string content, string defaultName)
        {
            using (SaveFileDialog sd = new SaveFileDialog())
            {
                sd.Filter = "JSON/Text (*.json;*.txt)|*.json;*.txt|All files (*.*)|*.*";
                sd.FileName = defaultName;
                if (sd.ShowDialog(this) != DialogResult.OK) return;
                File.WriteAllText(sd.FileName, content ?? "", Encoding.UTF8);
                MessageBox.Show(this, Lang.Fa ? "ذخیره شد:\r\n" + sd.FileName : "Saved:\r\n" + sd.FileName,
                    "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void ExportCurlFile()
        {
            string url = (txtApiUrl.Text ?? "").Trim();
            if (url.Length == 0)
            {
                MessageBox.Show(this, Lang.Fa ? "ابتدا URL را وارد کنید." : "Enter the URL first.",
                    "cURL", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string method = cbApiMethod.SelectedItem != null ? cbApiMethod.SelectedItem.ToString() : "GET";
            StringBuilder sb = new StringBuilder();
            sb.Append("curl -X ").Append(method).Append(" '").Append(url.Replace("'", "'\\''")).Append("'");
            int auth = cbApiAuth != null ? cbApiAuth.SelectedIndex : 0;
            if (auth == 1 && !string.IsNullOrWhiteSpace(txtApiToken.Text))
                sb.Append(" \\\n  -H 'Authorization: Bearer ").Append(txtApiToken.Text.Trim().Replace("'", "'\\''")).Append("'");
            else if (auth == 2 && !string.IsNullOrWhiteSpace(txtApiUser.Text))
            {
                string pair = (txtApiUser.Text ?? "") + ":" + (txtApiPass.Text ?? "");
                sb.Append(" \\\n  -u '").Append(pair.Replace("'", "'\\''")).Append("'");
            }
            else if (auth == 3 && !string.IsNullOrWhiteSpace(txtApiToken.Text))
            {
                string hn = string.IsNullOrWhiteSpace(txtApiKeyHeader.Text) ? "ApiKey" : txtApiKeyHeader.Text.Trim();
                sb.Append(" \\\n  -H '").Append(hn).Append(": ").Append(txtApiToken.Text.Trim().Replace("'", "'\\''")).Append("'");
            }
            if (txtApiHeaders != null && !string.IsNullOrWhiteSpace(txtApiHeaders.Text))
            {
                foreach (string line in txtApiHeaders.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    string hv = line.Trim();
                    if (hv.Length == 0) continue;
                    sb.Append(" \\\n  -H '").Append(hv.Replace("'", "'\\''")).Append("'");
                }
            }
            if (method != "GET" && method != "HEAD" && txtApiBody != null && !string.IsNullOrEmpty(txtApiBody.Text))
                sb.Append(" \\\n  -H 'Content-Type: application/json' \\\n  -d '").Append(txtApiBody.Text.Replace("'", "'\\''")).Append("'");
            sb.Append("\n");
            SaveTextFile(sb.ToString(), "request.curl.txt");
        }

        private void ImportFromCurl()
        {
            using (Form dlg = new Form())
            {
                dlg.Text = Lang.Fa ? "ورود از cURL" : "Import from cURL";
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.Size = new Size(640, 420);
                dlg.MinimizeBox = false;
                dlg.MaximizeBox = true;
                dlg.ShowIcon = false;
                TextBox tb = new TextBox
                {
                    Multiline = true, ScrollBars = ScrollBars.Both, WordWrap = false,
                    Font = new Font("Consolas", 9.5f), Dock = DockStyle.Fill,
                    AcceptsReturn = true, AcceptsTab = true
                };
                Label tip = new Label
                {
                    Dock = DockStyle.Top, Height = 36, Padding = new Padding(8, 6, 8, 0),
                    Text = Lang.Fa
                        ? "دستور curl را از Postman / مرورگر اینجا بچسبانید."
                        : "Paste a curl command from Postman / browser."
                };
                Panel bottom = new Panel { Dock = DockStyle.Bottom, Height = 44 };
                Button ok = new Button { Text = Lang.Fa ? "اعمال" : "Apply", Width = 90, DialogResult = DialogResult.OK, Left = 420, Top = 8 };
                Button cancel = new Button { Text = Lang.Fa ? "انصراف" : "Cancel", Width = 90, DialogResult = DialogResult.Cancel, Left = 520, Top = 8 };
                bottom.Controls.Add(ok);
                bottom.Controls.Add(cancel);
                dlg.Controls.Add(tb);
                dlg.Controls.Add(tip);
                dlg.Controls.Add(bottom);
                dlg.AcceptButton = ok;
                dlg.CancelButton = cancel;
                Theme.Apply(dlg);
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                ApplyCurl(tb.Text ?? "");
            }
        }

        private void ApplyCurl(string curl)
        {
            if (string.IsNullOrWhiteSpace(curl)) return;
            curl = curl.Replace("\\\r\n", " ").Replace("\\\n", " ").Replace("\r", " ");
            var mX = System.Text.RegularExpressions.Regex.Match(curl, @"\s-X\s+([A-Za-z]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (mX.Success)
            {
                string meth = mX.Groups[1].Value.ToUpperInvariant();
                int idx = cbApiMethod.Items.IndexOf(meth);
                if (idx >= 0) cbApiMethod.SelectedIndex = idx;
            }
            else if (System.Text.RegularExpressions.Regex.IsMatch(curl, @"\s--data(-raw|-binary)?\s+|\s-d\s+", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
            {
                int idx = cbApiMethod.Items.IndexOf("POST");
                if (idx >= 0) cbApiMethod.SelectedIndex = idx;
            }
            var mUrl = System.Text.RegularExpressions.Regex.Match(curl, @"['""](https?://[^'""\s]+)['""]|(https?://[^\s'""\\]+)");
            if (mUrl.Success)
                txtApiUrl.Text = mUrl.Groups[1].Success ? mUrl.Groups[1].Value : mUrl.Groups[2].Value;
            var headers = new System.Text.StringBuilder();
            foreach (System.Text.RegularExpressions.Match mh in System.Text.RegularExpressions.Regex.Matches(
                curl, @"-H\s+['""]([^'""]+)['""]", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
            {
                string hv = mh.Groups[1].Value.Trim();
                if (hv.StartsWith("Authorization:", StringComparison.OrdinalIgnoreCase))
                {
                    string val = hv.Substring("Authorization:".Length).Trim();
                    if (val.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                    {
                        cbApiAuth.SelectedIndex = 1;
                        txtApiToken.Text = val.Substring(7).Trim();
                    }
                    else if (val.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
                    {
                        cbApiAuth.SelectedIndex = 2;
                        try
                        {
                            string decoded = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(val.Substring(6).Trim()));
                            int c = decoded.IndexOf(':');
                            if (c >= 0) { txtApiUser.Text = decoded.Substring(0, c); txtApiPass.Text = decoded.Substring(c + 1); }
                        }
                        catch { txtApiToken.Text = val; }
                    }
                    continue;
                }
                if (headers.Length > 0) headers.AppendLine();
                headers.Append(hv);
            }
            if (headers.Length > 0) txtApiHeaders.Text = headers.ToString();
            var mu = System.Text.RegularExpressions.Regex.Match(curl, @"\s-u\s+['""]?([^'""\s]+)['""]?");
            if (mu.Success)
            {
                cbApiAuth.SelectedIndex = 2;
                string up = mu.Groups[1].Value;
                int c = up.IndexOf(':');
                if (c >= 0) { txtApiUser.Text = up.Substring(0, c); txtApiPass.Text = up.Substring(c + 1); }
                else txtApiUser.Text = up;
            }
            var md = System.Text.RegularExpressions.Regex.Match(curl,
                @"(?:--data-raw|--data-binary|--data|-d)\s+(['""])([\s\S]*?)\1",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (md.Success)
                txtApiBody.Text = md.Groups[2].Value;
            else
            {
                md = System.Text.RegularExpressions.Regex.Match(curl,
                    @"(?:--data-raw|--data-binary|--data|-d)\s+(\S+)",
                    System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                if (md.Success) txtApiBody.Text = md.Groups[1].Value.Trim('\'', '"');
            }
            UpdateTypeUi();
            MessageBox.Show(this,
                Lang.Fa ? "فیلدهای Web API از cURL پر شدند." : "Web API fields filled from cURL.",
                "Import cURL", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void LoadData()
        {
            txtName.Text = step.Name ?? "";
            cbType.SelectedIndex = Math.Max(0, Math.Min(3, (int)step.Type));
            // select Database combo by TargetConnectionId
            if (cbDatabase != null && _connList != null)
            {
                int sel = 0;
                if (!string.IsNullOrWhiteSpace(step.TargetConnectionId))
                {
                    for (int i = 0; i < _connList.Count; i++)
                        if (_connList[i] != null && _connList[i].Id == step.TargetConnectionId) { sel = i; break; }
                }
                if (sel < cbDatabase.Items.Count) cbDatabase.SelectedIndex = sel;
            }
            txtSql.Text = step.SqlCommand ?? "";
            _srcTableTyped = step.SourceTable ?? "";
            _dstTableTyped = step.DestTable ?? "";
            SafeSetComboText(txtSrcTable, _srcTableTyped);
            SafeSetComboText(txtDstTable, _dstTableTyped);
            cbMode.SelectedIndex = Math.Max(0, Math.Min(5, (int)step.Mode));
            // an older step that already uses a mode other than Append comes up ticked
            if (chkWriteMode != null) chkWriteMode.Checked = step.WriteModeOn || step.Mode != WriteMode.Append;
            txtDeleteWhere.Text = step.DestDeleteWhere ?? "";
            if (txtKeyColumns != null) txtKeyColumns.Text = step.KeyColumns ?? "";
            if (rbKeyIdxNonclustered != null)
            {
                if (step.KeyIndexClustered)
                    rbKeyIdxClusteredPk.Checked = true;
                else if (step.KeyIndexUnique)
                    rbKeyIdxUniqueNc.Checked = true;
                else
                    rbKeyIdxNonclustered.Checked = true;
            }
            if (txtIncrementalCol != null) txtIncrementalCol.Text = step.IncrementalColumn ?? "";
            if (chkChangeTracking != null) chkChangeTracking.Checked = step.UseChangeTracking;
            if (chkCdc != null) chkCdc.Checked = step.UseCdc;
            // Smart Delta method checkboxes
            bool rv = step.DeltaUseRv, col = step.DeltaUseCol, hash = step.DeltaUseHash;
            string dm = (step.DeltaMethod ?? "Auto").Trim();
            if (dm.Equals("RV", StringComparison.OrdinalIgnoreCase) && rv && col && hash)
            { rv = true; col = false; hash = false; }
            else if (dm.Equals("COL", StringComparison.OrdinalIgnoreCase) && rv && col && hash)
            { rv = false; col = true; hash = false; }
            else if (dm.Equals("HASH", StringComparison.OrdinalIgnoreCase) && rv && col && hash)
            { rv = false; col = false; hash = true; }
            else if (dm.IndexOf('+') >= 0)
            {
                rv = dm.IndexOf("RV", StringComparison.OrdinalIgnoreCase) >= 0;
                col = dm.IndexOf("COL", StringComparison.OrdinalIgnoreCase) >= 0;
                hash = dm.IndexOf("HASH", StringComparison.OrdinalIgnoreCase) >= 0;
            }
            if (chkDeltaRv != null) chkDeltaRv.Checked = rv;
            if (chkDeltaCol != null) chkDeltaCol.Checked = col;
            if (chkDeltaHash != null) chkDeltaHash.Checked = hash;
            if (cbDeltaMethod != null)
            {
                int di = cbDeltaMethod.Items.IndexOf(dm);
                cbDeltaMethod.SelectedIndex = di >= 0 ? di : 0;
            }
            numBatch.Value = Math.Max(0, Math.Min(1000000, step.BatchSize));
            chkDestMT.Checked = step.MaxThreads != 1;
            numThreads.Value = step.MaxThreads == 1 ? 0 : Math.Max(0, Math.Min(64, step.MaxThreads < 0 ? 0 : step.MaxThreads));
            chkSrcMT.Checked = step.SourceThreads != 1;
            numSourceThreads.Value = step.SourceThreads == 1 ? 0 : Math.Max(0, Math.Min(64, step.SourceThreads < 0 ? 0 : step.SourceThreads));
            {
                IndexRebuildKind ik = step.IndexRebuild;
                if (ik == IndexRebuildKind.Off && step.RebuildIndexesAfter) ik = IndexRebuildKind.AfterEveryRun;
                cbIdxMode.SelectedIndex = Math.Max(0, Math.Min(2, (int)ik));
                numIdxDays.Value = Math.Max(1, Math.Min(3650, step.IndexRebuildDays < 1 ? 7 : step.IndexRebuildDays));
                lblIdxLast.Text = step.IndexLastRebuildUtc.HasValue
                    ? Lang.T("Last rebuild: " + step.IndexLastRebuildUtc.Value.ToLocalTime().ToString("yyyy-MM-dd HH:mm"))
                    : Lang.T("Last rebuild: never");
            }
            numDelay.Value = Math.Max(0, Math.Min(60000, step.DelayMs));
            cbPriority.SelectedIndex = Math.Max(0, Math.Min(2, (int)step.Priority));
            cbBuffer.SelectedIndex = Math.Max(0, Math.Min(3, (int)step.Buffer));
            numRamLimit.Value = Math.Max(16, Math.Min(65536, step.RamLimitMb > 0 ? step.RamLimitMb : 256));
            if (chkBufAuto != null)
            {
                chkBufAuto.Checked = step.Buffer == BufferMode.Auto;
                chkBufRam.Checked = step.Buffer == BufferMode.Ram;
                chkBufStream.Checked = step.Buffer == BufferMode.Stream;
                chkBufDisk.Checked = step.Buffer == BufferMode.Disk;
            }
            if (chkCacheLiteDb != null)
            {
                chkCacheLiteDb.Checked = step.CacheUseLiteDb;
                chkCacheLevelDb.Checked = step.CacheUseLevelDb;
                chkCacheFaster.Checked = step.CacheUseFaster;
            }
            cbOnSuccess.SelectedIndex = Math.Max(0, Math.Min(2, (int)step.OnSuccess));
            cbOnFail.SelectedIndex = Math.Max(0, Math.Min(2, (int)step.OnFailure));
            numRetry.Value = Math.Max(0, step.RetryAttempts);
            numRetryMin.Value = Math.Max(0, step.RetryIntervalMinutes);
            chkContinueOnErr.Checked = step.ContinueOnBatchError;

            txtApiUrl.Text = step.ApiUrl ?? "";
            {
                string am = (step.ApiMethod ?? "GET").Trim().ToUpperInvariant();
                if (am == "POST") cbApiMethod.SelectedIndex = 1;
                else if (am == "PUT") cbApiMethod.SelectedIndex = 2;
                else if (am == "PATCH") cbApiMethod.SelectedIndex = 3;
                else cbApiMethod.SelectedIndex = 0;
            }
            cbApiAuth.SelectedIndex = Math.Max(0, Math.Min(3, (int)step.ApiAuth));
            txtApiToken.Text = step.ApiToken ?? "";
            if (txtApiAuthUrl != null) txtApiAuthUrl.Text = step.ApiAuthUrl ?? "";
            if (txtApiKeyHeader != null) txtApiKeyHeader.Text = string.IsNullOrWhiteSpace(step.ApiKeyHeader) ? "ApiKey" : step.ApiKeyHeader;
            txtApiUser.Text = step.ApiUser ?? "";
            txtApiPass.Text = step.ApiPassword ?? "";
            txtApiHeaders.Text = (step.ApiHeaders ?? "").Replace("\r\n", "\n").Replace("\n", "\r\n");
            txtApiBody.Text = step.ApiBody ?? "";
            txtApiPath.Text = step.ApiJsonPath ?? "";
            txtPageParam.Text = step.ApiPageParam ?? "";
            txtPageSizeParam.Text = step.ApiPageSizeParam ?? "";
            numPageSize.Value = Math.Max(0, Math.Min((int)numPageSize.Maximum, step.ApiPageSize));
            numMaxPages.Value = Math.Max(1, Math.Min((int)numMaxPages.Maximum, step.ApiMaxPages > 0 ? step.ApiMaxPages : 1000));
            chkApiIgnoreCert.Checked = step.ApiIgnoreCert;
            _uiReady = true;
            UpdateTypeUi();
            // only once - LoadData runs again on every Previous / Next
            if (!_shownHooked)
            {
                _shownHooked = true;
                Shown += (s, e) => { if (_uiReady) UpdateTypeUi(); LoadTableLists(); };
            }
        }


        /// <summary>Safe read of ComboBox.Text — avoids ArgumentOutOfRangeException when Items.Count==0 (known WinForms bug on .NET Framework).</summary>
        private static string SafeComboText(ComboBox cb)
        {
            if (cb == null) return "";
            try
            {
                // Even when Items.Count==0 the user may have typed a value; try read first.
                string t = cb.Text;
                return (t ?? "").Trim();
            }
            catch (System.ArgumentOutOfRangeException)
            {
                // Classic WinForms bug: get_Text -> Items[0] when collection is empty.
                return "";
            }
            catch (System.ArgumentException) { return ""; }
            catch { return ""; }
        }

        /// <summary>Safe set of ComboBox.Text without crashing on empty Items (known WinForms bug).</summary>
        private static void SafeSetComboText(ComboBox cb, string value)
        {
            if (cb == null) return;
            string v = value ?? "";
            try
            {
                if (cb.Items.Count == 0 && !string.IsNullOrEmpty(v))
                {
                    // Temporarily put the value into Items so the control accepts .Text
                    cb.BeginUpdate();
                    try
                    {
                        cb.Items.Add(v);
                        cb.SelectedIndex = 0;
                        cb.Text = v;
                        // Keep the typed value visible even after we clear the temporary list
                        cb.Items.Clear();
                        try { cb.Text = v; } catch { }
                    }
                    finally { cb.EndUpdate(); }
                    return;
                }
                cb.Text = v;
            }
            catch
            {
                try { cb.Text = v; } catch { }
            }
        }

        private bool SaveData()
        {
            string n = (txtName.Text ?? "").Trim();
            if (n.Length == 0)
            {
                MessageBox.Show("Step name is required.");
                return false;
            }
            step.Name = n;
            step.Type = (StepType)cbType.SelectedIndex;
            if (cbDatabase != null && _connList != null && cbDatabase.SelectedIndex >= 0 && cbDatabase.SelectedIndex < _connList.Count)
            {
                ConnectionProfile cp = _connList[cbDatabase.SelectedIndex];
                step.TargetConnectionId = cp != null ? cp.Id : "";
            }
            else step.TargetConnectionId = "";
            step.SqlCommand = txtSql.Text ?? "";
            {
                string st = SafeComboText(txtSrcTable);
                if (string.IsNullOrWhiteSpace(st) && !string.IsNullOrWhiteSpace(_srcTableTyped)) st = _srcTableTyped.Trim();
                step.SourceTable = st;
                string dt = SafeComboText(txtDstTable);
                if (string.IsNullOrWhiteSpace(dt) && !string.IsNullOrWhiteSpace(_dstTableTyped)) dt = _dstTableTyped.Trim();
                step.DestTable = dt;
            }
            bool wmOn = chkWriteMode == null || chkWriteMode.Checked;
            step.WriteModeOn = chkWriteMode != null && chkWriteMode.Checked;
            step.Mode = wmOn ? (WriteMode)cbMode.SelectedIndex : WriteMode.Append;
            step.DestDeleteWhere = (txtDeleteWhere.Text ?? "").Trim();
            step.KeyColumns = txtKeyColumns != null ? (txtKeyColumns.Text ?? "").Trim() : "";
            if (rbKeyIdxClusteredPk != null && rbKeyIdxClusteredPk.Checked)
            {
                step.KeyIndexClustered = true;
                step.KeyIndexUnique = true;
            }
            else if (rbKeyIdxUniqueNc != null && rbKeyIdxUniqueNc.Checked)
            {
                step.KeyIndexClustered = false;
                step.KeyIndexUnique = true;
            }
            else
            {
                step.KeyIndexClustered = false;
                step.KeyIndexUnique = false;
            }
            step.IncrementalColumn = txtIncrementalCol != null ? (txtIncrementalCol.Text ?? "").Trim() : "";
            step.UseChangeTracking = chkChangeTracking != null && chkChangeTracking.Checked;
            step.UseCdc = chkCdc != null && chkCdc.Checked;
            step.DeltaUseRv = chkDeltaRv != null && chkDeltaRv.Checked;
            step.DeltaUseCol = chkDeltaCol != null && chkDeltaCol.Checked;
            step.DeltaUseHash = chkDeltaHash != null && chkDeltaHash.Checked;
            // Build DeltaMethod for logs / old builds
            if (step.DeltaUseRv && step.DeltaUseCol && step.DeltaUseHash)
                step.DeltaMethod = "Auto";
            else
            {
                System.Collections.Generic.List<string> parts = new System.Collections.Generic.List<string>();
                if (step.DeltaUseRv) parts.Add("RV");
                if (step.DeltaUseCol) parts.Add("COL");
                if (step.DeltaUseHash) parts.Add("HASH");
                step.DeltaMethod = parts.Count == 0 ? "" : string.Join("+", parts.ToArray());
            }
            step.BatchSize = (int)numBatch.Value;
            step.MaxThreads = chkDestMT.Checked ? (int)numThreads.Value : 1;
            step.SourceThreads = chkSrcMT.Checked ? (int)numSourceThreads.Value : 1;
            step.IndexRebuild = (IndexRebuildKind)cbIdxMode.SelectedIndex;
            step.IndexRebuildDays = (int)numIdxDays.Value;
            step.RebuildIndexesAfter = step.IndexRebuild == IndexRebuildKind.AfterEveryRun;
            step.DelayMs = (int)numDelay.Value;
            step.Priority = (ResourcePriority)cbPriority.SelectedIndex;
            step.Buffer = (BufferMode)cbBuffer.SelectedIndex;
            step.RamLimitMb = (int)numRamLimit.Value;
            if (chkCacheLiteDb != null)
            {
                step.CacheUseLiteDb = chkCacheLiteDb.Checked;
                step.CacheUseLevelDb = chkCacheLevelDb.Checked;
                step.CacheUseFaster = chkCacheFaster.Checked;
            }
            step.OnSuccess = (StepAction)cbOnSuccess.SelectedIndex;
            step.OnFailure = (StepAction)cbOnFail.SelectedIndex;
            step.RetryAttempts = (int)numRetry.Value;
            step.RetryIntervalMinutes = (int)numRetryMin.Value;
            step.ContinueOnBatchError = chkContinueOnErr.Checked;

            step.ApiUrl = (txtApiUrl.Text ?? "").Trim();
            {
                int mi = cbApiMethod.SelectedIndex;
                step.ApiMethod = mi == 1 ? "POST" : mi == 2 ? "PUT" : mi == 3 ? "PATCH" : "GET";
            }
            step.ApiAuth = (ApiAuthType)cbApiAuth.SelectedIndex;
            step.ApiToken = (txtApiToken.Text ?? "").Trim();
            step.ApiAuthUrl = txtApiAuthUrl != null ? (txtApiAuthUrl.Text ?? "").Trim() : "";
            step.ApiKeyHeader = txtApiKeyHeader != null ? (txtApiKeyHeader.Text ?? "").Trim() : "ApiKey";
            step.ApiUser = txtApiUser.Text ?? "";
            step.ApiPassword = txtApiPass.Text ?? "";
            step.ApiHeaders = txtApiHeaders.Text ?? "";
            step.ApiBody = txtApiBody.Text ?? "";
            step.ApiJsonPath = (txtApiPath.Text ?? "").Trim();
            step.ApiPageParam = (txtPageParam.Text ?? "").Trim();
            step.ApiPageSizeParam = (txtPageSizeParam.Text ?? "").Trim();
            step.ApiPageSize = (int)numPageSize.Value;
            step.ApiMaxPages = (int)numMaxPages.Value;
            step.ApiIgnoreCert = chkApiIgnoreCert.Checked;

            if ((step.Type == StepType.Transfer || step.Type == StepType.ApiToDest) && string.IsNullOrWhiteSpace(step.DestTable))
            {
                MessageBox.Show(
                    "Dest table الزامی است.\r\nمثال: dbo.person   یا   ss.dbo.budget\r\n\r\nبرای Web API حتماً نام جدول مقصد را پر کنید.",
                    "Dest table required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                try { txtDstTable.Focus(); } catch { }
                return false;
            }
            if (step.Type == StepType.ApiToDest)
            {
                Uri u;
                if (!Uri.TryCreate(step.ApiUrl, UriKind.Absolute, out u) || (u.Scheme != Uri.UriSchemeHttp && u.Scheme != Uri.UriSchemeHttps))
                {
                    MessageBox.Show(
                        "URL وب‌سرویس الزامی است.\r\nمثال: http://172.21.62.242/api/v2/...",
                        "API URL required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    try { if (txtApiUrl != null) txtApiUrl.Focus(); } catch { }
                    return false;
                }
            }

            // Key columns are optional at save time.
            // - Empty: OK for Append / Truncate / Delete+Insert; Merge/Sync will fail at run with a clear message.
            // - Filled (e.g. id): Engine creates a nonclustered index on Dest for those columns if missing.
            int modeForKeys = cbMode != null ? cbMode.SelectedIndex : 0;
            if ((step.Type == StepType.Transfer || step.Type == StepType.ApiToDest)
                && (modeForKeys == 3 || modeForKeys == 4)
                && string.IsNullOrWhiteSpace(step.KeyColumns))
            {
                // Soft warning only — do not block Save
                AppLog.Warn("-", "Step '" + step.Name + "': Merge/Sync without Key columns — fill Key columns for correct upsert.");
            }

            if (step.Type != StepType.Transfer && step.Type != StepType.ApiToDest && string.IsNullOrWhiteSpace(step.SqlCommand))
            {
                MessageBox.Show("T-SQL command is required for this step type.");
                return false;
            }
            return true;
        }
    }

    internal static class JobStepExt
    {
        public static JobStep CloneForEdit(this JobStep s)
        {
            return Newtonsoft.Json.JsonConvert.DeserializeObject<JobStep>(
                Newtonsoft.Json.JsonConvert.SerializeObject(s));
        }
    }
}
