using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Newtonsoft.Json;

namespace SyncDB
{
    public enum ScheduleKind
    {
        Manual = 0,
        EveryNMinutes = 1,
        EveryNHours = 2,
        Daily = 3,
        Weekly = 4,
        Monthly = 5,  // day MonthlyDay of every IntervalValue month(s)
        RealtimeAsync = 6 // Async: every INSERT/UPDATE/DELETE is pushed; IntervalValue = poll seconds
    }

    /// <summary>Within the day: once at a time, or every N hours between start and end (SSMS-style).</summary>
    public enum DailyFreqKind
    {
        OnceAt = 0,
        EveryNHours = 1
    }

    /// <summary>Monthly: fixed day-of-month, or relative weekday (first Monday, etc.).</summary>
    public enum MonthlyModeKind
    {
        DayOfMonth = 0,
        Relative = 1
    }

    public enum WriteMode
    {
        Append = 0,
        TruncateInsert = 1,
        DeleteInsert = 2,
        /// <summary>INSERT new + UPDATE existing by KeyColumns (MERGE-style).</summary>
        MergeUpsert = 3,
        /// <summary>Auto sync: INSERT/UPDATE by keys + DELETE rows in Dest missing from Source (no full truncate).</summary>
        SyncChanges = 4,
        /// <summary>DROP destination table (if exists), recreate from source structure, then INSERT all rows.</summary>
        DropInto = 5
    }

    public enum StepType
    {
        Transfer = 0,       // copy data source → dest
        SqlOnSource = 1,    // run T-SQL on source connection
        SqlOnDest = 2,      // run T-SQL on destination connection
        ApiToDest = 3       // read JSON from a Web API → write to destination table
    }

    public enum ApiAuthType
    {
        None = 0,
        Bearer = 1,
        Basic = 2,
        ApiKey = 3
    }

    /// <summary>How a Transfer step holds source data while copying.</summary>
    public enum BufferMode
    {
        Auto = 0,     // small table -> RAM, heavy table -> Disk buffer
        Ram = 1,      // load whole table into memory (fastest, most RAM)
        Stream = 2,   // read in batches, bounded queue in RAM (low RAM, no disk)
        Disk = 3      // spill batches to temp files first, then write (lowest RAM, releases source early)
    }

    public enum ResourcePriority
    {
        Low = 0,
        Normal = 1,
        High = 2
    }

    public enum ConflictResolutionPolicy
    {
        SourceWins = 0,
        DestinationWins = 1,
        LatestByColumn = 2,
        Manual = 3
    }

    /// <summary>When to rebuild the indexes of the destination table after a Transfer.</summary>
    public enum IndexRebuildKind
    {
        Off = 0,
        AfterEveryRun = 1,   // after each successful run (skipped automatically if the table has no indexes)
        EveryNDays = 2       // only when N days have passed since the last rebuild
    }

    public enum StepAction
    {
        GoToNextStep = 0,
        QuitWithSuccess = 1,
        QuitWithFailure = 2
    }

    public class JobStep
    {
        public int StepId { get; set; }
        public string Name { get; set; }
        public StepType Type { get; set; }
        public string SqlCommand { get; set; }

        /// <summary>Optional connection Id. Empty = global Source/Dest by step type.</summary>
        public string TargetConnectionId { get; set; }

        // Transfer-only fields
        public string SourceTable { get; set; }
        public string DestTable { get; set; }
        public WriteMode Mode { get; set; }
        /// <summary>The "Write mode" tick in the step editor. Off = the drop-down is greyed out
        /// and the mode stays Append (INSERT only).</summary>
        public bool WriteModeOn { get; set; }
        public string DestDeleteWhere { get; set; }
        /// <summary>Comma-separated key columns for MergeUpsert (e.g. Id,Code).</summary>
        public string KeyColumns { get; set; }
        /// <summary>When KeyColumns is set: create CLUSTERED index (else NONCLUSTERED).</summary>
        public bool KeyIndexClustered { get; set; }
        /// <summary>When KeyColumns is set: create UNIQUE index (or UNIQUE constraint style).</summary>
        public bool KeyIndexUnique { get; set; }
        /// <summary>Column for incremental sync (e.g. ModifiedDate). Rows where col &gt; last watermark.</summary>
        public string IncrementalColumn { get; set; }
        /// <summary>Last watermark from previous successful run (auto-updated).</summary>
        public string IncrementalLastValue { get; set; }
        /// <summary>Use SQL Server Change Tracking (CHANGETABLE) for delta — no ModifiedDate column needed.</summary>
        public bool UseChangeTracking { get; set; }
        /// <summary>Last CHANGE_TRACKING_CURRENT_VERSION() after a successful CT sync (null = full load next time).</summary>
        public long? ChangeTrackingVersion { get; set; }
        /// <summary>Use SQL Server CDC (fn_cdc_get_net_changes) when enabled on source table.</summary>
        public bool UseCdc { get; set; }
        /// <summary>Last CDC LSN as hex string after successful sync.</summary>
        public string CdcLastLsn { get; set; }
        /// <summary>Auto | RV | COL | HASH | or combination like RV+HASH — Smart Delta strategy (legacy).</summary>
        public string DeltaMethod { get; set; }
        /// <summary>Allow rowversion (timestamp) method. Default false (user must tick).</summary>
        public bool DeltaUseRv { get; set; }
        /// <summary>Allow incremental column method. Default false (user must tick).</summary>
        public bool DeltaUseCol { get; set; }
        /// <summary>Allow HASH compare method. Default false (user must tick).</summary>
        public bool DeltaUseHash { get; set; }
        /// <summary>Last weekly HASH reconciliation UTC.</summary>
        public DateTime? LastHashFullUtc { get; set; }
        /// <summary>src|dst|keys fingerprint; change forces full baseline.</summary>
        public string DeltaFingerprint { get; set; }
        /// <summary>Rows per staged batch (~1M default).</summary>
        public long DeltaChunkRows { get; set; }
        /// <summary>After successful transfer, ALTER INDEX ALL ON table REBUILD.</summary>
        public bool RebuildIndexesAfter { get; set; }
        /// <summary>false = this step (table) is skipped when the job runs.</summary>
        public bool Enabled { get; set; }
        /// <summary>Parallel readers on the SOURCE (RAM mode, table / simple SELECT). 0 = Auto, 1 = single reader.</summary>
        public int SourceThreads { get; set; }
        /// <summary>Index rebuild policy for the destination table.</summary>
        public IndexRebuildKind IndexRebuild { get; set; }
        /// <summary>For IndexRebuildKind.EveryNDays.</summary>
        public int IndexRebuildDays { get; set; }
        /// <summary>Set automatically after a rebuild.</summary>
        public DateTime? IndexLastRebuildUtc { get; set; }
        public int BatchSize { get; set; }          // rows per batch  -> controls RAM
        public int MaxThreads { get; set; }         // 0 = Auto (CPU cores), else parallel writers
        public BufferMode Buffer { get; set; }      // RAM / Stream / Disk / Auto
        public int RamLimitMb { get; set; }         // Auto: tables estimated above this go to Disk buffer
        /// <summary>Local cache providers (UI checkboxes). LiteDB = general/light; LevelDB/FASTER = high-speed.</summary>
        public bool CacheUseLiteDb { get; set; }
        public bool CacheUseLevelDb { get; set; }
        public bool CacheUseFaster { get; set; }
        [JsonIgnore] public string SizeHintTable { get; set; }   // runtime only: table used to estimate size for Auto mode
        public int DelayMs { get; set; }            // pause between batches (ms)
        public ResourcePriority Priority { get; set; }

        // Web API fields (StepType.ApiToDest). Dest table / write mode / batch size are shared with Transfer.
        public string ApiUrl { get; set; }
        public string ApiMethod { get; set; }          // GET or POST
        public ApiAuthType ApiAuth { get; set; }
        public string ApiToken { get; set; }           // Bearer token or API key value
        /// <summary>Header name for ApiKey auth (default ApiKey). Example: X-Api-Key, ApiKey.</summary>
        public string ApiKeyHeader { get; set; }
        /// <summary>Optional: login URL to obtain Bearer token before main request (email=ApiUser, password=ApiPassword).</summary>
        public string ApiAuthUrl { get; set; }
        public string ApiUser { get; set; }            // Basic auth
        public string ApiPassword { get; set; }
        public string ApiHeaders { get; set; }         // one per line:  Name: Value
        public string ApiBody { get; set; }            // POST body (JSON)
        public string ApiJsonPath { get; set; }        // path to the array inside JSON, e.g. data.items (empty = root)
        public string ApiPageParam { get; set; }       // e.g. page  (empty = no paging)
        public string ApiPageSizeParam { get; set; }   // e.g. pageSize (optional)
        public int ApiPageSize { get; set; }
        public int ApiMaxPages { get; set; }
        public bool ApiIgnoreCert { get; set; }

        public StepAction OnSuccess { get; set; }
        public StepAction OnFailure { get; set; }
        public int RetryAttempts { get; set; }
        public int RetryIntervalMinutes { get; set; }
        /// <summary>T-SQL script step: when one statement / table fails, log it at once, go on with the next one and report all failures at the end.</summary>
        public bool ContinueOnBatchError { get; set; }

        public JobStep()
        {
            StepId = 1;
            Name = "Step 1";
            Type = StepType.Transfer;
            SqlCommand = "";
            TargetConnectionId = "";
            SourceTable = "";
            DestTable = "";
            Mode = WriteMode.Append;
            WriteModeOn = false;      // the Write mode drop-down starts greyed out
            DestDeleteWhere = "";
            KeyColumns = "";
            KeyIndexClustered = false;
            KeyIndexUnique = false;
            IncrementalColumn = "";
            IncrementalLastValue = "";
            UseChangeTracking = false;
            ChangeTrackingVersion = null;
            UseCdc = false;
            CdcLastLsn = "";
            DeltaMethod = "";
            // Off until the user ticks them — do not auto-activate Smart Delta methods.
            DeltaUseRv = false;
            DeltaUseCol = false;
            DeltaUseHash = false;
            LastHashFullUtc = null;
            DeltaFingerprint = "";
            DeltaChunkRows = 1000000;
            RebuildIndexesAfter = false;
            Enabled = true;
            SourceThreads = 0;
            IndexRebuild = IndexRebuildKind.Off;
            IndexRebuildDays = 7;
            IndexLastRebuildUtc = null;
            BatchSize = 1000;
            MaxThreads = 0;  // Auto = Environment.ProcessorCount
            Buffer = BufferMode.Auto;
            RamLimitMb = 256;
            CacheUseLiteDb = true;
            CacheUseLevelDb = false;
            CacheUseFaster = false;
            DelayMs = 0;
            Priority = ResourcePriority.Normal;
            ApiUrl = "";
            ApiMethod = "GET";
            ApiAuth = ApiAuthType.None;
            ApiToken = "";
            ApiKeyHeader = "ApiKey";
            ApiAuthUrl = "";
            ApiUser = "";
            ApiPassword = "";
            ApiHeaders = "";
            ApiBody = "";
            ApiJsonPath = "";
            ApiPageParam = "";
            ApiPageSizeParam = "";
            ApiPageSize = 0;
            ApiMaxPages = 1000;
            ApiIgnoreCert = true;  // SSL cert errors ignored by default (internal)
            OnSuccess = StepAction.GoToNextStep;
            OnFailure = StepAction.QuitWithFailure;
            RetryAttempts = 0;
            RetryIntervalMinutes = 0;
        }

        public string TypeText()
        {
            switch (Type)
            {
                case StepType.SqlOnSource: return "T-SQL (Source)";
                case StepType.SqlOnDest: return "T-SQL (Dest)";
                case StepType.ApiToDest: return "Web API → Dest";
                default: return "Transfer";
            }
        }

        public static string ActionText(StepAction a)
        {
            switch (a)
            {
                case StepAction.QuitWithSuccess: return "Quit success";
                case StepAction.QuitWithFailure: return "Quit failure";
                default: return "Go to next step";
            }
        }
    }

    public class ConnectionProfile
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Server { get; set; }
        public int Port { get; set; }
        public string Database { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
        public bool TrustServerCertificate { get; set; }
        public bool IntegratedSecurity { get; set; }
        /// <summary>Saved role colour of this connection: "" | "Source" | "Dest" | "Both".
        /// Kept when another connection becomes the active SOURCE/DEST (many green/blue rows).</summary>
        public string RoleTag { get; set; }

        public bool HasSourceTag() { return RoleTag == "Source" || RoleTag == "Both"; }
        public bool HasDestTag() { return RoleTag == "Dest" || RoleTag == "Both"; }

        public void AddRoleTag(bool source)
        {
            bool src = HasSourceTag() || source;
            bool dst = HasDestTag() || !source;
            RoleTag = src && dst ? "Both" : (src ? "Source" : "Dest");
        }

        public ConnectionProfile()
        {
            RoleTag = "";
            Id = Guid.NewGuid().ToString("N");
            Name = "New connection";
            Server = "";
            Port = 1433;
            Database = "";
            User = "";
            Password = "";
            TrustServerCertificate = true;
            IntegratedSecurity = false;
        }

        public string BuildConnectionString()
        {
            StringBuilder sb = new StringBuilder();
            string server = (Server ?? "").Trim();
            if (string.IsNullOrEmpty(server))
                return ""; // invalid — caller should check

            // avoid double port if user already typed Server,port
            if (Port > 0 && server.IndexOf(',') < 0)
                server = server + "," + Port;

            sb.Append("Data Source=").Append(server).Append(";");
            if (!string.IsNullOrWhiteSpace(Database))
                sb.Append("Initial Catalog=").Append(Database.Trim()).Append(";");

            if (IntegratedSecurity)
                sb.Append("Integrated Security=true;");
            else
            {
                sb.Append("User ID=").Append((User ?? "").Trim()).Append(";");
                // quote password if it contains ; or =
                string pw = Password ?? "";
                if (pw.IndexOf(';') >= 0 || pw.IndexOf('=') >= 0)
                {
                    string q = "\"";
                    sb.Append("Password=").Append(q).Append(pw.Replace(q, q + q)).Append(q).Append(";");
                }
                else
                    sb.Append("Password=").Append(pw).Append(";");
            }

            // SSL/TLS: always trust server certificate inside the app (no extra UI; avoids SSL errors)
            sb.Append("Encrypt=true;TrustServerCertificate=true;");

            return sb.ToString();
        }
    }

    public class SyncJob
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool Enabled { get; set; }

        public List<JobStep> Steps { get; set; }

        // legacy single-step fields (migrated into Steps if empty)
        public string SourceSql { get; set; }
        public string SourceTable { get; set; }
        public string DestTable { get; set; }
        public WriteMode Mode { get; set; }
        public string DestDeleteWhere { get; set; }
        /// <summary>Comma-separated key columns for MergeUpsert (e.g. Id,Code).</summary>
        public string KeyColumns { get; set; }
        /// <summary>Column for incremental sync (e.g. ModifiedDate). Rows where col &gt; last watermark.</summary>
        public string IncrementalColumn { get; set; }
        /// <summary>Last watermark from previous successful run (auto-updated).</summary>
        public string IncrementalLastValue { get; set; }
        /// <summary>After successful transfer, ALTER INDEX ALL ON table REBUILD.</summary>
        public bool RebuildIndexesAfter { get; set; }
        public int BatchSize { get; set; }
        public int CommandTimeoutSec { get; set; }
        /// <summary>"DELETE FROM t" + the next "INSERT INTO t" run in ONE transaction, so a failing
        /// refill can never leave the table empty. Turn it off for very large tables (bigger log).</summary>
        public bool AtomicRefill { get; set; }

        /// <summary>Confirm before executing DELETE / TRUNCATE / DROP on destination.</summary>
        public bool ConfirmBeforeDangerous { get; set; }
        /// <summary>Auto sync only latest changes (watermark/delta). Ignores DELETE/TRUNCATE/DROP — does not wipe dest.</summary>
        public bool AutoSyncLatest { get; set; }
        /// <summary>Also apply field / column changes (add missing columns) on Destination before syncing.</summary>
        public bool ApplyFieldChanges { get; set; }
        /// <summary>Dry run only: analyze and log, do not write any data.</summary>
        public bool DryRunOnly { get; set; }
        /// <summary>Auto-tune resources (CPU / cache / disk buffer). Does not add new fields/columns.</summary>
        public bool AutoTuneResources { get; set; }

        public ScheduleKind Schedule { get; set; }
        public int IntervalValue { get; set; }
        public int DailyHour { get; set; }
        public int DailyMinute { get; set; }
        /// <summary>Legacy single weekday (0=Sun..6=Sat). Used when WeekDaysMask is 0.</summary>
        public int WeekDay { get; set; }
        /// <summary>Bitmask: bit 0=Sunday … 6=Saturday. 0 = fall back to WeekDay.</summary>
        public int WeekDaysMask { get; set; }
        /// <summary>Day of month 1–31 for Monthly (clamped to last day of shorter months).</summary>
        public int MonthlyDay { get; set; }
        /// <summary>DayOfMonth vs Relative (first Monday of month, etc.).</summary>
        public MonthlyModeKind MonthlyMode { get; set; }
        /// <summary>1=first, 2=second, 3=third, 4=fourth, 5=last — for MonthlyMode.Relative.</summary>
        public int MonthlyRelativeOrdinal { get; set; }
        /// <summary>0=Sunday..6=Saturday — for MonthlyMode.Relative.</summary>
        public int MonthlyRelativeWeekday { get; set; }
        /// <summary>Once at DailyHour:DailyMinute, or every SubIntervalHours between start and EndHour:EndMinute.</summary>
        public DailyFreqKind DailyFreq { get; set; }
        public int SubIntervalHours { get; set; }
        public int EndHour { get; set; }
        public int EndMinute { get; set; }
        /// <summary>Schedule effective from this local date (date part only). Null = from now.</summary>
        public DateTime? ScheduleStartDate { get; set; }
        /// <summary>Optional end date (local date). Ignored when ScheduleNoEndDate is true.</summary>
        public DateTime? ScheduleEndDate { get; set; }
        public bool ScheduleNoEndDate { get; set; }

        public DateTime? LastRunUtc { get; set; }
        public DateTime? NextRunUtc { get; set; }
        public string LastStatus { get; set; }
        public long LastRows { get; set; }
        public string LastErrorDetail { get; set; }
        /// <summary>manual | schedule | service — how the last run was started.</summary>
        public string LastRunSource { get; set; }
        /// <summary>Temporarily suspends scheduled/Async runs without disabling the job.</summary>
        public bool Paused { get; set; }
        public string PauseReason { get; set; }
        /// <summary>Conflict policy for future conflict-aware/bidirectional runs.</summary>
        public ConflictResolutionPolicy ConflictPolicy { get; set; }
        public string ConflictColumn { get; set; }

        /// <summary>Async mode: use the IntervalValue as a second-based check interval (when true).</summary>
        public bool AsyncUseSeconds { get; set; }
        /// <summary>Async mode: only run on the checked weekdays (when true).</summary>
        public bool AsyncRestrictDays { get; set; }
        /// <summary>Async mode: only run inside the DailyHour/Minute .. EndHour/Minute window (when true).</summary>
        public bool AsyncRestrictTime { get; set; }

        /// <summary>If true, before DELETE or UPDATE on dest, copy the old row to RecycleSchema.DestTable so it can be recovered.</summary>
        public bool EnableRecycleBin { get; set; }
        /// <summary>Schema name for the recycle/backup tables (default bakuid). Tables are created as [RecycleSchema].[DestTable].</summary>
        public string RecycleSchema { get; set; }
        /// <summary>How many hours to keep rows in the recycle tables before automatic purge. 0 = keep forever until manual clean.</summary>
        public int RecycleRetentionHours { get; set; }

        public SyncJob()
        {
            Id = Guid.NewGuid().ToString("N");
            Name = "New Job";
            Description = "";
            Enabled = true;
            Steps = new List<JobStep>();
            SourceSql = "";
            SourceTable = "";
            DestTable = "";
            Mode = WriteMode.Append;
            DestDeleteWhere = "";
            KeyColumns = "";
            IncrementalColumn = "";
            IncrementalLastValue = "";
            RebuildIndexesAfter = false;
            BatchSize = 1000;
            CommandTimeoutSec = 0;          // 0 = no limit (was 300)
            AtomicRefill = false;           // default inactive
            ConfirmBeforeDangerous = false;
            AutoSyncLatest = false;
            ApplyFieldChanges = false;
            DryRunOnly = false;
            AutoTuneResources = false;
            Schedule = ScheduleKind.Manual;
            IntervalValue = 1;
            DailyHour = 2;
            DailyMinute = 0;
            WeekDay = 1;
            WeekDaysMask = 0;
            MonthlyDay = 1;
            MonthlyMode = MonthlyModeKind.DayOfMonth;
            MonthlyRelativeOrdinal = 1;
            MonthlyRelativeWeekday = 1; // Monday
            DailyFreq = DailyFreqKind.OnceAt;
            SubIntervalHours = 1;
            EndHour = 23;
            EndMinute = 59;
            ScheduleStartDate = null;
            ScheduleEndDate = null;
            ScheduleNoEndDate = true;
            LastStatus = "Never run";
            LastRunSource = "";
            LastRows = 0;
            Paused = false;
            PauseReason = "";
            ConflictPolicy = ConflictResolutionPolicy.SourceWins;
            ConflictColumn = "";
            AsyncUseSeconds = true;
            AsyncRestrictDays = false;
            AsyncRestrictTime = false;
            EnableRecycleBin = false;
            RecycleSchema = "bakuid";
            RecycleRetentionHours = 24;
        }

        /// <summary>Effective weekday mask: WeekDaysMask if set, else single bit from WeekDay.</summary>
        public int EffectiveWeekDaysMask()
        {
            if (WeekDaysMask != 0) return WeekDaysMask & 0x7F;
            int d = WeekDay;
            if (d < 0 || d > 6) d = 1;
            return 1 << d;
        }

        /// <summary>Ensure Steps list exists; migrate legacy fields if needed.</summary>
        public void EnsureSteps()
        {
            if (Steps == null) Steps = new List<JobStep>();
            if (Steps.Count == 0 &&
                (!string.IsNullOrWhiteSpace(SourceTable) || !string.IsNullOrWhiteSpace(SourceSql) || !string.IsNullOrWhiteSpace(DestTable)))
            {
                JobStep s = new JobStep();
                s.StepId = 1;
                s.Name = "Transfer";
                s.Type = StepType.Transfer;
                s.SqlCommand = SourceSql ?? "";
                s.SourceTable = SourceTable ?? "";
                s.DestTable = DestTable ?? "";
                s.Mode = Mode;
                s.DestDeleteWhere = DestDeleteWhere ?? "";
                s.KeyColumns = KeyColumns ?? "";
                s.KeyIndexClustered = false;  // legacy SyncJob has no KeyIndex* fields
                s.KeyIndexUnique = false;
                s.IncrementalColumn = IncrementalColumn ?? "";
                s.IncrementalLastValue = IncrementalLastValue ?? "";
                s.RebuildIndexesAfter = RebuildIndexesAfter;
                s.BatchSize = BatchSize > 0 ? BatchSize : 1000;
                Steps.Add(s);
            }
            RenumberSteps();
        }

        public void RenumberSteps()
        {
            if (Steps == null) return;
            for (int i = 0; i < Steps.Count; i++)
                Steps[i].StepId = i + 1;
        }

        public SyncJob Clone()
        {
            return JsonConvert.DeserializeObject<SyncJob>(JsonConvert.SerializeObject(this));
        }
    }

    public class AppConfig
    {
        public List<SyncJob> Jobs { get; set; }
        public List<ConnectionProfile> Connections { get; set; }
        public string SourceConnectionId { get; set; }
        public string DestConnectionId { get; set; }
        public string SourceConnection { get; set; }
        public string DestConnection { get; set; }
        public int LogRetentionDays { get; set; }
        public string LogFolder { get; set; }
        public bool SchedulerEnabled { get; set; }
        public int SchedulerPollSeconds { get; set; }
        /// <summary>Durable local outbox (LiteDB file) for failed / offline batches.</summary>
        public bool OutboxEnabled { get; set; }
        /// <summary>Local | Kafka | Nats — where outbox items are aimed after local queue.</summary>
        public string OutboxTransport { get; set; }
        public string KafkaBootstrap { get; set; }
        public string KafkaTopic { get; set; }
        public string NatsUrl { get; set; }
        public string NatsSubject { get; set; }
        /// <summary>Embedded Kafka-style topic name for LocalStream (no server).</summary>
        public string LocalStreamTopic { get; set; }
        /// <summary>0..5 UI skin (Theme.ApplyPreset).</summary>
        public int ThemeId { get; set; }
        /// <summary>Preferred local cache providers (settings UI).</summary>
        public bool CacheUseLiteDb { get; set; }
        public bool CacheUseLevelDb { get; set; }
        public bool CacheUseFaster { get; set; }
        /// <summary>Outbox Worker: max attempts before Dead Letter.</summary>
        public int OutboxMaxRetries { get; set; }
        /// <summary>Outbox Worker: items per batch.</summary>
        public int OutboxBatchSize { get; set; }
        /// <summary>Outbox Worker: idle sleep when queue empty (ms).</summary>
        public int OutboxIdleMs { get; set; }
        /// <summary>Outbox Worker: how long a claimed (Processing) item may stay locked.</summary>
        public int OutboxLeaseMinutes { get; set; }
        /// <summary>Outbox: delete Sent records and their payload files after this many days.</summary>
        public int OutboxSentRetentionDays { get; set; }
        /// <summary>Outbox HTTP transport timeout (seconds).</summary>
        public int OutboxHttpTimeoutSec { get; set; }
        /// <summary>Node / origin id for bidirectional loop prevention.</summary>
        public string OriginId { get; set; }
        /// <summary>Housekeeping of the data folder (buffer / stream / cache / outbox) at startup and hourly.</summary>
        public bool BufferAutoClean { get; set; }
        /// <summary>
        /// Off (default) = SyncDB never spills to disk: memory mode Disk falls back to Stream and no folder
        /// is created under %APPDATA%\SyncDB\buffer. On = the disk buffer may be used for huge tables.
        /// Deliberately a NEW key: a config.json written by an older build has no value for it, so every
        /// existing installation starts with the disk buffer switched OFF.
        /// </summary>
        public bool UseDiskBuffer { get; set; }
        /// <summary>Days to keep local cache records (row hashes / origin marks) and LocalStream segments.</summary>
        public int CacheKeepDays { get; set; }
        /// <summary>Maximum total size of the embedded LocalStream per topic (MB).</summary>
        public int StreamMaxMB { get; set; }

        public AppConfig()
        {
            Jobs = new List<SyncJob>();
            Connections = new List<ConnectionProfile>();
            SourceConnectionId = "";
            DestConnectionId = "";
            SourceConnection = "";
            DestConnection = "";
            LogRetentionDays = 30;
            LogFolder = "";
            SchedulerEnabled = false;
            SchedulerPollSeconds = 30;
            OutboxEnabled = true;
            OutboxTransport = "Local";
            KafkaBootstrap = "";
            KafkaTopic = "syncdb.changes";
            NatsUrl = "";
            NatsSubject = "syncdb.changes";
            LocalStreamTopic = "syncdb.changes";
            ThemeId = 0;
            CacheUseLiteDb = true;
            CacheUseLevelDb = false;
            CacheUseFaster = false;
            OutboxMaxRetries = 8;
            OutboxBatchSize = 20;
            OutboxIdleMs = 3000;
            OutboxLeaseMinutes = 10;
            OutboxSentRetentionDays = 7;
            OutboxHttpTimeoutSec = 30;
            OriginId = Environment.MachineName ?? "node1";
            BufferAutoClean = true;
            UseDiskBuffer = false;      // no disk buffer unless the user turns it on
            CacheKeepDays = 7;
            StreamMaxMB = 64;
        }

        /// <summary>Set by /datadir:"..." (Windows service mode) so the service uses the same config as the GUI.</summary>
        public static string DataDirOverride;

        public static string DataDir
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(DataDirOverride)) return DataDirOverride;
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "SyncDB");
            }
        }

        public static string ConfigPath { get { return Path.Combine(DataDir, "config.json"); } }
        public static string DefaultLogDir { get { return Path.Combine(DataDir, "logs"); } }

        public string EffectiveLogFolder
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(LogFolder)) return LogFolder;
                return DefaultLogDir;
            }
        }

        public ConnectionProfile FindConnection(string id)
        {
            if (string.IsNullOrEmpty(id) || Connections == null) return null;
            foreach (ConnectionProfile c in Connections)
                if (c.Id == id) return c;
            return null;
        }

        public string ResolveSourceConnectionString()
        {
            // Only active selected profile — never fall back to stale saved string
            ConnectionProfile p = FindConnection(SourceConnectionId);
            if (p == null) return "";
            return p.BuildConnectionString() ?? "";
        }

        public string ResolveDestConnectionString()
        {
            ConnectionProfile p = FindConnection(DestConnectionId);
            if (p == null) return "";
            return p.BuildConnectionString() ?? "";
        }

        /// <summary>
        /// Resolve the connection for a step.
        /// Transfer / ApiToDest: Source always uses the job/global Source; Dest uses TargetConnectionId if set, else global Dest.
        /// T-SQL steps: TargetConnectionId overrides when set; otherwise Source or Dest according to step type.
        /// (Previously TargetConnectionId was applied to BOTH sides and broke Transfer — source tables were looked up on the dest server.)
        /// </summary>
        public string ResolveStepConnectionString(JobStep step, bool asSource)
        {
            if (step != null)
            {
                bool isTransferLike = (step.Type == StepType.Transfer || step.Type == StepType.ApiToDest);
                // For Transfer: never force Source to TargetConnectionId (that is the Dest picker in the UI)
                if (isTransferLike && asSource)
                    return ResolveSourceConnectionString();

                if (!string.IsNullOrWhiteSpace(step.TargetConnectionId))
                {
                    // Transfer Dest side, or any T-SQL step with an explicit Database choice
                    if (!isTransferLike || !asSource)
                    {
                        ConnectionProfile p = FindConnection(step.TargetConnectionId);
                        if (p != null)
                        {
                            string cs = p.BuildConnectionString();
                            if (!string.IsNullOrEmpty(cs)) return cs;
                        }
                    }
                }
            }
            return asSource ? ResolveSourceConnectionString() : ResolveDestConnectionString();
        }

        public string ConnectionDisplayName(string id)
        {
            ConnectionProfile p = FindConnection(id);
            if (p == null) return "";
            string db = (p.Database ?? "").Trim();
            string n = (p.Name ?? "").Trim();
            if (db.Length > 0 && n.Length > 0) return n + "  [" + db + "]";
            if (n.Length > 0) return n;
            return db;
        }

        /// <summary>
        /// Persists only the state fields advanced by an outbox replay. The read-modify-write is
        /// protected by the cross-process config mutex, so the GUI's latest edits are not replaced
        /// by a stale AppConfig object.
        /// </summary>
        public static bool UpdateStepState(string jobId, int stepId, JobStep state)
        {
            if (state == null || string.IsNullOrEmpty(jobId)) return false;
            // Same lock order as Save(): process gate first, then the cross-process mutex.
            // (The worker and the GUI can save at the same time; inverting these would deadlock.)
            lock (SaveGate)
            {
                bool acquired = false;
                using (Mutex mutex = new Mutex(false, ConfigMutexName))
                {
                    try
                    {
                        try { acquired = mutex.WaitOne(10000); }
                        catch (AbandonedMutexException) { acquired = true; }
                        if (!acquired) return false;

                        AppConfig cfg = Load();
                        SyncJob job = null;
                        foreach (SyncJob j in cfg.Jobs)
                            if (j != null && j.Id == jobId) { job = j; break; }
                        if (job == null) return false;
                        JobStep step = null;
                        foreach (JobStep s in job.Steps)
                            if (s != null && s.StepId == stepId) { step = s; break; }
                        if (step == null) return false;

                        step.IncrementalLastValue = state.IncrementalLastValue;
                        step.ChangeTrackingVersion = state.ChangeTrackingVersion;
                        step.CdcLastLsn = state.CdcLastLsn;
                        step.LastHashFullUtc = state.LastHashFullUtc;
                        step.DeltaFingerprint = state.DeltaFingerprint;
                        step.IndexLastRebuildUtc = state.IndexLastRebuildUtc;
                        cfg.Save();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        AppLog.Warn(jobId, "Step state save failed: " + ex.Message);
                        return false;
                    }
                    finally
                    {
                        if (acquired) { try { mutex.ReleaseMutex(); } catch { } }
                    }
                }
            }
        }

        /// <summary>Clamp old/invalid values so a config written by an older build stays usable.</summary>
        public void Normalize()
        {
            if (Jobs == null) Jobs = new List<SyncJob>();
            if (Connections == null) Connections = new List<ConnectionProfile>();
            for (int i = Jobs.Count - 1; i >= 0; i--)
            {
                if (Jobs[i] == null) { Jobs.RemoveAt(i); continue; }
                if (string.IsNullOrWhiteSpace(Jobs[i].Id)) Jobs[i].Id = Guid.NewGuid().ToString("N");
                Jobs[i].EnsureSteps();
                if (Jobs[i].CommandTimeoutSec < 0) Jobs[i].CommandTimeoutSec = 0;   // 0 is allowed = no limit
            }
            if (LogRetentionDays < 0) LogRetentionDays = 30;   // 0 = stop logging
            if (LogRetentionDays > 1095) LogRetentionDays = 1095;
            if (SchedulerPollSeconds < 10) SchedulerPollSeconds = 30;
            if (SchedulerPollSeconds > 3600) SchedulerPollSeconds = 3600;

            if (OutboxMaxRetries < 1) OutboxMaxRetries = 8;
            if (OutboxMaxRetries > 100) OutboxMaxRetries = 100;
            if (OutboxBatchSize < 1) OutboxBatchSize = 20;
            if (OutboxBatchSize > 500) OutboxBatchSize = 500;
            if (OutboxIdleMs < 250) OutboxIdleMs = 3000;
            if (OutboxIdleMs > 600000) OutboxIdleMs = 600000;
            if (OutboxLeaseMinutes < 1) OutboxLeaseMinutes = 10;
            if (OutboxLeaseMinutes > 1440) OutboxLeaseMinutes = 1440;
            if (OutboxSentRetentionDays < 1) OutboxSentRetentionDays = 7;
            if (OutboxSentRetentionDays > 3650) OutboxSentRetentionDays = 3650;
            if (OutboxHttpTimeoutSec < 5) OutboxHttpTimeoutSec = 30;
            if (OutboxHttpTimeoutSec > 600) OutboxHttpTimeoutSec = 600;
            if (string.IsNullOrWhiteSpace(OutboxTransport)) OutboxTransport = "Local";
            else OutboxTransport = OutboxTransport.Trim();

            if (CacheKeepDays < 1) CacheKeepDays = 7;
            if (CacheKeepDays > 365) CacheKeepDays = 365;
            if (StreamMaxMB < 1) StreamMaxMB = 64;
            if (StreamMaxMB > 4096) StreamMaxMB = 4096;

            string origin = (OriginId ?? "").Trim();
            if (origin.Length == 0) origin = Environment.MachineName ?? "node1";
            if (origin.Length > 64) origin = origin.Substring(0, 64);
            OriginId = origin;
        }

        public static AppConfig Load()
        {
            string path = ConfigPath;
            for (int attempt = 0; attempt < 3; attempt++)
            {
                try
                {
                    if (!File.Exists(path)) return new AppConfig();
                    AppConfig c = JsonConvert.DeserializeObject<AppConfig>(File.ReadAllText(path, Encoding.UTF8));
                    if (c != null)
                    {
                        c.Normalize();
                        return c;
                    }
                }
                catch (IOException ex)
                {
                    // A concurrent atomic replace on a slow/network disk: retry briefly.
                    if (attempt == 2) AppLog.Warn("-", "Config load failed: " + ex.Message);
                    Thread.Sleep(120);
                }
                catch (Exception ex)
                {
                    AppLog.Warn("-", "Config is not readable/valid: " + ex.Message);
                    break;
                }
            }

            // Keep a copy of the bad file for support, then try the last known good backup.
            try
            {
                if (File.Exists(path))
                {
                    string bad = path + ".bad-" + DateTime.Now.ToString("yyyyMMddHHmmss");
                    File.Copy(path, bad, true);
                    AppLog.Warn("-", "Corrupt config saved as " + bad);
                }
            }
            catch { }
            try
            {
                string bak = path + ".bak";
                if (File.Exists(bak))
                {
                    AppConfig c = JsonConvert.DeserializeObject<AppConfig>(File.ReadAllText(bak, Encoding.UTF8));
                    if (c != null)
                    {
                        c.Normalize();
                        AppLog.Warn("-", "Config restored from backup " + bak);
                        return c;
                    }
                }
            }
            catch { }
            return new AppConfig();
        }

        private static readonly object SaveGate = new object();

        private static string ConfigMutexName
        {
            get
            {
                string p = (ConfigPath ?? "").ToLowerInvariant();
                using (SHA1 sha = SHA1.Create())
                {
                    byte[] h = sha.ComputeHash(Encoding.UTF8.GetBytes(p));
                    StringBuilder sb = new StringBuilder("Local\\SyncDB.Config.");
                    for (int i = 0; i < 8; i++) sb.Append(h[i].ToString("x2"));
                    return sb.ToString();
                }
            }
        }

        /// <summary>Atomic save (temp + replace) guarded by a cross-process mutex, so the GUI and service cannot corrupt config.json.</summary>
        public void Save()
        {
            Normalize();
            Directory.CreateDirectory(DataDir);
            string json = JsonConvert.SerializeObject(this, Formatting.Indented);
            string path = ConfigPath;
            string tmp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            lock (SaveGate)
            {
                bool acquired = false;
                using (Mutex mutex = new Mutex(false, ConfigMutexName))
                {
                    try
                    {
                        try { acquired = mutex.WaitOne(10000); }
                        catch (AbandonedMutexException) { acquired = true; }
                        if (!acquired) throw new IOException("Timed out waiting for the config file lock.");

                        File.WriteAllText(tmp, json, new UTF8Encoding(true));
                        if (File.Exists(path))
                        {
                            // Keep a last-known-good copy even on file systems where File.Replace fails.
                            try { File.Copy(path, path + ".bak", true); } catch { }
                            try
                            {
                                File.Replace(tmp, path, path + ".bak", true);
                            }
                            catch (Exception ex)
                            {
                                // Some network/FAT shares do not support Replace. Keep a safe fallback.
                                AppLog.Warn("-", "Atomic config replace unavailable (" + ex.Message + "); using copy fallback.");
                                File.Copy(tmp, path, true);
                                try { File.Delete(tmp); } catch { }
                            }
                        }
                        else
                        {
                            File.Move(tmp, path);
                        }
                    }
                    finally
                    {
                        if (acquired) { try { mutex.ReleaseMutex(); } catch { } }
                        try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
                    }
                }
            }
        }
    }
}
