using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SyncDB
{
    /// <summary>
    /// Transfer status window (it used to sit inside the Jobs tab, now it is a window of its own):
    /// the statement running right now, a progress bar, every finished statement, and a status bar
    /// with the table name, the records that are moving and how many minutes it has taken.
    /// </summary>
    public class LiveStatusForm : Form
    {
        private static LiveStatusForm _open;

        private readonly AppConfig _config;
        private Label _head;
        private ProgressBar _bar;
        private ListView _list;
        private StatusStrip _status;
        private ToolStripStatusLabel _lblTable, _lblRows, _lblTime;
        private Button _btnStop;
        private Timer _timer;
        private int _seen = -1;

        /// <summary>Opens the window, or brings the one that is already open to the front.</summary>
        public static LiveStatusForm ShowWindow(IWin32Window owner, AppConfig cfg)
        {
            try
            {
                if (_open != null && !_open.IsDisposed)
                {
                    if (_open.WindowState == FormWindowState.Minimized) _open.WindowState = FormWindowState.Normal;
                    _open.Show();
                    _open.BringToFront();
                    _open.Activate();
                    return _open;
                }
                LiveStatusForm f = new LiveStatusForm(cfg);
                _open = f;
                f.FormClosed += delegate { _open = null; };
                if (owner is Form) f.Show(owner); else f.Show();
                return f;
            }
            catch { return null; }
        }

        public LiveStatusForm(AppConfig config)
        {
            _config = config;
            Text = "Transfer status (live)";
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(1060, 520);
            MinimumSize = new Size(720, 340);
            ShowInTaskbar = false;
            try { Icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            BuildUi();
            try { Theme.Apply(this); } catch { }      // colours + Persian captions

            _timer = new Timer { Interval = 1000 };
            _timer.Tick += (s, e) => Refresh2();
            _timer.Start();
            FormClosed += (s, e) => { try { _timer.Stop(); _timer.Dispose(); } catch { } };
            Refresh2();
        }

        private void BuildUi()
        {
            Panel box = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8, 8, 8, 4) };

            _head = new Label
            {
                Dock = DockStyle.Top,
                Height = 56,          // room for the second line to wrap on a narrow window
                Font = new Font(Font.FontFamily, 9.5f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Text = "Transfer status: ready - select a job in the Jobs tab and press Run"
            };
            _bar = new ProgressBar { Dock = DockStyle.Top, Height = 12, Minimum = 0, Maximum = 100 };
            Panel gap = new Panel { Dock = DockStyle.Top, Height = 4 };

            _list = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                HideSelection = false
            };
            _list.Columns.Add("Time", 70);
            _list.Columns.Add("Step", 45);
            _list.Columns.Add("#", 60);
            _list.Columns.Add("Status", 60);
            _list.Columns.Add("Kind", 75);
            _list.Columns.Add("Statement / table", 330);
            _list.Columns.Add("Records", 95, HorizontalAlignment.Right);
            _list.Columns.Add("Took", 85, HorizontalAlignment.Right);
            _list.Columns.Add("Message", 420);

            box.Controls.Add(_list);
            box.Controls.Add(gap);
            box.Controls.Add(_bar);
            box.Controls.Add(_head);

            FlowLayoutPanel bar = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 44,
                FlowDirection = FlowDirection.RightToLeft,
                Padding = new Padding(8, 7, 8, 7)
            };
            bar.Controls.Add(MkBtn("Close", (s, e) => Close()));
            _btnStop = MkBtn("Stop job", (s, e) => StopRunningJob());
            _btnStop.Enabled = false;
            bar.Controls.Add(_btnStop);
            bar.Controls.Add(MkBtn("Clear list", (s, e) => { _list.Items.Clear(); _seen = -1; }));
            bar.Controls.Add(MkBtn("Job History...", (s, e) =>
            {
                using (JobHistoryForm f = new JobHistoryForm(_config)) f.ShowDialog(this);
            }));

            _status = new StatusStrip();
            _lblTable = new ToolStripStatusLabel("Table: -")
            { BorderSides = ToolStripStatusLabelBorderSides.Right, BorderStyle = Border3DStyle.Etched };
            _lblRows = new ToolStripStatusLabel("Records: 0")
            { BorderSides = ToolStripStatusLabelBorderSides.Right, BorderStyle = Border3DStyle.Etched };
            _lblTime = new ToolStripStatusLabel("Ready") { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
            _status.Items.Add(_lblTable);
            _status.Items.Add(_lblRows);
            _status.Items.Add(_lblTime);

            Controls.Add(box);
            Controls.Add(bar);
            Controls.Add(_status);
        }

        private Button MkBtn(string text, EventHandler h)
        {
            Button b = new Button { Text = text, Width = 110, Height = 28, Margin = new Padding(6, 0, 0, 0) };
            if (h != null) b.Click += h;
            return b;
        }

        private void StopRunningJob()
        {
            string job;
            lock (RunTrace.LiveLock) { job = RunTrace.LiveRunning ? RunTrace.LiveJob : null; }
            if (string.IsNullOrEmpty(job)) { MessageBox.Show(this, "No transfer is running.", "Stop"); return; }
            if (MessageBox.Show(this, "Stop the running job \"" + job + "\" ?", "Stop",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            if (_config != null && _config.Jobs != null)
                foreach (SyncJob j in _config.Jobs)
                    if (string.Equals(j.Name, job, StringComparison.CurrentCultureIgnoreCase) && Engine.IsRunning(j.Id))
                        Engine.RequestStop(j.Id);
            try { Audit.Write("JOB_STOP", job + " (from Transfer status)"); } catch { }
        }

        /// <summary>Reads the live trace every second and keeps the list, the header and the status bar in step.</summary>
        private void Refresh2()
        {
            try
            {
                List<TraceEntry> newOnes = new List<TraceEntry>();
                bool running; string job, table, stepName; int idx, tot, stepIdx, stepTot;
                long rows, jobRows; DateTime st, curAt, fin; int ver;
                lock (RunTrace.LiveLock)
                {
                    ver = RunTrace.LiveVersion;
                    running = RunTrace.LiveRunning;
                    if (ver == _seen && !running) return;
                    if (_seen < 0 || RunTrace.Live.Count < _list.Items.Count) _list.Items.Clear();
                    for (int i = _list.Items.Count; i < RunTrace.Live.Count; i++) newOnes.Add(RunTrace.Live[i]);
                    job = RunTrace.LiveJob; table = RunTrace.LiveTable;
                    idx = RunTrace.LiveIndex; tot = RunTrace.LiveTotal;
                    rows = RunTrace.LiveRows; jobRows = RunTrace.LiveJobRows;
                    st = RunTrace.LiveStartedAt; curAt = RunTrace.LiveCurrentAt; fin = RunTrace.LiveFinishedAt;
                    stepName = RunTrace.LiveStepName; stepIdx = RunTrace.LiveStepIndex; stepTot = RunTrace.LiveStepTotal;
                }
                _seen = ver;

                if (newOnes.Count > 0)
                {
                    _list.BeginUpdate();
                    foreach (TraceEntry e in newOnes)
                    {
                        ListViewItem it = new ListViewItem(e.Time.ToString("HH:mm:ss"));
                        it.SubItems.Add(e.StepId.ToString());
                        it.SubItems.Add(e.Index > 0 ? e.Index + "/" + e.Total : "-");
                        it.SubItems.Add(e.Status);
                        it.SubItems.Add(e.Kind);
                        it.SubItems.Add(e.Title);
                        it.SubItems.Add(e.Rows.ToString("N0"));
                        it.SubItems.Add(ShortTime(e.Ms));
                        it.SubItems.Add((e.Message ?? "").Replace("\r", " ").Replace("\n", " "));
                        if (e.Status == "FAIL") it.BackColor = Color.FromArgb(255, 220, 220);
                        else if (e.Status == "WARN") it.BackColor = Color.FromArgb(255, 245, 200);
                        else if (e.Kind == "STEP") it.BackColor = Color.FromArgb(225, 235, 250);
                        _list.Items.Add(it);
                    }
                    _list.EndUpdate();
                    _list.EnsureVisible(_list.Items.Count - 1);
                }

                _btnStop.Enabled = running;

                if (running)
                {
                    double curSec = (DateTime.Now - curAt).TotalSeconds;
                    double allSec = (DateTime.Now - st).TotalSeconds;
                    if (curSec < 0) curSec = 0;
                    if (allSec < 0) allSec = 0;
                    long speed = curSec >= 1 ? (long)(rows / curSec) : 0;

                    // top line = the JOB STEP that is running (never the T-SQL itself)
                    string stepText = "Step "
                        + (stepTot > 0 ? stepIdx + "/" + stepTot : (stepIdx > 0 ? stepIdx.ToString() : "-"))
                        + (string.IsNullOrEmpty(stepName) ? "" : ":  " + stepName);
                    string obj = string.IsNullOrEmpty(table) ? "(preparing)" : table;

                    _head.ForeColor = Color.FromArgb(0, 70, 140);
                    _head.Text = "RUNNING  " + job + "   |   " + stepText
                        + "\r\ntable/view: " + obj
                        + "   |   records: " + rows.ToString("N0")
                        + (speed > 0 ? " (" + speed.ToString("N0") + " rows/s)" : "")
                        + "   |   run total: " + (jobRows + rows).ToString("N0")
                        + "   |   elapsed: " + JobHistory.FormatElapsed((long)(allSec * 1000))
                        + (string.IsNullOrEmpty(RunTrace.LiveRoute) ? "" : "   |   " + RunTrace.LiveRoute);

                    int v = tot > 0 ? Math.Max(0, Math.Min(100, (int)((idx - 1) * 100.0 / tot))) : 0;
                    if (_bar.Style != ProgressBarStyle.Continuous) _bar.Style = ProgressBarStyle.Continuous;
                    _bar.Value = v;

                    _lblTable.Text = "Table: " + (string.IsNullOrEmpty(table) ? "(preparing)" : table)
                        + (tot > 0 ? "   [statement " + idx + "/" + tot + "]" : "");
                    _lblRows.Text = "Records moving: " + rows.ToString("N0")
                        + "   |   run total: " + (jobRows + rows).ToString("N0");
                    _lblTime.Text = "Took: " + JobHistory.FormatElapsed((long)(curSec * 1000))
                        + "   |   job elapsed: " + JobHistory.FormatElapsed((long)(allSec * 1000))
                        + "   |   started by: " + RunTrace.LiveRunSource;
                }
                else if (_list.Items.Count > 0)
                {
                    double allSec = (st > DateTime.MinValue && fin > st) ? (fin - st).TotalSeconds : 0;
                    string took = allSec > 0 ? JobHistory.FormatElapsed((long)(allSec * 1000)) : "-";
                    _head.ForeColor = SystemColors.ControlText;
                    _head.Text = "Finished  " + job + "   -   records: " + jobRows.ToString("N0")
                        + "   -   took: " + took
                        + "\r\n(the list stays until the next run)";
                    _bar.Value = 100;
                    _lblTable.Text = "Table: -";
                    _lblRows.Text = "Records: " + jobRows.ToString("N0");
                    _lblTime.Text = "Finished " + (fin > DateTime.MinValue ? fin.ToString("HH:mm:ss") : "")
                        + "   |   the run took " + took;
                }
            }
            catch { }
        }

        /// <summary>The "Took" column - seconds only, never milliseconds.</summary>
        private static string ShortTime(long ms)
        {
            return JobHistory.FormatSeconds(ms);
        }
    }
}
