using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using LiteDB;
using Newtonsoft.Json;

namespace SyncDB
{
    /// <summary>
    /// Local durable queue (LiteDB file).
    /// SQL transfer failure → durable intent (job/step, no passwords) → worker replays it,
    /// or a producer can enqueue an HTTP message.
    /// File: %APPDATA%\SyncDB\outbox.db
    /// </summary>
    public static class OutboxStore
    {
        public const int DefaultMaxRetries = 8;

        public static class Status
        {
            public const string Pending = "Pending";
            public const string Processing = "Processing";
            public const string Failed = "Failed";
            public const string Sent = "Sent";
            public const string Dead = "Dead";
            public const string Skipped = "Skipped";
        }

        public class OutboxItem
        {
            public int Id { get; set; }
            /// <summary>Idempotency key. A unique index protects against producer retries.</summary>
            public string MessageId { get; set; }
            public string Kind { get; set; }          // TransferReplay | Http | Legacy
            public string JobId { get; set; }
            public string JobName { get; set; }
            public int StepId { get; set; }
            public string StepName { get; set; }
            public string PayloadPath { get; set; }
            public string Status { get; set; }        // Pending | Processing | Failed | Sent | Dead | Skipped
            public int Attempts { get; set; }
            public string LastError { get; set; }
            public DateTime CreatedUtc { get; set; }
            public DateTime? UpdatedUtc { get; set; }
            public DateTime? NextAttemptUtc { get; set; }
            public DateTime? ProcessingStartedUtc { get; set; }
            public DateTime? CompletedUtc { get; set; }
            public string Transport { get; set; }     // Local | Http | Kafka | Nats
            public string TopicOrSubject { get; set; }
            public string DestinationUrl { get; set; }
            public string HttpMethod { get; set; }
            public string HttpHeaders { get; set; }   // one per line: Name: Value
            public string ContentType { get; set; }
            public string DeadReason { get; set; }
            public string OriginId { get; set; }
            /// <summary>Append is not idempotent; a blind replay can duplicate partially written rows.</summary>
            public bool ReplaySafe { get; set; }
            /// <summary>If set and it equals this node's OriginId, the item is not delivered (loop prevention).</summary>
            public string TargetOriginId { get; set; }

            [BsonIgnore]
            public string StatusText
            {
                get
                {
                    string s = Status ?? "";
                    if (s == "Pending" || s == "Failed") return s + " (" + Attempts + ")";
                    return s;
                }
            }
        }

        public class OutboxCounts
        {
            public int Pending;
            public int Processing;
            public int Failed;
            public int Sent;
            public int Dead;
            public int Skipped;
            public int Total { get { return Pending + Processing + Failed + Sent + Dead + Skipped; } }
        }

        public static string DbPath
        {
            get { return Path.Combine(AppConfig.DataDir, "outbox.db"); }
        }

        public static string PayloadFolder
        {
            get { return Path.Combine(AppConfig.DataDir, "outbox", "payload"); }
        }

        private static string Conn
        {
            get { return "Filename=" + DbPath + ";Connection=shared"; }
        }

        private static readonly object InitGate = new object();
        private static string _initializedPath;

        public static void EnsureOpen()
        {
            string path = DbPath;
            lock (InitGate)
            {
                if (string.Equals(_initializedPath, path, StringComparison.OrdinalIgnoreCase)) return;
                Directory.CreateDirectory(AppConfig.DataDir);
                using (var db = new LiteDatabase(Conn))
                {
                    var col = db.GetCollection<OutboxItem>("outbox");
                    col.EnsureIndex(x => x.Status);
                    col.EnsureIndex(x => x.JobId);
                    col.EnsureIndex(x => x.NextAttemptUtc);
                    col.EnsureIndex(x => x.CreatedUtc);
                    try
                    {
                        // The real idempotency guarantee, also across GUI + service processes.
                        col.EnsureIndex(x => x.MessageId, true);
                    }
                    catch (Exception ex)
                    {
                        AppLog.Warn("-", "Outbox unique MessageId index unavailable (old duplicates?): " + ex.Message);
                        try { col.EnsureIndex(x => x.MessageId); } catch { }
                    }
                }
                _initializedPath = path;
            }
        }

        /// <summary>Stable idempotency key (same event => same key).</summary>
        public static string MakeMessageId(string jobId, string step, string payloadPath)
        {
            return Hash("v2|" + (jobId ?? "") + "|" + (step ?? "") + "|" + (payloadPath ?? ""));
        }

        /// <summary>Stable within the same UTC minute; repeated enqueue calls for one failure are deduplicated.</summary>
        public static string MakeMessageId(string jobId, int stepId, string discriminator, DateTime occurredUtc)
        {
            string minute = occurredUtc.ToUniversalTime().ToString("yyyyMMddHHmm");
            return Hash("v2|" + (jobId ?? "") + "|" + stepId + "|" + (discriminator ?? "") + "|" + minute);
        }

        private static string Hash(string raw)
        {
            using (var sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(raw ?? ""));
                var sb = new StringBuilder(hash.Length * 2);
                for (int i = 0; i < hash.Length; i++) sb.Append(hash[i].ToString("x2"));
                return sb.ToString();
            }
        }

        public static int Enqueue(string jobId, string jobName, string stepName, string payloadPath,
            string transport, string topic)
        {
            return Enqueue(jobId, jobName, stepName, payloadPath, transport, topic, null);
        }

        public static int Enqueue(string jobId, string jobName, string stepName, string payloadPath,
            string transport, string topic, string messageId)
        {
            OutboxItem item = new OutboxItem();
            item.JobId = jobId ?? "";
            item.JobName = jobName ?? "";
            item.StepName = stepName ?? "";
            item.PayloadPath = payloadPath ?? "";
            item.Transport = string.IsNullOrWhiteSpace(transport) ? "Local" : transport.Trim();
            item.TopicOrSubject = topic ?? "";
            item.MessageId = messageId;
            item.Kind = "TransferReplay";
            return Enqueue(item);
        }

        /// <summary>Queue one payload. Returns the existing row id when MessageId was already seen.</summary>
        public static int Enqueue(OutboxItem item)
        {
            if (item == null) throw new ArgumentNullException("item");
            EnsureOpen();
            DateTime now = DateTime.UtcNow;
            if (string.IsNullOrEmpty(item.MessageId))
                item.MessageId = MakeMessageId(item.JobId, item.StepId + ":" + (item.StepName ?? ""),
                    item.PayloadPath ?? Guid.NewGuid().ToString("N"));
            if (string.IsNullOrEmpty(item.Status)) item.Status = Status.Pending;
            if (item.CreatedUtc == default(DateTime)) item.CreatedUtc = now;
            if (!item.NextAttemptUtc.HasValue) item.NextAttemptUtc = now;
            if (string.IsNullOrWhiteSpace(item.Transport)) item.Transport = "Local";
            if (string.IsNullOrWhiteSpace(item.Kind)) item.Kind = "TransferReplay";
            item.UpdatedUtc = now;

            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                OutboxItem existing = col.Query().Where(x => x.MessageId == item.MessageId).FirstOrDefault();
                if (existing != null)
                {
                    AppLog.Info("-", "Outbox skip duplicate MessageId=" + Short(item.MessageId) + " existing #" + existing.Id +
                                     " (" + existing.Status + ")");
                    return existing.Id;
                }
                try
                {
                    col.Insert(item);
                }
                catch (Exception ex)
                {
                    // Unique index race: another process inserted first.
                    existing = col.Query().Where(x => x.MessageId == item.MessageId).FirstOrDefault();
                    if (existing != null) return existing.Id;
                    throw new Exception("Outbox insert failed: " + ex.Message, ex);
                }
                AppLog.Info("-", "Outbox queued #" + item.Id + " [" + item.Transport + "/" + item.Kind + "] " + item.StepName);
                try
                {
                    if (!string.IsNullOrEmpty(item.OriginId))
                        CacheStoreFactory.Current.MarkOrigin(item.MessageId, item.OriginId, item.JobId, now);
                }
                catch { }
                return item.Id;
            }
        }

        public static int EnqueueFailure(string jobId, string jobName, JobStep step, AppConfig cfg, string error)
        {
            SyncJob job = new SyncJob();
            job.Id = jobId ?? "";
            job.Name = jobName ?? "";
            return EnqueueFailure(job, step, cfg, error);
        }

        /// <summary>Called only after all transfer retries failed. Stores metadata, never connection passwords.</summary>
        public static int EnqueueFailure(SyncJob job, JobStep step, AppConfig cfg, string error)
        {
            if (job == null || step == null || cfg == null) return -1;
            if (!cfg.OutboxEnabled) return -1;
            DateTime now = DateTime.UtcNow;
            string messageId = MakeMessageId(job.Id, step.StepId, "transfer-fail", now);
            string payloadPath = Path.Combine(PayloadFolder, messageId.Substring(0, 16) + ".json");
            try
            {
                Directory.CreateDirectory(PayloadFolder);
                var payload = new
                {
                    format = "SyncDB-outbox-replay",
                    version = 2,
                    jobId = job.Id,
                    jobName = job.Name,
                    stepId = step.StepId,
                    stepName = step.Name,
                    sourceTable = step.SourceTable,
                    destTable = step.DestTable,
                    mode = step.Mode.ToString(),
                    error = error ?? "",
                    createdUtc = now.ToString("o"),
                    originId = cfg.OriginId
                };
                File.WriteAllText(payloadPath, JsonConvert.SerializeObject(payload, Formatting.Indented), new UTF8Encoding(false));
            }
            catch (Exception ex)
            {
                AppLog.Warn(job.Name, "Outbox payload file could not be written: " + ex.Message);
            }

            OutboxItem item = new OutboxItem();
            item.MessageId = messageId;
            item.Kind = "TransferReplay";
            item.JobId = job.Id;
            item.JobName = job.Name ?? "";
            item.StepId = step.StepId;
            item.StepName = step.Name ?? "";
            item.PayloadPath = payloadPath;
            item.Transport = "Local";
            item.OriginId = cfg.OriginId;
            // TruncateInsert/DeleteInsert start from a clean destination; Merge/Sync are keyed upserts.
            // Append can have committed some batches before the failure, so it must stay manual.
            item.ReplaySafe = step.Mode != WriteMode.Append;
            item.CreatedUtc = now;
            item.NextAttemptUtc = now.AddSeconds(30);  // give a temporary outage a moment to clear
            item.LastError = TrimError(error);
            int id = Enqueue(item);
            Audit.Write("OUTBOX_ENQUEUE", "job=" + job.Name + " step=" + step.Name + " id=" + id + " " + TrimError(error));
            return id;
        }

        /// <summary>Generic HTTP delivery: payload is posted by the worker; no external client library needed.</summary>
        public static int EnqueueHttp(string jobId, string jobName, string stepName, string url,
            string jsonPayload, string headers, string messageId)
        {
            if (string.IsNullOrWhiteSpace(url)) throw new ArgumentException("Destination URL is empty.", "url");
            DateTime now = DateTime.UtcNow;
            string mid = string.IsNullOrWhiteSpace(messageId)
                ? Hash("http|" + (jobId ?? "") + "|" + (stepName ?? "") + "|" + (jsonPayload ?? ""))
                : messageId;
            string path = Path.Combine(PayloadFolder, mid.Substring(0, 16) + ".json");
            Directory.CreateDirectory(PayloadFolder);
            File.WriteAllText(path, jsonPayload ?? "", new UTF8Encoding(false));

            OutboxItem item = new OutboxItem();
            item.MessageId = mid;
            item.Kind = "Http";
            item.JobId = jobId ?? "";
            item.JobName = jobName ?? "";
            item.StepName = stepName ?? "";
            item.PayloadPath = path;
            item.Transport = "Http";
            item.DestinationUrl = url.Trim();
            item.HttpMethod = "POST";
            item.HttpHeaders = headers ?? "";
            item.ContentType = "application/json; charset=utf-8";
            item.CreatedUtc = now;
            item.NextAttemptUtc = now;
            return Enqueue(item);
        }

        public static OutboxItem Get(int id)
        {
            EnsureOpen();
            using (var db = new LiteDatabase(Conn))
                return db.GetCollection<OutboxItem>("outbox").FindById(id);
        }

        /// <summary>Items whose retry time has arrived. Ordered by NextAttemptUtc so old backed-off rows cannot starve.</summary>
        public static List<OutboxItem> ListReady(int max)
        {
            if (max < 1) max = 1;
            if (max > 1000) max = 1000;
            EnsureOpen();
            DateTime now = DateTime.UtcNow;
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                // LiteDB 4 materializes DateTime as Local kind. Comparing that directly with
                // DateTime.UtcNow compares wall-clock ticks and can delay an item by the UTC offset,
                // so all date filtering is done after normalizing to UTC.
                List<OutboxItem> candidates = col.Query()
                    .Where(x => x.Status == "Pending" || x.Status == "Failed")
                    .ToList();
                List<OutboxItem> ready = new List<OutboxItem>();
                foreach (OutboxItem x in candidates)
                {
                    if (!x.NextAttemptUtc.HasValue || x.NextAttemptUtc.Value.ToUniversalTime() <= now)
                        ready.Add(x);
                }
                ready.Sort(delegate(OutboxItem a, OutboxItem b)
                {
                    DateTime da = a.NextAttemptUtc.HasValue ? a.NextAttemptUtc.Value.ToUniversalTime() : DateTime.MinValue;
                    DateTime dbv = b.NextAttemptUtc.HasValue ? b.NextAttemptUtc.Value.ToUniversalTime() : DateTime.MinValue;
                    return da.CompareTo(dbv);
                });
                if (ready.Count > max) ready = ready.GetRange(0, max);
                return ready;
            }
        }

        public static List<OutboxItem> ListPending(int max)
        {
            return ListReady(max);
        }

        public static List<OutboxItem> ListByStatus(string status, int max)
        {
            if (max < 1) max = 500;
            EnsureOpen();
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                if (string.IsNullOrEmpty(status) || status == "All")
                    return col.Query().OrderByDescending(x => x.CreatedUtc).Limit(max).ToList();
                return col.Query().Where(x => x.Status == status).OrderByDescending(x => x.CreatedUtc).Limit(max).ToList();
            }
        }

        public static bool TryClaim(int id, TimeSpan lease, out OutboxItem claimed)
        {
            claimed = null;
            EnsureOpen();
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                db.BeginTrans();
                try
                {
                    OutboxItem item = col.FindById(id);
                    if (item == null) { db.Rollback(); return false; }
                    DateTime now = DateTime.UtcNow;
                    bool due = (item.Status == Status.Pending || item.Status == Status.Failed) &&
                               (!item.NextAttemptUtc.HasValue || item.NextAttemptUtc.Value.ToUniversalTime() <= now);
                    bool stale = item.Status == Status.Processing &&
                                 (!item.ProcessingStartedUtc.HasValue || item.ProcessingStartedUtc.Value.ToUniversalTime() <= now - lease);
                    if (!due && !stale) { db.Rollback(); return false; }
                    item.Status = Status.Processing;
                    item.ProcessingStartedUtc = now;
                    item.UpdatedUtc = now;
                    item.LastError = "";
                    col.Update(item);
                    db.Commit();
                    claimed = item;
                    return true;
                }
                catch
                {
                    try { db.Rollback(); } catch { }
                    throw;
                }
            }
        }

        public static void MarkSent(int id)
        {
            EnsureOpen();
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                OutboxItem item = col.FindById(id);
                if (item == null || item.Status == Status.Sent) return;
                DateTime now = DateTime.UtcNow;
                item.Status = Status.Sent;
                item.LastError = "";
                item.DeadReason = "";
                item.CompletedUtc = now;
                item.UpdatedUtc = now;
                item.NextAttemptUtc = null;
                item.ProcessingStartedUtc = null;
                col.Update(item);
            }
        }

        public static void MarkSkipped(int id, string reason)
        {
            EnsureOpen();
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                OutboxItem item = col.FindById(id);
                if (item == null) return;
                DateTime now = DateTime.UtcNow;
                item.Status = Status.Skipped;
                item.DeadReason = reason ?? "skipped";
                item.CompletedUtc = now;
                item.UpdatedUtc = now;
                item.NextAttemptUtc = null;
                item.ProcessingStartedUtc = null;
                col.Update(item);
            }
        }

        public static void MarkFailed(int id, string error, int maxRetries)
        {
            MarkFailed(id, error, maxRetries, false);
        }

        public static void MarkFailed(int id, string error, int maxRetries, bool permanent)
        {
            if (maxRetries < 1) maxRetries = DefaultMaxRetries;
            EnsureOpen();
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                OutboxItem item = col.FindById(id);
                if (item == null || item.Status == Status.Sent || item.Status == Status.Skipped) return;
                item.Attempts = item.Attempts + 1;
                item.LastError = TrimError(error);
                item.UpdatedUtc = DateTime.UtcNow;
                item.ProcessingStartedUtc = null;

                if (permanent || item.Attempts >= maxRetries)
                {
                    item.Status = Status.Dead;
                    item.DeadReason = permanent
                        ? "Permanent delivery failure: " + TrimError(error)
                        : "Max retries (" + maxRetries + ") exceeded: " + TrimError(error);
                    item.NextAttemptUtc = null;
                    item.CompletedUtc = DateTime.UtcNow;
                    AppLog.Warn("-", "Outbox DEAD #" + id + " after " + item.Attempts + " attempt(s): " + TrimError(error));
                    Audit.Write("OUTBOX_DEAD", "#" + id + " " + TrimError(error));
                }
                else
                {
                    item.Status = Status.Failed;
                    // 5, 10, 20, 40 ... seconds, capped at 15 minutes, plus small stable jitter.
                    int exp = Math.Min(item.Attempts - 1, 8);
                    int delaySec = Math.Min(900, 5 * (1 << exp));
                    delaySec += Math.Abs(id) % 5;
                    item.NextAttemptUtc = DateTime.UtcNow.AddSeconds(delaySec);
                }
                col.Update(item);
            }
        }

        /// <summary>Legacy helper. Does not treat every non-Sent status as a retryable failure.</summary>
        public static void Mark(int id, string status, string error)
        {
            if (status == Status.Sent) MarkSent(id);
            else if (status == Status.Skipped) MarkSkipped(id, error);
            else MarkFailed(id, error, DefaultMaxRetries, status == Status.Dead);
        }

        /// <summary>Releases Processing rows left behind by a crash and applies the normal retry/DLQ policy.</summary>
        public static int ReleaseStale(TimeSpan lease, int maxRetries)
        {
            EnsureOpen();
            DateTime cutoff = DateTime.UtcNow - lease;
            int released = 0;
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                List<OutboxItem> rows = col.Query().Where(x => x.Status == "Processing").ToList();
                foreach (OutboxItem item in rows)
                {
                    if (item.ProcessingStartedUtc.HasValue &&
                        item.ProcessingStartedUtc.Value.ToUniversalTime() > cutoff) continue;
                    item.Status = Status.Failed;
                    item.Attempts = item.Attempts + 1;
                    item.LastError = "Worker stopped or lease expired while processing.";
                    item.UpdatedUtc = DateTime.UtcNow;
                    item.ProcessingStartedUtc = null;
                    if (item.Attempts >= (maxRetries < 1 ? DefaultMaxRetries : maxRetries))
                    {
                        item.Status = Status.Dead;
                        item.DeadReason = "Max retries after worker crash/lease expiry.";
                        item.NextAttemptUtc = null;
                    }
                    else
                    {
                        item.NextAttemptUtc = DateTime.UtcNow;
                    }
                    col.Update(item);
                    released++;
                }
            }
            if (released > 0) AppLog.Warn("-", "Outbox recovered " + released + " stale Processing item(s).");
            return released;
        }

        /// <summary>Explicit operator override for an Append-mode item after accepting the duplicate risk.</summary>
        public static bool SetReplaySafe(int id, bool safe)
        {
            EnsureOpen();
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                OutboxItem item = col.FindById(id);
                if (item == null) return false;
                item.ReplaySafe = safe;
                item.UpdatedUtc = DateTime.UtcNow;
                col.Update(item);
                return true;
            }
        }

        public static bool Requeue(int id, bool resetAttempts)
        {
            EnsureOpen();
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                OutboxItem item = col.FindById(id);
                if (item == null) return false;
                // Never pull an item out from under an active worker; ReleaseStale handles crashes.
                if (item.Status == Status.Processing) return false;
                item.Status = Status.Pending;
                item.NextAttemptUtc = DateTime.UtcNow;
                item.UpdatedUtc = DateTime.UtcNow;
                item.DeadReason = "";
                item.LastError = "";
                item.CompletedUtc = null;
                item.ProcessingStartedUtc = null;
                if (resetAttempts) item.Attempts = 0;
                col.Update(item);
                return true;
            }
        }

        public static int RequeueDead(int max)
        {
            int n = 0;
            foreach (OutboxItem item in ListByStatus(Status.Dead, max))
                if (Requeue(item.Id, true)) n++;
            return n;
        }

        public static bool Delete(int id)
        {
            EnsureOpen();
            string payload = null;
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                OutboxItem item = col.FindById(id);
                if (item == null) return false;
                if (item.Status == Status.Processing) return false;
                payload = item.PayloadPath;
                col.Delete(id);
            }
            DeletePayload(payload);
            return true;
        }

        public static int PurgeCompleted(DateTime cutoffUtc)
        {
            EnsureOpen();
            int n = 0;
            using (var db = new LiteDatabase(Conn))
            {
                var col = db.GetCollection<OutboxItem>("outbox");
                List<OutboxItem> rows = col.Query()
                    .Where(x => x.Status == "Sent" || x.Status == "Skipped")
                    .ToList();
                DateTime cutoff = cutoffUtc.ToUniversalTime();
                foreach (OutboxItem item in rows)
                {
                    if (!item.CompletedUtc.HasValue || item.CompletedUtc.Value.ToUniversalTime() > cutoff) continue;
                    if (col.Delete(item.Id)) { n++; DeletePayload(item.PayloadPath); }
                }
            }
            if (n > 0) AppLog.Info("-", "Outbox purged " + n + " completed item(s).");
            return n;
        }

        /// <summary>
        /// Deletes payload .json files that no outbox row points at. A payload file is written just
        /// BEFORE its row is inserted, so a crash, a duplicate MessageId or a row removed another way
        /// used to leave the file behind forever. Files younger than 30 minutes are left alone.
        /// </summary>
        public static int SweepOrphanPayloads()
        {
            string folder = PayloadFolder;
            try { if (!Directory.Exists(folder)) return 0; }
            catch { return 0; }

            HashSet<string> used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                EnsureOpen();
                using (var db = new LiteDatabase(Conn))
                {
                    var col = db.GetCollection<OutboxItem>("outbox");
                    foreach (OutboxItem it in col.FindAll())
                    {
                        if (it == null || string.IsNullOrWhiteSpace(it.PayloadPath)) continue;
                        try { used.Add(Path.GetFullPath(it.PayloadPath)); }
                        catch { used.Add(it.PayloadPath); }
                    }
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "Outbox payload sweep skipped: " + ex.Message);
                return 0;      // never delete payloads when the queue could not be read
            }

            int n = 0;
            try
            {
                foreach (string f in Directory.GetFiles(folder, "*.json"))
                {
                    try
                    {
                        if (used.Contains(Path.GetFullPath(f))) continue;
                        if ((DateTime.Now - File.GetLastWriteTime(f)).TotalMinutes < 30) continue;
                        File.Delete(f);
                        n++;
                    }
                    catch { }
                }
            }
            catch { }
            if (n > 0) AppLog.Info("-", "Outbox removed " + n + " orphan payload file(s).");
            return n;
        }

        /// <summary>
        /// Checkpoints and rebuilds outbox.db. LiteDB does not shrink when rows are deleted and the
        /// "-log.db" side file grows until a checkpoint, so purged items kept using disk space.
        /// Returns the number of bytes released.
        /// </summary>
        public static long Compact()
        {
            long before = DbBytes();
            try
            {
                EnsureOpen();
                using (var db = new LiteDatabase(Conn))
                {
                    db.Checkpoint();
                    db.Rebuild(null);
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "outbox.db rebuild skipped: " + ex.Message);
                return 0;
            }
            long after = DbBytes();
            return before > after ? before - after : 0;
        }

        /// <summary>Merges the write-ahead log into outbox.db (cheap, safe to call often).</summary>
        public static long Checkpoint()
        {
            long before = DbBytes();
            try
            {
                EnsureOpen();
                using (var db = new LiteDatabase(Conn)) db.Checkpoint();
            }
            catch { return 0; }
            long after = DbBytes();
            return before > after ? before - after : 0;
        }

        /// <summary>outbox.db + outbox-log.db on disk.</summary>
        public static long DbBytes()
        {
            long n = 0;
            try
            {
                string db = DbPath;
                if (File.Exists(db)) n += new FileInfo(db).Length;
                string log = Path.Combine(Path.GetDirectoryName(db) ?? "",
                    Path.GetFileNameWithoutExtension(db) + "-log" + Path.GetExtension(db));
                if (File.Exists(log)) n += new FileInfo(log).Length;
            }
            catch { }
            return n;
        }

        private static void DeletePayload(string path)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return;
                string full = Path.GetFullPath(path);
                string root = Path.GetFullPath(AppConfig.DataDir).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                string rootWithSep = root + Path.DirectorySeparatorChar;
                if (full.StartsWith(rootWithSep, StringComparison.OrdinalIgnoreCase)) File.Delete(full);
            }
            catch { }
        }

        public static OutboxCounts Counts()
        {
            OutboxCounts c = new OutboxCounts();
            try
            {
                EnsureOpen();
                using (var db = new LiteDatabase(Conn))
                {
                    var col = db.GetCollection<OutboxItem>("outbox");
                    c.Pending = col.Query().Where(x => x.Status == "Pending").Count();
                    c.Processing = col.Query().Where(x => x.Status == "Processing").Count();
                    c.Failed = col.Query().Where(x => x.Status == "Failed").Count();
                    c.Sent = col.Query().Where(x => x.Status == "Sent").Count();
                    c.Dead = col.Query().Where(x => x.Status == "Dead").Count();
                    c.Skipped = col.Query().Where(x => x.Status == "Skipped").Count();
                }
            }
            catch { }
            return c;
        }

        public static int PendingCount()
        {
            OutboxCounts c = Counts();
            return c.Pending + c.Failed + c.Processing;
        }

        public static int DeadCount()
        {
            return Counts().Dead;
        }

        public static string Stats()
        {
            try
            {
                OutboxCounts c = Counts();
                return "Outbox: pending=" + c.Pending + " processing=" + c.Processing + " failed=" + c.Failed +
                       " sent=" + c.Sent + " dead=" + c.Dead + " skipped=" + c.Skipped;
            }
            catch (Exception ex) { return "Outbox: " + ex.Message; }
        }

        private static string TrimError(string error)
        {
            string e = error ?? "";
            e = e.Replace("\r", " ").Replace("\n", " ");
            return e.Length > 4000 ? e.Substring(0, 4000) : e;
        }

        private static string Short(string s)
        {
            return string.IsNullOrEmpty(s) ? "" : (s.Length > 12 ? s.Substring(0, 12) + "…" : s);
        }
    }

    /// <summary>
    /// Optional bridge targets (Kafka / NATS). Native clients are not bundled; the worker must not
    /// pretend these messages were sent. This class only logs configuration intent.
    /// </summary>
    public static class ChangeBridge
    {
        public static void PublishHint(AppConfig cfg, OutboxStore.OutboxItem item)
        {
            if (cfg == null || item == null) return;
            string t = (item.Transport ?? "Local").Trim();
            if (t.Equals("Kafka", StringComparison.OrdinalIgnoreCase))
            {
                string boot = (cfg.KafkaBootstrap ?? "").Trim();
                string topic = string.IsNullOrEmpty(item.TopicOrSubject) ? (cfg.KafkaTopic ?? "syncdb.changes") : item.TopicOrSubject;
                AppLog.Warn("-", "Kafka bootstrap=" + boot + " topic=" + topic +
                    " — native Kafka client is not bundled; outbox #" + item.Id + " cannot be sent.");
            }
            else if (t.Equals("Nats", StringComparison.OrdinalIgnoreCase))
            {
                string url = (cfg.NatsUrl ?? "").Trim();
                string subj = string.IsNullOrEmpty(item.TopicOrSubject) ? (cfg.NatsSubject ?? "syncdb.changes") : item.TopicOrSubject;
                AppLog.Warn("-", "NATS url=" + url + " subject=" + subj +
                    " — native NATS client is not bundled; outbox #" + item.Id + " cannot be sent.");
            }
        }
    }
}
