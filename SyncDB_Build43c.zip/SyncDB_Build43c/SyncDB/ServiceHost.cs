﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Windows.Forms;

namespace SyncDB
{
    /// <summary>Windows Service host: runs the same JobScheduler without any UI.</summary>
    public class SyncDbService : ServiceBase
    {
        public const string SvcName = "SyncDB";

        private JobScheduler _sch;
        private OutboxWorker _outbox;
        private System.Threading.Timer _reload;
        private int _reloadCount;

        public SyncDbService()
        {
            ServiceName = SvcName;
            CanStop = true;
            AutoLog = true;
        }

        private static AppConfig LoadCfg()
        {
            AppConfig c = AppConfig.Load();
            c.SchedulerEnabled = true;           // a running Windows service always schedules
            try { RuntimeSettings.Apply(c); }    // the service must honour the disk-buffer switch too
            catch { }
            return c;
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                AppConfig cfg = LoadCfg();
                AppLog.Configure(cfg.EffectiveLogFolder, cfg.LogRetentionDays);
                AppLog.PurgeOldLogs();
                AppLog.Info("-", "Windows service starting. " + AppBuild.Text + " | data folder: " + AppConfig.DataDir +
                                 " | disk buffer: " + (cfg.UseDiskBuffer ? "ON" : "OFF"));
                JobScheduler.RunSource = "service";      // job history shows where the run came from
                _sch = new JobScheduler();
                _sch.JobFinished += (job, r) =>
                    AppLog.Info(job.Name, "Finished: " + (r.Ok ? "OK" : "FAIL") + " — " + r.Message);
                _sch.Start(cfg);

                // Outbox background worker (Cache + Retry + DLQ + Circuit Breaker)
                _outbox = new OutboxWorker();
                if (cfg.OutboxBatchSize > 0) _outbox.BatchSize = cfg.OutboxBatchSize;
                if (cfg.OutboxMaxRetries > 0) _outbox.MaxRetries = cfg.OutboxMaxRetries;
                if (cfg.OutboxIdleMs > 0) _outbox.IdleSleepMs = cfg.OutboxIdleMs;
                _outbox.Start(cfg);

                // Same housekeeping as the GUI: the service is usually the process that actually
                // creates the disk buffers, so it must clean them up as well.
                try { Maintenance.Start(cfg); } catch { }

                _reload = new System.Threading.Timer(Reload, null, 60000, 60000);
            }
            catch (Exception ex)
            {
                AppLog.Error("-", "Service start error: " + ex);
                throw;
            }
        }

        private void Reload(object state)
        {
            try
            {
                AppConfig cfg = LoadCfg();           // pick up job/connection edits made in the GUI
                AppLog.Configure(cfg.EffectiveLogFolder, cfg.LogRetentionDays);
                if (_sch != null) _sch.UpdateConfig(cfg);
                if (_outbox != null) _outbox.UpdateConfig(cfg);
                try { Maintenance.Reconfigure(cfg); } catch { }
                if (++_reloadCount % 60 == 0) AppLog.PurgeOldLogs();
            }
            catch (Exception ex) { AppLog.Error("-", "Config reload error: " + ex.Message); }
        }

        protected override void OnStop()
        {
            try
            {
                if (_reload != null) { _reload.Dispose(); _reload = null; }
                if (_outbox != null) { _outbox.Stop(); _outbox.Dispose(); _outbox = null; }
                if (_sch != null) { _sch.Stop(); _sch.Dispose(); _sch = null; }
                try { Maintenance.Stop(); } catch { }
                try { Maintenance.CleanBufferRoot(); } catch { }
                CacheStoreFactory.Reset();
                AppLog.Info("-", "Windows service stopped.");
            }
            catch { }
        }
    }

    /// <summary>Install / uninstall / start / stop the Windows service (self-elevating).</summary>
    public static class WinSvc
    {
        public static bool IsAdmin()
        {
            try
            {
                WindowsPrincipal p = new WindowsPrincipal(WindowsIdentity.GetCurrent());
                return p.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }

        public static string Status()
        {
            try
            {
                using (ServiceController sc = new ServiceController(SyncDbService.SvcName))
                    return sc.Status.ToString();
            }
            catch { return "Not installed"; }
        }

        /// <summary>Starts this exe with a service command; it asks for admin rights itself.</summary>
        public static void LaunchCommand(string command)
        {
            Audit.Write("WINSVC_" + command.TrimStart('/').ToUpperInvariant(), "requested from the program menu");
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(Application.ExecutablePath,
                    command + " /datadir:\"" + AppConfig.DataDir + "\"");
                psi.UseShellExecute = true;
                Process.Start(psi);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "SyncDB"); }
        }


        /// <summary>Handles /install /uninstall /svcstart /svcstop. Returns true if a command was handled.</summary>
        public static bool HandleCommand(string[] args)
        {
            string cmd = null;
            foreach (string a in args)
            {
                string l = a.ToLowerInvariant();
                if (l == "/install" || l == "/uninstall" || l == "/svcstart" || l == "/svcstop") cmd = l;
            }
            if (cmd == null) return false;

            if (!IsAdmin())
            {
                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo(Application.ExecutablePath,
                        cmd + " /datadir:\"" + AppConfig.DataDir + "\"");
                    psi.UseShellExecute = true;
                    psi.Verb = "runas";
                    Process.Start(psi);
                }
                catch (Win32Exception) { MessageBox.Show("Administrator permission was cancelled.", "SyncDB"); }
                return true;
            }

            Audit.Write("WINSVC_EXEC", cmd + " (running with administrator rights)");
            StringBuilder log = new StringBuilder();
            string name = SyncDbService.SvcName;
            string st = Status();

            if (cmd == "/install")
            {
                // Data folder: the one passed on the command line (the window always passes its own).
                // Without it (build.bat calling "SyncDB.exe /install" elevated) keep the folder the
                // service was already registered with, so an elevated account can never switch the
                // service to somebody else's empty %APPDATA%.
                string svcData = AppConfig.DataDir;
                if (string.IsNullOrWhiteSpace(AppConfig.DataDirOverride))
                {
                    string regData = RegisteredDataDir();
                    if (!string.IsNullOrWhiteSpace(regData) && Directory.Exists(regData)) svcData = regData;
                }
                string bin = "\"" + Application.ExecutablePath + "\" /service /datadir:\"" + svcData + "\"";
                string binArg = "binPath= \"" + bin.Replace("\"", "\\\"") + "\"";
                if (st == "Not installed")
                    log.AppendLine(Sc("create " + name + " " + binArg + " start= auto DisplayName= \"SyncDB Scheduler\""));
                else
                {
                    if (st == "Running") { log.AppendLine(Sc("stop " + name)); WaitFor(ServiceControllerStatus.Stopped); }
                    log.AppendLine(Sc("config " + name + " " + binArg + " start= auto"));
                }
                log.AppendLine(Sc("description " + name + " \"SyncDB - scheduled SQL Server data transfer jobs\""));
                log.AppendLine(Sc("failure " + name + " reset= 86400 actions= restart/60000/restart/60000/restart/60000"));
                Sc("start " + name);
                WaitFor(ServiceControllerStatus.Running);     // so the dialog shows Running, not StartPending
                string instSt = Status();
                AppLog.Info("-", "Windows service installed. Status=" + instSt + " | " + log.ToString().Replace("\r\n", " | "));
                MessageBox.Show(Lang.T("Service installed successfully.") + "\r\n" +
                                Lang.T("Status: ") + instSt + "\r\n" +
                                Lang.T("Data folder: ") + svcData,
                                "SyncDB service", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (cmd == "/uninstall")
            {
                if (st == "Not installed")
                {
                    MessageBox.Show(Lang.T("The SyncDB service is not installed yet."), "SyncDB service",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return true;
                }
                if (st != "Stopped") { log.AppendLine(Sc("stop " + name)); WaitFor(ServiceControllerStatus.Stopped); }
                log.AppendLine(Sc("delete " + name));
                MessageBox.Show(Lang.T("Service removed successfully.") + "\r\n" +
                                Lang.T("Status: ") + Status(),
                                "SyncDB service", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (cmd == "/svcstart")
            {
                if (st == "Not installed")
                {
                    MessageBox.Show(Lang.T("The SyncDB service is not installed yet.") + "\r\n" +
                                    Lang.T("Use \"Install service\" first."),
                                    "SyncDB service", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return true;
                }

                // Build 42u: the path check used to run BEFORE the start and refused to start the
                // service when it did not find this EXE inside the raw "sc qc" text. sc.exe wraps a long
                // BINARY_PATH_NAME over several lines, the line break became a space, and a perfectly
                // correct registration looked wrong - the button did nothing. Now the service is simply
                // started, and the path is only examined if the start really failed.
                Sc("start " + name);
                WaitFor(ServiceControllerStatus.Running);
                string now = Status();

                if (now == "Running" || now == "StartPending")
                {
                    MessageBox.Show(Lang.T("Service started successfully.") + "\r\n" +
                                    Lang.T("Status: ") + now,
                                    "SyncDB service", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    // Keep the dialog short; the details belong in the log, not on screen.
                    string qc = Sc("qc " + name);
                    AppLog.Error("-", "Windows service did not start. Status=" + now + " | " + qc);
                    AppLog.Error("-", "Last log lines before the failure: " + TailLog(25).Replace("\r\n", " | "));
                    string hint = (PointsAtThisExe() && BinPathMatchesThisExe(qc))
                        ? Lang.T("See tab 6) Logs for the reason.")
                        : Lang.T("The service points at another folder. Run \"Install service\" once, then start it again.");
                    MessageBox.Show(Lang.T("The service did not start.") + "\r\n" +
                                    Lang.T("Status: ") + now + "\r\n\r\n" + hint,
                                    "SyncDB service", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (cmd == "/svcstop")
            {
                log.AppendLine(Sc("stop " + name));
                WaitFor(ServiceControllerStatus.Stopped);
                MessageBox.Show(Lang.T("Service stopped successfully.") + "\r\n" +
                                Lang.T("Status: ") + Status(),
                                "SyncDB service", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return true;
        }

        /// <summary>
        /// EXE the Windows service is registered to run, read from the registry (ImagePath) - no sc.exe
        /// text parsing involved. Null when the service is not installed or the value is unreadable.
        /// </summary>
        public static string RegisteredExePath()
        {
            try
            {
                using (Microsoft.Win32.RegistryKey k = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                    @"SYSTEM\CurrentControlSet\Services\" + SyncDbService.SvcName))
                {
                    if (k == null) return null;
                    string img = k.GetValue("ImagePath") as string;
                    if (string.IsNullOrEmpty(img)) return null;
                    img = img.Trim();
                    if (img.StartsWith("\""))
                    {
                        int q = img.IndexOf('"', 1);
                        if (q > 1) return img.Substring(1, q - 1);
                    }
                    int e = img.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
                    return e > 0 ? img.Substring(0, e + 4) : img;
                }
            }
            catch { return null; }
        }

        /// <summary>Data folder the service is registered with (the /datadir: part of ImagePath), or null.</summary>
        public static string RegisteredDataDir()
        {
            try
            {
                using (Microsoft.Win32.RegistryKey k = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                    @"SYSTEM\CurrentControlSet\Services\" + SyncDbService.SvcName))
                {
                    if (k == null) return null;
                    string img = k.GetValue("ImagePath") as string;
                    if (string.IsNullOrEmpty(img)) return null;
                    int i = img.IndexOf("/datadir:", StringComparison.OrdinalIgnoreCase);
                    if (i < 0) return null;
                    string rest = img.Substring(i + 9).Trim();
                    if (rest.StartsWith("\""))
                    {
                        int q = rest.IndexOf('"', 1);
                        return q > 1 ? rest.Substring(1, q - 1) : null;
                    }
                    int sp = rest.IndexOf(' ');
                    return sp > 0 ? rest.Substring(0, sp) : rest;
                }
            }
            catch { return null; }
        }

        /// <summary>
        /// False only when the service is installed AND registered to a different SyncDB.exe than the one
        /// running now (an older copy in another folder). That copy keeps executing the OLD code no matter
        /// what is rebuilt here, which makes every fix look as if it did nothing.
        /// </summary>
        public static bool PointsAtThisExe()
        {
            string reg = RegisteredExePath();
            if (string.IsNullOrEmpty(reg)) return true;
            try
            {
                return string.Equals(Path.GetFullPath(reg), Path.GetFullPath(Application.ExecutablePath),
                                     StringComparison.OrdinalIgnoreCase);
            }
            catch { return true; }
        }

        /// <summary>
        /// True when the service registration points at the EXE that is running now.
        /// All whitespace is removed from both sides first, because sc.exe wraps a long
        /// BINARY_PATH_NAME across lines and a path with spaces ("project sajad") would never match.
        /// Any problem answers true, so a parsing issue can never block the service.
        /// </summary>
        private static bool BinPathMatchesThisExe(string qc)
        {
            try
            {
                string a = StripWhitespace(qc);
                string b = StripWhitespace(Application.ExecutablePath);
                if (a.Length == 0 || b.Length == 0) return true;
                return a.IndexOf(b, StringComparison.OrdinalIgnoreCase) >= 0;
            }
            catch { return true; }
        }

        private static string StripWhitespace(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            StringBuilder sb = new StringBuilder(s.Length);
            foreach (char c in s) if (!char.IsWhiteSpace(c)) sb.Append(c);
            return sb.ToString();
        }

        /// <summary>Last lines of today's log file — shown when the service refuses to start.</summary>
        private static string TailLog(int lines)
        {
            try
            {
                string path = AppLog.TodayPath;
                if (!File.Exists(path)) return "(no log file yet: " + path + ")";
                string[] all = File.ReadAllLines(path, Encoding.UTF8);
                int n = Math.Min(lines, all.Length);
                StringBuilder sb = new StringBuilder();
                for (int i = all.Length - n; i < all.Length; i++) sb.AppendLine(all[i]);
                return sb.ToString();
            }
            catch (Exception ex) { return "(log unreadable: " + ex.Message + ")"; }
        }

        private static void WaitFor(ServiceControllerStatus target)
        {
            try
            {
                using (ServiceController sc = new ServiceController(SyncDbService.SvcName))
                    sc.WaitForStatus(target, TimeSpan.FromSeconds(20));
            }
            catch { }
        }

        private static string Sc(string arguments)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("sc.exe", arguments);
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                using (Process p = Process.Start(psi))
                {
                    string o = p.StandardOutput.ReadToEnd() + p.StandardError.ReadToEnd();
                    p.WaitForExit();
                    return "> sc " + arguments.Split(' ')[0] + " (exit " + p.ExitCode + ")  " + o.Trim().Replace("\r\n", " ");
                }
            }
            catch (Exception ex) { return "sc failed: " + ex.Message; }
        }
    }
}
