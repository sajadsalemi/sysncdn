using System;
using System.IO;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Text;
using System.Xml;
using System.Text.RegularExpressions;
using System.Threading;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SyncDB
{
    public class RunResult
    {
        public bool Ok;
        public long Rows;
        public long ElapsedMs;
        public string Message;
        /// <summary>Per-statement job history (every table / statement, in order).</summary>
        public string Trace;
        /// <summary>Who started the run: manual | schedule | service.</summary>
        public string Source;
        /// <summary>How many tables / statements moved data in this run.</summary>
        public int Tables;
        /// <summary>"dbo.person:125,000 | dbo.salary:2,345" - what was transferred.</summary>
        public string TableList;
    }

    public static partial class Engine
    {

        // schema metadata cache (connection+table -> PK CSV) — fewer catalog hits on re-runs
        private static readonly object SchemaCacheLock = new object();
        private static readonly Dictionary<string, string> SchemaCache = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        // ---- running jobs registry (Start / Stop job) ----
        private static readonly ConcurrentDictionary<string, CancellationTokenSource> _running =
            new ConcurrentDictionary<string, CancellationTokenSource>();
        [ThreadStatic] private static CancellationToken _tok;

        // Job context for the durable outbox (the transfer method only receives a step, not the job).
        [ThreadStatic] private static string _currentJobId;
        [ThreadStatic] private static string _currentJobName;
        [ThreadStatic] private static AppConfig _currentConfig;
        [ThreadStatic] private static SyncJob _currentJob;
        /// <summary>Set by the scheduler on the worker thread: "interval 50 s | previous check 50.1 s ago".</summary>
        [ThreadStatic] internal static string AsyncNote;
        private static SyncJob _recycleJob;   // visible to all threads (buffer/delta workers)
        [ThreadStatic] private static bool _suppressOutbox;

        public static bool IsRunning(string jobId)
        {
            return !string.IsNullOrEmpty(jobId) && _running.ContainsKey(jobId);
        }

        public static bool RequestStop(string jobId)
        {
            CancellationTokenSource cts;
            if (!string.IsNullOrEmpty(jobId) && _running.TryGetValue(jobId, out cts))
            {
                try { cts.Cancel(); return true; } catch { }
            }
            return false;
        }

        private static ThreadPriority ToThreadPriority(ResourcePriority p)
        {
            if (p == ResourcePriority.Low) return ThreadPriority.BelowNormal;
            if (p == ResourcePriority.High) return ThreadPriority.AboveNormal;
            return ThreadPriority.Normal;
        }

        public static List<string> ListTables(string connectionString)
        {
            return ListTablesAndViews(connectionString);
        }

        /// <summary>Returns items prefixed with [TABLE] or [VIEW].</summary>
        public static List<string> ListTablesAndViews(string connectionString)
        {
            List<string> list = new List<string>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(@"
SELECT N'[TABLE] ' + TABLE_SCHEMA + N'.' + TABLE_NAME AS n
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
UNION ALL
SELECT N'[VIEW] ' + TABLE_SCHEMA + N'.' + TABLE_NAME
FROM INFORMATION_SCHEMA.VIEWS
ORDER BY n", conn))
                {
                    cmd.CommandTimeout = 60;
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read()) list.Add(r.GetString(0));
                    }
                }
            }
            return list;
        }

        /// <summary>User databases on the server of this connection (excludes system DBs).</summary>
        public static List<string> ListDatabases(string connectionString)
        {
            List<string> list = new List<string>();
            if (string.IsNullOrWhiteSpace(connectionString)) return list;
            string cs = connectionString;
            try
            {
                // force catalog to master so we can list DBs even if current DB is offline
                System.Text.RegularExpressions.Regex re =
                    new System.Text.RegularExpressions.Regex(@"(Initial Catalog|Database)\s*=\s*[^;]*",
                        System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                if (re.IsMatch(cs))
                    cs = re.Replace(cs, "Initial Catalog=master");
                else
                    cs = cs.TrimEnd(';') + ";Initial Catalog=master;";
            }
            catch { }
            using (SqlConnection conn = new SqlConnection(cs))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(@"
SELECT name
FROM sys.databases
WHERE database_id > 4
  AND state_desc = N'ONLINE'
  AND HAS_DBACCESS(name) = 1
ORDER BY name", conn))
                {
                    cmd.CommandTimeout = 60;
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read()) list.Add(r.GetString(0));
                    }
                }
            }
            return list;
        }

        public static string TestConnection(string connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
                return "FAIL: Connection string is empty. Fill Server / Database / User / Password and Save.";

            try
            {
                return TryOpen(connectionString);
            }
            catch (Exception ex1)
            {
                // Retry without TrustServerCertificate (older SqlClient)
                string alt = connectionString.Replace("TrustServerCertificate=true;", "").Replace("TrustServerCertificate=true", "");
                if (alt != connectionString)
                {
                    try { return TryOpen(alt) + "  (without TrustServerCertificate)"; }
                    catch { }
                }
                return "FAIL: " + ex1.Message;
            }
        }

        private static string TryOpen(string connectionString)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT @@SERVERNAME, DB_NAME(), SYSTEM_USER", conn))
                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    if (r.Read())
                        return "OK — Server=" + r.GetValue(0) + "  DB=" + r.GetValue(1) + "  User=" + r.GetValue(2);
                }
            }
            return "OK";
        }

        /// <summary>"SRV1.HR  ->  SRV2.HRWarehouse" for the status bars.</summary>
        private static string DescribeRoute(AppConfig cfg)
        {
            try
            {
                if (cfg == null) return "";
                ConnectionProfile sp = cfg.FindConnection(cfg.SourceConnectionId);
                ConnectionProfile dp = cfg.FindConnection(cfg.DestConnectionId);
                string s = sp != null ? sp.Server + "." + sp.Database : "(source not set)";
                string d = dp != null ? dp.Server + "." + dp.Database : "(dest not set)";
                return s + "  ->  " + d;
            }
            catch { return ""; }
        }

        public static RunResult ExecuteJob(SyncJob job, AppConfig cfg)
        {
            return ExecuteJob(job, cfg, "manual");
        }

        /// <summary><paramref name="runSource"/> is manual | schedule | service and is kept in the job history.</summary>
        public static RunResult ExecuteJob(SyncJob job, AppConfig cfg, string runSource)
        {
            CancellationTokenSource cts = new CancellationTokenSource();
            if (!_running.TryAdd(job.Id, cts))
            {
                cts.Dispose();
                RunResult dup = new RunResult();
                dup.Ok = false;
                dup.Message = "Job is already running.";
                dup.Source = runSource;
                return dup;
            }
            _tok = cts.Token;
            _currentJobId = job != null ? job.Id : "";
            _currentJobName = job != null ? job.Name : "";
            _currentConfig = cfg;
            _currentJob = job;
            _recycleJob = job;
            try { RuntimeSettings.Apply(cfg); }
            catch { }
            try
            {
                RunTrace.Begin(job.Name ?? job.Id);
                RunTrace.LiveRunSource = string.IsNullOrEmpty(runSource) ? "manual" : runSource;
                RunTrace.LiveRoute = DescribeRoute(cfg);
                RunResult jr;
                try { jr = ExecuteJobCore(job, cfg); }
                finally { RunTrace.EndLive(); }
                int tcount;
                string tlist = JobHistory.BuildTableList(RunTrace.Snapshot(), out tcount);
                string tr = RunTrace.EndText();
                if (tr.Length > 100000) tr = tr.Substring(0, 100000) + "\r\n... (cut - the full text is in the history file)";
                // Which program really executed this run. The window, the Windows service and an older
                // copy of SyncDB in another folder all write "started by: async" - this block tells them
                // apart in the text the user reads in "Result OK / Error" and in Job History.
                try { tr = tr + "\r\n\r\n" + RunIdentity(job, cfg); }
                catch { }
                jr.Trace = tr;
                jr.Source = string.IsNullOrEmpty(runSource) ? "manual" : runSource;
                jr.Tables = tcount;
                jr.TableList = tlist;
                try { JobHistory.Persist(job, jr); }
                catch (Exception ex) { try { AppLog.Error(job != null ? job.Name : "-", "History persist failed: " + ex.Message); } catch { } }
                return jr;
            }
            finally
            {
                CancellationTokenSource x;
                _running.TryRemove(job.Id, out x);
                _tok = CancellationToken.None;
                _currentJobId = null;
                _currentJobName = null;
                _currentConfig = null;
                _currentJob = null;
                _recycleJob = null;
                cts.Dispose();
            }
        }

        /// <summary>Build, process and schedule facts of the run, appended to its history text.</summary>
        private static string RunIdentity(SyncJob job, AppConfig cfg)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("---------------- executed by ----------------");
            int pid = 0;
            try { pid = System.Diagnostics.Process.GetCurrentProcess().Id; } catch { }
            string exe = "";
            try { exe = System.Reflection.Assembly.GetExecutingAssembly().Location; } catch { }
            sb.AppendLine("Program:    " + AppBuild.Text + "  |  pid " + pid + "  |  " +
                          (Environment.UserInteractive ? "window" : "Windows service"));
            sb.AppendLine("File:       " + exe);
            if (job != null && job.Schedule == ScheduleKind.RealtimeAsync)
                sb.AppendLine("Async:      " + (string.IsNullOrEmpty(AsyncNote)
                    ? "configured every " + job.IntervalValue + " s"
                    : AsyncNote));
            if (cfg != null && cfg.Jobs != null)
            {
                int n = 0;
                StringBuilder others = new StringBuilder();
                foreach (SyncJob o in cfg.Jobs)
                {
                    if (o == null || !o.Enabled || o.Schedule == ScheduleKind.Manual) continue;
                    if (job != null && o.Id == job.Id) continue;
                    n++;
                    if (n <= 8)
                        others.AppendLine("            - " + o.Name + "  [" + o.Schedule +
                                          (o.Schedule == ScheduleKind.RealtimeAsync ? " every " + o.IntervalValue + " s" : "") + "]");
                }
                if (n > 0)
                {
                    sb.AppendLine("Other scheduled jobs that are enabled: " + n);
                    sb.Append(others.ToString());
                }
            }
            return sb.ToString().TrimEnd();
        }

        private static RunResult ExecuteJobCore(SyncJob job, AppConfig cfg)
        {
            RunResult res = new RunResult();
            Stopwatch sw = Stopwatch.StartNew();
            string name = job.Name ?? job.Id;
            long totalRows = 0;
            try
            {
                job.EnsureSteps();
                if (job.Steps.Count == 0)
                    throw new Exception("Job has no steps. Add at least one step.");

                string srcConnGlobal = cfg.ResolveSourceConnectionString();
                string dstConnGlobal = cfg.ResolveDestConnectionString();
                int timeout = job.CommandTimeoutSec >= 0 ? job.CommandTimeoutSec : 0;   // 0 = no limit
                _atomicRefill = job.AtomicRefill;

                AppLog.Info(name, "Job started. Steps=" + job.Steps.Count);

                // Create recycle schema early so the user can see it even before any delete
                if (job.EnableRecycleBin && !string.IsNullOrWhiteSpace(job.RecycleSchema)
                    && !string.IsNullOrEmpty(dstConnGlobal))
                {
                    try
                    {
                        using (SqlConnection dst = new SqlConnection(dstConnGlobal))
                        {
                            dst.Open();
                            foreach (JobStep st in job.Steps)
                            {
                                if (st == null || string.IsNullOrWhiteSpace(st.DestTable)) continue;
                                string tn = NormalizeTableName(st.DestTable);
                                EnsureRecycleTable(dst, tn, job.RecycleSchema, timeout);
                            }
                        }
                    }
                    catch (Exception rex)
                    {
                        AppLog.Warn(name, "Recycle schema/table create failed: " + rex.Message);
                    }
                }

                for (int i = 0; i < job.Steps.Count; i++)
                {
                    _tok.ThrowIfCancellationRequested();
                    JobStep step = job.Steps[i];
                    if (!step.Enabled)
                    {
                        AppLog.Info(name, "Step " + step.StepId + " [" + step.Name + "] skipped (not selected / disabled).");
                        continue;
                    }
                    // Per-step database/connection (SSMS-style Database dropdown); fall back to global roles
                    string srcConn = cfg.ResolveStepConnectionString(step, true);
                    string dstConn = cfg.ResolveStepConnectionString(step, false);
                    if (string.IsNullOrEmpty(srcConn)) srcConn = srcConnGlobal;
                    if (string.IsNullOrEmpty(dstConn)) dstConn = dstConnGlobal;
                    int attempt = 0;
                    int maxTry = 1 + Math.Max(0, step.RetryAttempts);
                    bool stepOk = false;
                    string stepMsg = "";
                    long stepRows = 0;

                    while (attempt < maxTry)
                    {
                        attempt++;
                        try
                        {
                            AppLog.Info(name, "Step " + step.StepId + " [" + step.Name + "] type=" + step.TypeText() + " attempt=" + attempt);
                            RunTrace.SetStep(step.StepId, step.Name, i + 1, job.Steps.Count);
                            RunTrace.SetCurrent(i + 1, job.Steps.Count, "Step " + step.StepId + " [" + step.Name + "] " + step.TypeText());
                            bool plainCopy = step.Type == StepType.Transfer || step.Type == StepType.ApiToDest;
                            if (plainCopy) RunTrace.StartProgress("Step " + step.StepId + " [" + step.Name + "] -> " + (step.DestTable ?? ""));
                            RunResult sr;
                            try { sr = ExecuteStep(step, srcConn, dstConn, timeout); }
                            finally { if (plainCopy) RunTrace.EndProgress(); }
                            stepOk = sr.Ok;
                            stepMsg = sr.Message;
                            stepRows = sr.Rows;
                            if (sr.Ok) break;
                        }
                        catch (OperationCanceledException) { throw; }
                        catch (Exception ex)
                        {
                            stepOk = false;
                            stepMsg = ex.Message;
                            AppLog.Error(name, "Step " + step.StepId + " error: " + ex);
                        }
                        if (!stepOk && attempt < maxTry && step.RetryIntervalMinutes > 0)
                            Thread.Sleep(step.RetryIntervalMinutes * 60 * 1000);
                        else if (!stepOk && attempt < maxTry)
                            Thread.Sleep(1000);
                    }

                    totalRows += stepRows;
                    AppLog.Info(name, "Step " + step.StepId + " result: " + (stepOk ? "OK" : "FAIL") + " — " + stepMsg);
                    RunTrace.Add("STEP", 0, 0, "Step " + step.StepId + " [" + step.Name + "] " + step.TypeText(),
                        stepOk ? "OK" : "FAIL", stepRows, 0, stepOk ? "" : stepMsg);

                    if (stepOk)
                    {
                        try
                        {
                            if (!string.IsNullOrEmpty(_currentJobId))
                            {
                                string table = string.IsNullOrWhiteSpace(step.DestTable) ? (step.Name ?? "") : step.DestTable;
                                CacheStoreFactory.Current.SetLastSuccess(_currentJobId, table, new SyncStateInfo
                                {
                                    JobId = _currentJobId,
                                    Table = table,
                                    LastSuccessUtc = DateTime.UtcNow,
                                    LastMessage = "Step " + step.StepId + " OK (" + stepRows + " rows)",
                                    RowsAffected = stepRows,
                                    Direction = "Forward",
                                    OriginId = _currentConfig != null ? _currentConfig.OriginId : ""
                                });
                                if (step.ChangeTrackingVersion.HasValue && step.ChangeTrackingVersion.Value > 0)
                                    CacheStoreFactory.Current.SetWatermark(_currentJobId, table,
                                        step.ChangeTrackingVersion.Value, DateTime.UtcNow);
                            }
                        }
                        catch { }

                        if (step.OnSuccess == StepAction.QuitWithSuccess)
                        {
                            res.Ok = true;
                            res.Rows = totalRows;
                            res.Message = "Stopped after step " + step.StepId + " (success policy). Rows=" + totalRows;
                            return Finish(res, sw);
                        }
                        if (step.OnSuccess == StepAction.QuitWithFailure)
                        {
                            res.Ok = false;
                            res.Rows = totalRows;
                            res.Message = "Stopped after step " + step.StepId + " (configured quit failure on success).";
                            return Finish(res, sw);
                        }
                        // else go to next
                    }
                    else
                    {
                        if (step.OnFailure == StepAction.GoToNextStep)
                            continue;
                        if (step.OnFailure == StepAction.QuitWithSuccess)
                        {
                            res.Ok = true;
                            res.Rows = totalRows;
                            res.Message = "Step " + step.StepId + " failed but policy=quit success. " + stepMsg;
                            return Finish(res, sw);
                        }
                        // QuitWithFailure
                        res.Ok = false;
                        res.Rows = totalRows;
                        res.Message = "Step " + step.StepId + " [" + step.Name + "] failed: " + stepMsg;
                        AppLog.Error(name, "FAIL detail: " + stepMsg);
                        return Finish(res, sw);
                    }
                }

                res.Ok = true;
                res.Rows = totalRows;
                res.Message = "All " + job.Steps.Count + " step(s) completed. Rows=" + totalRows;
                AppLog.Info(name, res.Message);
            }
            catch (OperationCanceledException)
            {
                res.Ok = false;
                res.Message = "Stopped by user (rows written before stop: " + totalRows + "). See JOB HISTORY below for the statement that was running.";
                AppLog.Warn(name, "Job stopped by user.");
            }
            catch (Exception ex)
            {
                res.Ok = false;
                res.Message = ex.Message;
                AppLog.Error(name, ex.ToString());
            }
            return Finish(res, sw);
        }

        private static RunResult ExecuteStep(JobStep step, string srcConn, string dstConn, int timeout)
        {
            if (step.Type == StepType.SqlOnSource)
            {
                // Same linked-server bypass as on Destination: the script runs on the Source connection,
                // and every [server].[db].[schema].[table] is read by SyncDB directly (linked server not used / may be closed).
                if (!string.IsNullOrWhiteSpace(step.SqlCommand))
                    step.SqlCommand = NormalizeDottedServerRefs(step.SqlCommand);
                RunResult ls;
                if (TryRunLinkedServerScript(step, srcConn, srcConn, timeout, out ls))
                    return ls;
                return ExecuteSql(srcConn, step.SqlCommand, timeout, "Source", step.ContinueOnBatchError);
            }
            if (step.Type == StepType.SqlOnDest)
            {
                // Normalize dotted-server table names before any execution so a loop that
                // references the source by FQDN is either staged or at least has a valid name.
                if (!string.IsNullOrWhiteSpace(step.SqlCommand))
                    step.SqlCommand = NormalizeDottedServerRefs(step.SqlCommand);
                RunResult lr;
                if (TryRunLinkedServerScript(step, srcConn, dstConn, timeout, out lr))
                    return lr;
                return ExecuteSql(dstConn, step.SqlCommand, timeout, "Dest", step.ContinueOnBatchError);
            }
            if (step.Type == StepType.ApiToDest)
                return ExecuteApiToDest(step, dstConn, timeout);
            return ExecuteTransfer(step, srcConn, dstConn, timeout);
        }

        private static RunResult ExecuteSql(string connStr, string sql, int timeout, string label)
        {
            return ExecuteSql(connStr, sql, timeout, label, false);
        }

        /// <summary>Runs and drains every statement/result set in a batch without buffering a SELECT in RAM.</summary>
        internal static long RunNativeBatch(SqlConnection conn, string batch, int timeout, out string info)
        {
            return RunNativeBatch(conn, null, batch, timeout, out info);
        }

        /// <summary>Same, inside an open transaction (used to make "DELETE t" + "INSERT INTO t" atomic).</summary>
        internal static long RunNativeBatch(SqlConnection conn, SqlTransaction tx, string batch, int timeout, out string info)
        {
            using (SqlCommand cmd = new SqlCommand(batch, conn))
            {
                if (tx != null) cmd.Transaction = tx;
                cmd.CommandTimeout = timeout;
                long selected = 0;
                int resultSets = 0;
                int affected;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    do
                    {
                        _tok.ThrowIfCancellationRequested();
                        if (reader.FieldCount <= 0) continue;
                        resultSets++;
                        while (reader.Read())
                        {
                            _tok.ThrowIfCancellationRequested();
                            selected++;
                        }
                    } while (reader.NextResult());
                    affected = reader.RecordsAffected;
                }
                info = "affected=" + affected;
                if (resultSets > 0) info += "; SELECT returned " + selected + " row(s) in " + resultSets + " result set(s)";
                return affected >= 0 ? affected : selected;
            }
        }

        private static RunResult ExecuteSql(string connStr, string sql, int timeout, string label, bool continueOnError)
        {
            RunResult r = new RunResult();
            if (string.IsNullOrWhiteSpace(connStr))
                throw new Exception(label + " connection is empty.");
            if (string.IsNullOrWhiteSpace(sql))
                throw new Exception("T-SQL command is empty for this step.");

            // Split on GO batch separator (SSMS-style) — GO is not valid T-SQL for SqlClient
            List<string> batches = SplitSqlBatches(sql);
            if (batches.Count == 0)
                throw new Exception("No SQL batches to run (after removing GO).");

            long totalRows = 0;
            int failed = 0;
            List<string> failMsgs = new List<string>();

            // what each batch empties / fills, so "DELETE t" + "INSERT INTO t" can be made atomic
            string[] cleans = new string[batches.Count];
            string[] empties = new string[batches.Count];
            string[] fills = new string[batches.Count];
            bool scriptHasTran = TranRx.IsMatch(MaskSqlNonCode(sql, true));
            for (int k = 0; k < batches.Count; k++)
            {
                cleans[k] = StripSqlComments(batches[k]).Trim();
                if (cleans[k].Length == 0) continue;
                Match ek = EmptyTableRx.Match(cleans[k]);
                if (ek.Success) empties[k] = TableKey(ek.Groups["t"].Value);
                Match fk = InsertIntoRx.Match(cleans[k]);
                if (fk.Success) fills[k] = TableKey(fk.Groups["t"].Value);
            }

            // one connection for the whole script: USE <db>, temp tables and SET options carry over from batch to batch
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlTransaction guard = null;
                string guardTable = null;
                int guardUntil = -1;
                try
                {
                for (int bz = 0; bz < batches.Count; bz++)
                {
                    string batch = batches[bz];
                    int bi = bz + 1;
                    _tok.ThrowIfCancellationRequested();
                    string clean = cleans[bz];
                    string title = DescribeBatch(clean);
                    RunTrace.SetCurrent(bi, batches.Count, title);
                    if (clean.Length == 0)
                    {
                        RunTrace.Add("SKIP", bi, batches.Count, "(comments only)", "SKIP", 0, 0, SkipPreview(batch));
                        continue;
                    }
                    Stopwatch bsw = Stopwatch.StartNew();
                    try
                    {
                        // "DELETE FROM t" + the next batch "INSERT INTO t ..." succeed together or not at all,
                        // so a failing / timing-out INSERT can never leave the table empty
                        if (guard == null && _atomicRefill && !scriptHasTran && empties[bz] != null)
                        {
                            int j = -1;
                            for (int k = bz + 1; k < batches.Count; k++)
                                if (cleans[k].Length > 0) { j = k; break; }
                            if (j > 0 && empties[j] == null && fills[j] == empties[bz] && !UseRx.IsMatch(cleans[j]))
                            {
                                guard = conn.BeginTransaction();
                                guardTable = empties[bz];
                                guardUntil = j;
                            }
                        }

                        string info;
                        long n = RunNativeBatch(conn, guard, batch, timeout, out info);
                        totalRows += n;
                        if (guard != null && bz == guardUntil)
                        {
                            guard.Commit();
                            try { guard.Dispose(); } catch { }
                            guard = null; guardTable = null; guardUntil = -1;
                            info += "; refill committed";
                        }
                        else if (guard != null) info += "; held in a transaction until [" + guardTable + "] is refilled";
                        RunTrace.Add(UseRx.IsMatch(clean) ? "USE" : "SQL", bi, batches.Count, title, "OK", n, bsw.ElapsedMilliseconds, info);
                    }
                    catch (OperationCanceledException) { RollbackGuard(ref guard, ref guardTable, ref guardUntil); throw; }
                    catch (Exception exBatch)
                    {
                        string undo = RollbackGuard(ref guard, ref guardTable, ref guardUntil);
                        string msg = exBatch.Message + TimeoutHint(exBatch, timeout) + undo;
                        RunTrace.Add("SQL", bi, batches.Count, title, "FAIL", 0, bsw.ElapsedMilliseconds, msg);
                        string preview = batch.Length > 200 ? batch.Substring(0, 200) + "..." : batch;
                        string full = label + " batch " + bi + "/" + batches.Count + " [" + title + "] error: " + msg
                            + Environment.NewLine + "SQL:" + Environment.NewLine + preview;
                        if (!continueOnError) throw new Exception(full, exBatch);
                        failed++;
                        failMsgs.Add("#" + bi + " " + title + ": " + msg);
                    }
                }
                }
                finally { RollbackGuard(ref guard, ref guardTable, ref guardUntil); }
            }
            r.Rows = totalRows;
            if (failed > 0)
            {
                r.Ok = false;
                r.Message = label + ": " + failed + " of " + batches.Count + " batch(es) FAILED - " + string.Join(" | ", failMsgs.ToArray());
                return r;
            }
            r.Ok = true;
            r.Message = label + " OK (" + batches.Count + " batch/es). Rows=" + totalRows;
            return r;
        }


        // =====================================================================
        //  Auto-convert  "SELECT ... INTO dest FROM [LinkedServer].[db].[schema].[table]"
        //  (T-SQL on Destination) into an app-side Transfer — Linked Server not needed.
        // =====================================================================

        private static readonly Regex LinkedSelectInto = new Regex(
            @"^\s*SELECT\s+(?<cols>.+?)\s+INTO\s+(?<dest>[\w\[\]\.]+)\s+FROM\s+\[(?<srv>[^\]]+)\]\s*\.\s*(?<db>\[[^\]]+\]|\w+)\s*\.\s*(?<sch>\[[^\]]*\]|\w*)\s*\.\s*(?<tbl>\[[^\]]+\]|\w+)(?<rest>[\s\S]*?)\s*;?\s*$",
            RegexOptions.IgnoreCase | RegexOptions.Singleline);

        private static string SourceHost(string srcConn)
        {
            try
            {
                string ds = new SqlConnectionStringBuilder(srcConn).DataSource ?? "";
                int c = ds.IndexOf(',');
                if (c >= 0) ds = ds.Substring(0, c);
                if (ds.StartsWith("tcp:", StringComparison.OrdinalIgnoreCase)) ds = ds.Substring(4);
                return ds.Trim();
            }
            catch { return ""; }
        }

        private static string SourceDatabase(string srcConn)
        {
            try { return new SqlConnectionStringBuilder(srcConn).InitialCatalog ?? ""; }
            catch { return ""; }
        }

        private static string Unbracket(string s)
        {
            return (s ?? "").Trim().Trim('[', ']').Trim();
        }

        /// <summary>Split script on standalone GO lines, including GO n, outside literals/comments.</summary>
        internal static List<string> SplitSqlBatches(string sql)
        {
            List<string> result = new List<string>();
            foreach (KeyValuePair<string, int> batch in SplitSqlBatchesWithLines(sql))
                result.Add(batch.Key.Trim());
            return result;
        }

        // =====================================================================
        //  T-SQL "Parse" (like SSMS: SET PARSEONLY ON) + automatic clean-up of pasted text
        // =====================================================================

        /// <summary>Result of <see cref="ParseSql"/>.</summary>
        public class SqlParseResult
        {
            public bool Ok;
            /// <summary>True when the check could not run at all (no connection) - not a syntax problem.</summary>
            public bool ConnectError;
            public string Message = "";
            /// <summary>1-based line of the first syntax error in the whole script (0 = unknown).</summary>
            public int ErrorLine;
        }

        /// <summary>Same as SplitSqlBatches, but remembers the 1-based script line where each batch starts.</summary>
        private static List<KeyValuePair<string, int>> SplitSqlBatchesWithLines(string sql)
        {
            List<KeyValuePair<string, int>> result = new List<KeyValuePair<string, int>>();
            if (string.IsNullOrWhiteSpace(sql)) return result;
            StringBuilder cur = new StringBuilder();
            int curStart = 1, lineNo = 0;
            using (StringReader reader = new StringReader(sql))
            using (StringReader codeReader = new StringReader(MaskSqlNonCode(sql, true)))
            using (StringReader commentReader = new StringReader(StripSqlComments(sql)))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    lineNo++;
                    string codeLine = codeReader.ReadLine() ?? "";
                    string commentFreeLine = commentReader.ReadLine() ?? "";
                    if (IsGoLine(codeLine) && IsGoLine(commentFreeLine))
                    {
                        string batch = cur.ToString();
                        int repeat = 1;
                        Match count = Regex.Match(ReplaceInvisible(codeLine).Trim(), @"^GO\s+(\d+)\s*;?$", RegexOptions.IgnoreCase);
                        if (count.Success) repeat = int.Parse(count.Groups[1].Value, CultureInfo.InvariantCulture);
                        if (repeat <= 0) throw new Exception("GO repeat count must be positive at line " + lineNo + ".");
                        if (batch.Trim().Length > 0)
                            for (int r = 0; r < repeat; r++)
                                result.Add(new KeyValuePair<string, int>(batch, curStart));
                        cur.Length = 0;
                        curStart = lineNo + 1;
                    }
                    else
                    {
                        // Normalize pasted direction marks only in executable code, never inside a multiline literal.
                        string cleaned = ReplaceInvisible(line);
                        for (int c = 0; c < line.Length; c++)
                            cur.Append(codeLine[c] == line[c] ? cleaned[c] : line[c]);
                        cur.AppendLine();
                    }
                }
            }
            if (cur.ToString().Trim().Length > 0)
                result.Add(new KeyValuePair<string, int>(cur.ToString(), curStart));
            return result;
        }

        /// <summary>
        /// Syntax check only - nothing is executed and object names are not resolved (exactly like the SSMS "Parse" button).
        /// GO lines split the script into batches as in SSMS.
        /// </summary>
        public static SqlParseResult ParseSql(string connStr, string sql)
        {
            SqlParseResult res = new SqlParseResult();
            if (string.IsNullOrWhiteSpace(sql))
            {
                res.Message = "The command is empty.";
                return res;
            }
            if (string.IsNullOrWhiteSpace(connStr))
            {
                res.ConnectError = true;
                res.Message = "No connection is selected for this step (choose Source/Dest in the main window, or pick a Database).";
                return res;
            }
            List<KeyValuePair<string, int>> batches = SplitSqlBatchesWithLines(sql);
            if (batches.Count == 0)
            {
                res.Message = "Nothing to parse (only GO lines).";
                return res;
            }

            StringBuilder err = new StringBuilder();
            bool ok = true;
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    using (SqlCommand on = new SqlCommand("SET PARSEONLY ON", conn))
                        on.ExecuteNonQuery();
                    try
                    {
                        foreach (KeyValuePair<string, int> b in batches)
                        {
                            try
                            {
                                using (SqlCommand cmd = new SqlCommand(b.Key, conn))
                                {
                                    cmd.CommandTimeout = 30;
                                    cmd.ExecuteNonQuery();
                                }
                            }
                            catch (SqlException ex)
                            {
                                ok = false;
                                foreach (SqlError e in ex.Errors)
                                {
                                    int ln = b.Value + Math.Max(1, e.LineNumber) - 1;
                                    if (res.ErrorLine == 0 || ln < res.ErrorLine) res.ErrorLine = ln;
                                    err.AppendLine("Line " + ln + ": " + e.Message);
                                }
                            }
                        }
                    }
                    finally
                    {
                        try { using (SqlCommand off = new SqlCommand("SET PARSEONLY OFF", conn)) off.ExecuteNonQuery(); }
                        catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                res.ConnectError = true;
                res.Message = ex.Message;
                return res;
            }
            res.Ok = ok;
            res.Message = ok ? "The command was successfully parsed." : err.ToString().TrimEnd();
            return res;
        }

        /// <summary>
        /// Repairs the damage typically caused by copy/paste from chats, web pages and Word:
        /// markdown ``` lines, curly quotes, long dashes, non-breaking spaces, zero-width / bidi control characters.
        /// Text inside string literals, [identifiers] and comments is never touched.
        /// <paramref name="notes"/> receives one short English line per kind of change (empty = nothing changed).
        /// </summary>
        public static string AutoFixSql(string sql, List<string> notes)
        {
            if (sql == null) return "";
            if (notes == null) notes = new List<string>();

            // 1) markdown code fences (```sql ... ```)
            int fences = 0;
            StringBuilder noFence = new StringBuilder();
            using (StringReader rd = new StringReader(sql))
            {
                string line;
                bool first = true;
                while ((line = rd.ReadLine()) != null)
                {
                    if (line.TrimStart().StartsWith("```", StringComparison.Ordinal)) { fences++; continue; }
                    if (!first) noFence.Append("\r\n");
                    noFence.Append(line);
                    first = false;
                }
            }
            string s = fences > 0 ? noFence.ToString() : sql;
            if (fences > 0) notes.Add("Removed " + fences + " markdown code-fence line(s)");

            // 2) character clean-up outside strings / comments / [brackets]
            int quotes = 0, dashes = 0, spaces = 0, invisible = 0;
            StringBuilder o = new StringBuilder(s.Length);
            // 0 code, 1 'string', 2 string opened by a curly quote, 3 -- comment, 4 /* comment */, 5 [identifier]
            int st = 0;
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                char n = (i + 1 < s.Length) ? s[i + 1] : '\0';
                switch (st)
                {
                    case 0:
                        if (c == '\'') { o.Append(c); st = 1; }
                        else if (c == '\u2018' || c == '\u201A' || c == '\u2019' || c == '\u2032')
                        { o.Append('\''); st = (c == '\u2018' || c == '\u201A') ? 2 : 1; quotes++; }
                        else if (c == '\u201C' || c == '\u201D' || c == '\u201E') { o.Append('"'); quotes++; }
                        else if (c == '[') { o.Append(c); st = 5; }
                        else if (c == '-' && n == '-') { o.Append(c); st = 3; }
                        else if (c == '/' && n == '*') { o.Append(c); st = 4; }
                        else if (c == '\u2014') { o.Append("--"); st = 3; dashes++; }          // em dash (Word turns -- into this)
                        else if (c == '\u2013' || c == '\u2212') { o.Append('-'); dashes++; }   // en dash / minus sign
                        else if (c == '\u00A0' || c == '\u202F' || c == '\u2007' || c == '\u2009' || c == '\u3000')
                        { o.Append(' '); spaces++; }
                        else if (c == '\u200B' || c == '\uFEFF' || c == '\u2060' || c == '\u200E' || c == '\u200F'
                                 || (c >= '\u202A' && c <= '\u202E') || (c >= '\u2066' && c <= '\u2069'))
                        { invisible++; }
                        else o.Append(c);
                        break;
                    case 1:
                        o.Append(c);
                        if (c == '\'') { if (n == '\'') { o.Append(n); i++; } else st = 0; }
                        break;
                    case 2:
                        if (c == '\u2019' || c == '\u2032' || c == '\'') { o.Append('\''); st = 0; quotes += (c == '\'' ? 0 : 1); }
                        else o.Append(c);
                        break;
                    case 3:
                        o.Append(c);
                        if (c == '\n' || c == '\r') st = 0;
                        break;
                    case 4:
                        o.Append(c);
                        if (c == '*' && n == '/') { o.Append(n); i++; st = 0; }
                        break;
                    case 5:
                        o.Append(c);
                        if (c == ']') { if (n == ']') { o.Append(n); i++; } else st = 0; }
                        break;
                }
            }
            if (quotes > 0) notes.Add("Replaced " + quotes + " curly quote(s) with normal quotes");
            if (dashes > 0) notes.Add("Replaced " + dashes + " long dash(es) with normal hyphen(s)");
            if (spaces > 0) notes.Add("Replaced " + spaces + " non-breaking space(s)");
            if (invisible > 0) notes.Add("Removed " + invisible + " invisible character(s)");
            return o.ToString();
        }

        /// <summary>0 = Auto: use CPU cores; more batches / heavy load → more writers.</summary>
        private static int ResolveThreadCount(JobStep step, int nBatches)
        {
            int cpu = Math.Max(1, Environment.ProcessorCount);
            int want;
            if (step == null || step.MaxThreads <= 0)
            {
                // Auto multi-thread on system side
                want = cpu;
                if (nBatches >= 32) want = Math.Min(cpu * 2, 16);
                else if (nBatches >= 8) want = cpu;
                else if (nBatches >= 2) want = Math.Min(cpu, 4);
                else want = 1;
            }
            else want = step.MaxThreads;
            int threads = Math.Max(1, Math.Min(want, Math.Max(cpu * 2, 8)));
            if (nBatches > 0 && nBatches < threads) threads = Math.Max(1, nBatches);
            return threads;
        }

        /// <summary>
        /// SQL Server Change Tracking (modern delta): only rows INSERT/UPDATE since last version.
        /// Requires CHANGE_TRACKING ON for the database + table. Returns null if CT cannot be used.
        /// </summary>
        /// <summary>
        /// SQL Server CDC net-changes when capture instance exists on the source table.
        /// </summary>
        private static string TryBuildCdcSelect(JobStep step, string srcConn, int timeout)
        {
            if (step == null || !step.UseCdc) return null;
            if (string.IsNullOrWhiteSpace(step.SourceTable) || !string.IsNullOrWhiteSpace(step.SqlCommand))
            {
                AppLog.Warn("-", "CDC needs a plain Source table (not custom SQL).");
                return null;
            }
            string table = NormalizeTableName(step.SourceTable);
            string bare = table.Replace("[", "").Replace("]", "");
            string[] parts = bare.Split('.');
            string inst = parts.Length >= 2
                ? (parts[parts.Length - 2] + "_" + parts[parts.Length - 1])
                : ("dbo_" + bare);
            inst = inst.Replace(" ", "_");
            try
            {
                using (SqlConnection c = new SqlConnection(srcConn))
                {
                    c.Open();
                    object en;
                    using (SqlCommand q = new SqlCommand(
                        "SELECT is_cdc_enabled FROM sys.databases WHERE database_id = DB_ID()", c))
                    {
                        q.CommandTimeout = timeout;
                        en = q.ExecuteScalar();
                    }
                    if (en == null || Convert.ToInt32(en) != 1)
                    {
                        AppLog.Warn("-", "CDC is not enabled on the SOURCE database.");
                        return null;
                    }
                    object maxLsn;
                    using (SqlCommand q = new SqlCommand("SELECT sys.fn_cdc_get_max_lsn()", c))
                    {
                        q.CommandTimeout = timeout;
                        maxLsn = q.ExecuteScalar();
                    }
                    if (maxLsn == null || maxLsn == DBNull.Value)
                    {
                        AppLog.Warn("-", "CDC max LSN unavailable.");
                        return null;
                    }
                    string maxHex = "0x" + BitConverter.ToString((byte[])maxLsn).Replace("-", "");
                    _pendingCdcLsn = maxHex;
                    if (string.IsNullOrWhiteSpace(step.CdcLastLsn))
                    {
                        AppLog.Info("-", "CDC first run (full load). LSN after success: " + maxHex);
                        return null;
                    }
                    string sql =
                        "SELECT * FROM cdc.fn_cdc_get_net_changes_" + inst + "(" +
                        "sys.fn_cdc_increment_lsn(CONVERT(binary(10), '" + step.CdcLastLsn.Replace("'", "") + "', 1)), " +
                        "sys.fn_cdc_get_max_lsn(), N'all')";
                    AppLog.Info("-", "CDC net changes: instance=" + inst + " from=" + step.CdcLastLsn);
                    return sql;
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "CDC unavailable (" + inst + "): " + ex.Message);
                _pendingCdcLsn = null;
                return null;
            }
        }

        [ThreadStatic]
        private static string _pendingCdcLsn;

        private static void CommitCdcLsn(JobStep step)
        {
            if (step == null || !step.UseCdc) return;
            if (!string.IsNullOrEmpty(_pendingCdcLsn))
            {
                step.CdcLastLsn = _pendingCdcLsn;
                _pendingCdcLsn = null;
                AppLog.Info("-", "CDC LSN saved: " + step.CdcLastLsn);
            }
        }

        private static string TryBuildChangeTrackingSelect(JobStep step, string srcConn, int timeout, out long? currentVersion)

        {
            currentVersion = null;
            if (step == null || !step.UseChangeTracking) return null;
            if (string.IsNullOrWhiteSpace(step.SourceTable) || !string.IsNullOrWhiteSpace(step.SqlCommand))
            {
                AppLog.Warn("-", "Change Tracking needs a plain Source table (not custom SQL). Falling back.");
                return null;
            }
            string table = NormalizeTableName(step.SourceTable);
            try
            {
                using (SqlConnection c = new SqlConnection(srcConn))
                {
                    c.Open();
                    // current CT version for this database
                    object verObj;
                    using (SqlCommand q = new SqlCommand("SELECT CHANGE_TRACKING_CURRENT_VERSION()", c))
                    {
                        q.CommandTimeout = timeout;
                        verObj = q.ExecuteScalar();
                    }
                    if (verObj == null || verObj == DBNull.Value)
                    {
                        AppLog.Warn("-", "Change Tracking is not enabled on the SOURCE database. Enable with: ALTER DATABASE ... SET CHANGE_TRACKING = ON");
                        return null;
                    }
                    long curVer = Convert.ToInt64(verObj);
                    currentVersion = curVer;

                    // table has CT?
                    int on;
                    using (SqlCommand q = new SqlCommand(
                        "SELECT COUNT(*) FROM sys.change_tracking_tables WHERE object_id = OBJECT_ID(@t)", c))
                    {
                        q.Parameters.AddWithValue("@t", table);
                        q.CommandTimeout = timeout;
                        on = Convert.ToInt32(q.ExecuteScalar());
                    }
                    if (on == 0)
                    {
                        AppLog.Warn("-", "Change Tracking is not enabled on table " + table + ". Enable: ALTER TABLE " + table + " ENABLE CHANGE_TRACKING;");
                        return null;
                    }

                    // primary key columns for JOIN with CHANGETABLE
                    string pkCsv = GetPrimaryKeyColumns(srcConn, step.SourceTable);
                    if (string.IsNullOrWhiteSpace(pkCsv))
                    {
                        AppLog.Warn("-", "Change Tracking needs a PRIMARY KEY on " + table + ".");
                        return null;
                    }
                    string[] pks = pkCsv.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    StringBuilder join = new StringBuilder();
                    for (int i = 0; i < pks.Length; i++)
                    {
                        string p = pks[i].Trim().Trim('[', ']').Replace("]", "]]");
                        if (i > 0) join.Append(" AND ");
                        join.Append("t.[").Append(p).Append("] = ct.[").Append(p).Append("]");
                    }

                    if (!step.ChangeTrackingVersion.HasValue)
                    {
                        // first run: full table; version will be saved after success
                        AppLog.Info("-", "Change Tracking: first run (full load). Version will be set to " + curVer + " after success.");
                        return null; // null => use normal full select
                    }

                    long last = step.ChangeTrackingVersion.Value;
                    if (last >= curVer)
                    {
                        AppLog.Info("-", "Change Tracking: no new changes (last=" + last + ", current=" + curVer + ").");
                        // empty result set
                        return "SELECT * FROM " + table + " AS t WHERE 1=0";
                    }

                    // only INSERT + UPDATE (deletes handled by SyncChanges mode separately if needed)
                    string sql =
                        "SELECT t.* FROM " + table + " AS t " +
                        "INNER JOIN CHANGETABLE(CHANGES " + table + ", " + last + ") AS ct ON " + join + " " +
                        "WHERE ct.SYS_CHANGE_OPERATION IN (N'I', N'U')";
                    AppLog.Info("-", "Change Tracking delta: version " + last + " -> " + curVer + " on " + table);
                    return sql;
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "Change Tracking unavailable: " + ex.Message);
                currentVersion = null;
                return null;
            }
        }

        private static void CommitChangeTrackingVersion(JobStep step, long? versionAfter)
        {
            if (step == null || !step.UseChangeTracking || !versionAfter.HasValue) return;
            step.ChangeTrackingVersion = versionAfter.Value;
            AppLog.Info("-", "Change Tracking version saved: " + versionAfter.Value);
        }

        private static string ApplyIncrementalFilter(JobStep step, string selectSql)
        {

            if (step == null || string.IsNullOrWhiteSpace(step.IncrementalColumn)) return selectSql;
            if (string.IsNullOrWhiteSpace(step.IncrementalLastValue)) return selectSql; // first run: full
            if (step.Mode == WriteMode.TruncateInsert || step.Mode == WriteMode.DeleteInsert || step.Mode == WriteMode.DropInto) return selectSql; // full reload modes need all rows
            string col = step.IncrementalColumn.Trim().Trim('[', ']').Replace("]", "]]");
            string lit = FormatSqlLiteral(step.IncrementalLastValue.Trim());
            // watermark filter: only rows newer than last successful run (ideal for large tables 10–100+ GB)
            AppLog.Info("-", "Incremental filter on [" + col + "] > " + step.IncrementalLastValue.Trim());
            return "SELECT * FROM (" + selectSql + ") AS __syncdb_inc WHERE [" + col + "] > " + lit;
        }

        private static string FormatSqlLiteral(string v)
        {
            if (v == null) return "NULL";
            // numeric?
            decimal d;
            if (decimal.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out d))
                return d.ToString(System.Globalization.CultureInfo.InvariantCulture);
            Guid g;
            if (Guid.TryParse(v, out g)) return "'" + g.ToString() + "'";
            DateTime dt;
            if (DateTime.TryParse(v, System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.RoundtripKind, out dt)
                || DateTime.TryParse(v, out dt))
                return "'" + dt.ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture) + "'";
            return "N'" + v.Replace("'", "''") + "'";
        }

        private static void UpdateIncrementalWatermark(JobStep step, DataTable data)
        {
            if (step == null || data == null || data.Rows.Count == 0) return;
            if (string.IsNullOrWhiteSpace(step.IncrementalColumn)) return;
            string col = step.IncrementalColumn.Trim();
            if (!data.Columns.Contains(col))
            {
                // try case-insensitive
                foreach (DataColumn c in data.Columns)
                    if (string.Equals(c.ColumnName, col, StringComparison.OrdinalIgnoreCase)) { col = c.ColumnName; break; }
            }
            if (!data.Columns.Contains(col)) return;
            object max = null;
            foreach (DataRow row in data.Rows)
            {
                object v = row[col];
                if (v == null || v == DBNull.Value) continue;
                if (max == null) { max = v; continue; }
                IComparable a = max as IComparable;
                IComparable b = v as IComparable;
                if (a != null && b != null && b.CompareTo(a) > 0) max = v;
            }
            if (max == null) return;
            if (max is DateTime)
                step.IncrementalLastValue = ((DateTime)max).ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture);
            else
                step.IncrementalLastValue = Convert.ToString(max, System.Globalization.CultureInfo.InvariantCulture);
            AppLog.Info("-", "Incremental watermark [" + col + "] = " + step.IncrementalLastValue);
        }

        private static RunResult ExecuteTransferCore(JobStep step, string srcConn, string dstConn, int timeout)
        {
            RunResult r = new RunResult();
            if (string.IsNullOrWhiteSpace(srcConn))
                throw new Exception("Source connection is empty.");
            if (string.IsNullOrWhiteSpace(dstConn))
                throw new Exception("Destination connection is empty.");
            if (string.IsNullOrWhiteSpace(step.DestTable))
                throw new Exception("Destination table is empty.");

            string selectSql;
            if (!string.IsNullOrWhiteSpace(step.SqlCommand))
                selectSql = step.SqlCommand.Trim();
            else if (!string.IsNullOrWhiteSpace(step.SourceTable))
                // Avoid Microsoft.SqlServer.Types: cast hierarchyid/geography/geometry to text in SQL
                selectSql = BuildSafeSelectFromTable(srcConn, step.SourceTable, timeout);
            else
                throw new Exception("Transfer step needs Source table or SQL command.");

            string selectBeforeInc = selectSql;
            long? ctVersionAfter = null;
            if (step.UseCdc)
            {
                string cdcSql = TryBuildCdcSelect(step, srcConn, timeout);
                if (cdcSql != null)
                    selectSql = cdcSql;
            }
            if (step.UseChangeTracking)
            {
                string ctSql = TryBuildChangeTrackingSelect(step, srcConn, timeout, out ctVersionAfter);
                if (ctSql != null)
                    selectSql = ctSql;
            }
            selectSql = ApplyIncrementalFilter(step, selectSql);
            bool incActive = !string.Equals(selectBeforeInc, selectSql, StringComparison.Ordinal);

            BufferMode bmode = ResolveBufferMode(step, srcConn, timeout);
            // Large transfer / incremental: prefer Stream or Disk to avoid loading 10–100+ GB into RAM
            if (bmode == BufferMode.Auto || bmode == BufferMode.Ram)
            {
                if (_lastEstMb >= 2048) // ~2 GB+
                {
                    bmode = LocalFreeGb() > 5.0 ? BufferMode.Disk : BufferMode.Stream;
                    AppLog.Info("-", "Large source (~" + (int)_lastEstMb + " MB): auto memory mode -> " + bmode);
                }
                else if (_lastEstMb >= 512 && !string.IsNullOrWhiteSpace(step.IncrementalColumn))
                {
                    // incremental on medium-large tables: Stream is enough
                    if (bmode == BufferMode.Ram) { bmode = BufferMode.Stream; AppLog.Info("-", "Incremental on medium table: memory mode -> Stream"); }
                }
            }
            if ((step.Mode == WriteMode.MergeUpsert || step.Mode == WriteMode.SyncChanges) && bmode != BufferMode.Ram)
            {
                AppLog.Warn("-", "Write mode " + step.Mode + " needs the rows in memory - memory mode " + bmode + " changed to RAM for '" + (step.Name ?? "") + "'.");
                bmode = BufferMode.Ram;
            }
            if (bmode == BufferMode.Disk && !RuntimeSettings.UseDiskBuffer)
            {
                // Settings -> "Use a disk buffer" is OFF (the default): nothing is ever written to
                // %APPDATA%\SyncDB\buffer; the rows stream straight from source to destination.
                AppLog.Info("-", "Disk buffer is OFF in Settings - memory mode Disk -> Stream (nothing is written to disk).");
                bmode = BufferMode.Stream;
            }
            if (bmode == BufferMode.Stream || bmode == BufferMode.Disk)
                return ExecuteTransferBuffered(step, srcConn, dstConn, selectSql, timeout, bmode == BufferMode.Disk);

            DataTable data = new DataTable();
            DataTable srcSchema = null;
            using (SqlConnection src = new SqlConnection(srcConn))
            {
                src.Open();
                try
                {
                    using (SqlCommand sc = new SqlCommand(selectSql, src))
                    {
                        sc.CommandTimeout = timeout;
                        using (SqlDataReader rd = sc.ExecuteReader(CommandBehavior.SchemaOnly))
                            srcSchema = rd.GetSchemaTable();
                    }
                }
                catch { srcSchema = null; }
                int srcThreads = ResolveSourceThreads(step, selectSql);
                DataTable par = srcThreads > 1 ? TryParallelFill(step, srcConn, selectSql, srcThreads, timeout) : null;
                if (par != null) data = par;
                else
                {
                    using (SqlCommand cmd = new SqlCommand(selectSql, src))
                    {
                        cmd.CommandTimeout = timeout;
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                            da.Fill(data);
                    }
                }
            }

            using (SqlConnection dst = new SqlConnection(dstConn))
            {
                dst.Open();
                string destNorm = NormalizeTableName(step.DestTable);
                // Drop into must DROP then recreate — never leave the table missing before bulk insert.
                if (step.Mode == WriteMode.DropInto && TableExists(dst, null, destNorm, timeout))
                {
                    DropDestTable(dst, null, destNorm, timeout);
                    AppLog.Info("-", "Drop into: dropped destination table " + destNorm + " — recreating from source.");
                }
                if (!TableExists(dst, null, destNorm, timeout))
                {
                    // schema first (HumanResources / Person / Production …), then table
                    EnsureSchemaExists(dst, null, destNorm, timeout);
                    // Like SELECT ... INTO : create the destination table from the source structure
                    using (SqlCommand cc = new SqlCommand(BuildCreateTableSql(destNorm, srcSchema, data), dst))
                    {
                        cc.CommandTimeout = timeout;
                        cc.ExecuteNonQuery();
                    }
                    AppLog.Info("-", "Destination table " + destNorm + " did not exist — created from source structure.");
                }
                else
                {
                    // Truncate / Delete+Insert only (DropInto already handled above)
                    PrepareDestination(dst, step, timeout);
                    EnsureDestSchema(dst, step, srcSchema, data, timeout);
                }
                EnsureKeyColumnsIndex(dstConn, step, timeout);

                if (data.Rows.Count == 0)
                {
                    r.Ok = true;
                    r.Rows = 0;
                    r.Message = "Transfer: 0 rows.";
                    return r;
                }

                int batch = step.BatchSize > 0 ? step.BatchSize : data.Rows.Count;
                int nBatches = (data.Rows.Count + batch - 1) / batch;
                int threads = ResolveThreadCount(step, nBatches);
                CancellationToken token = _tok;
                ThreadPriority prio = ToThreadPriority(step.Priority);
                ThreadPriority oldPrio = Thread.CurrentThread.Priority;
                int delay = Math.Max(0, step.DelayMs);
                long total = 0;
                try
                {
                    if (threads <= 1)
                    {
                        Thread.CurrentThread.Priority = prio;
                        for (int b = 0; b < nBatches; b++)
                        {
                            token.ThrowIfCancellationRequested();
                            total += WriteRows(dst, data, b * batch, batch, step, timeout);
                            if (delay > 0 && b < nBatches - 1) token.WaitHandle.WaitOne(delay);
                        }
                    }
                    else
                    {
                        long shared = 0;
                        ParallelOptions po = new ParallelOptions();
                        po.MaxDegreeOfParallelism = threads;
                        po.CancellationToken = token;
                        try
                        {
                            Parallel.For(0, nBatches, po, b =>
                            {
                                ThreadPriority before = Thread.CurrentThread.Priority;
                                try
                                {
                                    Thread.CurrentThread.Priority = prio;
                                    using (SqlConnection c = new SqlConnection(dstConn))
                                    {
                                        c.Open();
                                        long n = WriteRows(c, data, b * batch, batch, step, timeout);
                                        Interlocked.Add(ref shared, n);
                                    }
                                    if (delay > 0) token.WaitHandle.WaitOne(delay);
                                }
                                finally { Thread.CurrentThread.Priority = before; }
                            });
                        }
                        catch (AggregateException ae)
                        {
                            throw ae.Flatten().InnerExceptions[0];
                        }
                        total = shared;
                    }
                }
                finally { Thread.CurrentThread.Priority = oldPrio; }
                r.Rows = total;
                UpdateIncrementalWatermark(step, data);
                if (step.Mode == WriteMode.SyncChanges && !incActive)
                {
                    long del = DeleteOrphanDestRows(dstConn, step, data, timeout, _currentJob);
                    r.Message = "Sync " + total + " upserted, " + del + " deleted → " + step.DestTable;
                }
            }
            r.Ok = true;
            if (string.IsNullOrEmpty(r.Message))
                r.Message = "Transferred " + r.Rows + " row(s) → " + step.DestTable;
            return r;
        }


        // ======================= buffer mode: Auto / Ram / Stream / Disk =======================

        private static BufferMode ResolveBufferMode(JobStep step, string srcConn, int timeout)
        {
            _lastEstMb = -1;
            if (step.Buffer != BufferMode.Auto) return step.Buffer;
            int limitMb = step.RamLimitMb > 0 ? step.RamLimitMb : 256;
            double estMb = -1;
            try
            {
                string hint = !string.IsNullOrWhiteSpace(step.SizeHintTable) ? step.SizeHintTable
                    : (string.IsNullOrWhiteSpace(step.SqlCommand) && !string.IsNullOrWhiteSpace(step.SourceTable) ? step.SourceTable : null);
                if (hint != null)
                {
                    string norm = NormalizeTableName(hint);
                    string[] parts = norm.Split(new string[] { "]." }, StringSplitOptions.None);
                    string dbPrefix = parts.Length >= 3 ? parts[0] + "]." : "";      // table in another database
                    using (SqlConnection c = new SqlConnection(srcConn))
                    {
                        c.Open();
                        using (SqlCommand q = new SqlCommand(
                            "SELECT CAST(SUM(used_page_count) * 8.0 / 1024.0 AS float) FROM " + dbPrefix + "sys.dm_db_partition_stats " +
                            "WHERE object_id = OBJECT_ID(@n) AND index_id IN (0,1)", c))
                        {
                            q.CommandTimeout = Math.Min(timeout, 60);
                            q.Parameters.AddWithValue("@n", norm);
                            object o = q.ExecuteScalar();
                            if (o != null && o != DBNull.Value) estMb = Convert.ToDouble(o) * 2.0;   // in-memory ≈ 2x on-disk
                        }
                    }
                }
            }
            catch { estMb = -1; }

            _lastEstMb = estMb;
            BufferMode pick;
            if (estMb < 0) pick = BufferMode.Stream;                       // size unknown (custom SQL / view): stay safe on RAM
            else pick = estMb > limitMb ? BufferMode.Disk : BufferMode.Ram;
            AppLog.Info("-", "Auto buffer for '" + (step.Name ?? "") + "': est " + (estMb < 0 ? "unknown" : estMb.ToString("0.0") + " MB") +
                        ", limit " + limitMb + " MB -> " + pick);
            return pick;
        }

        private sealed class BatchItem
        {
            public DataTable Table;
            public string File;
        }

        private static DataTable BuildShape(SqlDataReader rd)
        {
            DataTable dt = new DataTable();
            int fc = rd.FieldCount;
            HashSet<string> used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < fc; i++)
            {
                string name = rd.GetName(i);
                if (string.IsNullOrEmpty(name)) name = "Column" + (i + 1);
                string u = name; int k = 1;
                while (!used.Add(u)) u = name + "_" + (++k);
                Type t;
                try { t = rd.GetFieldType(i); } catch { t = typeof(object); }
                if (t == null) t = typeof(object);
                dt.Columns.Add(u, t);
            }
            return dt;
        }

        private static void SpillBatch(DataTable t, string file)
        {
            t.RemotingFormat = SerializationFormat.Binary;
            using (FileStream fs = new FileStream(file, FileMode.Create, FileAccess.Write, FileShare.None, 1 << 16))
                new BinaryFormatter().Serialize(fs, t);
        }

        private static DataTable LoadSpill(string file)
        {
            using (FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16))
                return (DataTable)new BinaryFormatter().Deserialize(fs);
        }

        private static void WriteTable(SqlConnection c, DataTable t, JobStep step, int timeout, int batch)
        {
            try
            {
                using (SqlBulkCopy bulk = new SqlBulkCopy(c))
                {
                    bulk.DestinationTableName = NormalizeTableName(step.DestTable);
                    bulk.BulkCopyTimeout = timeout;
                    bulk.BatchSize = batch;
                    foreach (DataColumn col in t.Columns)
                        bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                    bulk.WriteToServer(t);
                    RunTrace.Progress(t.Rows.Count);
                }
            }
            catch (Exception ex)
            {
                if (IsBulkTypeMismatch(ex) && TryRecreateEmptyDest(c, step, t, null, timeout))
                {
                    using (SqlBulkCopy bulk = new SqlBulkCopy(c))
                    {
                        bulk.DestinationTableName = NormalizeTableName(step.DestTable);
                        bulk.BulkCopyTimeout = timeout;
                        bulk.BatchSize = batch;
                        foreach (DataColumn col in t.Columns)
                            bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                        bulk.WriteToServer(t);
                        RunTrace.Progress(t.Rows.Count);
                    }
                }
                else throw;
            }
        }

        /// <summary>
        /// If KeyColumns is filled, create an index on Dest with the chosen kind:
        /// Nonclustered / Unique Nonclustered / Unique Clustered (PK-style).
        /// Failures are logged; transfer is not aborted.
        /// </summary>
        private static void EnsureKeyColumnsIndex(string dstConn, JobStep step, int timeout)
        {
            if (step == null || string.IsNullOrWhiteSpace(step.KeyColumns) || string.IsNullOrWhiteSpace(step.DestTable))
            {
                AppLog.Info("-", "EnsureKeyColumnsIndex: skipped (no KeyColumns or DestTable).");
                return;
            }
            if (string.IsNullOrWhiteSpace(dstConn)) return;

            string[] keys = (step.KeyColumns ?? "").Split(new char[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
            System.Collections.Generic.List<string> cols = new System.Collections.Generic.List<string>();
            for (int i = 0; i < keys.Length; i++)
            {
                string k = keys[i].Trim().Trim('[', ']');
                if (k.Length == 0) continue;
                bool ok = true;
                for (int c = 0; c < k.Length; c++)
                {
                    char ch = k[c];
                    if (!(char.IsLetterOrDigit(ch) || ch == '_' || ch == '@' || ch == '#' || ch == '$'))
                    { ok = false; break; }
                }
                if (ok) cols.Add(k);
                else AppLog.Warn("-", "EnsureKeyColumnsIndex: ignored invalid key token '" + keys[i] + "'.");
            }
            if (cols.Count == 0)
            {
                AppLog.Warn("-", "EnsureKeyColumnsIndex: no valid key columns in '" + step.KeyColumns + "'.");
                return;
            }

            try
            {
                string destNorm = NormalizeTableName(step.DestTable);
                string objIdArg = destNorm.Replace("[", "").Replace("]", "");
                string rawName = "IX_SyncDB_" + objIdArg.Replace(".", "_") + "_" + string.Join("_", cols.ToArray());
                if (rawName.Length > 120) rawName = rawName.Substring(0, 120);
                string idxName = "[" + rawName.Replace("]", "]]") + "]";

                System.Text.StringBuilder colList = new System.Text.StringBuilder();
                for (int i = 0; i < cols.Count; i++)
                {
                    if (i > 0) colList.Append(", ");
                    colList.Append('[').Append(cols[i].Replace("]", "]]")).Append(']');
                }

                bool clustered = step.KeyIndexClustered;
                bool unique = step.KeyIndexUnique;

                using (SqlConnection dst = new SqlConnection(dstConn))
                {
                    dst.Open();
                    if (!TableExists(dst, null, destNorm, timeout))
                    {
                        AppLog.Warn("-", "EnsureKeyColumnsIndex: table " + destNorm + " not found — skip.");
                        return;
                    }

                    // Resolve object_id robustly
                    int objectId = 0;
                    using (SqlCommand idCmd = new SqlCommand(
                        "SELECT ISNULL(OBJECT_ID(@a), ISNULL(OBJECT_ID(@b), 0))", dst))
                    {
                        idCmd.CommandTimeout = timeout;
                        idCmd.Parameters.AddWithValue("@a", objIdArg);
                        idCmd.Parameters.AddWithValue("@b", "dbo." + objIdArg.Replace("dbo.", ""));
                        object oid = idCmd.ExecuteScalar();
                        if (oid != null && oid != DBNull.Value) objectId = Convert.ToInt32(oid);
                    }
                    if (objectId == 0)
                    {
                        AppLog.Warn("-", "EnsureKeyColumnsIndex: OBJECT_ID failed for " + objIdArg);
                        return;
                    }

                    // Verify columns (case-insensitive)
                    for (int i = 0; i < cols.Count; i++)
                    {
                        using (SqlCommand chk = new SqlCommand(
                            "SELECT 1 FROM sys.columns WHERE object_id = @oid AND name = @c", dst))
                        {
                            chk.CommandTimeout = timeout;
                            chk.Parameters.AddWithValue("@oid", objectId);
                            chk.Parameters.AddWithValue("@c", cols[i]);
                            object o = chk.ExecuteScalar();
                            if (o == null || o == DBNull.Value)
                            {
                                // try case-insensitive
                                using (SqlCommand chk2 = new SqlCommand(
                                    "SELECT 1 FROM sys.columns WHERE object_id = @oid AND LOWER(name) = LOWER(@c)", dst))
                                {
                                    chk2.CommandTimeout = timeout;
                                    chk2.Parameters.AddWithValue("@oid", objectId);
                                    chk2.Parameters.AddWithValue("@c", cols[i]);
                                    o = chk2.ExecuteScalar();
                                }
                            }
                            if (o == null || o == DBNull.Value)
                            {
                                AppLog.Warn("-", "EnsureKeyColumnsIndex: column [" + cols[i] + "] not on " + destNorm + " — skip index.");
                                return;
                            }
                        }
                    }

                    // Already have this index name?
                    using (SqlCommand ex = new SqlCommand(
                        "SELECT 1 FROM sys.indexes WHERE object_id = @oid AND name = @n", dst))
                    {
                        ex.CommandTimeout = timeout;
                        ex.Parameters.AddWithValue("@oid", objectId);
                        ex.Parameters.AddWithValue("@n", rawName);
                        object o = ex.ExecuteScalar();
                        if (o != null && o != DBNull.Value)
                        {
                            AppLog.Info("-", "Key index already exists: " + rawName + " on " + destNorm);
                            return;
                        }
                    }

                    if (clustered)
                    {
                        using (SqlCommand cx = new SqlCommand(
                            "SELECT 1 FROM sys.indexes WHERE object_id = @oid AND type = 1", dst))
                        {
                            cx.CommandTimeout = timeout;
                            cx.Parameters.AddWithValue("@oid", objectId);
                            object hasCl = cx.ExecuteScalar();
                            if (hasCl != null && hasCl != DBNull.Value)
                            {
                                AppLog.Warn("-", "Table " + destNorm + " already has CLUSTERED index — using NONCLUSTERED UNIQUE instead.");
                                clustered = false;
                                unique = true;
                            }
                        }
                    }

                    string kind = (unique ? "UNIQUE " : "") + (clustered ? "CLUSTERED" : "NONCLUSTERED");
                    string createSql = "CREATE " + kind + " INDEX " + idxName + " ON " + destNorm + " (" + colList.ToString() + ");";
                    AppLog.Info("-", "EnsureKeyColumnsIndex SQL: " + createSql);
                    using (SqlCommand cr = new SqlCommand(createSql, dst))
                    {
                        cr.CommandTimeout = Math.Max(timeout, 120);
                        cr.ExecuteNonQuery();
                    }
                    AppLog.Info("-", "Created key index " + rawName + " (" + kind.Trim() + ") on " + destNorm + " (" + string.Join(",", cols.ToArray()) + ")");
                    Audit.Write("KEY_INDEX_CREATE", destNorm + " | " + rawName + " | " + kind.Trim() + " | " + string.Join(",", cols.ToArray()));
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "EnsureKeyColumnsIndex failed (non-fatal): " + ex.Message);
            }
        }

        private static void PrepareDestTable(string dstConn, JobStep step, DataTable srcSchema, DataTable shape, int timeout)
        {
            using (SqlConnection dst = new SqlConnection(dstConn))
            {
                dst.Open();
                string destNorm = NormalizeTableName(step.DestTable);
                // Drop into: remove the destination table completely, then recreate from source shape.
                if (step.Mode == WriteMode.DropInto && TableExists(dst, null, destNorm, timeout))
                {
                    DropDestTable(dst, null, destNorm, timeout);
                    AppLog.Info("-", "Drop into: dropped destination table " + destNorm + " — will recreate from source.");
                }
                if (!TableExists(dst, null, destNorm, timeout))
                {
                    EnsureSchemaExists(dst, null, destNorm, timeout);
                    using (SqlCommand cc = new SqlCommand(BuildCreateTableSql(destNorm, srcSchema, shape), dst))
                    {
                        cc.CommandTimeout = timeout;
                        cc.ExecuteNonQuery();
                    }
                    AppLog.Info("-", "Destination table " + destNorm + " did not exist — created from source structure.");
                }
                else
                {
                    PrepareDestination(dst, step, timeout);
                    EnsureDestSchema(dst, step, srcSchema, shape, timeout);
                }
            }
            // After table exists: create index on KeyColumns if the user filled them
            EnsureKeyColumnsIndex(dstConn, step, timeout);
        }

        /// <summary>
        /// DROP TABLE for Drop into. Drops FKs that reference this table and FKs on the table first
        /// (AdventureWorks-style graphs), then drops the table. Missing table is ignored.
        /// </summary>
        private static void DropDestTable(SqlConnection dst, SqlTransaction tx, string normalizedTable, int timeout)
        {
            if (string.IsNullOrWhiteSpace(normalizedTable)) return;
            try
            {
                // 1) FKs on OTHER tables that REFERENCE this table
                List<string> dropFkSql = new List<string>();
                using (SqlCommand q = new SqlCommand(@"
SELECT 'ALTER TABLE ' + QUOTENAME(OBJECT_SCHEMA_NAME(fk.parent_object_id)) + '.' + QUOTENAME(OBJECT_NAME(fk.parent_object_id))
     + ' DROP CONSTRAINT ' + QUOTENAME(fk.name)
FROM sys.foreign_keys fk
WHERE fk.referenced_object_id = OBJECT_ID(@n)
UNION ALL
SELECT 'ALTER TABLE ' + QUOTENAME(OBJECT_SCHEMA_NAME(fk.parent_object_id)) + '.' + QUOTENAME(OBJECT_NAME(fk.parent_object_id))
     + ' DROP CONSTRAINT ' + QUOTENAME(fk.name)
FROM sys.foreign_keys fk
WHERE fk.parent_object_id = OBJECT_ID(@n)", dst, tx))
                {
                    q.CommandTimeout = timeout;
                    q.Parameters.AddWithValue("@n", normalizedTable);
                    using (SqlDataReader rd = q.ExecuteReader())
                    {
                        while (rd.Read())
                            dropFkSql.Add(Convert.ToString(rd[0]));
                    }
                }
                foreach (string sql in dropFkSql)
                {
                    try
                    {
                        using (SqlCommand c = new SqlCommand(sql, dst, tx))
                        {
                            c.CommandTimeout = timeout;
                            c.ExecuteNonQuery();
                        }
                    }
                    catch (Exception ex)
                    {
                        AppLog.Warn("-", "Drop into: could not drop FK (" + sql + "): " + ex.Message);
                    }
                }

                // 2) DROP TABLE
                using (SqlCommand cmd = new SqlCommand(
                    "IF OBJECT_ID(@n, N'U') IS NOT NULL DROP TABLE " + normalizedTable, dst, tx))
                {
                    cmd.CommandTimeout = timeout;
                    cmd.Parameters.AddWithValue("@n", normalizedTable);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                // Surface a clear message instead of a later "Cannot access destination table"
                throw new Exception("Drop into: failed to drop destination table " + normalizedTable + ": " + ex.Message, ex);
            }
        }

        /// <summary>
        /// Low-RAM transfer. Stream: bounded in-memory queue between reader and writers.
        /// Disk: spill all batches to temp files first (source is released early, destination untouched
        /// until the spill is complete), then write them with MaxThreads writers.
        /// </summary>
        private static RunResult ExecuteTransferBuffered(JobStep step, string srcConn, string dstConn, string selectSql, int timeout, bool useDisk)
        {
            RunResult r = new RunResult();
            // Last line of defence: whichever path got here, the disk buffer is only ever used when the
            // user switched it on. This is checked here (not only by the caller) so no code path can
            // create a folder under %APPDATA%\SyncDB\buffer behind the setting's back.
            if (useDisk && !RuntimeSettings.UseDiskBuffer)
            {
                AppLog.Info("-", "Disk buffer is OFF in Settings - this transfer runs in Stream mode (no buffer folder).");
                useDisk = false;
            }
            int batch = step.BatchSize > 0 ? step.BatchSize : 5000;
            int threads = ResolveThreadCount(step, 0);
            int delay = Math.Max(0, step.DelayMs);
            ThreadPriority prio = ToThreadPriority(step.Priority);
            ThreadPriority oldPrio = Thread.CurrentThread.Priority;
            CancellationToken outer = _tok;
            CancellationTokenSource lcts = CancellationTokenSource.CreateLinkedTokenSource(outer);
            CancellationToken token = lcts.Token;

            long written = 0;
            long spilledRows = 0;
            long spilledBytes = 0;
            Exception fault = null;
            object faultLock = new object();
            SpillBuffer spill = null;
            List<Thread> workers = new List<Thread>();
            BlockingCollection<BatchItem> queue = useDisk
                ? new BlockingCollection<BatchItem>()
                : new BlockingCollection<BatchItem>(Math.Max(2, threads * 2));

            ThreadStart consumer = () =>
            {
                try
                {
                    using (SqlConnection c = new SqlConnection(dstConn))
                    {
                        c.Open();
                        foreach (BatchItem it in queue.GetConsumingEnumerable(token))
                        {
                            DataTable t = it.Table;
                            if (t == null)
                            {
                                t = LoadSpill(it.File);
                                try { File.Delete(it.File); } catch { }
                            }
                            WriteTable(c, t, step, timeout, batch);
                            Interlocked.Add(ref written, t.Rows.Count);
                            if (delay > 0) token.WaitHandle.WaitOne(delay);
                        }
                    }
                }
                catch (OperationCanceledException) { }
                catch (Exception ex)
                {
                    lock (faultLock) { if (fault == null) fault = ex; }
                    lcts.Cancel();
                }
            };

            Action startWorkers = () =>
            {
                for (int i = 0; i < threads; i++)
                {
                    Thread th = new Thread(consumer);
                    th.IsBackground = true;
                    th.Priority = prio;
                    th.Start();
                    workers.Add(th);
                }
            };

            try
            {
                Thread.CurrentThread.Priority = prio;
                if (useDisk)
                {
                    // Self-cleaning buffer folder: it holds an open lock file, is deleted when the run ends
                    // (also on error / cancel) and is swept away by Maintenance if the process dies first.
                    spill = new SpillBuffer();
                    AppLog.Info(_currentJobName ?? "-", "Disk buffer ON for step '" + (step.Name ?? "") +
                        "' - spill folder " + spill.Dir + " (switch it off in Settings -> Disk buffer).");
                    Maintenance.CleanBufferRoot();   // drop leftovers of earlier runs
                }

                DataTable srcSchema = null;
                DataTable shape = null;
                int fileNo = 0;

                using (SqlConnection src = new SqlConnection(srcConn))
                {
                    src.Open();
                    using (SqlCommand cmd = new SqlCommand(selectSql, src))
                    {
                        cmd.CommandTimeout = timeout;
                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            srcSchema = rd.GetSchemaTable();
                            shape = BuildShape(rd);

                            if (!useDisk)
                            {
                                PrepareDestTable(dstConn, step, srcSchema, shape, timeout);
                                startWorkers();
                            }

                            int fc = rd.FieldCount;
                            object[] vals = new object[fc];
                            DataTable cur = shape.Clone();
                            bool producerOk = true;
                            try
                            {
                                while (rd.Read())
                                {
                                    token.ThrowIfCancellationRequested();
                                    rd.GetValues(vals);
                                    cur.LoadDataRow(vals, true);
                                    if (cur.Rows.Count >= batch)
                                    {
                                        if (useDisk)
                                        {
                                            string f = spill.FilePath(++fileNo);
                                            SpillBatch(cur, f);
                                            spilledRows += cur.Rows.Count;
                                            try { spilledBytes += new FileInfo(f).Length; } catch { }
                                            queue.Add(new BatchItem { File = f });
                                        }
                                        else
                                        {
                                            queue.Add(new BatchItem { Table = cur }, token);
                                        }
                                        cur = shape.Clone();
                                    }
                                }
                                if (cur.Rows.Count > 0)
                                {
                                    if (useDisk)
                                    {
                                        string f = spill.FilePath(++fileNo);
                                        SpillBatch(cur, f);
                                        spilledRows += cur.Rows.Count;
                                        try { spilledBytes += new FileInfo(f).Length; } catch { }
                                        queue.Add(new BatchItem { File = f });
                                    }
                                    else queue.Add(new BatchItem { Table = cur }, token);
                                }
                            }
                            catch (OperationCanceledException) { producerOk = false; }
                            finally
                            {
                                if (!producerOk) { try { cmd.Cancel(); } catch { } }
                            }
                        }
                    }
                }

                if (useDisk)
                {
                    AppLog.Info("-", "Disk buffer: " + spilledRows + " row(s), " + (spilledBytes / 1048576.0).ToString("0.0") +
                                " MB in " + fileNo + " file(s). Source released, writing to destination…");
                    if (!token.IsCancellationRequested)
                    {
                        PrepareDestTable(dstConn, step, srcSchema, shape, timeout);   // also for 0 rows (TruncateInsert / create table)
                        if (fileNo > 0) startWorkers();
                    }
                }

                queue.CompleteAdding();
                foreach (Thread th in workers) th.Join();

                lock (faultLock) { if (fault != null) throw fault; }
                outer.ThrowIfCancellationRequested();

            }
            catch
            {
                lcts.Cancel();      // stop writers if the reader / destination failed or the job was cancelled
                throw;
            }
            finally
            {
                try { queue.CompleteAdding(); } catch { }
                foreach (Thread th in workers) { try { th.Join(); } catch { } }
                Thread.CurrentThread.Priority = oldPrio;
                // Batches still queued (cancel / error) keep their spill files: delete them explicitly,
                // then drop the whole folder. Nothing is left in %APPDATA%\SyncDB\buffer after a run.
                try
                {
                    BatchItem left;
                    while (queue.TryTake(out left))
                    {
                        if (left != null && left.File != null) { try { File.Delete(left.File); } catch { } }
                    }
                }
                catch { }
                try { queue.Dispose(); } catch { }
                lcts.Dispose();
                if (spill != null) { try { spill.Dispose(); } catch { } }
            }

            r.Ok = true;
            r.Rows = Interlocked.Read(ref written);
            r.Message = "Transferred " + r.Rows + " row(s) → " + step.DestTable + " [" + (useDisk ? "disk buffer" : "stream") + "]";
            return r;
        }

        /// <summary>For SyncChanges: DELETE dest rows whose keys are not present in source data (no TRUNCATE).</summary>
        private static string BareTableName(string table)
        {
            if (string.IsNullOrEmpty(table)) return "Unknown";
            string s = table.Trim();
            int dot = s.LastIndexOf('.');
            if (dot >= 0) s = s.Substring(dot + 1);
            return s.Trim().Trim('[', ']').Replace("]]", "]");
        }

        /// <summary>
        /// Creates [schema] if missing and [schema].[Table] as an empty copy of the destination table,
        /// plus the two audit columns.
        ///
        /// Build 42t: the table used to be made with "SELECT TOP 0 * INTO bak FROM src", which COPIES THE
        /// IDENTITY PROPERTY. Every later "INSERT INTO bak SELECT ..." then failed with
        /// "Cannot insert explicit value for identity column", the fallback failed too (column count), and
        /// the recycle table stayed empty - which looked like the feature doing nothing. Selecting through
        /// a UNION ALL makes SQL Server drop the identity property, so the copy is a plain table.
        /// </summary>
        private static void EnsureRecycleTable(SqlConnection dst, string sourceTable, string schema, int timeout)
        {
            EnsureRecycleTable(dst, null, sourceTable, schema, timeout);
        }

        private static void EnsureRecycleTable(SqlConnection dst, SqlTransaction tx, string sourceTable, string schema, int timeout)
        {
            if (dst == null || string.IsNullOrWhiteSpace(schema) || string.IsNullOrWhiteSpace(sourceTable)) return;
            string sch = schema.Trim().Replace("]", "]]");
            string raw = BareTableName(sourceTable).Replace("]", "]]");
            string bak = "[" + sch + "].[" + raw + "]";

            using (SqlCommand c = new SqlCommand(
                "IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = @s) " +
                "BEGIN EXEC('CREATE SCHEMA [" + sch + "]'); END", dst, tx))
            {
                c.Parameters.AddWithValue("@s", schema.Trim());
                c.CommandTimeout = timeout;
                c.ExecuteNonQuery();
            }

            using (SqlCommand c = new SqlCommand(
                "IF OBJECT_ID(N'" + bak + "', N'U') IS NULL " +
                "BEGIN " +
                "  SELECT TOP 0 * INTO " + bak + " FROM " +
                "     (SELECT * FROM " + sourceTable + " UNION ALL SELECT * FROM " + sourceTable + ") AS __x; " +
                "  ALTER TABLE " + bak + " ADD [__DeletedUtc] datetime2 NULL; " +
                "  ALTER TABLE " + bak + " ADD [__Op] nchar(1) NULL; " +
                "END", dst, tx))
            {
                c.CommandTimeout = timeout;
                c.ExecuteNonQuery();
                AppLog.Info("-", "Recycle table ready: " + bak);
            }
        }

        /// <summary>Column names of a table, in ordinal order (computed columns included, they are readable).</summary>
        private static List<string> TableColumns(SqlConnection dst, SqlTransaction tx, string table, int timeout)
        {
            List<string> cols = new List<string>();
            using (SqlCommand c = new SqlCommand(
                "SELECT c.name FROM sys.columns c WHERE c.object_id = OBJECT_ID(@t) ORDER BY c.column_id", dst, tx))
            {
                c.Parameters.AddWithValue("@t", table);
                c.CommandTimeout = timeout;
                using (SqlDataReader rd = c.ExecuteReader())
                    while (rd.Read()) cols.Add(rd.GetString(0));
            }
            return cols;
        }

        /// <summary>
        /// Copies rows that are about to be deleted or overwritten into the recycle table.
        /// The column list is built by NAME from both tables, so a column added to the destination after
        /// the recycle table was created no longer breaks the copy (it is simply skipped).
        /// </summary>
        /// <param name="alias">Alias the whereClause / joinSql use for the destination table.</param>
        internal static int RecycleCopy(SqlConnection dst, SqlTransaction tx, string table, string alias,
                                        string joinSql, string whereClause, string op, int timeout, SyncJob job)
        {
            if (job == null) job = CurrentRecycleJob();
            if (job == null || !job.EnableRecycleBin || string.IsNullOrWhiteSpace(job.RecycleSchema)) return 0;
            if (dst == null || string.IsNullOrWhiteSpace(table)) return 0;
            if (string.IsNullOrEmpty(alias)) alias = "src";

            try
            {
                EnsureRecycleTable(dst, tx, table, job.RecycleSchema, timeout);

                string raw = BareTableName(table).Replace("]", "]]");
                string bak = "[" + job.RecycleSchema.Trim().Replace("]", "]]") + "].[" + raw + "]";

                List<string> srcCols = TableColumns(dst, tx, table, timeout);
                List<string> bakCols = TableColumns(dst, tx, bak, timeout);
                if (srcCols.Count == 0 || bakCols.Count == 0)
                {
                    AppLog.Warn("-", "Recycle skipped: could not read the columns of " + table + " / " + bak);
                    return 0;
                }

                Dictionary<string, bool> inBak = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
                foreach (string cn in bakCols) inBak[cn] = true;
                bool hasUtc = inBak.ContainsKey("__DeletedUtc");
                bool hasOp = inBak.ContainsKey("__Op");

                StringBuilder target = new StringBuilder();
                StringBuilder source = new StringBuilder();
                int n = 0;
                foreach (string cn in srcCols)
                {
                    if (string.Equals(cn, "__DeletedUtc", StringComparison.OrdinalIgnoreCase)) continue;
                    if (string.Equals(cn, "__Op", StringComparison.OrdinalIgnoreCase)) continue;
                    if (!inBak.ContainsKey(cn)) continue;              // column added after the table was made
                    if (n > 0) { target.Append(", "); source.Append(", "); }
                    string e = cn.Replace("]", "]]");
                    target.Append("[").Append(e).Append("]");
                    source.Append(alias).Append(".[").Append(e).Append("]");
                    n++;
                }
                if (n == 0)
                {
                    AppLog.Warn("-", "Recycle skipped: no common column between " + table + " and " + bak);
                    return 0;
                }
                if (hasUtc) { target.Append(", [__DeletedUtc]"); source.Append(", SYSUTCDATETIME()"); }
                if (hasOp) { target.Append(", [__Op]"); source.Append(", N'").Append(op == "U" ? "U" : "D").Append("'"); }

                string sql = "INSERT INTO " + bak + " (" + target + ") SELECT " + source +
                             " FROM " + table + " AS " + alias +
                             (string.IsNullOrWhiteSpace(joinSql) ? "" : " " + joinSql) +
                             (string.IsNullOrWhiteSpace(whereClause) ? "" : " WHERE " + whereClause);

                using (SqlCommand c = new SqlCommand(sql, dst, tx))
                {
                    c.CommandTimeout = timeout;
                    int rows = c.ExecuteNonQuery();
                    if (rows > 0) AppLog.Info("-", "Recycle saved " + rows + " " + (op == "U" ? "pre-update" : "deleted") + " row(s) into " + bak);
                    else AppLog.Info("-", "Recycle: no matching row to save (" + op + ") " + bak);
                    return rows;
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "Recycle copy failed for " + table + ": " + ex.Message);
                return 0;
            }
        }

        /// <summary>Job of the run on this thread, falling back to the last started run (worker threads).</summary>
        internal static SyncJob CurrentRecycleJob()
        {
            return _currentJob ?? _recycleJob;
        }

        /// <summary>Kept for the delta engine: copy rows matching a WHERE clause.</summary>
        internal static void CopyToRecycle(SqlConnection dst, string sourceTable, string whereClause, string op, int timeout)
        {
            RecycleCopy(dst, null, sourceTable, "src", null, whereClause, op, timeout, null);
        }

        private static long DeleteOrphanDestRows(string dstConn, JobStep step, DataTable data, int timeout, SyncJob job = null)
        {
            if (step == null || data == null) return 0;
            string[] keys = (step.KeyColumns ?? "").Split(new char[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < keys.Length; i++) keys[i] = keys[i].Trim().Trim('[', ']');
            if (keys.Length == 0) return 0;
            // resolve column names
            for (int i = 0; i < keys.Length; i++)
            {
                foreach (DataColumn c in data.Columns)
                    if (string.Equals(c.ColumnName, keys[i], StringComparison.OrdinalIgnoreCase))
                    { keys[i] = c.ColumnName; break; }
            }
            System.Collections.Generic.HashSet<string> srcKeys = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (DataRow row in data.Rows)
            {
                StringBuilder kb = new StringBuilder();
                for (int k = 0; k < keys.Length; k++)
                {
                    if (k > 0) kb.Append('\x1f');
                    object v = row[keys[k]];
                    kb.Append(v == null || v == DBNull.Value ? "" : Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture));
                }
                srcKeys.Add(kb.ToString());
            }
            string table = NormalizeTableName(step.DestTable);
            long deleted = 0;
            using (SqlConnection dst = new SqlConnection(dstConn))
            {
                dst.Open();
                // read dest keys
                StringBuilder colList = new StringBuilder();
                for (int k = 0; k < keys.Length; k++)
                {
                    if (k > 0) colList.Append(",");
                    colList.Append("[").Append(keys[k].Replace("]", "]]")).Append("]");
                }
                System.Collections.Generic.List<string> toDelete = new System.Collections.Generic.List<string>();
                using (SqlCommand cmd = new SqlCommand("SELECT " + colList + " FROM " + table, dst))
                {
                    cmd.CommandTimeout = timeout;
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            StringBuilder kb = new StringBuilder();
                            for (int k = 0; k < keys.Length; k++)
                            {
                                if (k > 0) kb.Append('\x1f');
                                object v = rd.IsDBNull(k) ? null : rd.GetValue(k);
                                kb.Append(v == null ? "" : Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture));
                            }
                            string key = kb.ToString();
                            if (!srcKeys.Contains(key)) toDelete.Add(key);
                        }
                    }
                }
                foreach (string key in toDelete)
                {
                    string[] parts = key.Split(new char[] { '\x1f' });
                    StringBuilder where = new StringBuilder();
                    for (int k = 0; k < keys.Length; k++)
                    {
                        if (k > 0) where.Append(" AND ");
                        where.Append("[").Append(keys[k].Replace("]", "]]")).Append("]=");
                        string pv = k < parts.Length ? parts[k] : "";
                        if (pv.Length == 0) where.Append("NULL");
                        else where.Append(FormatSqlLiteral(pv));
                    }
                    // Recycle bin: copy the row to the bak schema before deleting, if enabled
                    RecycleCopy(dst, null, table, "src", null, where.ToString(), "D", timeout, job);
                    using (SqlCommand del = new SqlCommand("DELETE FROM " + table + " WHERE " + where, dst))
                    {
                        del.CommandTimeout = timeout;
                        deleted += del.ExecuteNonQuery();
                    }
                }
            }
            if (deleted > 0)
                AppLog.Info("-", "SyncChanges deleted " + deleted + " orphan row(s) from " + step.DestTable);
            return deleted;
        }

        /// <summary>Rebuilds all indexes of the destination table. Returns the number of indexes found (0 = nothing done).</summary>
        private static int RebuildDestIndexes(string dstConn, string destTable, int timeout)
        {
            if (string.IsNullOrWhiteSpace(destTable)) return 0;
            string table = NormalizeTableName(destTable);
            string[] parts = table.Split(new string[] { "]." }, StringSplitOptions.None);
            using (SqlConnection dst = new SqlConnection(dstConn))
            {
                dst.Open();
                string target = table;
                if (parts.Length >= 3)
                {
                    dst.ChangeDatabase(parts[0].Trim('[', ']').Replace("]]", "]"));
                    target = parts[1] + "]." + parts[2];
                }
                int count;
                using (SqlCommand chk = new SqlCommand(
                    "SELECT COUNT(*) FROM sys.indexes WHERE object_id = OBJECT_ID(@n) AND index_id > 0 AND is_hypothetical = 0 AND is_disabled = 0", dst))
                {
                    chk.CommandTimeout = timeout;
                    chk.Parameters.AddWithValue("@n", target);
                    count = Convert.ToInt32(chk.ExecuteScalar());
                }
                if (count == 0) return 0;
                using (SqlCommand cmd = new SqlCommand("ALTER INDEX ALL ON " + target + " REBUILD", dst))
                {
                    cmd.CommandTimeout = Math.Max(timeout, 600);
                    cmd.ExecuteNonQuery();
                }
                return count;
            }
        }

        private static long WriteRows(SqlConnection dst, DataTable data, int start, int count, JobStep step, int timeout)
        {
            if (step != null && (step.Mode == WriteMode.MergeUpsert || step.Mode == WriteMode.SyncChanges))
                return WriteMergeBatch(dst, data, start, count, step, timeout);
            return WriteBatch(dst, data, start, count, step, timeout);
        }

        /// <summary>MERGE-style: UPDATE existing by KeyColumns, INSERT missing.</summary>
        private static long WriteMergeBatch(SqlConnection dst, DataTable data, int start, int count, JobStep step, int timeout)
        {
            if (count <= 0 || start >= data.Rows.Count) return 0;
            string table = NormalizeTableName(step.DestTable);
            string[] keys = (step.KeyColumns ?? "").Split(new char[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < keys.Length; i++) keys[i] = keys[i].Trim().Trim('[', ']');
            if (keys.Length == 0)
                throw new Exception("Merge UPSERT requires Key columns (e.g. Id or Code,Id).");

            // ensure keys exist in data
            foreach (string k in keys)
            {
                bool found = false;
                foreach (DataColumn c in data.Columns)
                    if (string.Equals(c.ColumnName, k, StringComparison.OrdinalIgnoreCase)) { found = true; break; }
                if (!found) throw new Exception("Key column not in source data: " + k);
            }

            long n = 0;
            int end = Math.Min(start + count, data.Rows.Count);
            using (SqlTransaction tx = dst.BeginTransaction())
            {
                for (int i = start; i < end; i++)
                {
                    DataRow row = data.Rows[i];
                    // build WHERE
                    StringBuilder where = new StringBuilder();
                    for (int k = 0; k < keys.Length; k++)
                    {
                        if (k > 0) where.Append(" AND ");
                        object kv = row[keys[k]];
                        // case-insensitive column access
                        foreach (DataColumn c in data.Columns)
                            if (string.Equals(c.ColumnName, keys[k], StringComparison.OrdinalIgnoreCase)) { kv = row[c]; keys[k] = c.ColumnName; break; }
                        where.Append("[").Append(keys[k].Replace("]", "]]")).Append("]=");
                        if (kv == null || kv == DBNull.Value) where.Append("NULL");
                        else where.Append(FormatSqlLiteral(Convert.ToString(kv, System.Globalization.CultureInfo.InvariantCulture)));
                    }
                    // exists?
                    bool exists = false;
                    using (SqlCommand chk = new SqlCommand("SELECT TOP 1 1 FROM " + table + " WHERE " + where.ToString(), dst, tx))
                    {
                        chk.CommandTimeout = timeout;
                        object o = chk.ExecuteScalar();
                        exists = (o != null && o != DBNull.Value);
                    }
                    if (exists)
                    {
                        // UPDATE non-key columns
                        StringBuilder sets = new StringBuilder();
                        int sc = 0;
                        foreach (DataColumn c in data.Columns)
                        {
                            bool isKey = false;
                            foreach (string k in keys)
                                if (string.Equals(k, c.ColumnName, StringComparison.OrdinalIgnoreCase)) { isKey = true; break; }
                            if (isKey) continue;
                            if (sc > 0) sets.Append(", ");
                            sets.Append("[").Append(c.ColumnName.Replace("]", "]]")).Append("]=");
                            object v = row[c];
                            if (v == null || v == DBNull.Value) sets.Append("NULL");
                            else sets.Append(FormatSqlLiteral(Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture)));
                            sc++;
                        }
                        if (sc > 0)
                        {
                            // Save the pre-update image into the recycle table (same transaction)
                            RecycleCopy(dst, tx, table, "src", null, where.ToString(), "U", timeout, null);

                            using (SqlCommand u = new SqlCommand("UPDATE " + table + " SET " + sets.ToString() + " WHERE " + where.ToString(), dst, tx))
                            {
                                u.CommandTimeout = timeout;
                                u.ExecuteNonQuery();
                            }
                        }
                    }
                    else
                    {
                        // INSERT
                        StringBuilder cols = new StringBuilder();
                        StringBuilder vals = new StringBuilder();
                        for (int c = 0; c < data.Columns.Count; c++)
                        {
                            if (c > 0) { cols.Append(","); vals.Append(","); }
                            cols.Append("[").Append(data.Columns[c].ColumnName.Replace("]", "]]")).Append("]");
                            object v = row[c];
                            if (v == null || v == DBNull.Value) vals.Append("NULL");
                            else vals.Append(FormatSqlLiteral(Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture)));
                        }
                        using (SqlCommand ins = new SqlCommand("INSERT INTO " + table + " (" + cols + ") VALUES (" + vals + ")", dst, tx))
                        {
                            ins.CommandTimeout = timeout;
                            ins.ExecuteNonQuery();
                        }
                    }
                    n++;
                }
                tx.Commit();
            }
            return n;
        }

        private static long WriteBatch(SqlConnection dst, DataTable data, int offset, int batch, JobStep step, int timeout)
        {
            int take = Math.Min(batch, data.Rows.Count - offset);
            DataTable slice = data.Clone();
            for (int i = 0; i < take; i++)
                slice.ImportRow(data.Rows[offset + i]);
            try
            {
                using (SqlBulkCopy bulk = new SqlBulkCopy(dst))
                {
                    bulk.DestinationTableName = NormalizeTableName(step.DestTable);
                    bulk.BulkCopyTimeout = timeout;
                    bulk.BatchSize = batch;
                    foreach (DataColumn col in data.Columns)
                        bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                    bulk.WriteToServer(slice);
                    RunTrace.Progress(slice.Rows.Count);
                }
            }
            catch (Exception ex)
            {
                // Wrong column types from an earlier bad CREATE (e.g. TIME stored as NVARCHAR)
                if (IsBulkTypeMismatch(ex) && TryRecreateEmptyDest(dst, step, data, null, timeout))
                {
                    using (SqlBulkCopy bulk = new SqlBulkCopy(dst))
                    {
                        bulk.DestinationTableName = NormalizeTableName(step.DestTable);
                        bulk.BulkCopyTimeout = timeout;
                        bulk.BatchSize = batch;
                        foreach (DataColumn col in data.Columns)
                            bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                        bulk.WriteToServer(slice);
                        RunTrace.Progress(slice.Rows.Count);
                    }
                }
                else throw;
            }
            return take;
        }

        private static bool IsBulkTypeMismatch(Exception ex)
        {
            if (ex == null) return false;
            string m = ex.Message ?? "";
            return m.IndexOf("cannot be converted", StringComparison.OrdinalIgnoreCase) >= 0
                || m.IndexOf("type mismatch", StringComparison.OrdinalIgnoreCase) >= 0
                || m.IndexOf("failed to convert", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>If dest table is empty, DROP and recreate from the in-memory DataTable shape.</summary>
        private static bool TryRecreateEmptyDest(SqlConnection dst, JobStep step, DataTable shape, DataTable srcSchema, int timeout)
        {
            try
            {
                string table = NormalizeTableName(step.DestTable);
                using (SqlCommand q = new SqlCommand(
                    "SELECT CASE WHEN OBJECT_ID(@t, N'U') IS NULL THEN 1 WHEN EXISTS (SELECT 1 FROM " + table + ") THEN 0 ELSE 1 END", dst))
                {
                    q.Parameters.AddWithValue("@t", table);
                    q.CommandTimeout = timeout;
                    if (Convert.ToInt32(q.ExecuteScalar()) != 1) return false; // missing or has data
                }
                using (SqlCommand drop = new SqlCommand("DROP TABLE " + table, dst))
                {
                    drop.CommandTimeout = timeout;
                    drop.ExecuteNonQuery();
                }
                EnsureSchemaExists(dst, null, table, timeout);
                using (SqlCommand cc = new SqlCommand(BuildCreateTableSql(table, srcSchema, shape), dst))
                {
                    cc.CommandTimeout = timeout;
                    cc.ExecuteNonQuery();
                }
                AppLog.Warn("-", "Recreated empty dest table " + table + " with corrected column types.");
                return true;
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "TryRecreateEmptyDest: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// SELECT list that casts hierarchyid / geography / geometry to nvarchar so the client
        /// does not need Microsoft.SqlServer.Types.dll (SQL 8116 / assembly load errors).
        /// Other columns stay as-is. Falls back to SELECT * if catalog lookup fails.
        /// </summary>
        private static string BuildSafeSelectFromTable(string srcConn, string sourceTable, int timeout)
        {
            string table = NormalizeTableName(sourceTable);
            try
            {
                using (SqlConnection c = new SqlConnection(srcConn))
                {
                    c.Open();
                    List<string> cols = new List<string>();
                    string plain = sourceTable.Replace("[", "").Replace("]", "");
                    using (SqlCommand q = new SqlCommand(@"
SELECT c.name, t.name AS type_name
FROM sys.columns c
JOIN sys.types t ON c.user_type_id = t.user_type_id
WHERE c.object_id = OBJECT_ID(@t)
ORDER BY c.column_id", c))
                    {
                        q.CommandTimeout = Math.Max(timeout, 60);
                        q.Parameters.AddWithValue("@t", plain);
                        using (SqlDataReader r = q.ExecuteReader())
                        {
                            while (r.Read())
                            {
                                string name = r.GetString(0);
                                string tn = (r.IsDBNull(1) ? "" : r.GetString(1)).ToLowerInvariant();
                                string col = "[" + name.Replace("]", "]]") + "]";
                                if (tn == "hierarchyid" || tn == "geography" || tn == "geometry")
                                    cols.Add("CONVERT(nvarchar(max), " + col + ") AS " + col);
                                else
                                    cols.Add(col);
                            }
                        }
                    }
                    if (cols.Count == 0)
                    {
                        // INFORMATION_SCHEMA fallback
                        string schema = "dbo", obj = plain;
                        int dot = plain.LastIndexOf('.');
                        if (dot > 0) { schema = plain.Substring(0, dot); obj = plain.Substring(dot + 1); }
                        using (SqlCommand q2 = new SqlCommand(@"
SELECT COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = @s AND TABLE_NAME = @o
ORDER BY ORDINAL_POSITION", c))
                        {
                            q2.Parameters.AddWithValue("@s", schema);
                            q2.Parameters.AddWithValue("@o", obj);
                            q2.CommandTimeout = Math.Max(timeout, 60);
                            using (SqlDataReader r2 = q2.ExecuteReader())
                            {
                                while (r2.Read())
                                {
                                    string name = r2.GetString(0);
                                    string tn = (r2.IsDBNull(1) ? "" : r2.GetString(1)).ToLowerInvariant();
                                    string col = "[" + name.Replace("]", "]]") + "]";
                                    if (tn == "hierarchyid" || tn == "geography" || tn == "geometry")
                                        cols.Add("CONVERT(nvarchar(max), " + col + ") AS " + col);
                                    else
                                        cols.Add(col);
                                }
                            }
                        }
                    }
                    if (cols.Count > 0)
                        return "SELECT " + string.Join(", ", cols.ToArray()) + " FROM " + table;
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "BuildSafeSelectFromTable: " + ex.Message);
            }
            return "SELECT * FROM " + table;
        }

        // ---- build CREATE TABLE from source structure (for Transfer auto-create) ----

        /// <summary>
        /// If dest table is schema.table and schema is missing, CREATE SCHEMA.
        /// Fixes "Invalid object name 'HumanResources.Employee'" when only dbo exists on dest.
        /// </summary>
        private static void EnsureSchemaExists(SqlConnection conn, SqlTransaction tx, string normalizedTable, int timeout)
        {
            if (conn == null || string.IsNullOrWhiteSpace(normalizedTable)) return;
            try
            {
                string raw = normalizedTable.Replace("[", "").Replace("]", "");
                string[] parts = raw.Split('.');
                if (parts.Length < 2) return; // dbo implied / single name
                // last part = table; previous = schema (ignore 3-part db.schema.table → schema is middle)
                string schema = parts.Length >= 3 ? parts[parts.Length - 2] : parts[0];
                if (string.IsNullOrWhiteSpace(schema)) return;
                if (string.Equals(schema, "dbo", StringComparison.OrdinalIgnoreCase)) return; // always exists
                string sch = schema.Replace("]", "]]");
                string sql =
                    "IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'" + sch.Replace("'", "''") + "') " +
                    "EXEC(N'CREATE SCHEMA [" + sch + "]')";
                using (SqlCommand cmd = new SqlCommand(sql, conn, tx))
                {
                    cmd.CommandTimeout = Math.Max(timeout, 30);
                    cmd.ExecuteNonQuery();
                }
                AppLog.Info("-", "Ensured schema exists: [" + schema + "]");
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "EnsureSchemaExists: " + ex.Message);
            }
        }

        private static string BuildCreateTableSql(string table, DataTable schema, DataTable data)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("CREATE TABLE ").Append(table).Append(" (");
            for (int i = 0; i < data.Columns.Count; i++)
            {
                DataColumn dc = data.Columns[i];
                DataRow sr = null;
                if (schema != null)
                {
                    foreach (DataRow row in schema.Rows)
                        if (string.Equals(Convert.ToString(row["ColumnName"]), dc.ColumnName, StringComparison.OrdinalIgnoreCase)) { sr = row; break; }
                }
                if (i > 0) sb.Append(", ");
                sb.Append('[').Append(dc.ColumnName.Replace("]", "]]")).Append("] ").Append(SqlTypeFor(sr, dc)).Append(" NULL");
            }
            sb.Append(")");
            return sb.ToString();
        }

        private static string SqlTypeFor(DataRow sr, DataColumn dc)
        {
            if (sr != null)
            {
                string tn = Convert.ToString(sr["DataTypeName"]).ToLowerInvariant();
                int size = 0; int prec = 0; int scale = 0;
                try { size = Convert.ToInt32(sr["ColumnSize"]); } catch { }
                try { prec = Convert.ToInt32(sr["NumericPrecision"]); } catch { }
                try { scale = Convert.ToInt32(sr["NumericScale"]); } catch { }
                switch (tn)
                {
                    case "char": case "varchar":
                        return tn.ToUpperInvariant() + "(" + ((size <= 0 || size > 8000) ? "MAX" : size.ToString()) + ")";
                    case "nchar": case "nvarchar":
                        return tn.ToUpperInvariant() + "(" + ((size <= 0 || size > 4000) ? "MAX" : size.ToString()) + ")";
                    case "binary": case "varbinary":
                        return tn.ToUpperInvariant() + "(" + ((size <= 0 || size > 8000) ? "MAX" : size.ToString()) + ")";
                    case "text": return "VARCHAR(MAX)";
                    case "ntext": return "NVARCHAR(MAX)";
                    case "image": return "VARBINARY(MAX)";
                    case "decimal": case "numeric":
                        if (prec <= 0 || prec > 38) { prec = 38; scale = 10; }
                        return tn.ToUpperInvariant() + "(" + prec + "," + scale + ")";
                    case "datetime2": case "datetimeoffset": case "time":
                        return (scale >= 0 && scale <= 7) ? tn.ToUpperInvariant() + "(" + scale + ")" : tn.ToUpperInvariant();
                    case "timestamp": case "rowversion": return "VARBINARY(8)";
                    case "hierarchyid":
                    case "geography":
                    case "geometry":
                        // without Microsoft.SqlServer.Types.dll we store the textual form
                        return "NVARCHAR(MAX)";
                    case "int": case "bigint": case "smallint": case "tinyint": case "bit":
                    case "money": case "smallmoney": case "float": case "real":
                    case "datetime": case "smalldatetime": case "date":
                    case "uniqueidentifier": case "xml": case "sql_variant":
                        return tn.ToUpperInvariant();
                }
            }
            Type t = dc.DataType;
            if (t == typeof(string)) return "NVARCHAR(MAX)";
            if (t == typeof(int)) return "INT";
            if (t == typeof(long)) return "BIGINT";
            if (t == typeof(short)) return "SMALLINT";
            if (t == typeof(byte)) return "TINYINT";
            if (t == typeof(bool)) return "BIT";
            if (t == typeof(decimal)) return "DECIMAL(38,10)";
            if (t == typeof(double)) return "FLOAT";
            if (t == typeof(float)) return "REAL";
            if (t == typeof(DateTime)) return "DATETIME2";
            if (t == typeof(DateTimeOffset)) return "DATETIMEOFFSET";
            if (t == typeof(Guid)) return "UNIQUEIDENTIFIER";
            if (t == typeof(byte[])) return "VARBINARY(MAX)";
            if (t == typeof(TimeSpan)) return "TIME";
            return "NVARCHAR(MAX)";
        }

        private static void PrepareDestination(SqlConnection dst, JobStep step, int timeout)
        {
            PrepareDestination(dst, step, timeout, null);
        }

        private static void PrepareDestination(SqlConnection dst, JobStep step, int timeout, SqlTransaction tx)
        {
            string table = NormalizeTableName(step.DestTable);
            string sql = null;
            if (step.Mode == WriteMode.TruncateInsert)
                sql = "TRUNCATE TABLE " + table;
            else if (step.Mode == WriteMode.DeleteInsert)
            {
                sql = "DELETE FROM " + table;
                if (!string.IsNullOrWhiteSpace(step.DestDeleteWhere))
                    sql += " WHERE " + step.DestDeleteWhere.Trim();
            }
            else if (step.Mode == WriteMode.DropInto)
            {
                // Prefer full drop+recreate via PrepareDestTable; if we land here (e.g. API path), drop only.
                DropDestTable(dst, tx, table, timeout);
                return;
            }
            if (sql == null) return;
            using (SqlCommand cmd = new SqlCommand(sql, dst, tx))
            {
                cmd.CommandTimeout = timeout;
                cmd.ExecuteNonQuery();
            }
        }

        public static string NormalizeTableName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return name;
            name = name.Trim();
            if (name.StartsWith("[") && name.EndsWith("]")) return name;
            string[] parts = name.Split('.');
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.Length; i++)
            {
                if (i > 0) sb.Append('.');
                string p = parts[i].Trim().Trim('[', ']');
                sb.Append('[').Append(p.Replace("]", "]]")).Append(']');
            }
            return sb.ToString();
        }


        // =====================================================================
        //  Web API  →  Destination table   (no Linked Server needed)
        // =====================================================================

        /// <summary>POST login to AuthUrl; parse JSON token / access_token / BearerToken.</summary>
        private static string TryFetchApiToken(string authUrl, string user, string password, bool ignoreCert, int timeoutSec)
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(authUrl);
            req.Method = "POST";
            req.ContentType = "application/json";
            req.Accept = "application/json";
            req.Timeout = Math.Min(timeoutSec, 60) * 1000;
            req.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            if (ignoreCert)
                req.ServerCertificateValidationCallback = delegate { return true; };
            string body = "{\"email\":" + JsonEscape(user ?? "") + ",\"password\":" + JsonEscape(password ?? "") +
                          ",\"username\":" + JsonEscape(user ?? "") + "}";
            byte[] data = Encoding.UTF8.GetBytes(body);
            req.ContentLength = data.Length;
            using (Stream s = req.GetRequestStream())
                s.Write(data, 0, data.Length);
            using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
            using (Stream rs = resp.GetResponseStream())
            using (StreamReader sr = new StreamReader(rs ?? Stream.Null, Encoding.UTF8))
            {
                string json = sr.ReadToEnd() ?? "";
                return ExtractTokenFromJson(json);
            }
        }

        private static string JsonEscape(string s)
        {
            if (s == null) s = "";
            return "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "\\n") + "\"";
        }

        private static string ExtractTokenFromJson(string json)
        {
            if (string.IsNullOrWhiteSpace(json)) return "";
            try
            {
                Newtonsoft.Json.Linq.JToken root = Newtonsoft.Json.Linq.JToken.Parse(json);
                string[] keys = new string[] { "token", "Token", "access_token", "accessToken", "bearerToken", "BearerToken", "jwt", "id_token" };
                foreach (string k in keys)
                {
                    Newtonsoft.Json.Linq.JToken t = root[k];
                    if (t != null && t.Type == Newtonsoft.Json.Linq.JTokenType.String)
                    {
                        string v = t.ToString();
                        if (!string.IsNullOrWhiteSpace(v)) return v;
                    }
                    Newtonsoft.Json.Linq.JToken data = root["data"];
                    if (data != null)
                    {
                        t = data[k];
                        if (t != null && t.Type == Newtonsoft.Json.Linq.JTokenType.String)
                        {
                            string v = t.ToString();
                            if (!string.IsNullOrWhiteSpace(v)) return v;
                        }
                    }
                }
            }
            catch { }
            return "";
        }

        private static RunResult ExecuteApiToDest(JobStep step, string dstConn, int timeout)
        {
            RunResult r = new RunResult();
            if (string.IsNullOrWhiteSpace(dstConn))
                throw new Exception("Destination connection is empty.");
            if (string.IsNullOrWhiteSpace(step.DestTable))
                throw new Exception("Destination table is empty.");
            if (string.IsNullOrWhiteSpace(step.ApiUrl))
                throw new Exception("API URL is empty.");

            // 1) Fetch everything first, so a failing API never wipes the destination table.
            List<JObject> items = FetchApiItems(step, timeout);
            AppLog.Info("-", "API returned " + items.Count + " item(s) from " + step.ApiUrl);

            if (items.Count == 0)
            {
                r.Ok = true;
                r.Rows = 0;
                r.Message = "Web API: 0 rows (destination not modified).";
                return r;
            }

            // 2) Union of JSON property names (keeps first-seen order)
            List<string> apiCols = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (JObject o in items)
                foreach (JProperty pr in o.Properties())
                    if (seen.Add(pr.Name)) apiCols.Add(pr.Name);

            string table = NormalizeTableName(step.DestTable);
            int batch = step.BatchSize > 0 ? step.BatchSize : items.Count;

            using (SqlConnection dst = new SqlConnection(dstConn))
            {
                dst.Open();
                using (SqlTransaction tx = dst.BeginTransaction())
                {
                    try
                    {
                        bool exists = TableExists(dst, tx, table, timeout);
                        if (!exists)
                        {
                            CreateTableFromJson(dst, tx, table, apiCols, items, timeout);
                            AppLog.Info("-", "Destination table " + table + " did not exist — created with inferred SQL types from JSON.");
                        }
                        else
                        {
                            PrepareDestination(dst, step, timeout, tx);
                        }

                        // 3) Read destination schema, map columns by name (case-insensitive)
                        DataTable schema = new DataTable();
                        using (SqlCommand sc = new SqlCommand("SELECT TOP 0 * FROM " + table, dst, tx))
                        {
                            sc.CommandTimeout = timeout;
                            using (SqlDataAdapter da = new SqlDataAdapter(sc))
                                da.Fill(schema);
                        }

                        DataTable dt = new DataTable();
                        List<string> jsonNames = new List<string>();
                        List<string> skipped = new List<string>();
                        foreach (string ac in apiCols)
                        {
                            DataColumn match = null;
                            foreach (DataColumn dc in schema.Columns)
                                if (string.Equals(dc.ColumnName, ac, StringComparison.OrdinalIgnoreCase)) { match = dc; break; }
                            if (match == null) { skipped.Add(ac); continue; }
                            dt.Columns.Add(match.ColumnName, match.DataType);
                            jsonNames.Add(ac);
                        }
                        if (dt.Columns.Count == 0)
                        {
                            List<string> dcols = new List<string>();
                            foreach (DataColumn dc in schema.Columns) dcols.Add(dc.ColumnName);
                            throw new Exception("No JSON property matches a column of " + table
                                + ". JSON: [" + string.Join(", ", apiCols.ToArray())
                                + "]  Table: [" + string.Join(", ", dcols.ToArray()) + "]");
                        }
                        if (skipped.Count > 0)
                            AppLog.Warn("-", "JSON properties with no matching column (ignored): " + string.Join(", ", skipped.ToArray()));

                        // 4) Convert values
                        int rowNo = 0;
                        foreach (JObject o in items)
                        {
                            rowNo++;
                            DataRow row = dt.NewRow();
                            for (int c = 0; c < dt.Columns.Count; c++)
                            {
                                JToken tok = o[jsonNames[c]];
                                try { row[c] = ConvertJsonValue(tok, dt.Columns[c].DataType); }
                                catch
                                {
                                    // soft fallback: try as string, else NULL (do not fail whole job)
                                    try
                                    {
                                        if (dt.Columns[c].DataType == typeof(string))
                                            row[c] = tok == null || tok.Type == JTokenType.Null ? (object)DBNull.Value : tok.ToString();
                                        else
                                            row[c] = ConvertJsonValueSoft(tok, dt.Columns[c].DataType);
                                    }
                                    catch
                                    {
                                        row[c] = DBNull.Value;
                                        AppLog.Warn("-", "Row " + rowNo + " col " + dt.Columns[c].ColumnName + ": value set to NULL (type mismatch).");
                                    }
                                }
                            }
                            dt.Rows.Add(row);
                        }

                        // 5) Bulk insert (same transaction as TRUNCATE/DELETE → all or nothing)
                        using (SqlBulkCopy bulk = new SqlBulkCopy(dst, SqlBulkCopyOptions.Default, tx))
                        {
                            bulk.DestinationTableName = table;
                            bulk.BulkCopyTimeout = timeout;
                            bulk.BatchSize = batch;
                            foreach (DataColumn col in dt.Columns)
                                bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                            bulk.WriteToServer(dt);
                            RunTrace.Progress(dt.Rows.Count);
                        }

                        tx.Commit();
                        r.Rows = dt.Rows.Count;
                    }
                    catch
                    {
                        try { tx.Rollback(); } catch { }
                        throw;
                    }
                }
            }
            r.Ok = true;
            r.Message = "Web API → " + step.DestTable + ": " + r.Rows + " row(s).";
            return r;
        }

        private static bool TableExists(SqlConnection conn, SqlTransaction tx, string normalizedTable, int timeout)
        {
            using (SqlCommand cmd = new SqlCommand("SELECT CASE WHEN OBJECT_ID(@n, N'U') IS NULL THEN 0 ELSE 1 END", conn, tx))
            {
                cmd.CommandTimeout = timeout;
                cmd.Parameters.AddWithValue("@n", normalizedTable);
                return Convert.ToInt32(cmd.ExecuteScalar()) == 1;
            }
        }

        /// <summary>True if the source table/view exists on the given connection.</summary>
        private static bool SourceTableExists(string srcConn, string sourceTable, int timeout)
        {
            if (string.IsNullOrWhiteSpace(srcConn) || string.IsNullOrWhiteSpace(sourceTable)) return false;
            string norm = NormalizeTableName(sourceTable);
            string plain = sourceTable.Replace("[", "").Replace("]", "");
            using (SqlConnection c = new SqlConnection(srcConn))
            {
                c.Open();
                if (TableExists(c, null, norm, timeout)) return true;
                if (!string.Equals(norm, plain, StringComparison.OrdinalIgnoreCase) && TableExists(c, null, plain, timeout))
                    return true;
                // also accept views
                using (SqlCommand cmd = new SqlCommand(
                    "SELECT CASE WHEN OBJECT_ID(@n, N'V') IS NULL THEN 0 ELSE 1 END", c))
                {
                    cmd.CommandTimeout = timeout;
                    cmd.Parameters.AddWithValue("@n", norm);
                    if (Convert.ToInt32(cmd.ExecuteScalar()) == 1) return true;
                }
                return false;
            }
        }

        private static void CreateTextTable(SqlConnection conn, SqlTransaction tx, string normalizedTable, List<string> cols, int timeout)
        {
            CreateTableFromJson(conn, tx, normalizedTable, cols, null, timeout);
        }

        /// <summary>Create table; infer BIGINT/INT/DECIMAL/BIT/DATETIME2/NVARCHAR from sample JSON values.</summary>
        private static void CreateTableFromJson(SqlConnection conn, SqlTransaction tx, string normalizedTable, List<string> cols, List<JObject> samples, int timeout)
        {
            EnsureSchemaExists(conn, tx, normalizedTable, timeout);
            StringBuilder sb = new StringBuilder();
            sb.Append("CREATE TABLE ").Append(normalizedTable).Append(" (");
            for (int i = 0; i < cols.Count; i++)
            {
                if (i > 0) sb.Append(", ");
                string col = cols[i];
                string sqlType = InferSqlType(col, samples);
                sb.Append('[').Append(col.Replace("]", "]]")).Append("] ").Append(sqlType).Append(" NULL");
            }
            sb.Append(")");
            using (SqlCommand cmd = new SqlCommand(sb.ToString(), conn, tx))
            {
                cmd.CommandTimeout = timeout;
                cmd.ExecuteNonQuery();
            }
        }

        private static string InferSqlType(string colName, List<JObject> samples)
        {
            if (samples == null || samples.Count == 0)
                return "NVARCHAR(MAX)";

            bool saw = false;
            bool okBool = true, okInt = true, okLong = true, okDec = true, okDate = true;
            int maxLen = 0;
            int n = 0;

            foreach (JObject o in samples)
            {
                if (o == null) continue;
                JToken tok = o[colName];
                if (tok == null || tok.Type == JTokenType.Null || tok.Type == JTokenType.Undefined)
                    continue;
                saw = true;
                n++;
                if (n > 200) break;

                if (tok.Type == JTokenType.Boolean)
                {
                    okInt = false; okLong = false; okDec = false; okDate = false;
                    continue;
                }
                if (tok.Type == JTokenType.Integer)
                {
                    okBool = false; okDate = false;
                    try
                    {
                        long lv = tok.Value<long>();
                        if (lv > int.MaxValue || lv < int.MinValue) okInt = false;
                    }
                    catch { okInt = false; okLong = false; }
                    continue;
                }
                if (tok.Type == JTokenType.Float)
                {
                    okBool = false; okInt = false; okLong = false; okDate = false;
                    continue;
                }
                if (tok.Type == JTokenType.Object || tok.Type == JTokenType.Array)
                {
                    okBool = false; okInt = false; okLong = false; okDec = false; okDate = false;
                    string js = tok.ToString(Newtonsoft.Json.Formatting.None);
                    if (js != null && js.Length > maxLen) maxLen = js.Length;
                    continue;
                }

                string sVal = tok.ToString();
                if (sVal == null) sVal = "";
                if (sVal.Length > maxLen) maxLen = sVal.Length;
                okBool = false;

                long li;
                decimal dec;
                DateTime dt;
                bool asLong = long.TryParse(sVal, NumberStyles.Integer, CultureInfo.InvariantCulture, out li);
                bool asDec = decimal.TryParse(sVal, NumberStyles.Any, CultureInfo.InvariantCulture, out dec);
                bool asDate = DateTime.TryParse(sVal, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out dt)
                    || DateTime.TryParse(sVal, CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal, out dt);

                if (!asLong) { okInt = false; okLong = false; }
                else if (li > int.MaxValue || li < int.MinValue) okInt = false;
                if (!asDec) okDec = false;
                if (!asDate) okDate = false;
            }

            if (!saw) return "NVARCHAR(MAX)";
            if (okBool) return "BIT";
            if (okInt) return "INT";
            if (okLong) return "BIGINT";
            if (okDec) return "DECIMAL(18,4)";
            if (okDate) return "DATETIME2";
            if (maxLen > 0 && maxLen <= 50) return "NVARCHAR(100)";
            if (maxLen <= 250) return "NVARCHAR(500)";
            if (maxLen <= 1000) return "NVARCHAR(2000)";
            return "NVARCHAR(MAX)";
        }

        private static object ConvertJsonValueSoft(JToken tok, Type target)
        {
            if (tok == null || tok.Type == JTokenType.Null || tok.Type == JTokenType.Undefined)
                return DBNull.Value;
            string text = tok.Type == JTokenType.String ? tok.ToString() : tok.ToString(Newtonsoft.Json.Formatting.None);
            if (string.IsNullOrWhiteSpace(text)) return DBNull.Value;
            text = text.Trim();
            try
            {
                if (target == typeof(string)) return text;
                if (target == typeof(int))
                {
                    int i;
                    if (int.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out i)) return i;
                }
                if (target == typeof(long))
                {
                    long l;
                    if (long.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out l)) return l;
                }
                if (target == typeof(short))
                {
                    short s;
                    if (short.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out s)) return s;
                }
                if (target == typeof(decimal))
                {
                    decimal d;
                    if (decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out d)) return d;
                }
                if (target == typeof(double))
                {
                    double d;
                    if (double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out d)) return d;
                }
                if (target == typeof(float))
                {
                    float f;
                    if (float.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out f)) return f;
                }
                if (target == typeof(bool))
                {
                    if (text == "1" || text.Equals("true", StringComparison.OrdinalIgnoreCase) || text.Equals("yes", StringComparison.OrdinalIgnoreCase)) return true;
                    if (text == "0" || text.Equals("false", StringComparison.OrdinalIgnoreCase) || text.Equals("no", StringComparison.OrdinalIgnoreCase)) return false;
                }
                if (target == typeof(DateTime))
                {
                    DateTime dt;
                    if (DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out dt)) return dt;
                    if (DateTime.TryParse(text, CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal, out dt)) return dt;
                }
                if (target == typeof(Guid))
                {
                    Guid g;
                    if (Guid.TryParse(text, out g)) return g;
                }
            }
            catch { }
            return DBNull.Value;
        }

        private static object ConvertJsonValue(JToken tok, Type target)
        {
            if (tok == null || tok.Type == JTokenType.Null || tok.Type == JTokenType.Undefined)
                return DBNull.Value;

            string text;
            if (tok.Type == JTokenType.Object || tok.Type == JTokenType.Array)
                text = tok.ToString(Newtonsoft.Json.Formatting.None);
            else if (tok.Type == JTokenType.Boolean)
                text = ((bool)tok) ? "true" : "false";
            else
            {
                JValue jv = tok as JValue;
                object v = jv != null ? jv.Value : null;
                text = v == null ? "" : Convert.ToString(v, CultureInfo.InvariantCulture);
            }

            if (target == typeof(string)) return text;

            text = text.Trim();
            if (text.Length == 0) return DBNull.Value;

            if (target == typeof(bool))
            {
                string l = text.ToLowerInvariant();
                if (l == "true" || l == "1" || l == "yes") return true;
                if (l == "false" || l == "0" || l == "no") return false;
                throw new FormatException("not a boolean");
            }
            if (target == typeof(DateTime))
                return DateTime.Parse(text, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
            if (target == typeof(DateTimeOffset))
                return DateTimeOffset.Parse(text, CultureInfo.InvariantCulture);
            if (target == typeof(Guid))
                return new Guid(text);
            if (target == typeof(byte[]))
                return Convert.FromBase64String(text);
            if (target == typeof(TimeSpan))
                return TimeSpan.Parse(text, CultureInfo.InvariantCulture);
            return Convert.ChangeType(text, target, CultureInfo.InvariantCulture);
        }

        private static List<JObject> FetchApiItems(JobStep step, int timeout)
        {
            List<JObject> all = new List<JObject>();
            bool paging = !string.IsNullOrWhiteSpace(step.ApiPageParam);
            int maxPages = step.ApiMaxPages > 0 ? step.ApiMaxPages : 1000;
            int page = 1;

            while (true)
            {
                string url = BuildPageUrl(step, page, paging);
                string body = HttpRequestText(step, url, timeout);
                if (string.IsNullOrWhiteSpace(body))
                    throw new Exception("API returned empty body for " + url);

                List<JObject> pageItems = ParseApiBodyToObjects(body, step.ApiJsonPath);
                int count = pageItems.Count;
                foreach (JObject o in pageItems)
                    all.Add(o);

                if (!paging) break;
                if (count == 0) break;
                if (step.ApiPageSize > 0 && count < step.ApiPageSize) break;
                if (page >= maxPages) break;
                page++;
            }
            return all;
        }

        /// <summary>JSON or XML → list of row objects. XML like &lt;caapi&gt;&lt;id&gt;… is supported.</summary>
        public static List<JObject> ParseApiBodyToObjects(string body, string pathHint)
        {
            string trim = (body ?? "").TrimStart();
            if (trim.Length == 0) return new List<JObject>();

            // Prefer JSON when it looks like JSON
            if (trim.StartsWith("{") || trim.StartsWith("["))
                return JsonBodyToObjects(body, pathHint);

            // XML / HTML-ish: try XML first
            if (trim.StartsWith("<"))
            {
                try { return XmlBodyToObjects(body, pathHint); }
                catch (Exception xex)
                {
                    string prev = trim.Length > 200 ? trim.Substring(0, 200) + "..." : trim;
                    throw new Exception("API returned XML/HTML that could not be parsed: " + xex.Message + " | Preview: " + prev);
                }
            }

            // Last resort: try JSON parse anyway
            try { return JsonBodyToObjects(body, pathHint); }
            catch (Exception jex)
            {
                string prev = trim.Length > 200 ? trim.Substring(0, 200) + "..." : trim;
                throw new Exception("API body is neither JSON nor XML: " + jex.Message + " | Preview: " + prev);
            }
        }

        private static List<JObject> JsonBodyToObjects(string json, string pathHint)
        {
            List<JObject> list = new List<JObject>();
            JToken root;
            using (JsonTextReader jr = new JsonTextReader(new StringReader(json)))
            {
                jr.DateParseHandling = DateParseHandling.None;
                root = JToken.Load(jr);
            }
            JToken arr = string.IsNullOrWhiteSpace(pathHint) ? root : root.SelectToken(pathHint.Trim());
            if (arr == null)
                throw new Exception("JSON path '" + pathHint + "' not found in the response.");
            if (arr is JArray)
            {
                foreach (JToken it in (JArray)arr)
                {
                    JObject o = it as JObject;
                    if (o == null) { o = new JObject(); o["value"] = it; }
                    list.Add(o);
                }
            }
            else if (arr is JObject)
                list.Add((JObject)arr);
            else
            {
                JObject o = new JObject();
                o["value"] = arr;
                list.Add(o);
            }
            return list;
        }

        private static List<JObject> XmlBodyToObjects(string xml, string pathHint)
        {
            XmlDocument doc = new XmlDocument();
            doc.XmlResolver = null; // no external DTD
            doc.LoadXml(xml);
            XmlElement root = doc.DocumentElement;
            if (root == null) return new List<JObject>();

            // Optional path: element name to select (e.g. "data" or "item")
            XmlNode scope = root;
            if (!string.IsNullOrWhiteSpace(pathHint))
            {
                string p = pathHint.Trim().Replace("/", "").Replace(".", "");
                XmlNode found = root.SelectSingleNode("//*[local-name()='" + p.Replace("'", "") + "']");
                if (found != null) scope = found;
            }

            List<XmlElement> recordNodes = new List<XmlElement>();
            // If scope has multiple child elements with the SAME name and those children have element kids → rows
            Dictionary<string, int> nameCount = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            List<XmlElement> childEls = new List<XmlElement>();
            foreach (XmlNode n in scope.ChildNodes)
            {
                XmlElement el = n as XmlElement;
                if (el == null) continue;
                childEls.Add(el);
                if (!nameCount.ContainsKey(el.LocalName)) nameCount[el.LocalName] = 0;
                nameCount[el.LocalName]++;
            }

            bool multiRecords = false;
            string repeatName = null;
            foreach (KeyValuePair<string, int> kv in nameCount)
            {
                if (kv.Value >= 2)
                {
                    // check first of that name has element children
                    foreach (XmlElement el in childEls)
                    {
                        if (!string.Equals(el.LocalName, kv.Key, StringComparison.OrdinalIgnoreCase)) continue;
                        if (HasElementChild(el))
                        {
                            multiRecords = true;
                            repeatName = kv.Key;
                        }
                        break;
                    }
                }
                if (multiRecords) break;
            }

            List<JObject> list = new List<JObject>();
            if (multiRecords && repeatName != null)
            {
                foreach (XmlElement el in childEls)
                {
                    if (string.Equals(el.LocalName, repeatName, StringComparison.OrdinalIgnoreCase))
                        list.Add(XmlElementToObject(el));
                }
            }
            else
            {
                // Single record: either scope itself is the row, or each leaf child is a column
                if (childEls.Count > 0 && !HasElementChild(childEls[0]))
                    list.Add(XmlElementToObject(scope as XmlElement ?? root));
                else if (childEls.Count == 1 && HasElementChild(childEls[0]))
                    list.Add(XmlElementToObject(childEls[0]));
                else
                    list.Add(XmlElementToObject(scope as XmlElement ?? root));
            }
            AppLog.Info("API", "Parsed XML → " + list.Count + " row(s).");
            return list;
        }

        private static bool HasElementChild(XmlElement el)
        {
            if (el == null) return false;
            foreach (XmlNode n in el.ChildNodes)
                if (n is XmlElement) return true;
            return false;
        }

        private static JObject XmlElementToObject(XmlElement el)
        {
            JObject o = new JObject();
            if (el == null) return o;
            // attributes
            if (el.Attributes != null)
            {
                foreach (XmlAttribute a in el.Attributes)
                    o[a.LocalName] = a.Value;
            }
            bool anyElement = false;
            foreach (XmlNode n in el.ChildNodes)
            {
                XmlElement child = n as XmlElement;
                if (child == null) continue;
                anyElement = true;
                string name = child.LocalName;
                if (HasElementChild(child))
                {
                    // nested: store as JSON string or flatten with prefix
                    o[name] = child.InnerXml;
                }
                else
                {
                    string val = child.InnerText ?? "";
                    // duplicate column names → join
                    if (o[name] != null)
                        o[name] = o[name].ToString() + "," + val;
                    else
                        o[name] = val;
                }
            }
            if (!anyElement)
            {
                o[el.LocalName] = el.InnerText ?? "";
            }
            return o;
        }

        private static string BuildPageUrl(JobStep step, int page, bool paging)
        {
            string url = step.ApiUrl.Trim();
            if (!paging) return url;
            StringBuilder sb = new StringBuilder(url);
            sb.Append(url.IndexOf('?') >= 0 ? "&" : "?");
            sb.Append(Uri.EscapeDataString(step.ApiPageParam.Trim())).Append('=').Append(page);
            if (!string.IsNullOrWhiteSpace(step.ApiPageSizeParam) && step.ApiPageSize > 0)
                sb.Append('&').Append(Uri.EscapeDataString(step.ApiPageSizeParam.Trim())).Append('=').Append(step.ApiPageSize);
            return sb.ToString();
        }

        private static string HttpRequestText(JobStep step, string url, int timeoutSec)
        {
            try
            {
                // Allow TLS 1.2 / 1.1 / 1.0 on older .NET Framework defaults
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)(3072 | 768 | 192);
            }
            catch { }

            string meth = (step.ApiMethod ?? "GET").Trim().ToUpperInvariant();
            if (meth != "POST" && meth != "PUT" && meth != "PATCH") meth = "GET";

            // Bearer: refresh from AuthUrl+user/pass every call when configured; on 401 retry once
            string bearerTok = step.ApiToken ?? "";
            bool canRefresh =
                !string.IsNullOrWhiteSpace(step.ApiAuthUrl) &&
                (step.ApiAuth == ApiAuthType.Bearer || step.ApiAuth == ApiAuthType.None) &&
                (!string.IsNullOrWhiteSpace(step.ApiUser) || !string.IsNullOrWhiteSpace(step.ApiPassword));
            if (canRefresh)
            {
                try
                {
                    string got = TryFetchApiToken(step.ApiAuthUrl.Trim(), step.ApiUser, step.ApiPassword, step.ApiIgnoreCert, timeoutSec);
                    if (!string.IsNullOrWhiteSpace(got))
                    {
                        bearerTok = got;
                        AppLog.Info("API", "Token refreshed from Auth URL.");
                    }
                }
                catch (Exception exTok)
                {
                    AppLog.Warn("API", "AuthUrl token fetch failed: " + exTok.Message);
                }
            }

            string contentType = "application/json";
            // parse custom headers once
            System.Collections.Generic.List<string> extraHeaderLines = new System.Collections.Generic.List<string>();
            if (!string.IsNullOrWhiteSpace(step.ApiHeaders))
            {
                using (StringReader hr = new StringReader(step.ApiHeaders))
                {
                    string line;
                    while ((line = hr.ReadLine()) != null)
                    {
                        int idx = line.IndexOf(':');
                        if (idx <= 0) continue;
                        string name = line.Substring(0, idx).Trim();
                        string value = line.Substring(idx + 1).Trim();
                        if (name.Length == 0) continue;
                        string ln = name.ToLowerInvariant();
                        if (ln == "content-type") contentType = value;
                        else extraHeaderLines.Add(line);
                    }
                }
            }

            int attempt = 0;
            while (true)
            {
                attempt++;
                HttpWebRequest req2 = (HttpWebRequest)WebRequest.Create(url);
                req2.Method = meth;
                req2.Timeout = timeoutSec * 1000;
                req2.ReadWriteTimeout = timeoutSec * 1000;
                req2.Accept = "application/json";
                req2.UserAgent = "SyncDB/1.0";
                req2.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
                if (step.ApiIgnoreCert)
                    req2.ServerCertificateValidationCallback = delegate { return true; };

                if (step.ApiAuth == ApiAuthType.Bearer && !string.IsNullOrWhiteSpace(bearerTok))
                    req2.Headers["Authorization"] = "Bearer " + bearerTok.Trim();
                else if (step.ApiAuth == ApiAuthType.Basic)
                    req2.Headers["Authorization"] = "Basic " + Convert.ToBase64String(
                        Encoding.UTF8.GetBytes((step.ApiUser ?? "") + ":" + (step.ApiPassword ?? "")));
                else if (step.ApiAuth == ApiAuthType.ApiKey && !string.IsNullOrWhiteSpace(step.ApiToken))
                {
                    string hk = string.IsNullOrWhiteSpace(step.ApiKeyHeader) ? "ApiKey" : step.ApiKeyHeader.Trim();
                    req2.Headers[hk] = step.ApiToken.Trim();
                }

                foreach (string line in extraHeaderLines)
                {
                    int idx = line.IndexOf(':');
                    string name = line.Substring(0, idx).Trim();
                    string value = line.Substring(idx + 1).Trim();
                    string ln = name.ToLowerInvariant();
                    if (ln == "accept") req2.Accept = value;
                    else if (ln == "user-agent") req2.UserAgent = value;
                    else if (ln == "host" || ln == "content-length" || ln == "connection" || ln == "authorization") continue;
                    else
                        try { req2.Headers[name] = value; } catch { }
                }

                if (req2.Method == "POST" || req2.Method == "PUT" || req2.Method == "PATCH")
                {
                    byte[] bodyBytes = Encoding.UTF8.GetBytes(step.ApiBody ?? "");
                    req2.ContentType = contentType;
                    req2.ContentLength = bodyBytes.Length;
                    using (Stream rs = req2.GetRequestStream())
                        rs.Write(bodyBytes, 0, bodyBytes.Length);
                }

                try
                {
                    using (HttpWebResponse resp = (HttpWebResponse)req2.GetResponse())
                    using (Stream st = resp.GetResponseStream())
                    using (StreamReader sr = new StreamReader(st, Encoding.UTF8))
                        return sr.ReadToEnd();
                }
                catch (WebException wex)
                {
                    HttpWebResponse er = wex.Response as HttpWebResponse;
                    int code = er != null ? (int)er.StatusCode : 0;
                    // Token expired → refresh once and retry
                    if (code == 401 && attempt < 2 && canRefresh)
                    {
                        try
                        {
                            string got = TryFetchApiToken(step.ApiAuthUrl.Trim(), step.ApiUser, step.ApiPassword, step.ApiIgnoreCert, timeoutSec);
                            if (!string.IsNullOrWhiteSpace(got))
                            {
                                bearerTok = got;
                                AppLog.Info("API", "HTTP 401 — token refreshed, retrying once.");
                                continue;
                            }
                        }
                        catch (Exception exTok)
                        {
                            AppLog.Warn("API", "Token refresh after 401 failed: " + exTok.Message);
                        }
                    }
                    string detail = "";
                    if (er != null)
                    {
                        try
                        {
                            using (Stream es = er.GetResponseStream())
                            using (StreamReader esr = new StreamReader(es, Encoding.UTF8))
                            {
                                string body = esr.ReadToEnd();
                                if (body.Length > 300) body = body.Substring(0, 300) + "...";
                                detail = " HTTP " + code + " " + er.StatusDescription + " — " + body;
                            }
                        }
                        catch { detail = " HTTP " + code + " " + er.StatusDescription; }
                    }
                    throw new Exception("API request failed (" + meth + " " + url + "): " + wex.Message + detail, wex);
                }
            }
        }

        private static RunResult Finish(RunResult res, Stopwatch sw)
        {
            sw.Stop();
            res.ElapsedMs = sw.ElapsedMilliseconds;
            return res;
        }
    }
}
