using System;
using System.Linq;
using System.Threading;

namespace SyncDB
{
    public class JobScheduler : IDisposable
    {
        private readonly object _gate = new object();
        private Timer _timer;
        private Timer _rtTimer;
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, byte> _rtBusy =
            new System.Collections.Concurrent.ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);
        // When the next async check of each job is due. Build 42v: this used to live on the SyncJob
        // object (LastRunUtc / NextRunUtc), which is reloaded from config.json - the Windows service
        // rebuilds every job object in Reload() once a minute and the window overwrites LastRunUtc from
        // disk every 2 seconds. A run that moved 0 rows is never saved, so the reload put a stale value
        // back and the job became due again at once: the "every 30 seconds" setting was effectively
        // ignored and changes propagated continuously. The schedule now lives in the scheduler itself,
        // where no config reload can touch it.
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, DateTime> _rtNext =
            new System.Collections.Concurrent.ConcurrentDictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, int> _rtSeen =
            new System.Collections.Concurrent.ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        // When each job was last actually checked, so the log can state the real gap between checks.
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, DateTime> _rtLast =
            new System.Collections.Concurrent.ConcurrentDictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        // Heartbeat: one log line a minute per async job, so the real rhythm is visible without
        // reading the job history (which only records runs that moved rows).
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, int> _rtChecks =
            new System.Collections.Concurrent.ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, DateTime> _rtHeartbeat =
            new System.Collections.Concurrent.ConcurrentDictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        // Only ONE process may schedule jobs for a data folder. Several SyncDB.exe instances (the window
        // plus the Windows service, or copies left over from earlier starts) each ran their own async
        // timer, so a job set to "every 50 seconds" was checked several times a second between them and
        // every change looked instant. The first process to take this mutex owns scheduling.
        private Thread _ownThread;
        private ManualResetEvent _ownStop;
        private ManualResetEvent _ownFirstTry;
        private volatile bool _ownsScheduling;
        private bool _warnedNotOwner;
        private AppConfig _config;
        private int _executing;
        private bool _warnedOff;
        private readonly System.Collections.Generic.Dictionary<string, bool> _warnedDisabled =
            new System.Collections.Generic.Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

        public event Action<SyncJob, RunResult> JobFinished;
        public event Action<string> TickStatus;

        /// <summary>What the job history writes in the Source column: "schedule" in the app, "service" in the Windows service.</summary>
        public static string RunSource = "schedule";

        public void Start(AppConfig config)
        {
            lock (_gate)
            {
                _config = config;
                StopTimer_NoLock();
                int sec = config.SchedulerPollSeconds > 0 ? config.SchedulerPollSeconds : 30;
                _timer = new Timer(OnTick, null, 2000, sec * 1000);
                _rtTimer = new Timer(OnRealtimeTick, null, 500, 500);  // finer resolution for second-level async checks
                _warnedOff = false;
                _warnedDisabled.Clear();
                TakeOwnership();
                int armed = 0, offJobs = 0;
                if (config.Jobs != null)
                {
                    foreach (SyncJob j in config.Jobs)
                    {
                        if (j == null || j.Schedule == ScheduleKind.Manual) continue;
                        if (j.Enabled) armed++;
                        else offJobs++;
                    }
                }
                // Starting the scheduler must also arm automatic execution. Older callers could
                // start the timers while this flag was still false, making every callback return.
                config.SchedulerEnabled = true;
                AppLog.Info("-", "Scheduler started. Poll=" + sec + "s | scheduled jobs armed: " + armed +
                                 (offJobs > 0 ? " | with a schedule but DISABLED: " + offJobs : "") +
                                 " | scheduling is " + (config.SchedulerEnabled ? "ON" : "OFF"));
            }
        }

        public void UpdateConfig(AppConfig config)
        {
            lock (_gate) { _config = config; }
            try { RuntimeSettings.Apply(config); }
            catch { }
        }

        /// <summary>
        /// Re-arms one Async job after its schedule was edited. The job editor updates
        /// NextRunUtc, but the scheduler keeps its own due time so config reloads cannot
        /// make a zero-row run immediately due. Reset both values explicitly after Save.
        /// </summary>
        public void RearmAsync(SyncJob job)
        {
            if (job == null || job.Schedule != ScheduleKind.RealtimeAsync) return;
            int intervalSec = job.AsyncUseSeconds
                ? (job.IntervalValue < 1 ? 1 : job.IntervalValue)
                : ((_config != null && _config.SchedulerPollSeconds > 0) ? _config.SchedulerPollSeconds : 30);
            DateTime due = DateTime.UtcNow.AddSeconds(intervalSec);
            string key = job.Id ?? job.Name ?? "";
            if (key.Length == 0) return;
            _rtSeen[key] = intervalSec;
            _rtNext[key] = due;
            job.NextRunUtc = due;
            WriteAsyncStatus(job.Name, intervalSec, DateTime.MinValue, due, -1);
            AppLog.Info(job.Name, "Async timer re-armed after save: first check in " + intervalSec + " second(s).");
        }

        public void Stop()
        {
            lock (_gate)
            {
                StopTimer_NoLock();
                _rtNext.Clear();
                _rtSeen.Clear();
                _rtLast.Clear();
                _rtChecks.Clear();
                _rtHeartbeat.Clear();
                ReleaseOwnership();
            }
            AppLog.Info("-", "Scheduler stopped.");
        }

        private void StopTimer_NoLock()
        {
            if (_timer != null)
            {
                _timer.Dispose();
                _timer = null;
            }
            if (_rtTimer != null)
            {
                _rtTimer.Dispose();
                _rtTimer = null;
            }
        }

        private void OnTick(object state)
        {
            if (Interlocked.CompareExchange(ref _executing, 1, 0) != 0) return;
            try
            {
                AppConfig cfg;
                lock (_gate) cfg = _config;
                if (cfg == null || !cfg.SchedulerEnabled)
                {
                    // Used to return in silence, so a wrong flag looked exactly like a broken scheduler.
                    if (!_warnedOff)
                    {
                        _warnedOff = true;
                        AppLog.Warn("-", "Scheduler tick: scheduling is OFF - no job runs automatically. " +
                                         "Press \"Start Service\" (or start the Windows service).");
                    }
                    if (TickStatus != null) TickStatus("Scheduler is OFF - automatic runs are disabled");
                    return;
                }
                _warnedOff = false;
                if (!_ownsScheduling)
                {
                    if (TickStatus != null) TickStatus("Another SyncDB process owns the scheduler - no job runs here");
                    return;
                }

                DateTime now = DateTime.UtcNow;
                SyncJob soonest = null;

                // Snapshot: the user can delete a job from the UI while this loop runs, and iterating
                // the live list would throw "Collection was modified" and skip the remaining jobs.
                SyncJob[] jobs;
                try { jobs = cfg.Jobs != null ? cfg.Jobs.ToArray() : new SyncJob[0]; }
                catch { return; }

                foreach (SyncJob job in jobs)
                {
                    if (job == null) continue;
                    if (job.Schedule == ScheduleKind.Manual) continue;
                    if (job.Schedule == ScheduleKind.RealtimeAsync) continue; // always owned by the seconds timer
                    if (job.Paused) continue;
                    // the job may have been deleted since the snapshot was taken
                    if (cfg.Jobs == null || !cfg.Jobs.Contains(job)) continue;
                    if (!job.Enabled)
                    {
                        // A job with a schedule that is switched off is the most common reason for
                        // "automatic does not work". Say it once per job instead of skipping silently.
                        string key = job.Id ?? job.Name ?? "";
                        if (!_warnedDisabled.ContainsKey(key))
                        {
                            _warnedDisabled[key] = true;
                            AppLog.Warn(job.Name, "Job has a schedule (" + job.Schedule +
                                ") but is DISABLED - it will not run automatically. Tick it in the jobs list.");
                        }
                        continue;
                    }

                    if (job.NextRunUtc == null)
                        job.NextRunUtc = ComputeNextRunUtc(job, now);

                    if (job.NextRunUtc != null && job.NextRunUtc.Value <= now)
                    {
                        AppLog.Info(job.Name, "Scheduled run triggered.");
                        RunResult r = Engine.ExecuteJob(job, cfg, RunSource);
                        job.LastRunUtc = DateTime.UtcNow;
                        job.LastRows = r.Rows;
                        job.LastStatus = (r.Ok ? "OK" : "FAIL") + " — " + r.Message + " (" + JobHistory.FormatSeconds(r.ElapsedMs) + ")";
                        job.LastRunSource = RunSource;   // "schedule" or "service"
                        try { job.LastErrorDetail = JobHistory.BuildDetail(job, r); } catch { }
                        job.NextRunUtc = ComputeNextRunUtc(job, DateTime.UtcNow.AddSeconds(1));
                        try { cfg.Save(); } catch { }
                        Audit.Write("JOB_SCHEDULED", job.Name + " | " + (r.Ok ? "OK" : "FAIL") + " | rows=" + r.Rows + " | " + JobHistory.FormatSeconds(r.ElapsedMs));
                        if (JobFinished != null) JobFinished(job, r);
                    }

                    if (job.NextRunUtc != null &&
                        (soonest == null || job.NextRunUtc.Value < soonest.NextRunUtc.Value)) soonest = job;
                }

                if (TickStatus != null)
                {
                    string msg = "Scheduler " + DateTime.Now.ToString("HH:mm:ss");
                    if (soonest != null && soonest.NextRunUtc != null)
                        msg += " - next: " + soonest.Name + " at " +
                               soonest.NextRunUtc.Value.ToLocalTime().ToString("yyyy-MM-dd HH:mm");
                    else
                        msg += " - no scheduled job is armed (enable a job and give it a schedule)";
                    TickStatus(msg);
                }
            }
            catch (Exception ex)
            {
                AppLog.Error("-", "Scheduler tick error: " + ex.Message);
            }
            finally
            {
                Interlocked.Exchange(ref _executing, 0);
            }
        }

        /// <summary>
        /// Scheduling ownership for the data folder, held by a dedicated thread.
        ///
        /// A named Mutex is used because Windows hands it over automatically when its owner dies
        /// (a semaphore would stay at zero forever if the owning process was killed while another copy
        /// still had it open). A mutex belongs to the thread that took it, so one background thread takes
        /// it, keeps it for as long as this scheduler runs and releases it on Stop. While another process
        /// owns it, this thread retries every 3 seconds - so the Windows service takes over by itself as
        /// soon as a window lets go, and the other way round.
        /// </summary>
        private void TakeOwnership()
        {
            if (_ownThread != null && _ownThread.IsAlive) return;
            _ownStop = new ManualResetEvent(false);
            _ownFirstTry = new ManualResetEvent(false);
            _ownThread = new Thread(OwnershipLoop);
            _ownThread.IsBackground = true;
            _ownThread.Name = "SyncDB.SchedulerOwner";
            _ownThread.Start();
            try { _ownFirstTry.WaitOne(1500); } catch { }      // know the answer before the first tick
        }

        private static Mutex OpenOwnershipMutex()
        {
            string key = (AppConfig.DataDir ?? "").ToLowerInvariant();
            int h = 0;
            foreach (char c in key) h = unchecked(h * 31 + c);
            string name = "Global\\SyncDB.Scheduler." + h.ToString("X8");
            bool createdNew;
            try
            {
                // Open to everyone: the service (LocalSystem) and the window (the user) must both be
                // able to open the same object, whoever creates it first.
                System.Security.AccessControl.MutexSecurity sec = new System.Security.AccessControl.MutexSecurity();
                sec.AddAccessRule(new System.Security.AccessControl.MutexAccessRule(
                    new System.Security.Principal.SecurityIdentifier(System.Security.Principal.WellKnownSidType.WorldSid, null),
                    System.Security.AccessControl.MutexRights.FullControl,
                    System.Security.AccessControl.AccessControlType.Allow));
                return new Mutex(false, name, out createdNew, sec);
            }
            catch (UnauthorizedAccessException) { throw; }
            catch
            {
                return new Mutex(false, name, out createdNew);
            }
        }

        private void OwnershipLoop()
        {
            Mutex m = null;
            bool owned = false;
            bool failOpen = false;          // could not even create/open the mutex for a technical reason
            try
            {
                while (true)
                {
                    if (!owned && !failOpen)
                    {
                        try
                        {
                            if (m == null) m = OpenOwnershipMutex();
                            try { owned = m.WaitOne(0); }
                            catch (AbandonedMutexException) { owned = true; }   // previous owner died
                        }
                        catch (UnauthorizedAccessException)
                        {
                            owned = false;      // exists under another account: somebody else owns it
                            m = null;
                        }
                        catch (Exception ex)
                        {
                            // never block scheduling because of a locking problem
                            failOpen = true;
                            AppLog.Warn("-", "Scheduler ownership check skipped: " + ex.Message);
                        }

                        bool now = owned || failOpen;
                        if (now && !_ownsScheduling)
                        {
                            _ownsScheduling = true;
                            _warnedNotOwner = false;
                            AppLog.Info("-", "Scheduler ownership taken by pid " + CurrentPid() + " for " + AppConfig.DataDir);
                        }
                        else if (!now && !_warnedNotOwner)
                        {
                            _warnedNotOwner = true;
                            AppLog.Warn("-", "Another SyncDB process is already running the scheduler for " +
                                             AppConfig.DataDir + " - this process (pid " + CurrentPid() +
                                             ") will not execute jobs until that one stops.");
                        }
                    }
                    try { _ownFirstTry.Set(); } catch { }

                    // owner: sleep until Stop(); otherwise look again in 3 seconds
                    if (_ownStop.WaitOne((owned || failOpen) ? Timeout.Infinite : 3000)) break;
                }
            }
            catch { }
            finally
            {
                _ownsScheduling = false;
                try { if (m != null && owned) m.ReleaseMutex(); } catch { }
                try { if (m != null) m.Close(); } catch { }
                try { _ownFirstTry.Set(); } catch { }
            }
        }

        private void ReleaseOwnership()
        {
            try
            {
                if (_ownStop != null) _ownStop.Set();
                if (_ownThread != null && _ownThread.IsAlive) _ownThread.Join(3000);
            }
            catch { }
            _ownThread = null;
            _ownsScheduling = false;
            _warnedNotOwner = false;
        }

        /// <summary>File the window reads to show "next check in N s" - whoever owns the scheduler writes it.</summary>
        public static string AsyncStatusPath
        {
            get { return System.IO.Path.Combine(AppConfig.DataDir, "async_status.txt"); }
        }

        private static readonly object AsyncStatusLock = new object();

        /// <summary>One line: build | pid | kind | job | interval | last check (UTC ticks) | next check (UTC ticks) | rows.</summary>
        private static void WriteAsyncStatus(string jobName, int intervalSec, DateTime lastUtc, DateTime nextUtc, long rows)
        {
            try
            {
                string line = AppBuild.Name + "|" + CurrentPid() + "|" +
                              (Environment.UserInteractive ? "window" : "service") + "|" +
                              (jobName ?? "").Replace("|", "/") + "|" + intervalSec + "|" +
                              (lastUtc == DateTime.MinValue ? 0 : lastUtc.Ticks) + "|" + nextUtc.Ticks + "|" + rows;
                lock (AsyncStatusLock)
                    System.IO.File.WriteAllText(AsyncStatusPath, line, System.Text.Encoding.UTF8);
            }
            catch { }
        }

        private static int CurrentPid()
        {
            try { return System.Diagnostics.Process.GetCurrentProcess().Id; }
            catch { return 0; }
        }

        /// <summary>One line a minute per async job: how often it really checked and the average gap.</summary>
        private void Heartbeat(string jkey, SyncJob job, int intervalSec, DateTime now)
        {
            DateTime since;
            if (!_rtHeartbeat.TryGetValue(jkey, out since)) { _rtHeartbeat[jkey] = now; return; }
            if ((now - since).TotalSeconds < 60) return;
            int checks;
            _rtChecks.TryGetValue(jkey, out checks);
            double span = (now - since).TotalSeconds;
            _rtHeartbeat[jkey] = now;
            _rtChecks[jkey] = 0;
            AppLog.Info(job.Name, "Async heartbeat (pid " + CurrentPid() + "): " + checks + " check(s) in " +
                                  span.ToString("0") + "s | configured interval " + intervalSec + "s | average gap " +
                                  (checks > 0 ? (span / checks).ToString("0.0") : "-") + "s");
        }

        // Async (realtime) mode: each RealtimeAsync job runs on its own thread-pool worker every
        // IntervalValue seconds, independent of the normal poll, so a slow scheduled job never delays
        // change propagation. The delta engine carries INSERT/UPDATE/DELETE since the last run.
        private void OnRealtimeTick(object state)
        {
            AppConfig cfg;
            lock (_gate) cfg = _config;
            if (cfg == null || !cfg.SchedulerEnabled || cfg.Jobs == null) return;
            if (!_ownsScheduling) return;        // another SyncDB process owns the scheduler (logged once)
            SyncJob[] jobs;
            try { jobs = cfg.Jobs.ToArray(); } catch { return; }
            DateTime now = DateTime.UtcNow;
            foreach (SyncJob job in jobs)
            {
                if (job == null || !job.Enabled || job.Paused || job.Schedule != ScheduleKind.RealtimeAsync) continue;
                // The "Every N second(s) check" tick decides the rhythm. Unticked, the job follows the
                // normal scheduler poll instead.
                int intervalSec = job.AsyncUseSeconds
                    ? (job.IntervalValue < 1 ? 1 : job.IntervalValue)
                    : (cfg.SchedulerPollSeconds > 0 ? cfg.SchedulerPollSeconds : 30);

                string jkey = job.Id ?? job.Name ?? "";
                int seen;
                if (!_rtSeen.TryGetValue(jkey, out seen))
                {
                    _rtSeen[jkey] = intervalSec;
                    AppLog.Info(job.Name, "Async armed - checks every " + intervalSec + " second(s) for INSERT / UPDATE / DELETE.");
                }
                else if (seen != intervalSec)
                {
                    _rtSeen[jkey] = intervalSec;
                    AppLog.Info(job.Name, "Async interval changed to " + intervalSec + " second(s).");
                    DateTime dummy;
                    _rtNext.TryRemove(jkey, out dummy);     // re-arm with the new interval
                }

                DateTime due;
                if (!_rtNext.TryGetValue(jkey, out due))
                {
                    // First time this process sees the job: wait a full interval, never fire at once.
                    due = now.AddSeconds(intervalSec);
                    _rtNext[jkey] = due;
                    job.NextRunUtc = due;
                    WriteAsyncStatus(job.Name, intervalSec, DateTime.MinValue, due, -1);
                    continue;
                }
                // A shortened interval must take effect without waiting out the old one.
                if (due > now.AddSeconds(intervalSec))
                {
                    due = now.AddSeconds(intervalSec);
                    _rtNext[jkey] = due;
                }
                if (now < due)
                {
                    job.NextRunUtc = due;                   // for the UI only
                    continue;
                }

                // Optional time window / weekdays restriction
                if (!IsWithinAsyncWindow(job, now))
                {
                    _rtNext[jkey] = now.AddSeconds(intervalSec);
                    job.NextRunUtc = _rtNext[jkey];
                    continue;
                }

                // Reserve the next slot BEFORE starting the work so a fast re-tick cannot fire again
                _rtNext[jkey] = now.AddSeconds(intervalSec);
                job.NextRunUtc = _rtNext[jkey];

                double gap = 0;
                DateTime prev;
                if (_rtLast.TryGetValue(jkey, out prev)) gap = (now - prev).TotalSeconds;
                _rtLast[jkey] = now;
                int cc;
                _rtChecks.TryGetValue(jkey, out cc);
                _rtChecks[jkey] = cc + 1;
                Heartbeat(jkey, job, intervalSec, now);
                string key = job.Id ?? job.Name ?? "";
                if (!_rtBusy.TryAdd(key, 0)) continue;   // previous async pass still running
                SyncJob j = job;
                int jobIntervalSec = intervalSec;        // own copy: the loop variable changes per job
                string jobKey = jkey;
                double gapSec = gap;
                ThreadPool.QueueUserWorkItem(_ =>
                {
                    try
                    {
                        Engine.AsyncNote = "every " + jobIntervalSec + " s  |  " +
                            (gapSec > 0 ? "previous check " + gapSec.ToString("0.0") + " s ago" : "first check since this program started");
                        RunResult r;
                        try { r = Engine.ExecuteJob(j, cfg, "async"); }
                        finally { Engine.AsyncNote = null; }
                        j.LastRunUtc = DateTime.UtcNow;
                        // Count the interval from the END of the run, in the scheduler's own state.
                        _rtNext[jobKey] = j.LastRunUtc.Value.AddSeconds(jobIntervalSec);
                        j.NextRunUtc = _rtNext[jobKey];
                        WriteAsyncStatus(j.Name, jobIntervalSec, j.LastRunUtc.Value, _rtNext[jobKey], r.Rows);
                        j.LastRows = r.Rows;
                        j.LastStatus = (r.Ok ? "OK" : "FAIL") + " — " + r.Message + " (" + JobHistory.FormatSeconds(r.ElapsedMs) + ")";
                        j.LastRunSource = "async";
                        if (!r.Ok) { try { j.LastErrorDetail = JobHistory.BuildDetail(j, r); } catch { } }
                        // Persist every pass, including a successful zero-row pass. Delta engines
                        // advance CT/CDC/watermark state even when no destination row was written;
                        // skipping Save() made a service reload an old watermark every minute.
                        try { cfg.Save(); }
                        catch (Exception saveEx) { AppLog.Warn(j.Name, "Async state save failed: " + saveEx.Message); }
                        // NextRunUtc was already reserved before this run.
                        // Only extend it if the run itself took longer than the interval.

                        if (r.Rows > 0 || !r.Ok)
                        {
                            Audit.Write("JOB_ASYNC", j.Name + " | " + (r.Ok ? "OK" : "FAIL") + " | rows=" + r.Rows);
                            AppLog.Info(j.Name, "Async check: rows=" + r.Rows + " | interval=" + jobIntervalSec +
                                                "s | " + (gapSec > 0 ? gapSec.ToString("0.0") + "s since the previous check" : "first check"));
                            if (JobFinished != null) JobFinished(j, r);
                        }
                    }
                    catch (Exception ex)
                    {
                        AppLog.Error(j.Name, "Async run error: " + ex.Message);
                        _rtNext[jobKey] = DateTime.UtcNow.AddSeconds(Math.Max(10, jobIntervalSec));
                        j.NextRunUtc = _rtNext[jobKey];
                    }
                    finally { byte b; _rtBusy.TryRemove(key, out b); }
                });
            }
        }

        /// <summary>For RealtimeAsync: true if current local time is allowed by the job's weekdays and daily time window (if configured).</summary>
        private static bool IsWithinAsyncWindow(SyncJob job, DateTime utcNow)
        {
            DateTime local = utcNow.ToLocalTime();

            // Day restriction only when the user explicitly checked it
            if (job.AsyncRestrictDays && job.WeekDaysMask != 0)
            {
                int bit = 1 << (int)local.DayOfWeek;
                if ((job.WeekDaysMask & bit) == 0) return false;
            }

            // Time-window restriction only when the user explicitly checked it
            if (job.AsyncRestrictTime)
            {
                int startMin = job.DailyHour * 60 + job.DailyMinute;
                int endMin = job.EndHour * 60 + job.EndMinute;
                int nowMin = local.Hour * 60 + local.Minute;
                if (startMin <= endMin)
                {
                    if (nowMin < startMin || nowMin > endMin) return false;
                }
                else
                {
                    if (nowMin < startMin && nowMin > endMin) return false;
                }
            }
            return true;
        }

        public static DateTime? ComputeNextRunUtc(SyncJob job, DateTime fromUtc)
        {
            DateTime localFrom = fromUtc.ToLocalTime();
            int hour = Clamp(job.DailyHour, 0, 23);
            int minute = Clamp(job.DailyMinute, 0, 59);
            int endH = Clamp(job.EndHour, 0, 23);
            int endM = Clamp(job.EndMinute, 0, 59);
            switch (job.Schedule)
            {
                case ScheduleKind.RealtimeAsync:
                    return fromUtc.AddSeconds(job.IntervalValue < 1 ? 1 : job.IntervalValue);
                case ScheduleKind.EveryNMinutes:
                    return fromUtc.AddMinutes(job.IntervalValue < 1 ? 1 : job.IntervalValue);
                case ScheduleKind.EveryNHours:
                    return fromUtc.AddHours(job.IntervalValue < 1 ? 1 : job.IntervalValue);
                case ScheduleKind.Daily:
                    {
                        int everyDays = job.IntervalValue < 1 ? 1 : job.IntervalValue;
                        DateTime next = NextInDay(localFrom, hour, minute, endH, endM, job.DailyFreq, job.SubIntervalHours);
                        if (next == DateTime.MinValue)
                        {
                            // move to next period day
                            DateTime day = localFrom.Date.AddDays(everyDays);
                            next = NextInDay(day, hour, minute, endH, endM, job.DailyFreq, job.SubIntervalHours);
                            if (next == DateTime.MinValue)
                                next = new DateTime(day.Year, day.Month, day.Day, hour, minute, 0);
                        }
                        // if everyDays>1 and we have last run, jump full periods
                        if (everyDays > 1 && job.LastRunUtc != null)
                        {
                            DateTime last = job.LastRunUtc.Value.ToLocalTime().Date;
                            DateTime minDay = last.AddDays(everyDays);
                            while (next.Date < minDay)
                            {
                                DateTime d = next.Date.AddDays(1);
                                DateTime n2 = NextInDay(d, hour, minute, endH, endM, job.DailyFreq, job.SubIntervalHours);
                                next = n2 != DateTime.MinValue ? n2 : new DateTime(d.Year, d.Month, d.Day, hour, minute, 0);
                            }
                        }
                        return next.ToUniversalTime();
                    }
                case ScheduleKind.Weekly:
                    {
                        int mask = job.EffectiveWeekDaysMask();
                        if (mask == 0) mask = 1 << 1;
                        int everyWeeks = job.IntervalValue < 1 ? 1 : job.IntervalValue;
                        // search up to 14 days for a matching weekday with a free slot
                        for (int i = 0; i < 14; i++)
                        {
                            DateTime day = localFrom.Date.AddDays(i);
                            int dow = (int)day.DayOfWeek;
                            if ((mask & (1 << dow)) == 0) continue;
                            DateTime probe = (i == 0) ? localFrom : day;
                            DateTime next = NextInDay(probe, hour, minute, endH, endM, job.DailyFreq, job.SubIntervalHours);
                            if (next == DateTime.MinValue) continue;
                            if (everyWeeks > 1 && job.LastRunUtc != null)
                            {
                                DateTime last = job.LastRunUtc.Value.ToLocalTime();
                                if (next < last.AddDays(everyWeeks * 7 - 6)) continue;
                            }
                            return next.ToUniversalTime();
                        }
                        DateTime fallback = localFrom.Date.AddDays(7);
                        return new DateTime(fallback.Year, fallback.Month, fallback.Day, hour, minute, 0).ToUniversalTime();
                    }
                case ScheduleKind.Monthly:
                    {
                        int everyMonths = job.IntervalValue < 1 ? 1 : job.IntervalValue;
                        DateTime candidate;
                        if (job.MonthlyMode == MonthlyModeKind.Relative)
                        {
                            candidate = MakeMonthlyRelative(localFrom.Year, localFrom.Month,
                                job.MonthlyRelativeOrdinal, job.MonthlyRelativeWeekday, hour, minute);
                            if (candidate.Date == localFrom.Date || candidate > localFrom)
                            {
                                DateTime n = NextInDay(candidate.Date == localFrom.Date ? localFrom : candidate.Date,
                                    hour, minute, endH, endM, job.DailyFreq, job.SubIntervalHours);
                                if (n != DateTime.MinValue && n.Date == candidate.Date)
                                    return n.ToUniversalTime();
                            }
                            // advance months
                            int y = localFrom.Year, mo = localFrom.Month;
                            for (int guard = 0; guard < 48; guard++)
                            {
                                mo += everyMonths;
                                while (mo > 12) { mo -= 12; y++; }
                                candidate = MakeMonthlyRelative(y, mo, job.MonthlyRelativeOrdinal, job.MonthlyRelativeWeekday, hour, minute);
                                if (candidate > localFrom) return candidate.ToUniversalTime();
                            }
                            return candidate.ToUniversalTime();
                        }
                        else
                        {
                            int day = Clamp(job.MonthlyDay, 1, 31);
                            candidate = MakeMonthly(localFrom.Year, localFrom.Month, day, hour, minute);
                            if (candidate.Date == localFrom.Date || candidate > localFrom)
                            {
                                DateTime n = NextInDay(localFrom.Date == candidate.Date ? localFrom : candidate.Date, hour, minute, endH, endM, job.DailyFreq, job.SubIntervalHours);
                                if (n != DateTime.MinValue && n.Day == candidate.Day)
                                    return n.ToUniversalTime();
                            }
                            if (candidate <= localFrom)
                            {
                                int y = localFrom.Year, mo = localFrom.Month + everyMonths;
                                while (mo > 12) { mo -= 12; y++; }
                                candidate = MakeMonthly(y, mo, day, hour, minute);
                            }
                            if (everyMonths > 1 && job.LastRunUtc != null)
                            {
                                DateTime lastLocal = job.LastRunUtc.Value.ToLocalTime();
                                int y = lastLocal.Year, mo = lastLocal.Month + everyMonths;
                                while (mo > 12) { mo -= 12; y++; }
                                DateTime fromLast = MakeMonthly(y, mo, day, hour, minute);
                                if (fromLast > candidate) candidate = fromLast;
                                while (candidate <= localFrom)
                                {
                                    mo += everyMonths;
                                    while (mo > 12) { mo -= 12; y++; }
                                    candidate = MakeMonthly(y, mo, day, hour, minute);
                                }
                            }
                            return candidate.ToUniversalTime();
                        }
                    }
                default:
                    return null;
            }
        }

        /// <summary>Next run time on the same calendar day as from (or MinValue if none left today).</summary>
        private static DateTime NextInDay(DateTime from, int startH, int startM, int endH, int endM,
            DailyFreqKind kind, int everyHours)
        {
            DateTime start = new DateTime(from.Year, from.Month, from.Day, startH, startM, 0);
            if (kind != DailyFreqKind.EveryNHours || everyHours < 1)
            {
                return start > from ? start : DateTime.MinValue;
            }
            DateTime end = new DateTime(from.Year, from.Month, from.Day, endH, endM, 0);
            if (end < start) end = start; // safety
            DateTime slot = start;
            while (slot <= end)
            {
                if (slot > from) return slot;
                slot = slot.AddHours(everyHours < 1 ? 1 : everyHours);
            }
            return DateTime.MinValue;
        }

        private static DateTime MakeMonthly(int year, int month, int day, int hour, int minute)
        {
            int last = DateTime.DaysInMonth(year, month);
            if (day > last) day = last;
            return new DateTime(year, month, day, hour, minute, 0);
        }

        /// <summary>ordinal: 1=first..4=fourth, 5=last. weekday: 0=Sun..6=Sat.</summary>
        private static DateTime MakeMonthlyRelative(int year, int month, int ordinal, int weekday, int hour, int minute)
        {
            if (ordinal < 1) ordinal = 1;
            if (ordinal > 5) ordinal = 5;
            if (weekday < 0 || weekday > 6) weekday = 1;
            int lastDay = DateTime.DaysInMonth(year, month);
            if (ordinal == 5)
            {
                // last weekday in month
                DateTime d = new DateTime(year, month, lastDay, hour, minute, 0);
                while ((int)d.DayOfWeek != weekday) d = d.AddDays(-1);
                return d;
            }
            // Nth weekday
            DateTime first = new DateTime(year, month, 1, hour, minute, 0);
            int add = (weekday - (int)first.DayOfWeek + 7) % 7;
            DateTime nth = first.AddDays(add + 7 * (ordinal - 1));
            if (nth.Month != month)
            {
                // overflow — fall back to last of that weekday
                DateTime d = new DateTime(year, month, lastDay, hour, minute, 0);
                while ((int)d.DayOfWeek != weekday) d = d.AddDays(-1);
                return d;
            }
            return nth;
        }

        private static int Clamp(int v, int min, int max)
        {
            if (v < min) return min;
            if (v > max) return max;
            return v;
        }

        public void Dispose() { Stop(); }
    }
}
