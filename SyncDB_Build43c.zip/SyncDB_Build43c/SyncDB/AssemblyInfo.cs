﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SyncDB")]
[assembly: AssemblyDescription("SyncDB Build 43c - SQL data transfer, Smart Delta, durable outbox")]
[assembly: AssemblyCompany("SyncDB")]
[assembly: AssemblyProduct("SyncDB")]
[assembly: AssemblyVersion("43.5.0.0")]
[assembly: AssemblyFileVersion("43.5.0.0")]
[assembly: ComVisible(false)]
