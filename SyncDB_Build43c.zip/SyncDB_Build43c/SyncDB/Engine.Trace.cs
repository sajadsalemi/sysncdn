using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace SyncDB
{
    /// <summary>One line of the per-statement job history (what ran, in which order, what came out).</summary>
    public class TraceEntry
    {
        public DateTime Time;
        public int StepId;
        public int Index;      // 1-based statement number inside the script (0 = step line)
        public int Total;
        public string Kind;    // SQL | USE | APP-READ | LINKED | STEP | SKIP
        public string Title;
        public string Status;  // OK | FAIL | WARN | SKIP
        public long Rows;
        public long Ms;
        public string Message;
    }

    /// <summary>
    /// Live "job history": every statement / table is written to the daily log the moment it finishes
    /// (so a failure is visible immediately) and collected for the Result window + history file.
    /// </summary>
    public static class RunTrace
    {
        [ThreadStatic] private static List<TraceEntry> _list;
        [ThreadStatic] private static string _job;
        [ThreadStatic] private static int _step;

        // ---- shared live view for the window (one running job at a time is shown) ----
        public static readonly object LiveLock = new object();
        public static readonly List<TraceEntry> Live = new List<TraceEntry>();
        public static volatile bool LiveRunning;
        public static volatile string LiveJob = "";
        public static volatile int LiveIndex, LiveTotal;
        public static volatile string LiveCurrent = "";
        public static long LiveRows;            // rows of the statement running now
        public static long LiveJobRows;         // rows of the whole run so far
        public static DateTime LiveStartedAt = DateTime.MinValue;
        public static DateTime LiveCurrentAt = DateTime.MinValue;
        /// <summary>When the last run ended (so the windows can still show how long it took).</summary>
        public static DateTime LiveFinishedAt = DateTime.MinValue;
        public static int LiveVersion;          // changes whenever something new happened

        // ---- extra live details for the status bars (table being moved, route, who started the run) ----
        /// <summary>Table / object that is being transferred right now.</summary>
        public static volatile string LiveTable = "";
        /// <summary>"srcServer.srcDb  ->  dstServer.dstDb" of the running job.</summary>
        public static volatile string LiveRoute = "";
        /// <summary>manual | schedule | service</summary>
        public static volatile string LiveRunSource = "manual";
        /// <summary>Tables / statements already finished in this run.</summary>
        public static volatile int LiveDoneCount;

        // ---- which JOB STEP is running (the status window shows this instead of the raw T-SQL) ----
        /// <summary>Name of the job step running right now ("sync_raw_data_person").</summary>
        public static volatile string LiveStepName = "";
        /// <summary>Place of that step in the job: step LiveStepIndex of LiveStepTotal.</summary>
        public static volatile int LiveStepIndex, LiveStepTotal;

        public static void Begin(string job)
        {
            _list = new List<TraceEntry>();
            _job = job;
            _step = 0;
            lock (LiveLock)
            {
                Live.Clear();
                LiveRunning = true;
                LiveJob = job ?? "";
                LiveIndex = 0; LiveTotal = 0; LiveCurrent = "starting...";
                LiveRows = 0; LiveJobRows = 0;
                LiveTable = ""; LiveDoneCount = 0;
                LiveStepName = ""; LiveStepIndex = 0; LiveStepTotal = 0;
                LiveStartedAt = LiveCurrentAt = DateTime.Now;
                LiveVersion++;
            }
        }

        /// <summary>Copy of the statements collected so far (used to build the transfer summary).</summary>
        public static List<TraceEntry> Snapshot()
        {
            return _list != null ? new List<TraceEntry>(_list) : new List<TraceEntry>();
        }

        /// <summary>
        /// One readable line for every status bar: which table is moving, how many records went over,
        /// how long it has taken (minutes) and the totals of the whole run.
        /// </summary>
        public static string BuildStatusLine()
        {
            bool run; string job, tbl, cur; long rows, jobRows; DateTime st, curAt; int idx, tot;
            lock (LiveLock)
            {
                run = LiveRunning; job = LiveJob ?? ""; tbl = LiveTable ?? ""; cur = LiveCurrent ?? "";
                rows = LiveRows; jobRows = LiveJobRows;
                st = LiveStartedAt; curAt = LiveCurrentAt; idx = LiveIndex; tot = LiveTotal;
            }
            if (!run) return "";
            double curSec = (DateTime.Now - curAt).TotalSeconds;
            double allSec = (DateTime.Now - st).TotalSeconds;
            if (curSec < 0) curSec = 0;
            if (allSec < 0) allSec = 0;
            long speed = curSec >= 1 ? (long)(rows / curSec) : 0;
            StringBuilder sb = new StringBuilder();
            sb.Append("Transferring: ").Append(tbl.Length > 0 ? tbl : (cur.Length > 0 ? cur : "(preparing)"));
            sb.Append("   |   records moved: ").Append(rows.ToString("N0"));
            if (speed > 0) sb.Append(" (").Append(speed.ToString("N0")).Append(" rows/s)");
            sb.Append("   |   this table: ").Append(JobHistory.FormatElapsed((long)(curSec * 1000)));
            if (tot > 0) sb.Append("   |   statement ").Append(idx).Append("/").Append(tot);
            sb.Append("   |   job ").Append(job).Append(": ").Append((jobRows + rows).ToString("N0"))
              .Append(" records in ").Append(JobHistory.FormatElapsed((long)(allSec * 1000)));
            string route = LiveRoute;
            if (!string.IsNullOrEmpty(route)) sb.Append("   |   ").Append(route);
            return sb.ToString();
        }

        /// <summary>Called just before a statement / table starts.</summary>
        public static void SetCurrent(int index, int total, string title)
        {
            lock (LiveLock)
            {
                LiveIndex = index; LiveTotal = total;
                LiveCurrent = "step " + _step + "  #" + index + "/" + total + "  " + (title ?? "");
                LiveTable = TableOf(title);
                LiveRows = 0;
                LiveCurrentAt = DateTime.Now;
                LiveVersion++;
            }
            LiveStatus = BuildStatusLine();
        }

        /// <summary>Short table / view name out of a statement title ("copy dbo.person -> dbo.person" => "dbo.person").
        /// Returns "" when the statement names no object, so the status window never shows a whole query.</summary>
        public static string TableOf(string title)
        {
            string t = (title ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
            if (t.Length == 0) return "";
            Match m = Regex.Match(t, @"(?:INTO|FROM|TABLE|UPDATE|copy|->|<-)\s+(\[?[\w\.\[\]#@]+\]?)", RegexOptions.IgnoreCase);
            if (m.Success)
            {
                string v = m.Groups[1].Value.Trim();
                if (v.Length > 0) return v;
            }
            return "";
        }

        /// <summary>Object name when the statement names one, otherwise a short piece of the title
        /// (used by the history summary, which must never show an empty name).</summary>
        public static string TableOrTitle(string title)
        {
            string v = TableOf(title);
            if (!string.IsNullOrEmpty(v)) return v;
            string t = (title ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
            return t.Length > 50 ? t.Substring(0, 50) + "..." : t;
        }

        public static void EndLive()
        {
            lock (LiveLock) { LiveRunning = false; LiveCurrent = ""; LiveTable = ""; LiveFinishedAt = DateTime.Now; LiveVersion++; }
            LiveStatus = "";
        }

        public static void SetStep(int stepId) { _step = stepId; }

        /// <summary>Same, plus the step name and its place in the job - what the status window shows on top.</summary>
        public static void SetStep(int stepId, string stepName, int index, int total)
        {
            _step = stepId;
            lock (LiveLock)
            {
                LiveStepName = stepName ?? "";
                LiveStepIndex = index;
                LiveStepTotal = total;
                LiveVersion++;
            }
        }

        [ThreadStatic] private static string _progTitle;
        [ThreadStatic] private static long _progRows;
        [ThreadStatic] private static DateTime _progStart, _progLast;

        /// <summary>Latest progress text (read by the window's status bar).</summary>
        public static volatile string LiveStatus = "";

        /// <summary>Starts counting rows for one table (a progress line is logged about every 10 seconds).</summary>
        public static void StartProgress(string title)
        {
            _progTitle = title ?? "";
            _progRows = 0;
            _progStart = _progLast = DateTime.Now;
            lock (LiveLock) { LiveTable = TableOf(_progTitle); LiveRows = 0; LiveCurrentAt = DateTime.Now; LiveVersion++; }
            LiveStatus = BuildStatusLine();
            AppLog.Info(_job ?? "-", "STMT start  " + _progTitle);
        }

        public static void Progress(long rows)
        {
            if (_progTitle == null) return;
            _progRows += rows;
            lock (LiveLock) { LiveRows = _progRows; LiveVersion++; }
            DateTime now = DateTime.Now;
            double sec = (now - _progStart).TotalSeconds;
            LiveStatus = BuildStatusLine();
            if ((now - _progLast).TotalSeconds >= 10)
            {
                _progLast = now;
                AppLog.Info(_job ?? "-", "STMT progress  " + _progTitle + "  rows written=" + _progRows.ToString("N0")
                    + "  " + (sec > 0 ? ((long)(_progRows / sec)).ToString("N0") : "0") + " rows/s  " + (int)sec + " s");
            }
        }

        public static void EndProgress() { _progTitle = null; LiveStatus = ""; }

        public static void Add(string kind, int index, int total, string title, string status, long rows, long ms, string message)
        {
            TraceEntry e = new TraceEntry();
            e.Time = DateTime.Now;
            e.StepId = _step;
            e.Index = index;
            e.Total = total;
            e.Kind = kind ?? "";
            e.Title = title ?? "";
            e.Status = status ?? "OK";
            e.Rows = rows;
            e.Ms = ms;
            e.Message = message ?? "";
            if (_list != null) _list.Add(e);
            lock (LiveLock)
            {
                Live.Add(e);
                if (e.Kind != "STEP" && e.Kind != "STAGE") { LiveJobRows += rows; LiveDoneCount++; }
                LiveVersion++;
            }

            // written immediately - not at the end of the job
            string pos = index > 0 ? "[" + index + "/" + total + "] " : "";
            string line = "STMT " + pos + e.Status.PadRight(4) + " " + e.Kind + " | " + e.Title
                + (rows > 0 || e.Status == "OK" ? " | rows=" + rows : "")
                + " | " + JobHistory.FormatSeconds(ms)
                + (e.Message.Length > 0 ? " | " + e.Message : "");
            if (e.Status == "FAIL") AppLog.Error(_job ?? "-", line);
            else if (e.Status == "WARN") AppLog.Warn(_job ?? "-", line);
            else AppLog.Info(_job ?? "-", line);
        }

        /// <summary>Returns the collected history as readable text and clears it.</summary>
        public static string EndText()
        {
            List<TraceEntry> l = _list;
            _list = null;
            if (l == null || l.Count == 0) return "";
            return Format(l);
        }

        private static string Cut(string s, int n)
        {
            if (s == null) return "";
            s = s.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ").Trim();
            return s.Length > n ? s.Substring(0, n) + "..." : s;
        }

        public static string Format(List<TraceEntry> l)
        {
            int ok = 0, fail = 0, warn = 0, skip = 0;
            foreach (TraceEntry e in l)
            {
                if (e.Kind == "STEP") continue;
                if (e.Status == "FAIL") fail++;
                else if (e.Status == "WARN") warn++;
                else if (e.Status == "SKIP") skip++;
                else ok++;
            }
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Statements: OK=" + ok + "  FAILED=" + fail + "  WARNINGS=" + warn + "  EMPTY/SKIPPED=" + skip);
            if (fail > 0 || warn > 0)
            {
                sb.AppendLine();
                sb.AppendLine("Needs attention:");
                foreach (TraceEntry e in l)
                {
                    if (e.Kind == "STEP") continue;
                    if (e.Status != "FAIL" && e.Status != "WARN") continue;
                    sb.AppendLine("  " + e.Status + "  step " + e.StepId + " #" + e.Index + "/" + e.Total + "  " + e.Title + "  -  " + Cut(e.Message, 300));
                }
            }
            sb.AppendLine();
            sb.AppendLine("Time      Step  Stmt     Status  Kind       Rows        ms      What");
            sb.AppendLine("--------  ----  -------  ------  ---------  ----------  ------  ------------------------------");
            foreach (TraceEntry e in l)
            {
                string pos = e.Index > 0 ? (e.Index + "/" + e.Total) : "-";
                sb.AppendLine(e.Time.ToString("HH:mm:ss") + "  "
                    + e.StepId.ToString().PadRight(4) + "  "
                    + pos.PadRight(7) + "  "
                    + e.Status.PadRight(6) + "  "
                    + e.Kind.PadRight(9) + "  "
                    + e.Rows.ToString().PadLeft(10) + "  "
                    + e.Ms.ToString().PadLeft(6) + "  "
                    + e.Title
                    + (e.Message.Length > 0 && e.Status != "OK" ? "   <- " + Cut(e.Message, 400) : (e.Message.Length > 0 ? "   (" + Cut(e.Message, 160) + ")" : "")));
            }
            return sb.ToString();
        }
    }

    /// <summary>One finished run, as one row of the Job History window.</summary>
    public class HistoryRun
    {
        public DateTime Time;            // when the run finished
        public string Job = "";
        public string Status = "OK";     // OK | WARN | FAIL
        public long Rows;                // records transferred in the whole run
        public long ElapsedMs;
        public string Source = "-";      // manual | schedule | service
        public int Tables;               // tables / statements that moved data
        public string TableList = "";    // "dbo.person:125,000 | dbo.salary:2,345"
        public string Message = "";
        public string Detail = "";       // full text of the run (statement by statement)

        public string Elapsed { get { return JobHistory.FormatElapsed(ElapsedMs); } }
    }

    /// <summary>Job history helpers: result text, a per-job text log and a per-job index the history window reads.</summary>
    public static class JobHistory
    {
        /// <summary>History older than this is dropped from the index and hidden in the window.</summary>
        public const int KeepDays = 30;

        /// <summary>Deleted / cleared history stays in the archive this many days, then is removed automatically.</summary>
        public const int ArchiveDays = 4;

        public static string Dir { get { return Path.Combine(AppConfig.DataDir, "history"); } }

        /// <summary>Folder for history that was cleared or belongs to a deleted job (auto-purged after ArchiveDays).</summary>
        public static string ArchiveDir { get { return Path.Combine(Dir, "archive"); } }

        public static string SafeName(string name)
        {
            string n = string.IsNullOrEmpty(name) ? "job" : name;
            foreach (char c in Path.GetInvalidFileNameChars()) n = n.Replace(c, '_');
            return n;
        }

        public static string LogPath(string jobName) { return Path.Combine(Dir, SafeName(jobName) + ".log"); }
        public static string IndexPath(string jobName) { return Path.Combine(Dir, SafeName(jobName) + ".runs.tsv"); }

        /// <summary>Every duration is shown in SECONDS, never in milliseconds.
        /// "376473 ms" => "376 s  (6 min 16 s)", "217 ms" => "0.22 s".</summary>
        public static string FormatElapsed(long ms)
        {
            string head = FormatSeconds(ms);
            if (ms < 60000) return head;
            long totalSec = (long)Math.Round((ms < 0 ? 0 : ms) / 1000.0);
            long h = totalSec / 3600, m = (totalSec % 3600) / 60, s = totalSec % 60;
            string t = h > 0 ? (h + " h " + m + " min " + s + " s") : (m + " min " + s + " s");
            return head + "  (" + t + ")";
        }

        /// <summary>Seconds only, for narrow columns: "0.22 s", "4.3 s", "376 s".</summary>
        public static string FormatSeconds(long ms)
        {
            if (ms < 0) ms = 0;
            double sec = ms / 1000.0;
            if (sec < 1) return sec.ToString("0.00") + " s";
            if (sec < 10) return sec.ToString("0.0") + " s";
            return Math.Round(sec).ToString("N0") + " s";
        }

        /// <summary>Names of the jobs that have a history file (what the "Select logs" list shows).</summary>
        public static List<string> ListJobs()
        {
            List<string> names = new List<string>();
            try
            {
                if (!Directory.Exists(Dir)) return names;
                foreach (string f in Directory.GetFiles(Dir, "*.log"))
                {
                    if (!f.EndsWith(".log", StringComparison.OrdinalIgnoreCase)) continue;   // never ".log.old"
                    string n = Path.GetFileNameWithoutExtension(f);
                    if (!string.IsNullOrEmpty(n) && !names.Contains(n)) names.Add(n);
                }
                foreach (string f in Directory.GetFiles(Dir, "*.runs.tsv"))
                {
                    string n = Path.GetFileName(f);
                    if (n.Length <= ".runs.tsv".Length || !n.EndsWith(".runs.tsv", StringComparison.OrdinalIgnoreCase)) continue;
                    n = n.Substring(0, n.Length - ".runs.tsv".Length);
                    if (!string.IsNullOrEmpty(n) && !names.Contains(n)) names.Add(n);
                }
            }
            catch { }
            names.Sort(StringComparer.CurrentCultureIgnoreCase);
            return names;
        }

        /// <summary>Timestamps are always written and read the same way, whatever the Windows language is.</summary>
        public const string Stamp = "yyyy-MM-dd HH:mm:ss";

        public static string Fmt(DateTime t) { return t.ToString(Stamp, CultureInfo.InvariantCulture); }

        public static bool TryStamp(string s, out DateTime t)
        {
            if (DateTime.TryParseExact((s ?? "").Trim(), Stamp, CultureInfo.InvariantCulture, DateTimeStyles.None, out t)) return true;
            return DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.None, out t);
        }

        private static string Esc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\t", " ").Replace("\r", " ").Replace("\n", " ").Trim();
        }

        /// <summary>Appends one run to the index file and drops entries older than KeepDays.</summary>
        private static void AppendIndex(string jobName, HistoryRun run)
        {
            try
            {
                Directory.CreateDirectory(Dir);
                string path = IndexPath(jobName);
                List<string> keep = new List<string>();
                DateTime min = DateTime.Now.AddDays(-KeepDays);
                if (File.Exists(path))
                {
                    foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        string[] p = line.Split('\t');
                        DateTime t;
                        if (p.Length > 0 && TryStamp(p[0], out t) && t < min) continue;
                        keep.Add(line);
                    }
                }
                keep.Add(string.Join("\t", new string[]
                {
                    Fmt(run.Time),
                    Esc(run.Status),
                    run.Rows.ToString(),
                    run.ElapsedMs.ToString(),
                    Esc(run.Source),
                    run.Tables.ToString(),
                    Esc(run.TableList),
                    Esc(run.Message)
                }));
                File.WriteAllLines(path, keep.ToArray(), new UTF8Encoding(true));
            }
            catch { }
        }

        /// <summary>Reads the runs of one job (index + older text log), newest first.</summary>
        public static List<HistoryRun> Load(string jobName)
        {
            List<HistoryRun> result = new List<HistoryRun>();
            DateTime min = DateTime.Now.AddDays(-KeepDays);
            Dictionary<string, HistoryRun> fromLog = new Dictionary<string, HistoryRun>();
            try
            {
                foreach (HistoryRun lr in ReadLogRuns(LogPath(jobName), jobName))
                {
                    string k = Fmt(lr.Time);
                    fromLog[k] = lr;
                }
            }
            catch { }

            HashSet<string> used = new HashSet<string>();
            try
            {
                string path = IndexPath(jobName);
                if (File.Exists(path))
                {
                    foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        string[] p = line.Split('\t');
                        DateTime t;
                        if (p.Length < 4 || !TryStamp(p[0], out t)) continue;
                        if (t < min) continue;
                        HistoryRun r = new HistoryRun();
                        r.Time = t;
                        r.Job = jobName;
                        r.Status = p[1];
                        long v;
                        r.Rows = long.TryParse(p[2], out v) ? v : 0;
                        r.ElapsedMs = long.TryParse(p[3], out v) ? v : 0;
                        r.Source = p.Length > 4 ? p[4] : "-";
                        int n;
                        r.Tables = p.Length > 5 && int.TryParse(p[5], out n) ? n : 0;
                        r.TableList = p.Length > 6 ? p[6] : "";
                        r.Message = p.Length > 7 ? p[7] : "";
                        string key = Fmt(t);
                        HistoryRun lr;
                        if (fromLog.TryGetValue(key, out lr)) { r.Detail = lr.Detail; used.Add(key); }
                        result.Add(r);
                    }
                }
            }
            catch { }

            foreach (KeyValuePair<string, HistoryRun> kv in fromLog)
            {
                if (used.Contains(kv.Key)) continue;
                if (kv.Value.Time < min) continue;
                result.Add(kv.Value);
            }

            result.Sort(delegate (HistoryRun a, HistoryRun b) { return b.Time.CompareTo(a.Time); });
            return result;
        }

        /// <summary>Status of the newest run of a job ("OK" / "WARN" / "FAIL" / "" ) - cheap, for the log list.</summary>
        public static string LastStatus(string jobName)
        {
            try
            {
                string idx = IndexPath(jobName);
                if (File.Exists(idx))
                {
                    string[] lines = File.ReadAllLines(idx, Encoding.UTF8);
                    for (int i = lines.Length - 1; i >= 0; i--)
                    {
                        if (string.IsNullOrWhiteSpace(lines[i])) continue;
                        string[] p = lines[i].Split('\t');
                        if (p.Length > 1) return p[1];
                    }
                }
                string log = LogPath(jobName);
                if (File.Exists(log))
                {
                    // only the tail of the file is read - the newest run is at the end
                    string text;
                    using (FileStream fs = new FileStream(log, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        long len = fs.Length;
                        long from = len > 200000 ? len - 200000 : 0;
                        fs.Seek(from, SeekOrigin.Begin);
                        byte[] buf = new byte[len - from];
                        int got = fs.Read(buf, 0, buf.Length);
                        text = new UTF8Encoding(false).GetString(buf, 0, got);
                    }
                    string last = "";
                    foreach (string line in text.Replace("\r\n", "\n").Split('\n'))
                    {
                        Match m = HeadRx.Match(line.Trim());
                        if (m.Success) last = m.Groups["st"].Value.ToUpperInvariant();
                    }
                    if (last == "SUCCESS") return "OK";
                    if (last == "WARNING") return "WARN";
                    if (last.Length > 0) return "FAIL";
                }
            }
            catch { }
            return "";
        }

        private static readonly Regex HeadRx = new Regex(
            @"^(?<t>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+(?<st>SUCCESS|FAILED|WARNING|STOPPED)\s+rows=(?<rows>\d+)\s+(?<ms>\d+)\s*ms(?<tail>.*)$",
            RegexOptions.IgnoreCase);

        /// <summary>Splits history\&lt;job&gt;.log into runs (also understands files written by older builds).</summary>
        private static List<HistoryRun> ReadLogRuns(string path, string jobName)
        {
            List<HistoryRun> list = new List<HistoryRun>();
            if (!File.Exists(path)) return list;
            string text;
            try { text = File.ReadAllText(path, Encoding.UTF8); }
            catch { return list; }
            // only the newest part of a big file is parsed (the window shows the last 30 days)
            if (text.Length > 1200000)
            {
                int cut = text.IndexOf("==================", text.Length - 1200000, StringComparison.Ordinal);
                text = cut > 0 ? text.Substring(cut) : text.Substring(text.Length - 1200000);
            }
            string[] lines = text.Replace("\r\n", "\n").Split('\n');
            HistoryRun cur = null;
            StringBuilder body = null;
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                Match m = HeadRx.Match(line.Trim());
                if (m.Success)
                {
                    if (cur != null) { cur.Detail = body.ToString().Trim(); FinishLogRun(cur); list.Add(cur); }
                    cur = new HistoryRun();
                    body = new StringBuilder();
                    DateTime t;
                    TryStamp(m.Groups["t"].Value, out t);
                    cur.Time = t;
                    cur.Job = jobName;
                    string st = m.Groups["st"].Value.ToUpperInvariant();
                    cur.Status = st == "SUCCESS" ? "OK" : (st == "WARNING" ? "WARN" : "FAIL");
                    long v;
                    cur.Rows = long.TryParse(m.Groups["rows"].Value, out v) ? v : 0;
                    cur.ElapsedMs = long.TryParse(m.Groups["ms"].Value, out v) ? v : 0;
                    string tail = m.Groups["tail"].Value ?? "";
                    Match ms2 = Regex.Match(tail, @"source=(\w+)", RegexOptions.IgnoreCase);
                    if (ms2.Success) cur.Source = ms2.Groups[1].Value;
                    Match mt = Regex.Match(tail, @"tables=(\d+)", RegexOptions.IgnoreCase);
                    int tn;
                    if (mt.Success && int.TryParse(mt.Groups[1].Value, out tn)) cur.Tables = tn;
                    continue;
                }
                if (cur == null) continue;
                if (line.StartsWith("=====")) continue;
                body.AppendLine(line);
            }
            if (cur != null) { cur.Detail = body.ToString().Trim(); FinishLogRun(cur); list.Add(cur); }
            return list;
        }

        private static void FinishLogRun(HistoryRun r)
        {
            if (!string.IsNullOrEmpty(r.Message)) return;
            foreach (string l in (r.Detail ?? "").Replace("\r\n", "\n").Split('\n'))
            {
                string t = l.Trim();
                if (t.Length == 0) continue;
                if (t.StartsWith("Transferred: ", StringComparison.Ordinal)) continue;
                r.Message = t.Length > 300 ? t.Substring(0, 300) : t;
                break;
            }
        }

        /// <summary>Paths inside the archive folder for one job.</summary>
        public static string ArchiveLogPath(string jobName) { return Path.Combine(ArchiveDir, SafeName(jobName) + ".log"); }
        public static string ArchiveIndexPath(string jobName) { return Path.Combine(ArchiveDir, SafeName(jobName) + ".runs.tsv"); }
        public static string ArchiveStampPath(string jobName) { return Path.Combine(ArchiveDir, SafeName(jobName) + ".archived"); }

        /// <summary>Moves active history of a job into the archive (keeps ArchiveDays, then PurgeArchive removes it).</summary>
        public static void Archive(string jobName)
        {
            if (string.IsNullOrWhiteSpace(jobName)) return;
            try
            {
                Directory.CreateDirectory(ArchiveDir);
                string safe = SafeName(jobName);
                // replace any previous archive entry for this job name
                try { string p = ArchiveLogPath(jobName); if (File.Exists(p)) File.Delete(p); } catch { }
                try { string p = ArchiveLogPath(jobName) + ".old"; if (File.Exists(p)) File.Delete(p); } catch { }
                try { string p = ArchiveIndexPath(jobName); if (File.Exists(p)) File.Delete(p); } catch { }

                string log = LogPath(jobName);
                string logOld = log + ".old";
                string idx = IndexPath(jobName);
                bool moved = false;
                if (File.Exists(log)) { try { File.Move(log, ArchiveLogPath(jobName)); moved = true; } catch { try { File.Copy(log, ArchiveLogPath(jobName), true); File.Delete(log); moved = true; } catch { } } }
                if (File.Exists(logOld)) { try { File.Move(logOld, ArchiveLogPath(jobName) + ".old"); moved = true; } catch { try { File.Copy(logOld, ArchiveLogPath(jobName) + ".old", true); File.Delete(logOld); moved = true; } catch { } } }
                if (File.Exists(idx)) { try { File.Move(idx, ArchiveIndexPath(jobName)); moved = true; } catch { try { File.Copy(idx, ArchiveIndexPath(jobName), true); File.Delete(idx); moved = true; } catch { } } }
                if (moved)
                {
                    try { File.WriteAllText(ArchiveStampPath(jobName), DateTime.Now.ToString("o", CultureInfo.InvariantCulture), new UTF8Encoding(true)); } catch { }
                }
                // ensure active files are gone even if move partially failed
                try { if (File.Exists(log)) File.Delete(log); } catch { }
                try { if (File.Exists(logOld)) File.Delete(logOld); } catch { }
                try { if (File.Exists(idx)) File.Delete(idx); } catch { }
            }
            catch { }
        }

        /// <summary>Permanently deletes active history of one job (no archive). Prefer Archive() for UI clear.</summary>
        public static void Clear(string jobName)
        {
            try { string p = LogPath(jobName); if (File.Exists(p)) File.Delete(p); } catch { }
            try { string p = LogPath(jobName) + ".old"; if (File.Exists(p)) File.Delete(p); } catch { }
            try { string p = IndexPath(jobName); if (File.Exists(p)) File.Delete(p); } catch { }
        }

        /// <summary>Permanently deletes one job from the archive.</summary>
        public static void DeleteArchived(string jobName)
        {
            try { string p = ArchiveLogPath(jobName); if (File.Exists(p)) File.Delete(p); } catch { }
            try { string p = ArchiveLogPath(jobName) + ".old"; if (File.Exists(p)) File.Delete(p); } catch { }
            try { string p = ArchiveIndexPath(jobName); if (File.Exists(p)) File.Delete(p); } catch { }
            try { string p = ArchiveStampPath(jobName); if (File.Exists(p)) File.Delete(p); } catch { }
        }

        /// <summary>Removes archive entries older than ArchiveDays (based on .archived stamp or file time).</summary>
        public static int PurgeArchive()
        {
            int removed = 0;
            try
            {
                if (!Directory.Exists(ArchiveDir)) return 0;
                DateTime min = DateTime.Now.AddDays(-ArchiveDays);
                // collect job names from stamp / log / index files
                Dictionary<string, DateTime> when = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
                foreach (string f in Directory.GetFiles(ArchiveDir, "*.archived"))
                {
                    string n = Path.GetFileNameWithoutExtension(f);
                    DateTime t = DateTime.MinValue;
                    try
                    {
                        string s = File.ReadAllText(f).Trim();
                        DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out t);
                    }
                    catch { }
                    if (t == DateTime.MinValue) try { t = File.GetLastWriteTime(f); } catch { t = DateTime.Now; }
                    when[n] = t;
                }
                foreach (string f in Directory.GetFiles(ArchiveDir))
                {
                    string name = Path.GetFileName(f);
                    string job = null;
                    if (name.EndsWith(".runs.tsv", StringComparison.OrdinalIgnoreCase))
                        job = name.Substring(0, name.Length - ".runs.tsv".Length);
                    else if (name.EndsWith(".log.old", StringComparison.OrdinalIgnoreCase))
                        job = name.Substring(0, name.Length - ".log.old".Length);
                    else if (name.EndsWith(".log", StringComparison.OrdinalIgnoreCase))
                        job = Path.GetFileNameWithoutExtension(name);
                    else if (name.EndsWith(".archived", StringComparison.OrdinalIgnoreCase))
                        continue;
                    else continue;
                    if (string.IsNullOrEmpty(job)) continue;
                    if (!when.ContainsKey(job))
                    {
                        try { when[job] = File.GetLastWriteTime(f); } catch { when[job] = DateTime.Now; }
                    }
                }
                foreach (KeyValuePair<string, DateTime> kv in when)
                {
                    if (kv.Value >= min) continue;
                    DeleteArchived(kv.Key);
                    removed++;
                }
            }
            catch { }
            return removed;
        }

        /// <summary>Job names that currently have files in the archive folder.</summary>
        public static List<string> ListArchivedJobs()
        {
            List<string> names = new List<string>();
            try
            {
                if (!Directory.Exists(ArchiveDir)) return names;
                foreach (string f in Directory.GetFiles(ArchiveDir, "*.log"))
                {
                    if (f.EndsWith(".log.old", StringComparison.OrdinalIgnoreCase)) continue;
                    string n = Path.GetFileNameWithoutExtension(f);
                    if (!string.IsNullOrEmpty(n) && !names.Contains(n)) names.Add(n);
                }
                foreach (string f in Directory.GetFiles(ArchiveDir, "*.runs.tsv"))
                {
                    string n = Path.GetFileName(f);
                    if (n.Length <= ".runs.tsv".Length || !n.EndsWith(".runs.tsv", StringComparison.OrdinalIgnoreCase)) continue;
                    n = n.Substring(0, n.Length - ".runs.tsv".Length);
                    if (!string.IsNullOrEmpty(n) && !names.Contains(n)) names.Add(n);
                }
            }
            catch { }
            names.Sort(StringComparer.CurrentCultureIgnoreCase);
            return names;
        }

        /// <summary>Loads runs from the archive (same shape as Load).</summary>
        public static List<HistoryRun> LoadArchived(string jobName)
        {
            // temporarily point paths by reading archive files with the same parsers
            List<HistoryRun> result = new List<HistoryRun>();
            try
            {
                DateTime min = DateTime.Now.AddDays(-Math.Max(KeepDays, ArchiveDays));
                Dictionary<string, HistoryRun> fromLog = new Dictionary<string, HistoryRun>();
                string log = ArchiveLogPath(jobName);
                if (File.Exists(log))
                {
                    foreach (HistoryRun lr in ReadLogRuns(log, jobName))
                    {
                        if (lr.Time < min) continue;
                        string key = Fmt(lr.Time);
                        fromLog[key] = lr;
                    }
                }
                string path = ArchiveIndexPath(jobName);
                if (File.Exists(path))
                {
                    foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        string[] p = line.Split('\t');
                        if (p.Length < 4) continue;
                        DateTime t;
                        if (!TryStamp(p[0], out t) || t < min) continue;
                        HistoryRun r = new HistoryRun();
                        r.Time = t;
                        r.Job = jobName;
                        r.Status = p.Length > 1 ? p[1] : "OK";
                        long v;
                        r.Rows = long.TryParse(p.Length > 2 ? p[2] : "0", out v) ? v : 0;
                        r.ElapsedMs = long.TryParse(p.Length > 3 ? p[3] : "0", out v) ? v : 0;
                        r.Source = p.Length > 4 ? p[4] : "-";
                        int n;
                        r.Tables = p.Length > 5 && int.TryParse(p[5], out n) ? n : 0;
                        r.TableList = p.Length > 6 ? p[6] : "";
                        r.Message = p.Length > 7 ? p[7] : "";
                        string key = Fmt(t);
                        HistoryRun lr;
                        if (fromLog.TryGetValue(key, out lr) && !string.IsNullOrEmpty(lr.Detail))
                            r.Detail = lr.Detail;
                        result.Add(r);
                        fromLog.Remove(key);
                    }
                }
                foreach (KeyValuePair<string, HistoryRun> kv in fromLog)
                    result.Add(kv.Value);
                result.Sort(delegate (HistoryRun a, HistoryRun b) { return b.Time.CompareTo(a.Time); });
            }
            catch { }
            return result;
        }

        /// <summary>When the job was moved to archive (for UI); DateTime.MinValue if unknown.</summary>
        public static DateTime ArchiveTime(string jobName)
        {
            try
            {
                string p = ArchiveStampPath(jobName);
                if (File.Exists(p))
                {
                    DateTime t;
                    if (DateTime.TryParse(File.ReadAllText(p).Trim(), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out t))
                        return t;
                    return File.GetLastWriteTime(p);
                }
            }
            catch { }
            return DateTime.MinValue;
        }

        /// <summary>"dbo.person:125,000 | dbo.salary:2,345" out of the statements of a run.</summary>
        public static string BuildTableList(List<TraceEntry> entries, out int tableCount)
        {
            tableCount = 0;
            StringBuilder sb = new StringBuilder();
            if (entries == null) return "";
            foreach (TraceEntry e in entries)
            {
                if (e == null || e.Kind == "STEP" || e.Kind == "USE") continue;
                if (e.Rows <= 0 && e.Status == "OK") continue;
                tableCount++;
                if (tableCount > 40) continue;
                if (sb.Length > 0) sb.Append(" | ");
                sb.Append(RunTrace.TableOrTitle(e.Title)).Append(':').Append(e.Rows.ToString("N0"));
                if (e.Status != "OK") sb.Append('(').Append(e.Status).Append(')');
            }
            if (tableCount > 40) sb.Append(" | ... +").Append(tableCount - 40).Append(" more");
            return sb.ToString();
        }

        public static string BuildDetail(SyncJob job, RunResult r)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(r.Ok ? "RESULT: SUCCESS" : "RESULT: FAILED");
            sb.AppendLine("Job: " + (job != null ? job.Name : ""));
            sb.AppendLine("Time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("Elapsed: " + JobHistory.FormatElapsed(r.ElapsedMs));
            sb.AppendLine("Rows: " + r.Rows);
            sb.AppendLine();
            sb.AppendLine("Message:");
            sb.AppendLine(r.Message ?? "");
            if (!string.IsNullOrEmpty(r.Trace))
            {
                sb.AppendLine();
                sb.AppendLine("=== JOB HISTORY - every statement, in order ===");
                sb.AppendLine(r.Trace);
            }
            return sb.ToString();
        }

        /// <summary>Appends this run to history\&lt;job&gt;.log (kept under ~2 MB).</summary>
        public static void Persist(SyncJob job, RunResult r)
        {
            try
            {
                if (job == null || r == null) return;
                string name = job.Name ?? job.Id ?? "job";
                Directory.CreateDirectory(Dir);
                string path = LogPath(name);
                if (File.Exists(path) && new FileInfo(path).Length > 2 * 1024 * 1024)
                {
                    string old = path + ".old";
                    try { if (File.Exists(old)) File.Delete(old); File.Move(path, old); } catch { }
                }
                DateTime now = DateTime.Now;
                string status = r.Ok ? "SUCCESS" : "FAILED";
                string src = string.IsNullOrEmpty(r.Source) ? "manual" : r.Source;
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("==================================================================");
                // machine-readable header line - HeadRx parses "rows=N  <ms> ms", so this one stays in ms
                sb.AppendLine(Fmt(now) + "  " + status
                    + "  rows=" + r.Rows + "  " + r.ElapsedMs + " ms"
                    + "  source=" + src + "  tables=" + r.Tables);
                if (!string.IsNullOrEmpty(r.TableList)) sb.AppendLine("Transferred: " + r.TableList);
                sb.AppendLine(r.Message ?? "");
                if (!string.IsNullOrEmpty(r.Trace)) sb.AppendLine(r.Trace);
                File.AppendAllText(path, sb.ToString(), new UTF8Encoding(true));

                HistoryRun run = new HistoryRun();
                run.Time = now;
                run.Job = name;
                run.Status = r.Ok ? "OK" : "FAIL";
                run.Rows = r.Rows;
                run.ElapsedMs = r.ElapsedMs;
                run.Source = src;
                run.Tables = r.Tables;
                run.TableList = r.TableList ?? "";
                run.Message = (r.Message ?? "").Replace("\r", " ").Replace("\n", " ");
                if (run.Message.Length > 400) run.Message = run.Message.Substring(0, 400) + "...";
                AppendIndex(name, run);
                try { AppLog.Info(name, "History written: " + path); } catch { }
            }
            catch { }
        }
    }

    public static partial class Engine
    {
        // ------------------------------------------------------------------
        //  SQL text helpers
        // ------------------------------------------------------------------

        /// <summary>Removes -- line comments and (nested) block comments; literals and quoted identifiers are left alone.</summary>
        internal static string StripSqlComments(string s)
        {
            return MaskSqlNonCodeCore(s, false, false);
        }

        /// <summary>
        /// Masks literals/comments (and optionally quoted identifiers), keeping offsets and line breaks.
        /// Used for lexical checks; SQL inside a string/comment is never executable SQL.
        /// </summary>
        internal static string MaskSqlNonCode(string sql, bool maskIdentifiers)
        {
            return MaskSqlNonCodeCore(sql, maskIdentifiers, true);
        }

        private static string MaskSqlNonCodeCore(string sql, bool maskIdentifiers, bool maskLiterals)
        {
            if (string.IsNullOrEmpty(sql)) return sql ?? "";
            char[] masked = sql.ToCharArray();
            int i = 0;
            while (i < sql.Length)
            {
                int start = i;
                char c = sql[i];
                bool hide = true;
                if (c == '-' && i + 1 < sql.Length && sql[i + 1] == '-')
                {
                    i += 2;
                    while (i < sql.Length && sql[i] != '\r' && sql[i] != '\n') i++;
                }
                else if (c == '/' && i + 1 < sql.Length && sql[i + 1] == '*')
                {
                    int depth = 1;
                    i += 2;
                    while (i < sql.Length && depth > 0)
                    {
                        if (i + 1 < sql.Length && sql[i] == '/' && sql[i + 1] == '*') { depth++; i += 2; }
                        else if (i + 1 < sql.Length && sql[i] == '*' && sql[i + 1] == '/') { depth--; i += 2; }
                        else i++;
                    }
                }
                else if (c == '\'' || c == '"' || c == '[')
                {
                    char end = c == '[' ? ']' : c;
                    hide = c == '\'' ? maskLiterals : maskIdentifiers;
                    i++;
                    while (i < sql.Length)
                    {
                        if (sql[i++] != end) continue;
                        if (i < sql.Length && sql[i] == end) { i++; continue; }
                        break;
                    }
                }
                else { i++; continue; }
                if (hide)
                    for (int k = start; k < i; k++)
                        if (masked[k] != '\r' && masked[k] != '\n') masked[k] = ' ';
            }
            return new string(masked);
        }

        /// <summary>Invisible / direction marks (common when text is pasted from chat, Word or RTL text) become spaces.</summary>
        internal static string ReplaceInvisible(string s)
        {
            if (string.IsNullOrEmpty(s)) return s ?? "";
            StringBuilder sb = null;
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                bool bad = c == (char)0x200B || c == (char)0x200C || c == (char)0x200D || c == (char)0x200E || c == (char)0x200F
                    || (c >= (char)0x202A && c <= (char)0x202E) || c == (char)0x2060 || c == (char)0xFEFF || c == (char)0x00A0
                    || (c >= (char)0x2066 && c <= (char)0x2069);
                if (bad && sb == null) { sb = new StringBuilder(s.Length); sb.Append(s, 0, i); }
                if (sb != null) sb.Append(bad ? ' ' : c);
            }
            return sb == null ? s : sb.ToString();
        }

        /// <summary>
        /// Invisible direction / zero-width characters pasted into a script line break keywords ("insert" at the start of a line).
        /// Lines that contain a quote are left alone (a Persian text literal may need its zero-width non-joiner).
        /// </summary>
        internal static string CleanScriptLine(string line)
        {
            if (string.IsNullOrEmpty(line) || line.IndexOf('\'') >= 0) return line;
            return ReplaceInvisible(line);
        }

        /// <summary>True for "GO", "go ", "GO 5", "GO -- comment" (also with invisible characters around it).</summary>
        internal static bool IsGoLine(string line)
        {
            if (line == null) return false;
            string t = ReplaceInvisible(line).Trim();
            int cm = t.IndexOf("--", StringComparison.Ordinal);
            if (cm >= 0) t = t.Substring(0, cm).Trim();
            if (t.Length > 0 && t[t.Length - 1] == ';') t = t.Substring(0, t.Length - 1).Trim();
            if (t.Equals("GO", StringComparison.OrdinalIgnoreCase)) return true;
            Match count = Regex.Match(t, @"^GO\s+([0-9]+)$", RegexOptions.IgnoreCase);
            int x;
            return count.Success && int.TryParse(count.Groups[1].Value, out x);
        }

        private static readonly Regex DescribeRx = new Regex(
            @"^\s*(?<verb>DELETE\s+FROM|DELETE|TRUNCATE\s+TABLE|INSERT\s+INTO|INSERT|UPDATE|SELECT\s+.+?\s+INTO|EXEC(?:UTE)?|USE|DROP\s+TABLE|CREATE\s+\w+|ALTER\s+\w+|MERGE(?:\s+INTO)?|WITH|SELECT)\s*(?<obj>[\w\[\]\.\#@]+)?",
            RegexOptions.IgnoreCase | RegexOptions.Singleline);

        /// <summary>Short readable name of a statement for the history ("DELETE FROM mapping").</summary>
        internal static string DescribeBatch(string clean)
        {
            if (string.IsNullOrWhiteSpace(clean)) return "(empty)";
            string one = Regex.Replace(clean.Trim(), @"\s+", " ");
            Match m = DescribeRx.Match(one);
            string t;
            if (m.Success)
            {
                string verb = Regex.Replace(m.Groups["verb"].Value, @"\s+", " ").ToUpperInvariant();
                if (verb.StartsWith("SELECT ") && verb.EndsWith(" INTO")) verb = "SELECT..INTO";
                string obj = m.Groups["obj"].Value;
                t = obj.Length > 0 ? verb + " " + obj : verb;
                if (verb == "SELECT" || verb == "WITH") t = one;
            }
            else t = one;
            return t.Length > 90 ? t.Substring(0, 90) + "..." : t;
        }

        private static readonly Regex UseRx = new Regex(@"^\s*USE\s+(\[[^\]]+\]|\w+)\s*;?\s*$", RegexOptions.IgnoreCase);

        // DELETE / TRUNCATE lines written directly in front of "INSERT INTO ... SELECT ... FROM [srv].[db].[sch].[tbl]" (no GO, no ';')
        private static readonly Regex PreDeleteRx = new Regex(
            @"^\s*(?<pre>(?:DELETE|TRUNCATE)\b[\s\S]*?)(?=\bINSERT\s+INTO\b)", RegexOptions.IgnoreCase);

        private static readonly Regex MoreStatementsRx = new Regex(
            @"(?im)(^|;)\s*(DELETE|TRUNCATE|UPDATE|INSERT|EXEC|EXECUTE|DROP|CREATE|ALTER|SET|USE|DECLARE|IF|WHILE|BEGIN)\b");

        internal static string WithDatabase(string connStr, string db)
        {
            try
            {
                System.Data.SqlClient.SqlConnectionStringBuilder b = new System.Data.SqlClient.SqlConnectionStringBuilder(connStr);
                b.InitialCatalog = db;
                return b.ConnectionString;
            }
            catch { return connStr; }
        }
    }
}
