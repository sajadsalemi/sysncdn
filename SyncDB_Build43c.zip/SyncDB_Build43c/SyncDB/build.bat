@echo off
setlocal EnableExtensions
echo SyncDB BUILD 43c
cd /d "%~dp0"

rem csc needs a valid TEMP folder (error CS0016 "The directory name is invalid" = bad TEMP) - use a folder inside the project
if not exist "%~dp0_tmp" mkdir "%~dp0_tmp" >nul 2>&1
set "TEMP=%~dp0_tmp"
set "TMP=%~dp0_tmp"

rem ---------------------------------------------------------------------------
rem The Windows service runs a SyncDB.exe too. If it is installed:
rem   - replacing the EXE and stopping the service both need administrator rights,
rem     so this script asks for them itself (one UAC prompt);
rem   - after the build the service is switched to THIS new SyncDB.exe. Without
rem     that, a service registered from another folder keeps running the OLD code
rem     and every new build looks as if it changed nothing.
rem ---------------------------------------------------------------------------
set "ELEVATED_CHILD="
if /i "%~1"=="/elevated" set "ELEVATED_CHILD=1"

set "SVCINSTALLED="
sc query SyncDB >nul 2>&1
if not errorlevel 1 set "SVCINSTALLED=1"

if not defined SVCINSTALLED goto no_service
net session >nul 2>&1
if not errorlevel 1 goto have_admin
if defined ELEVATED_CHILD goto have_admin

echo The SyncDB Windows service is installed.
echo Administrator rights are needed to replace SyncDB.exe and update the service...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList '/elevated' -Verb RunAs -Wait"
if errorlevel 1 (
  echo.
  echo Administrator permission was not granted - nothing was built.
  pause
  exit /b 1
)
if exist "%~dp0SyncDB.exe" start "" "%~dp0SyncDB.exe"
exit /b 0

:have_admin
set "SVCWASRUNNING="
sc query SyncDB | find "RUNNING" >nul 2>&1
if not errorlevel 1 set "SVCWASRUNNING=1"
if not defined SVCWASRUNNING goto no_service
echo Stopping the SyncDB Windows service...
net stop SyncDB >nul 2>&1
sc stop SyncDB >nul 2>&1
for /l %%i in (1,1,20) do (
  sc query SyncDB | find "STOPPED" >nul 2>&1
  if not errorlevel 1 goto no_service
  timeout /t 1 /nobreak >nul 2>&1
)

:no_service

taskkill /f /im SyncDB.exe >nul 2>&1
timeout /t 1 /nobreak >nul 2>&1
if exist SyncDB.exe del /f /q SyncDB.exe >nul 2>&1
if exist SyncDB.exe (
  echo.
  echo ERROR: SyncDB.exe is still locked and could not be replaced.
  echo        The Windows service or another copy of the program is still using it.
  echo        Stop the service ^(services.msc -^> SyncDB^) and run build.bat again.
  echo.
  pause
  exit /b 1
)
if exist build_log.txt del /f /q build_log.txt >nul 2>&1

set "LOG=%~dp0build_log.txt"
(
  echo ========================================
  echo SyncDB build log
  echo Date: %DATE% %TIME%
  echo Folder: %CD%
  echo ========================================
) > "%LOG%"

echo.
echo Building SyncDB...
echo Building SyncDB... >> "%LOG%"

set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo ERROR: csc.exe not found. Install .NET Framework 4.x Developer Pack / targeting pack.
  echo ERROR: csc.exe not found >> "%LOG%"
  echo Tried:
  echo   %WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
  echo   %WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
  echo.
  echo Log saved: %LOG%
  pause
  exit /b 1
)

echo Compiler: %CSC%
echo Compiler: %CSC% >> "%LOG%"

if not exist "Program.cs" (
  echo ERROR: .cs files are not in this folder. Put build.bat next to Program.cs, Engine.cs ...
  echo ERROR: Program.cs missing >> "%LOG%"
  pause
  exit /b 1
)

if not exist "Newtonsoft.Json.dll" (
  echo ERROR: Newtonsoft.Json.dll is missing in this folder.
  echo ERROR: Newtonsoft.Json.dll is missing >> "%LOG%"
  echo Log saved: %LOG%
  pause
  exit /b 1
)

if not exist "LiteDB.dll" (
  echo WARNING: LiteDB.dll missing - outbox will not compile.
  echo WARNING: LiteDB.dll missing >> "%LOG%"
)
if not exist "System.Buffers.dll" (
  echo WARNING: System.Buffers.dll is missing - LiteDB will fail at runtime.
  echo WARNING: System.Buffers.dll missing >> "%LOG%"
)
if not exist "System.Memory.dll" (
  echo WARNING: System.Memory.dll is missing - LiteDB will fail at runtime.
  echo WARNING: System.Memory.dll missing >> "%LOG%"
)
if not exist "System.Runtime.CompilerServices.Unsafe.dll" (
  echo WARNING: System.Runtime.CompilerServices.Unsafe.dll is missing - LiteDB will fail at runtime.
  echo WARNING: System.Runtime.CompilerServices.Unsafe.dll missing >> "%LOG%"
)

echo Files in folder: >> "%LOG%"
dir /b *.cs Newtonsoft.Json.dll LiteDB.dll app.ico >> "%LOG%" 2>&1
echo. >> "%LOG%"

set "ICON="
if exist app.ico set "ICON=/win32icon:app.ico"

echo.
echo Running csc...
echo Running csc... >> "%LOG%"

"%CSC%" /nologo /target:winexe /optimize+ /codepage:65001 /out:"%~dp0SyncDB.exe" %ICON% ^
  /r:Newtonsoft.Json.dll /r:LiteDB.dll /r:System.dll /r:System.Core.dll /r:System.Data.dll ^
  /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Xml.dll /r:System.ServiceProcess.dll ^
  Program.cs Lang.cs Models.cs Logger.cs Engine.cs Scheduler.cs MainForm.cs JobEditForm.cs ResourcesForm.cs Theme.cs SelectPreviewForm.cs ServiceHost.cs Engine.Smart.cs Security.cs ExportImport.cs OutboxStore.cs LocalStream.cs Engine.Delta.cs ICacheStore.cs OutboxWorker.cs OutboxReplay.cs OutboxForm.cs Engine.Trace.cs JobHistoryForm.cs LiveStatusForm.cs OperationsForm.cs Maintenance.cs AssemblyInfo.cs >> "%LOG%" 2>&1

if errorlevel 1 goto build_failed
if not exist SyncDB.exe goto missing_exe

echo.
echo ========== BUILD OK ==========
echo Output: %CD%\SyncDB.exe
echo Log:    %LOG%
echo.
echo BUILD OK >> "%LOG%"
echo Output: %CD%\SyncDB.exe >> "%LOG%"

echo Keep Newtonsoft.Json.dll and LiteDB.dll next to SyncDB.exe
echo To run as a Windows service: install_service.bat

if defined SVCWASRUNNING (
  echo.
  echo Switching the SyncDB Windows service to this build and starting it...
  start "" /wait "%~dp0SyncDB.exe" /install
  sc query SyncDB | find "STATE"
  echo Service switched to this build. >> "%LOG%"
)

if defined ELEVATED_CHILD (
  echo.
  echo Done. This window can be closed - SyncDB starts from the first window.
  timeout /t 3 /nobreak >nul 2>&1
  exit /b 0
)

echo.
echo Starting SyncDB.exe ...
start "" "%CD%\SyncDB.exe"
pause
exit /b 0

:build_failed
echo.
echo ========== BUILD FAILED ==========
echo Errors are listed below (also saved in build_log.txt)
echo.
type "%LOG%"
echo.
echo Log saved: %LOG%
pause
exit /b 1

:missing_exe
echo ERROR: csc returned success but SyncDB.exe was not created.
echo ERROR: SyncDB.exe missing after build >> "%LOG%"
dir >> "%LOG%"
echo.
echo Log saved: %LOG%
pause
exit /b 1
