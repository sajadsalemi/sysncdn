using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SyncDB
{
    /// <summary>
    /// Background worker that drains the local Outbox with:
    /// - cross-process claim (Processing lease), so GUI + Windows service cannot send twice
    /// - batching
    /// - exponential backoff + dead-letter after MaxRetries
    /// - circuit breaker (stops hammering when the destination is down)
    /// - idempotency via MessageId
    /// - real delivery: Local = SQL step replay, Http = webhook POST.
    /// </summary>
    public sealed class OutboxWorker : IDisposable
    {
        private sealed class DeliveryOutcome
        {
            public bool Ok;
            public bool Permanent;
            public string Error;
            public long Rows;
            public string Table;
        }

        private readonly object _gate = new object();
        private readonly AutoResetEvent _wake = new AutoResetEvent(false);
        private readonly CircuitBreaker _breaker = new CircuitBreaker(5, TimeSpan.FromSeconds(60));
        private CancellationTokenSource _cts;
        private Task _loop;
        private AppConfig _cfg;
        private volatile bool _running;

        public int BatchSize { get; set; }
        public int MaxRetries { get; set; }
        public int IdleSleepMs { get; set; }
        public int LeaseMinutes { get; set; }
        public bool IsRunning { get { return _running; } }

        public OutboxWorker()
        {
            BatchSize = 20;
            MaxRetries = OutboxStore.DefaultMaxRetries;
            IdleSleepMs = 3000;
            LeaseMinutes = 10;
        }

        private void ApplyConfiguration(AppConfig cfg)
        {
            if (cfg == null) return;
            if (cfg.OutboxBatchSize > 0) BatchSize = Math.Min(500, cfg.OutboxBatchSize);
            if (cfg.OutboxMaxRetries > 0) MaxRetries = Math.Min(100, cfg.OutboxMaxRetries);
            if (cfg.OutboxIdleMs >= 250) IdleSleepMs = cfg.OutboxIdleMs;
            if (cfg.OutboxLeaseMinutes > 0) LeaseMinutes = Math.Min(1440, cfg.OutboxLeaseMinutes);
        }

        public void Start(AppConfig cfg)
        {
            lock (_gate)
            {
                if (_running) return;
                _cfg = cfg ?? new AppConfig();
                ApplyConfiguration(_cfg);
                if (!_cfg.OutboxEnabled)
                {
                    AppLog.Info("-", "OutboxWorker: OutboxEnabled=false — not started");
                    return;
                }
                OutboxStore.EnsureOpen();
                CacheStoreFactory.Configure(_cfg);
                _cts = new CancellationTokenSource();
                _running = true;
                _breaker.Reset();
                try
                {
                    _loop = Task.Factory.StartNew(() => RunLoop(_cts.Token),
                        _cts.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
                }
                catch
                {
                    _running = false;
                    _cts.Dispose();
                    _cts = null;
                    throw;
                }
                AppLog.Info("-", "OutboxWorker started (batch=" + BatchSize + ", maxRetries=" + MaxRetries +
                                 ", idle=" + IdleSleepMs + "ms, lease=" + LeaseMinutes + "m)");
            }
        }

        public void UpdateConfig(AppConfig cfg)
        {
            if (cfg == null) return;
            bool needStart;
            bool needStop;
            lock (_gate)
            {
                _cfg = cfg;
                ApplyConfiguration(cfg);
                needStart = cfg.OutboxEnabled && !_running;
                needStop = !cfg.OutboxEnabled && _running;
            }
            if (needStop) Stop();
            else if (needStart) Start(cfg);
            else
            {
                CacheStoreFactory.Configure(cfg);
                _wake.Set();
            }
        }

        public void Stop()
        {
            CancellationTokenSource cts;
            Task loop;
            lock (_gate)
            {
                if (!_running && _loop == null) return;
                _running = false;
                cts = _cts;
                loop = _loop;
                _cts = null;
                _loop = null;
            }
            try { if (cts != null) cts.Cancel(); } catch { }
            try { _wake.Set(); } catch { }
            bool finished = true;
            try { if (loop != null) finished = loop.Wait(10000); }
            catch { }
            if (finished)
            {
                try { if (cts != null) cts.Dispose(); } catch { }
            }
            else
            {
                AppLog.Warn("-", "OutboxWorker did not stop within 10s; it will exit after the current item.");
            }
            AppLog.Info("-", "OutboxWorker stopped. " + OutboxStore.Stats());
        }

        /// <summary>Wake the loop immediately (used by the Outbox manager's "Process now" button).</summary>
        public void ProcessNow()
        {
            try { _wake.Set(); } catch { }
        }

        private void RunLoop(CancellationToken ct)
        {
            DateTime lastStaleCheck = DateTime.MinValue;
            DateTime lastPurge = DateTime.MinValue;
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    if (_breaker.IsOpen)
                    {
                        Wait(2000, ct);
                        continue;
                    }

                    DateTime now = DateTime.UtcNow;
                    if ((now - lastStaleCheck).TotalMinutes >= 5)
                    {
                        lastStaleCheck = now;
                        TimeSpan lease = TimeSpan.FromMinutes(Math.Max(1, LeaseMinutes));
                        OutboxStore.ReleaseStale(lease, MaxRetries);
                    }
                    if ((now - lastPurge).TotalMinutes >= 60)
                    {
                        lastPurge = now;
                        AppConfig cfg = _cfg;
                        int days = cfg != null ? cfg.OutboxSentRetentionDays : 7;
                        if (days < 1) days = 7;
                        OutboxStore.PurgeCompleted(now.AddDays(-days));
                        // Deleting rows does not shrink outbox.db and the -log.db side file keeps
                        // growing until a checkpoint, so merge it back every hour.
                        try { OutboxStore.Checkpoint(); } catch { }
                    }

                    var batch = OutboxStore.ListReady(BatchSize);
                    if (batch == null || batch.Count == 0)
                    {
                        Wait(IdleSleepMs, ct);
                        continue;
                    }

                    foreach (var item in batch)
                    {
                        if (ct.IsCancellationRequested) break;
                        AppConfig cfg = _cfg;
                        string target = item.TargetOriginId ?? "";
                        string localOrigin = cfg != null ? (cfg.OriginId ?? "") : "";
                        if (target.Length > 0 && string.Equals(target, localOrigin, StringComparison.OrdinalIgnoreCase))
                        {
                            OutboxStore.MarkSkipped(item.Id, "Loop prevention: target origin is this node (" + localOrigin + ").");
                            AppLog.Info("-", "Outbox #" + item.Id + " skipped (target origin is local).");
                            continue;
                        }

                        OutboxStore.OutboxItem claimed;
                        TimeSpan lease = TimeSpan.FromMinutes(Math.Max(1, LeaseMinutes));
                        if (!OutboxStore.TryClaim(item.Id, lease, out claimed)) continue;
                        ProcessOne(claimed);
                        if (_breaker.IsOpen) break;
                    }
                }
                catch (Exception ex)
                {
                    AppLog.Error("-", "OutboxWorker loop: " + ex.Message);
                    Wait(5000, ct);
                }
            }
        }

        private void ProcessOne(OutboxStore.OutboxItem item)
        {
            DeliveryOutcome outcome;
            try
            {
                outcome = Deliver(item);
            }
            catch (Exception ex)
            {
                outcome = new DeliveryOutcome();
                outcome.Permanent = false;
                outcome.Error = ex.Message;
            }

            if (outcome.Ok)
            {
                OutboxStore.MarkSent(item.Id);
                _breaker.OnSuccess();
                UpdateCache(item, outcome);
                AppLog.Info("-", "Outbox delivered #" + item.Id + " " + item.Kind + "/" + item.Transport + " " + item.StepName);
                Audit.Write("OUTBOX_SENT", "#" + item.Id + " job=" + item.JobName + " step=" + item.StepName +
                    " rows=" + outcome.Rows + " " + Short(item.MessageId));
            }
            else
            {
                OutboxStore.MarkFailed(item.Id, outcome.Error, MaxRetries, outcome.Permanent);
                if (!outcome.Permanent) _breaker.OnFailure();
                AppLog.Warn("-", "Outbox #" + item.Id + " delivery failed" +
                    (outcome.Permanent ? " permanently: " : ": ") + outcome.Error);
            }
        }

        private DeliveryOutcome Deliver(OutboxStore.OutboxItem item)
        {
            AppConfig cfg = _cfg;
            if (cfg == null)
            {
                DeliveryOutcome noCfg = new DeliveryOutcome();
                noCfg.Error = "OutboxWorker has no configuration.";
                return noCfg;
            }
            string t = (item.Transport ?? "Local").Trim();

            if (t.Equals("Http", StringComparison.OrdinalIgnoreCase) ||
                t.Equals("Https", StringComparison.OrdinalIgnoreCase))
                return DeliverHttp(item, cfg);

            if (t.Equals("Local", StringComparison.OrdinalIgnoreCase) ||
                t.Equals("Sql", StringComparison.OrdinalIgnoreCase) ||
                t.Equals("SqlReplay", StringComparison.OrdinalIgnoreCase))
            {
                if (!item.ReplaySafe)
                {
                    DeliveryOutcome unsafeOutcome = new DeliveryOutcome();
                    unsafeOutcome.Permanent = true;
                    unsafeOutcome.Error = "Manual replay required: the failed step uses Append mode, so automatic replay " +
                        "could duplicate rows that were already copied. Rerun the job, or change the step to Merge/SyncChanges " +
                        "or TruncateInsert for automatic outbox recovery.";
                    return unsafeOutcome;
                }
                OutboxReplayResult rr = OutboxReplay.Replay(item, cfg);
                DeliveryOutcome o = new DeliveryOutcome();
                o.Ok = rr.Ok;
                o.Permanent = rr.Permanent;
                o.Error = rr.Message;
                o.Rows = rr.Rows;
                o.Table = rr.Table;
                return o;
            }

            if (t.Equals("Kafka", StringComparison.OrdinalIgnoreCase) ||
                t.Equals("Nats", StringComparison.OrdinalIgnoreCase))
            {
                ChangeBridge.PublishHint(cfg, item);
                DeliveryOutcome o = new DeliveryOutcome();
                o.Permanent = true;
                o.Error = t + " transport is not available: the native client is not bundled in this build. " +
                           "Use Local (SQL replay) or Http, or route the payload with an external bridge.";
                return o;
            }

            DeliveryOutcome unknown = new DeliveryOutcome();
            unknown.Permanent = true;
            unknown.Error = "Unknown outbox transport: " + t;
            return unknown;
        }

        private DeliveryOutcome DeliverHttp(OutboxStore.OutboxItem item, AppConfig cfg)
        {
            DeliveryOutcome o = new DeliveryOutcome();
            if (string.IsNullOrWhiteSpace(item.DestinationUrl))
            {
                o.Permanent = true;
                o.Error = "HTTP destination URL is empty.";
                return o;
            }
            if (string.IsNullOrWhiteSpace(item.PayloadPath) || !File.Exists(item.PayloadPath))
            {
                o.Permanent = true;
                o.Error = "HTTP payload file is missing: " + item.PayloadPath;
                return o;
            }

            byte[] body;
            try { body = File.ReadAllBytes(item.PayloadPath); }
            catch (Exception ex)
            {
                o.Permanent = true;
                o.Error = "Cannot read payload: " + ex.Message;
                return o;
            }

            int timeoutMs = Math.Max(5, cfg.OutboxHttpTimeoutSec) * 1000;
            try
            {
                try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)(3072 | 768 | 192); }
                catch { }

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(item.DestinationUrl);
                req.Method = string.IsNullOrWhiteSpace(item.HttpMethod) ? "POST" : item.HttpMethod.Trim().ToUpperInvariant();
                req.Timeout = timeoutMs;
                req.ReadWriteTimeout = timeoutMs;
                req.ContentType = string.IsNullOrWhiteSpace(item.ContentType) ? "application/json; charset=utf-8" : item.ContentType;
                req.Accept = "application/json, text/plain, */*";
                req.UserAgent = "SyncDB-Outbox/34";
                req.Headers["Idempotency-Key"] = item.MessageId ?? "";
                req.Headers["X-SyncDB-MessageId"] = item.MessageId ?? "";
                AddHeaders(req.Headers, item.HttpHeaders);
                req.ContentLength = body.Length;
                using (Stream s = req.GetRequestStream())
                {
                    s.Write(body, 0, body.Length);
                    s.Flush();
                }
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                {
                    int code = (int)resp.StatusCode;
                    string text = ReadLimited(resp.GetResponseStream(), 2048);
                    o.Ok = code >= 200 && code <= 299;
                    if (!o.Ok)
                    {
                        o.Error = "HTTP " + code + " " + resp.StatusDescription + " " + text;
                        o.Permanent = IsPermanentHttpStatus(code);
                    }
                    return o;
                }
            }
            catch (WebException wex)
            {
                HttpWebResponse resp = wex.Response as HttpWebResponse;
                if (resp != null)
                {
                    using (resp)
                    {
                        int code = (int)resp.StatusCode;
                        string text = ReadLimited(resp.GetResponseStream(), 2048);
                        o.Error = "HTTP " + code + " " + resp.StatusDescription + " " + text;
                        o.Permanent = IsPermanentHttpStatus(code);
                    }
                }
                else
                {
                    o.Permanent = false;
                    o.Error = "HTTP transport: " + wex.Message;
                }
                return o;
            }
            catch (Exception ex)
            {
                o.Permanent = false;
                o.Error = "HTTP transport: " + ex.Message;
                return o;
            }
        }

        private static bool IsPermanentHttpStatus(int code)
        {
            if (code == 408 || code == 409 || code == 425 || code == 429) return false;
            return code >= 400 && code < 500;
        }

        private static void AddHeaders(WebHeaderCollection headers, string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return;
            foreach (string line in raw.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                int idx = line.IndexOf(':');
                if (idx <= 0) continue;
                string name = line.Substring(0, idx).Trim();
                string value = line.Substring(idx + 1).Trim();
                if (name.Length == 0) continue;
                if (name.Equals("Content-Type", StringComparison.OrdinalIgnoreCase) ||
                    name.Equals("Content-Length", StringComparison.OrdinalIgnoreCase) ||
                    name.Equals("Host", StringComparison.OrdinalIgnoreCase)) continue;
                try { headers[name] = value; } catch { }
            }
        }

        private static string ReadLimited(Stream stream, int max)
        {
            if (stream == null) return "";
            try
            {
                using (StreamReader r = new StreamReader(stream, Encoding.UTF8))
                {
                    char[] buf = new char[max];
                    int n = r.Read(buf, 0, buf.Length);
                    return n > 0 ? new string(buf, 0, n) : "";
                }
            }
            catch { return ""; }
        }

        private void UpdateCache(OutboxStore.OutboxItem item, DeliveryOutcome outcome)
        {
            if (string.IsNullOrEmpty(item.JobId)) return;
            try
            {
                AppConfig cfg = _cfg;
                string table = string.IsNullOrWhiteSpace(outcome.Table) ? (item.StepName ?? "") : outcome.Table;
                CacheStoreFactory.Current.SetLastSuccess(item.JobId, table, new SyncStateInfo
                {
                    JobId = item.JobId,
                    Table = table,
                    LastSuccessUtc = DateTime.UtcNow,
                    LastMessage = "Outbox delivered #" + item.Id + " (" + item.Transport + ")",
                    RowsAffected = outcome.Rows,
                    Direction = "Forward",
                    OriginId = cfg != null ? cfg.OriginId : ""
                });
            }
            catch { }
        }

        /// <summary>Wait for the idle interval, but return early on stop or ProcessNow. Returns true when cancelled.</summary>
        private bool Wait(int ms, CancellationToken ct)
        {
            if (ct.IsCancellationRequested) return true;
            try
            {
                int idx = WaitHandle.WaitAny(new WaitHandle[] { ct.WaitHandle, _wake }, Math.Max(10, ms));
                return idx == 0;
            }
            catch
            {
                Thread.Sleep(Math.Max(10, ms));
                return ct.IsCancellationRequested;
            }
        }

        private static string Short(string s)
        {
            return string.IsNullOrEmpty(s) ? "" : (s.Length > 12 ? s.Substring(0, 12) + "…" : s);
        }

        public void Dispose()
        {
            Stop();
            try { _wake.Close(); } catch { }
        }
    }

    /// <summary>Thread-safe circuit breaker used by <see cref="OutboxWorker"/>.</summary>
    public sealed class CircuitBreaker
    {
        private readonly int _failureThreshold;
        private readonly TimeSpan _openDuration;
        private int _failures;
        private bool _open;
        private bool _halfOpen;
        private DateTime _openUntilUtc = DateTime.MinValue;
        private readonly object _gate = new object();

        public CircuitBreaker(int failureThreshold, TimeSpan openDuration)
        {
            _failureThreshold = Math.Max(1, failureThreshold);
            _openDuration = openDuration <= TimeSpan.Zero ? TimeSpan.FromSeconds(60) : openDuration;
        }

        public int FailureCount
        {
            get { lock (_gate) return _failures; }
        }

        /// <summary>True while calls must be skipped. After the open window it allows one half-open probe.</summary>
        public bool IsOpen
        {
            get
            {
                lock (_gate)
                {
                    if (!_open) return false;
                    if (DateTime.UtcNow >= _openUntilUtc)
                    {
                        _open = false;
                        _halfOpen = true;
                        return false;
                    }
                    return true;
                }
            }
        }

        public bool IsHalfOpen
        {
            get { lock (_gate) return _halfOpen; }
        }

        public void OnSuccess()
        {
            lock (_gate)
            {
                _failures = 0;
                _open = false;
                _halfOpen = false;
            }
        }

        public void OnFailure()
        {
            lock (_gate)
            {
                _failures++;
                if (_halfOpen || _failures >= _failureThreshold)
                {
                    _open = true;
                    _halfOpen = false;
                    _openUntilUtc = DateTime.UtcNow + _openDuration;
                }
            }
        }

        public void Reset()
        {
            lock (_gate)
            {
                _failures = 0;
                _open = false;
                _halfOpen = false;
                _openUntilUtc = DateTime.MinValue;
            }
        }
    }
}
