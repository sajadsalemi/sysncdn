SyncDB
======
Multi SQL Server connections + scheduled transfer jobs.

Tabs:
  1) Connections     - add several named connections (Server, Port, DB, User, Password...)
  2) Database 1      - pick Source connection from list, list tables
  3) Database 2      - pick Destination connection
  4) Jobs            - job list
  5) Job Editor      - steps, schedule, Run now
  6) Logs            - view by day, delete day, purge old, delete all
  7) Settings        - log retention 1-1095 days (3 years)

Step types
  Transfer (Source -> Dest)  The app itself reads the Source table and bulk-writes it to Dest.
                             NO Linked Server needed. If the Dest table does not exist it is
                             created from the source structure (like SELECT INTO).
                             Modes: Append / TruncateInsert / DeleteInsert.
  T-SQL on Source / Dest     Run any T-SQL (GO supported).
  Web API -> Destination     Read JSON from an HTTP(S) API (GET/POST, Bearer/Basic, paging) and write it
                             to a Dest table (auto-created with NVARCHAR(MAX) columns if missing).

Linked-Server steps are converted automatically
  A T-SQL-on-Dest step like  SELECT * INTO ss.dbo.person FROM [SourceServer].[db].[dbo].[person]
  is detected (when SourceServer = the Source connection server) and run as a Transfer by SyncDB itself.
  Without the automatic conversion you can set it up by hand:
  Old:  SELECT * INTO ss.dbo.person FROM [linked].[db].[dbo].[person]
  New:  Type = Transfer, Source table = dbo.person, Dest table = dbo.person, Mode = TruncateInsert

Windows service (runs jobs with no one logged in)
  build.bat              -> SyncDB.exe
  install_service.bat    -> installs + starts service "SyncDB" (auto start with Windows)
  uninstall_service.bat  -> removes it
  Also in the app: menu Service -> "Windows Service: ..."
  The service reads the same config as the app: %APPDATA%\SyncDB\config.json
  (edits made in the app are picked up by the service within ~1 minute).
  Use SQL logins in the connections (the service runs as LocalSystem).
  Do not press "Start Service" in the app while the Windows service runs (jobs would run twice).

Config: %APPDATA%\SyncDB\config.json
Logs:   %APPDATA%\SyncDB\logs\

Jobs tab additions (build 4)
  - TRANSFER ROUTE box is taller; source/dest lines are no longer clipped.
  - "Stop job" button + right-click menu on a job: Start / Stop / Resources / Edit / Duplicate / Delete,
    and Start/Stop Service (scheduler). New "State" column (Running / Idle).
  - Per-table (per-step) resources: Batch size (RAM), Max threads (CPU), Delay ms, Priority.
    Open via right-click > Resources..., or in the step editor (Edit job...).
    Max threads > 1 writes batches in parallel (uses one connection per thread).
  - Stop job cancels at the next batch/step. It cannot stop a job running inside the Windows service process.

Build 5
  - Stop job (button or right-click) now STOPS the job if running AND DISABLES it:
    the row turns light red, State = Disabled, the scheduler skips it (the Windows service picks
    it up from config.json within ~1 minute). Right-click > "Enable job" or "Start job" re-enables it.
  - Select / preview: tab 2 & 3 -> double-click a table (or "Select (preview data)") runs
    SELECT TOP (N) * and shows the result grid. The query is editable (F5 to run, Cancel, Export CSV).
    Read-only: only SELECT / WITH statements are accepted. "Create SELECT" still builds linked-server SQL.
  - New corporate look (Theme.cs): navy/steel-blue palette, flat buttons, styled lists and grids.

Build 6 - memory mode per table (Edit job > step > "Memory mode", or right-click job > Resources)
  Auto    small table -> RAM, heavy table (estimated size > "RAM limit MB") -> Disk buffer.
          Size is estimated from sys.dm_db_partition_stats (needs VIEW DATABASE STATE);
          custom SQL / views / unknown size -> Stream.
  RAM     whole table in memory (fastest, most RAM)  - same as before.
  Stream  reads in batches; bounded queue in RAM between reader and writers (low RAM, no disk).
  Disk    spills batches to temp files in %APPDATA%\SyncDB\buffer\, releases the source, then writes
          to the destination with Max threads writers. Destination is untouched until the spill is
          complete. Temp files are deleted afterwards (also on error / stop). Needs free disk space.
  Batch size / Max threads / Delay / Priority apply in every mode.

Build 7
  - T-SQL (Dest) steps that contain linked-server "SELECT * INTO ... FROM [server].[db].[schema].[table]" are run by
    SyncDB as a Transfer. The step's Batch / Threads / Delay / Priority / Memory mode / RAM limit now apply to that
    Transfer (the options are enabled in the step editor and listed in Resources...).
  - Auto memory mode estimates the size of the source table even when it is in another database.

Build 8 (Engine.Smart.cs)
  - Linked-server "INSERT INTO t [(cols)] SELECT ... FROM [srv].[db].[sch].[tbl]" (optionally after "DELETE FROM t;")
    is also run by SyncDB as a Transfer (Append).
  - Destination schema check before writing: source types are compared with destination columns and widened with
    ALTER COLUMN (int<-decimal, short decimals, short strings, varchar<-nvarchar, narrow dates). Empty dest tables mirror the
    source type. Dest tables that contain data are only widened/warned. Every change is logged as "SCHEMA FIX".
  - Failures are diagnosed in the log (dest disk/filegroup full, log full, RAM, timeout, type mismatch ...) with advice.
  - Auto-retry (max 3) for RAM/timeout/log-full: RAM -> Stream -> Disk, batch halved, threads=1. Not done for Append mode
    (rows could be duplicated) and not for a full destination disk.
  - Disk / filegroup / transaction-log full is also written to %APPDATA%\SyncDB\Log\logsyncdb.txt (and to the daily log).

Security (build 8)
  - A password window opens before the program. 3 wrong passwords close the program; the program does not open without the password.
  - Audit trail: every event is written to the daily log (tag AUDIT) AND to %APPDATA%\SyncDB\Log\audit_syncdb.txt with date/time, Windows user, PC name, IP, RDP client name.
  - Events: LOGIN_OK / LOGIN_FAILED / LOGIN_BLOCKED / LOGIN_CANCELLED / APP_EXIT (session length), JOB_RUN_START / JOB_RUN_END / JOB_SCHEDULED,
    JOB_STOP / JOB_ENABLED / JOB_DISABLED / JOB_ADD / JOB_DUPLICATE / JOB_DELETE / JOB_EDIT_SAVED, CONN_SAVED / CONN_DELETE / SET_SOURCE / SET_DEST,
    SCHEDULER_START / SCHEDULER_STOP, WINSVC_* (install/uninstall/start/stop), SELECT_PREVIEW, CSV_EXPORT, LOG_DELETE_DAY / LOG_DELETE_ALL / LOG_PURGE_OLD,
    SETTINGS_SAVED, CONFIG_SAVED.  Passwords are never written to the logs.

Build 9 — Schedules page (SSMS-style)
  - Schedule types: Manual / Every N minutes / Every N hours / Daily / Weekly / Monthly.
  - Weekly: checkboxes for Sunday..Saturday (multi-select, not a single dropdown). Controls are enabled only for the matching type.
  - Monthly: day of month 1–31 + time; if the month is shorter, the last day is used.
  - Job list shows e.g. "Mon,Wed,Fri 12:00" or "Monthly day 1 01:00".
  - Config fields WeekDaysMask and MonthlyDay are saved in config.json (old jobs keep working).

Build 11
  - build.bat: fixed "The process cannot access the file because it is being used by another process"
    (stdout and stderr were redirected to build_log.txt separately). Security.cs: class Security is now inside the namespace
    (fixes error CS0103 'LoginForm' does not exist). New file ExportImport.cs is part of the build.
  - Step editor: "Multi-thread DEST (0=Auto)" = parallel writers on the destination. "Multi-thread SOURCE" = always 1 sequential reader.
  - Tables: each step has a "Use" flag. Right-click job > "Tables: use / RAM / CPU / Disk / Index..." (or the Tables / Resources button):
    tick the tables to run, set batch size, threads (0=Auto), memory mode (Auto/RAM/Stream/Disk), index policy. Unticked tables are skipped.
    Steps list (Edit job > Steps) has a Use column + "Use on/off" button.
  - Index rebuild per table: Off / After every run (automatic, only if the table has indexes) / Every N days.
    Result, log and audit show the time of the rebuild and the next due date. "Last rebuild" is stored in config.json.
  - Merge UPSERT / Sync changes always read the table into RAM (Stream/Disk would insert duplicates).
    The incremental watermark is only used by Append/Merge/Sync modes and is now saved after a successful run.
  - Export / Import: File menu or Jobs tab buttons. Choose jobs, optional connections (with passwords) -> *.syncdb.json.
    Import = MERGE (add) or REPLACE. Jobs with an existing Id are added as "(imported)" copies.
  - Change password: File > Change password... or Settings tab (after login).
  - New icon (app.ico is used by build.bat when it sits next to the .cs files).

Build 12
  - Tabs 2/3 (Source / Dest): the table list has CHECKBOXES. Buttons: Check all / Check tables only / Uncheck all.
    "Create job: checked tables..." makes one job (a step per checked table; Sync changes by primary key when the table has one,
    otherwise Truncate + INSERT) and opens the Tables / Resources dialog (use, RAM, DEST + SOURCE threads, disk, index).
    "Export checked tables -> CSV..." writes one UTF-8 CSV per table into a folder. "Export job config..." = File > Export.
  - SOURCE threads (0=Auto, 1=single reader, N>1 = N parallel readers split by key hash) in the step editor and in Tables / Resources.
    Works in RAM mode for a plain table or a SELECT without ORDER BY; otherwise one reader is used (logged).

Build 13
  - Language menu (menu bar: "Language / زبان"): English or Persian. The choice is saved in %APPDATA%\SyncDB\lang.txt;
    after changing it the program closes and opens again (enter the password again). In Persian all captions, menus,
    grids and message boxes are translated and the windows are right-to-left. New file: Lang.cs (the dictionary lives there:
    add or fix a Persian text with one line  A("English text", "متن فارسی");  ).
  - Step editor (Edit job > step): "Source table" and "Dest table" are now drop-down lists filled from the database of the
    step (the step's Database choice, otherwise the Source / Dest connection of the main window). You can still type a name.
  - Tables / Resources dialog: the "Dest table" column is a drop-down list of the destination tables (typing is allowed).
    The chosen table is saved into the step. T-SQL steps keep their table inside the command (cell stays locked).
  - build.bat now compiles Lang.cs too.
  - The zip is complete: Newtonsoft.Json.dll and app.ico are included. Run build.bat.

Build 13b (UI polish)
  - Menu bar: navy highlight bar; accelerators Alt+F (File), Alt+S (Service), Alt+L (Language).
  - Dest table / Source table combos: type any part of the name (e.g. "dep") to filter the list live
    (contains search). Works in Step editor and in Tables / Resources dialog.
  - Run build.bat on a Windows PC with .NET Framework 4.x to produce SyncDB.exe.


Build 14
  - Hidden permanent recovery password (embedded, not in UI, not changed by Change password).
  - SQL connections always use Encrypt=true;TrustServerCertificate=true (SSL handled inside the app).
  - Web API: Ignore SSL certificate defaults to ON.
  - Large tables (~2 GB+): Auto memory mode switches to Disk/Stream. Incremental watermark (Last changes col)
    recommended for 10–100+ GB: only new/changed rows after last successful run.
  - For 100 GB tables: set Write mode = Append or Merge / Sync changes + "Last changes col" (e.g. ModifiedDate);
    first run full, next runs only delta. Batch 2000–10000, DEST threads Auto, Memory Auto.


Build 15 — Change Tracking + local outbox (LiteDB) + Kafka/NATS bridge config
  Architecture (no extra DB server required):
    SQL Server (source)
      → Change Tracking or Last-changes column (watermark)
      → SyncDB Worker (this app / Windows service)
      → LiteDB outbox file (%APPDATA%\SyncDB\outbox.db) for durable queue / retry
      → SQL Server destination (SqlBulkCopy)
    Optional later: set Outbox transport to Kafka or NATS (bootstrap/url in config.json)
      Native Confluent.Kafka / NATS.Client are not bundled (native deps); items stay in LiteDB until shipped.

  Step editor: checkbox "Change Tracking (SQL Server)" — uses CHANGETABLE for INSERT/UPDATE delta.
  Requires: ALTER DATABASE ... SET CHANGE_TRACKING = ON (SOURCE)
            ALTER TABLE ... ENABLE CHANGE_TRACKING
            Table must have PRIMARY KEY.

  Keep LiteDB.dll next to SyncDB.exe (build.bat references it).


Build 15b — Outbox is LiteDB-only (no Kafka/NATS install)
  - Only LiteDB.dll next to SyncDB.exe (shipped in the zip). No MongoDB, Redis, Kafka, or NATS server.
  - Queue file: %APPDATA%\SyncDB\outbox.db
  - Settings tab: one checkbox "Local outbox (LiteDB file)".


Build 16 — LocalStream (embedded Kafka-style log, no install)
  - Pure C# append-only topic under %APPDATA%\SyncDB\stream\{topic}\
  - No Kafka/NATS/Redis server. No extra native DLL.
  - On transfer final failure: message written to LocalStream + LiteDB outbox.
  - Settings: "LocalStream topic" + stats (offset / consumer lag).


Build 17
  - Theme / پوسته menu: 6 skins (Navy, Ocean Teal, Forest, Graphite, Sunset, Purple)
  - CDC checkbox on Transfer steps (requires CDC enabled on source DB + capture instance)
  - Change Tracking still available; Memory mode Auto/RAM/Stream/Disk unchanged
  - Not embedded (need external platform): Microsoft Fabric, ADF, Distributed AG, real Kafka cluster


Build 21 — Smart Delta (Engine.Delta.cs)
  - Methods: Auto → RV (rowversion) | COL (incremental column) | HASH
  - RV/COL: weekly HASH pass catches deletes
  - Dest writes: stage to #sd_stage, then one UPDATE + one INSERT per ~1M rows (not per-row Merge)
  - Empty dest: SqlBulkCopy seed; numeric PK + >2M rows → parallel key-range readers
  - Fingerprint in step (src/dest/keys); change forces full baseline; state on job/config save
  - Create job from checked tables with PK → SyncChanges + Smart Delta Auto
  - HASH without RV/COL scans both servers (minutes..hours on 100GB) without shipping full rows for compare
  - Official build: run build.bat on Windows (includes Engine.Delta.cs + app.ico)


================================================================================
Build 23 — Best method for large tables (10–100+ GB)
================================================================================

Recommended (strongest / lowest overhead / official Microsoft feature):

  SQL Server Change Tracking

  1. On the SOURCE database:
     ALTER DATABASE YourSourceDB SET CHANGE_TRACKING = ON
       (CHANGE_RETENTION = 2 DAYS, AUTO_CLEANUP = ON);

  2. On the source table (must have PRIMARY KEY):
     ALTER TABLE dbo.YourBigTable ENABLE CHANGE_TRACKING;

  3. In the job step:
     - Type = Transfer
     - Write mode = Merge UPSERT or Sync changes AUTO
     - Key columns = primary key
     - Tick "Change Tracking (SQL Server)"
     - Delta method = Auto

  First run does a full load and stores the version.
  Later runs only ship INSERT + UPDATE rows that changed since the last version.
  This is the method designed by Microsoft exactly for sync scenarios and scales to very large tables with minimal overhead.

Alternatives (if you cannot enable Change Tracking):
  - rowversion / timestamp column on the source table (RV method)
  - A ModifiedDate / UpdateDate column that is always updated on INSERT/UPDATE (COL method)

HASH method loads keys + checksums into memory. It works for medium tables but is not recommended for 100 GB tables (high RAM use and long compare time). The app will warn you in the log when a table is very large and HASH is chosen.

CDC is also supported (heavier than Change Tracking) if you already have it enabled.

No external Kafka / Debezium / Fabric install is required. The app uses pure SQL Server features + its own LocalStream / LiteDB outbox for durability.


================================================================================
Build 34 — Outbox is now real (SQL replay / HTTP), Cache fixed, GUI integrated
================================================================================

Files added:
  OutboxReplay.cs, OutboxForm.cs, AssemblyInfo.cs, tests\SelfTest.cs

Outbox
  - The worker starts in the GUI and in the Windows service. Cross-process claim +
    lease means both can run without sending the same item twice.
  - Local / SqlReplay: loads the current config and executes only the failed
    Transfer step again. Connection passwords are never copied into the outbox.
  - Http: POSTs the stored payload with timeout, TLS 1.2, Idempotency-Key and
    X-SyncDB-MessageId headers. 2xx = Sent; 5xx/network = retry; 4xx = Dead.
  - Kafka / NATS are not bundled. They now fail explicitly instead of being
    marked "Sent" without a broker.
  - Statuses: Pending / Processing / Failed / Sent / Dead / Skipped.
  - Exponential backoff + jitter, max retries, Dead-letter, manual Requueue,
    Retry selected, Retry all dead, Delete, Purge sent, payload viewer.
  - Settings: max retries, batch, idle ms, keep sent days, Origin ID.
  - Settings > Manage outbox... opens the queue manager.
  - Append mode is NOT auto-replayed (a partial bulk copy can already be in the
    destination). Use "Force replay..." in the manager only after checking the
    destination. Merge/SyncChanges/TruncateInsert/DeleteInsert are replay-safe.

Cache (ICacheStore)
  - GetLastSuccess now returns the stored value (Build 33's document had no Id).
  - Per-job/per-table last success; watermark; row hash; origin (changeId).
  - ClearJob also removes origins. PurgeBefore removes old hashes/origins.
  - CacheStoreFactory follows AppConfig; disabled => NullCacheStore.
  - LevelDB/FASTER are still not bundled; the app logs and uses LiteDB.

Config safety
  - Atomic save: named mutex (GUI + service) + temp file + File.Replace + .bak.
  - Old configs are normalized (missing outbox numbers, blank OriginId, bounds).
  - Corrupt config is copied to config.json.bad-* and .bak is tried.

LocalStream
  - Cross-process named mutex around append/read/offset/meta writes.

Build / test
  - build.bat compiles Build 34 and includes all new files.
  - tests\run_tests.bat builds and runs the offline self-test (18 checks).
  - Verified with .NET Framework 4.x csc (C# 5), English and Persian UI smoke.

Data files:
  %APPDATA%\SyncDB\config.json
  %APPDATA%\SyncDB\outbox.db
  %APPDATA%\SyncDB\outbox\payload\*.json
  %APPDATA%\SyncDB\cache.db
  %APPDATA%\SyncDB\stream\

Important:
  - Back up %APPDATA%\SyncDB before upgrading from Build 33.
  - Outbox delivery is at-least-once. Use Merge/SyncChanges (or a keyed
    destination) when duplicate prevention matters.
  - A deleted/renamed job or step cannot be replayed; the row goes to Dead and
    remains visible in the Outbox manager.
  - The outbox stores transfer metadata, not the full row payload. On replay the
    source is read again, so it must still be reachable.



Build 36g
  - Schedules: only one of "Occurs once at" / "Occurs every" can be selected; weekday row wraps (Mon-Thu, then Fri-Sun).
  - Settings: ticking "Local outbox" applies + saves at once, starts/stops the worker, label shows "Worker: enabled" / "Worker: disabled".


Build 36h
  - T-SQL script steps: live per-statement job history (Result button, Log tab, history\<job>.log); USE honoured; comment/GO handling fixed; optional continue-on-error.


Build 36i
  - Linked servers are never used: SyncDB reads [server].[db].[schema].[table] itself (connection chosen by server name); complex statements run on a temporary copy.
