# تحلیل SyncDB Build 33 و گزارش تکمیل‌شدهٔ Build 34

## 1) خلاصهٔ اجرایی

Build 33 از نظر کامپایل سالم بود؛ سورس با `csc.exe` (C# 5 / .NET Framework 4.x) بدون خطا build شد. اما لایهٔ `Outbox` در عمل یک «پایهٔ اولیه» بود، نه یک صف پایدار قابل اتکا:

- Worker در GUI اصلاً اجرا نمی‌شد و فقط سرویس ویندوز آن را start می‌کرد.
- تحویل Local همیشه «موفق» تلقی می‌شد، بدون این‌که چیزی به SQL تحویل شود.
- Kafka/NATS هم بدون کلاینت و بدون بروکر «موفق» ثبت می‌شدند.
- در خطای انتقال، `JobId` اشتباه (نام Step) و Payload خالی صف می‌شد.
- `MessageId` شامل `DateTime.UtcNow.Ticks` بود؛ یعنی ادعای Idempotency در عمل برقرار نبود.
- هیچ Claim/Lease ای نبود؛ اجرای هم‌زمان GUI و سرویس می‌توانست یک پیام را دوبار تحویل دهد.
- `ICacheStore.GetLastSuccess` همیشه `null` برمی‌گرداند (سند ذخیره‌شده `Id` نداشت).
- مقایسهٔ تاریخ‌های LiteDB با `DateTime.UtcNow` به‌خاطر Kind=Local، در تهران حدود ۳:۳۰ ساعت تأخیر ایجاد می‌کرد.
- `config.json` به‌صورت غیر Atomic ذخیره می‌شد و GUI/سرویس می‌توانستند آن را خراب کنند.

در Build 34 این موارد تا حد امکان تکمیل و اصلاح شده‌اند. خروجی شامل سورس، `SyncDB.exe` ساخته‌شده، DLLهای لازم، تست‌ها و همین گزارش است.

## 2) روش بررسی

1. استخراج و مرور کامل ۲۱ فایل سورس (حدود ۱۸٬۰۰۰ خط).
2. Build خط فرمان با همان `csc.exe` و همان referenceهای `build.bat`.
3. ساخت Probeهای جداگانه برای بازتولید باگ‌ها (LiteDB DateTime، Cache، Claim).
4. نوشتن ۱۸ تست خودکار برای Cache، Outbox، Backoff، Dead-letter، HTTP، Config و هم‌زمانی دو Worker.
5. UI Smoke در حالت انگلیسی و فارسی (راست‌به‌چپ).
6. بررسی اتصال به SQL Server محلی برای تست End-to-End. نصب SQL Server وجود داشت، اما احراز هویت Windows/SSPI در این محیط خطای `Cannot generate SSPI context` داد و رمز `sa` در دسترس نبود؛ بنابراین تست SQL زنده انجام نشد (جزئیات در بخش محدودیت‌ها).

## 3) یافته‌ها و وضعیت رفع

| # | شدت | یافته | وضعیت در Build 34 |
|---|-----|-------|-------------------|
| 1 | بحرانی | `OutboxWorker` در `MainForm` ساخته/Start نمی‌شد | رفع شد؛ در GUI و سرویس Start می‌شود |
| 2 | بحرانی | `Deliver` محلی فقط وجود فایل را چک می‌کرد و همیشه `true` برمی‌گرداند | رفع شد؛ Replay واقعی همان Job/Step در SQL |
| 3 | بحرانی | Kafka/NATS بدون کلاینت «Sent» می‌شدند | رفع شد؛ صریحاً Dead با دلیل روشن |
| 4 | بحرانی | در `Engine.Smart` به‌جای JobId، `step.Name` ذخیره می‌شد؛ Payload خالی بود | رفع شد؛ JobId/StepId واقعی + Payload JSON امن |
| 5 | بحرانی | `MessageId` با Ticks یکتا می‌شد و Idempotency نداشت | رفع شد؛ SHA-256 پایدار + ایندکس Unique |
| 6 | بحرانی | `GetLastSuccess` به‌خاطر نداشتن `Id` همیشه NULL بود | رفع شد؛ `StateDoc` با `_id` واقعی |
| 7 | بحرانی | مقایسهٔ DateTime محلی LiteDB با UTC؛ Retry تا ۳:۳۰ ساعت دیر می‌شد | رفع شد؛ نرمال‌سازی `ToUniversalTime()` در همهٔ مقایسه‌ها |
| 8 | بالا | بدون Claim/Lease؛ تحویل تکراری بین دو Worker ممکن بود | رفع شد؛ `TryClaim` تراکنشی + Lease + ReleaseStale |
| 9 | بالا | `config.json` غیر Atomic؛ احتمال خرابی با GUI + سرویس | رفع شد؛ Mutex بین‌پروسسی + Temp/Replace + `.bak` |
| 10 | بالا | Dead-letter هیچ UI/Retry/Purge نداشت | رفع شد؛ فرم مدیریت Outbox |
| 11 | بالا | Replay خودکار Append می‌توانست ردیف‌های تکراری بسازد | مسدود شد؛ فقط با «Force replay…» و تأیید خطر |
| 12 | متوسط | `ListReady` قبل از فیلتر Due، Limit می‌زد (Starvation) | رفع شد؛ فیلتر در حافظه + مرتب‌سازی بر اساس Due |
| 13 | متوسط | Backoff اول ۱۰ ثانیه بود (به‌جای ۵) و Jitter نداشت | رفع شد؛ ۵s، ۱۰s، ۲۰s … با سقف ۱۵ دقیقه + Jitter |
| 14 | متوسط | `ClearJob` رکوردهای Origin را پاک نمی‌کرد | رفع شد |
| 15 | متوسط | `IsOriginLocal` مقدار Origin را مقایسه نمی‌کرد | رفع شد؛ Overload دقیق با OriginId |
| 16 | متوسط | `CacheStoreFactory` تنظیمات Cache را نادیده می‌گرفت | رفع شد؛ `Configure` + `NullCacheStore` |
| 17 | متوسط | `LocalStream` فقط Lock درون‌پروسسی داشت | رفع شد؛ Named Mutex بین GUI/سرویس |
| 18 | متوسط | مقادیر جدید Config در فایل‌های قدیمی صفر می‌ماند | رفع شد؛ `Normalize()` با Clamp و Default |
| 19 | کم | UI برای مشاهده/مدیریت صف نبود | رفع شد؛ Settings + OutboxForm |
| 20 | کم | آمار Outbox فقط یک‌بار هنگام باز شدن Settings به‌روز می‌شد | رفع شد؛ Refresh دوره‌ای |

## 4) آنچه در Build 34 اضافه/اصلاح شد

### 4-1) تحویل واقعی Outbox

سه مسیر تحویل:

1. **Local / SqlReplay**
   - `config.json` فعلی خوانده می‌شود.
   - همان Job و همان Step (بر اساس Id) پیدا می‌شود.
   - فقط همان Step از طریق `Engine.ExecuteOutboxReplay` اجرا می‌شود.
   - رمز اتصال هرگز داخل `outbox.db` یا Payload نوشته نمی‌شود.
   - Stateهای Delta (Watermark، ChangeTrackingVersion، CDC LSN، Fingerprint، LastHashFullUtc) بعد از موفقیت در config ذخیره می‌شوند.
   - برای جلوگیری از زنجیرهٔ بی‌نهایت، هنگام Replay پرچم `_suppressOutbox` فعال است.

2. **Http**
   - Payload فایل JSON با `POST` ارسال می‌شود.
   - هدرهای `Idempotency-Key` و `X-SyncDB-MessageId` خودکار اضافه می‌شوند.
   - Timeout، TLS 1.2، هدرهای دلخواه و محدودیت اندازهٔ خواندن پاسخ.
   - 2xx موفق؛ 5xx/شبکه/Timeout قابل Retry؛ 4xx دائمی و Dead.

3. **Kafka / NATS**
   - هیچ کلاینت Native همراه برنامه نیست.
   - این مقصدها دیگر «موفق» علامت نمی‌خورند؛ یک‌بار Dead می‌شوند و دلیل در UI دیده می‌شود.

### 4-2) وضعیت‌ها و چرخهٔ عمر

`Pending → Processing → Sent`

`Pending/Failed → Processing → Failed → … → Dead`

`Dead/Failed → (Retry) → Pending`

`Pending/Failed → Skipped` (Loop prevention)

- `Processing` دارای `ProcessingStartedUtc` و Lease است.
- اگر Worker از بین برود، `ReleaseStale` بعد از Lease آن را آزاد می‌کند.
- `Sent/Skipped` بعد از N روز (پیش‌فرض ۷) Purge می‌شوند.
- `Dead` به‌صورت دستی قابل Retry است؛ Attempts صفر می‌شود.

### 4-3) ایمنی داده در Replay

- `MergeUpsert` / `SyncChanges` / `TruncateInsert` / `DeleteInsert`: Replay خودکار.
- `Append`: Replay خودکار **نه**؛ چون ممکن است چند Batch قبلاً Commit شده باشد.
- دکمهٔ **Force replay…** در فرم Outbox برای Append وجود دارد، اما با هشدار صریح و ثبت در Audit.
- این رفتار در README و CHANGES توضیح داده شده است.

### 4-4) ICacheStore

- `StateDoc` واقعی با `Id = jobId|table`.
- `GetLastSuccess(jobId)` و `GetLastSuccess(jobId, table)`.
- Watermark عددی برای Change Tracking.
- Row Hash و Origin با کلید مرکب.
- `ClearJob` حالا Watermark، Hash، State و Originهای همان Job را پاک می‌کند.
- `PurgeBefore` برای Hash/Originهای قدیمی.
- `NullCacheStore` برای وقتی Cache خاموش است.
- `CacheStoreFactory.Configure(cfg)` از تنظیمات پیروی می‌کند.

### 4-5) امنیت و پایداری Config

- `Save()`:
  - Named Mutex `Local\SyncDB.Config.<hash>` برای GUI و سرویس.
  - نوشتن در فایل Temp.
  - `File.Replace` (Atomic) و Fallback.
  - نسخهٔ قبلی در `config.json.bak`.
- `Load()`:
  - سه بار Retry برای فایل‌های در حال Replace.
  - کپی فایل خراب به `config.json.bad-*`.
  - تلاش برای بازیابی از `.bak`.
  - `Normalize()` مقادیر خالی/خارج از بازه را اصلاح می‌کند.

### 4-6) UI

- تب Settings:
  - تعداد Retry، Batch، Idle، Keep sent days، Origin ID.
  - وضعیت زندهٔ Worker.
  - دکمه‌های Manage outbox… و Process outbox now.
- فرم `Outbox / Dead-letter queue`:
  - فیلتر Status.
  - نمایش Job/Step/Transport/Error.
  - Retry selected / Retry all dead / Force replay / Delete / Purge / Details / Open payload.
  - Refresh خودکار هر ۵ ثانیه.
- ترجمهٔ فارسی برچسب‌های جدید و بررسی RTL.

## 5) تست‌ها

فایل `tests\SelfTest.cs` (قابل اجرا با `tests\run_tests.bat`) شامل ۱۸ تست است:

1. Cache state round-trip
2. Cache origin exact match + ClearJob
3. Cache purge
4. Outbox MessageId stability
5. Outbox enqueue dedupe
6. Outbox claim/lease
7. Retry → Dead → Requeue
8. Completed purge
9. Config normalize + atomic save
10. Config step-state merge
11. HTTP delivery 2xx
12. HTTP 5xx سپس موفقیت
13. HTTP 4xx دائمی → Dead
14. Loop prevention بر اساس TargetOrigin
15. Failure payload + metadata
16. Replay با Job حذف‌شده → Dead
17. دو Worker هم‌زمان، بدون تحویل تکراری HTTP
18. Cache provider disable

نتیجه در محیط بررسی: **هر ۱۸ تست PASS** و UI Smoke انگلیسی/فارسی **PASS**.

نکته: تست شمارهٔ 17 با دو `OutboxWorker` واقعی روی یک دیتابیس انجام شد و تعداد درخواست‌های HTTP دقیقاً برابر تعداد آیتم‌ها بود.

## 6) محدودیت‌ها و چیزهایی که عمداً انجام نشده

1. **تست SQL زنده انجام نشد.**
   - SQL Server محلی در دسترس بود، اما Windows Auth با خطای SSPI و بدون رمز `sa` قابل استفاده نبود.
   - کد SQL Replay کامپایل شده و منطق آن تا مرحلهٔ Resolve Job/Step تست شده، ولی تحویل واقعی به یک دیتابیس SQL در این محیط اجرا نشد.
   - پیشنهاد: قبل از Production، یک Job کوچک با `MergeUpsert` بسازید، عمداً Dest را قطع کنید، سپس از Settings > Manage outbox… دکمهٔ Retry را بزنید.

2. **Payload ردیفی ذخیره نمی‌شود.**
   - Outbox فقط متادیتای Job/Step/Payload JSON را نگه می‌دارد و هنگام Replay دوباره از Source می‌خواند.
   - برای این‌که Replay معنی داشته باشد، Source باید در دسترس و داده‌ها پایدار باشند. این برای Merge/SyncChanges طراحی شده است.

3. **Append خودکار Replay نمی‌شود.**
   - دلیل: احتمال ردیف تکراری بعد از BulkCopy نیمه‌کاره.
   - راه‌حل: `MergeUpsert`/`SyncChanges` یا Force replay بعد از بررسی Dest.

4. **Kafka/NATS توکار نیست.**
   - اگر واقعاً لازم است، باید کلاینت Native اضافه شود یا از یک Bridge خارجی به HTTP استفاده شود.

5. **Row Hash در Delta هنوز مصرف نمی‌شود.**
   - API آن کامل و تست‌شده است، اما موتور Smart Delta از Watermark/CT/CDC خودش استفاده می‌کند. این مورد برای فاز «سینک دوطرفه» باقی می‌ماند.

6. **Outbox تضمین Exactly-once نمی‌دهد.**
   - تحویل At-least-once است. برای HTTP هدر Idempotency-Key و برای SQL باید Key/Merge داشته باشید.

7. **صف بسیار بزرگ.**
   - `ListReady` برای اطمینان از صحت تاریخ‌ها، رکوردهای Pending/Failed را در حافظه فیلتر می‌کند. برای صف‌های چندصدهزارتایی بهتر است فیلد `NextAttemptTicks` و Query ایندکس‌شده اضافه شود.

8. **LevelDB/FASTER**
   - همراه برنامه نیستند؛ در صورت انتخاب، برنامه لاگ می‌دهد و از LiteDB استفاده می‌کند.

## 7) ارتقا از Build 33

قبل از اجرا:

1. سرویس ویندوز را Stop کنید.
2. از کل پوشهٔ `%APPDATA%\SyncDB` بکاپ بگیرید (config، outbox.db، cache.db، logs).
3. فایل‌های Build 34 را جایگزین کنید؛ DLLها را کنار `SyncDB.exe` نگه دارید.
4. یک‌بار برنامه را باز کنید تا `config.json` با فیلدهای جدید Normalize شود.
5. اگر Outbox قدیمی دارید، در Settings > Manage outbox… وضعیت آن را ببینید. آیتم‌های قدیمیِ Append عمداً Dead/manual هستند.

## 8) ساخت

```bat
build.bat
```

خروجی: `SyncDB.exe` در همان پوشه.

تست‌ها:

```bat
tests\run_tests.bat
```

## 9) فایل‌های جدید

- `OutboxReplay.cs` — تحویل واقعی SQL Step از Outbox
- `OutboxForm.cs` — مدیریت صف و Dead-letter
- `AssemblyInfo.cs` — نسخهٔ 34
- `tests\SelfTest.cs` — ۱۸ تست
- `tests\run_tests.bat` — اجرای تست

## 10) جمع‌بندی

Build 33 یک اسکلت درست اما ناتمام بود. Build 34 آن را به یک قابلیت قابل استفاده تبدیل می‌کند: صف پایدار، Claim بین‌پروسسی، Retry/Backoff، Dead-letter قابل مدیریت، تحویل واقعی SQL و HTTP، Cache سالم، Config امن و UI. موارد باقی‌مانده (به‌خصوص Exactly-once، Kafka/NATS و Payload ردیفی) در بخش محدودیت‌ها شفاف آمده‌اند.
