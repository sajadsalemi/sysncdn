using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SyncDB
{
    /// <summary>
    /// Two languages: English (default) and Persian (right-to-left).
    /// The choice is stored in lang.txt in the data folder and read at start-up;
    /// changing it from the Language menu restarts the program.
    /// Every form calls Theme.Apply(), which calls Lang.Apply(): all static captions are translated there.
    /// </summary>
    public static class Lang
    {
        public static bool Fa;

        private static string FilePath { get { return Path.Combine(AppConfig.DataDir, "lang.txt"); } }

        public static void Load()
        {
            try
            {
                if (File.Exists(FilePath))
                    Fa = File.ReadAllText(FilePath).Trim().ToLowerInvariant().StartsWith("fa");
            }
            catch { Fa = false; }
        }

        public static void Save(bool fa)
        {
            Directory.CreateDirectory(AppConfig.DataDir);
            File.WriteAllText(FilePath, fa ? "fa" : "en");
            Fa = fa;
        }

        // ------------------------------------------------------------------ dictionary
        private static readonly Dictionary<string, string> D = new Dictionary<string, string>(StringComparer.Ordinal);
        private static readonly List<KeyValuePair<string, string>> Prefix = new List<KeyValuePair<string, string>>();
        private static readonly List<KeyValuePair<Regex, string>> Patterns = new List<KeyValuePair<Regex, string>>();

        private static void A(string en, string fa)
        {
            if (en.EndsWith("*")) { Prefix.Add(new KeyValuePair<string, string>(en.Substring(0, en.Length - 1), fa)); return; }
            if (en.Contains("{0}"))
            {
                string rx = "^" + Regex.Escape(en) + "$";
                rx = Regex.Replace(rx, @"\\\{(\d)\}", "(?<g$1>.*?)");
                Patterns.Add(new KeyValuePair<Regex, string>(new Regex(rx, RegexOptions.Singleline), fa));
                return;
            }
            D[en] = fa;
        }

        static Lang()
        {
            // ---------- main window: menus
            A("File", "فایل");
            A("Service", "سرویس");
            A("Save all", "ذخیره همه");
            A("Change password...", "تغییر رمز عبور...");
            A("Export jobs / settings...", "خروجی گرفتن از جاب‌ها / تنظیمات...");
            A("Import jobs / settings...", "ورود جاب‌ها / تنظیمات از فایل...");
            A("Open data folder", "باز کردن پوشه داده‌ها");
            A("Open Log folder (audit_syncdb.txt / logsyncdb.txt)", "باز کردن پوشه لاگ (audit_syncdb.txt / logsyncdb.txt)");
            A("Exit", "خروج");
            A("Start", "شروع");
            A("Stop", "توقف");
            A("Windows Service: Install && start (auto-start with Windows)", "سرویس ویندوز: نصب و شروع (اجرای خودکار با ویندوز)");
            A("Windows Service: Start", "سرویس ویندوز: شروع");
            A("Windows Service: Stop", "سرویس ویندوز: توقف");
            A("Windows Service: Uninstall", "سرویس ویندوز: حذف");
            A("Windows Service: Status", "سرویس ویندوز: وضعیت");
            A("Ready", "آماده");
            A("SyncDB — Database Transfer & Jobs*", "SyncDB — انتقال دیتابیس و جاب‌ها");
            A("Database Transfer & Jobs", "انتقال دیتابیس و جاب‌ها");
            A("Service: STOPPED", "سرویس: متوقف");
            A("Service: RUNNING", "سرویس: در حال اجرا");
            A("▶ Start Service", "▶ شروع سرویس");
            A("■ Stop Service", "■ توقف سرویس");

            // ---------- tabs
            A("1) Connections", "۱) اتصال‌ها");
            A("2) Database 1 (Source)", "۲) دیتابیس ۱ (مبدأ)");
            A("3) Database 2 (Destination)", "۳) دیتابیس ۲ (مقصد)");
            A("4) Jobs / Transfer", "۴) جاب‌ها / انتقال");
            A("5) Job Designer", "۵) طراحی جاب");
            A("6) Logs", "۶) لاگ‌ها");
            A("7) Settings", "۷) تنظیمات");
            A("8) Advanced guide", "۸) راهنمای پیشرفته");
            A("Advanced options & external tools (reference)", "گزینه‌های پیشرفته و ابزارهای بیرونی (مرجع)");

            // ---------- connections tab
            A("Connections (drag middle bar)", "اتصال‌ها (نوار وسط را بکشید)");
            A("Name", "نام");
            A("Server", "سرور");
            A("DB", "دیتابیس");
            A("Role", "نقش");
            A("Add", "افزودن");
            A("Delete", "حذف");
            A("Set SOURCE", "تعیین به‌عنوان مبدأ");
            A("Set DEST", "تعیین به‌عنوان مقصد");
            A("Clear role", "حذف نقش");
            A("Connection properties", "مشخصات اتصال");
            A("Port", "پورت");
            A("Database", "دیتابیس");
            A("User name", "نام کاربری");
            A("Password", "رمز عبور");
            A("Conn. string", "رشته اتصال");
            A("Actions", "عملیات");
            A("TrustServerCertificate = yes", "TrustServerCertificate = بله");
            A("Windows Authentication", "احراز هویت ویندوز");
            A("Show password", "نمایش رمز");
            A("Save connection", "ذخیره اتصال");
            A("Test", "تست");
            A("Show string", "نمایش رشته");
            A("Hide string", "پنهان کردن رشته");
            A("Select a connection → Set SOURCE or Set DEST (green/blue in list). Tabs 2/3 follow these roles.",
              "یک اتصال را انتخاب کنید ← «مبدأ» یا «مقصد» (در لیست سبز/آبی می‌شود). زبانه‌های ۲ و ۳ از همین نقش‌ها پیروی می‌کنند.");

            // ---------- source / dest tabs
            A("SOURCE — pick connection (data is READ from here)", "مبدأ — اتصال را انتخاب کنید (داده از اینجا خوانده می‌شود)");
            A("DESTINATION — pick connection (data is WRITTEN here)", "مقصد — اتصال را انتخاب کنید (داده اینجا نوشته می‌شود)");
            A("Connection:", "اتصال:");
            A("Save selection", "ذخیره انتخاب");
            A("List tables & views", "فهرست جدول‌ها و ویوها");
            A("▶ Select (preview data)", "▶ مشاهده داده (پیش‌نمایش)");
            A("Create job: checked tables...", "ساخت جاب: جدول‌های تیک‌خورده...");
            A("Create SELECT", "ساخت SELECT");
            A("Create SELECT all", "ساخت SELECT برای همه");
            A("Select all", "انتخاب همه");
            A("Select tables only", "فقط جدول‌ها");
            A("Select none", "هیچ‌کدام");
            A("Export checked tables → CSV...", "خروجی جدول‌های تیک‌خورده ← CSV...");
            A("Export job config...", "خروجی تنظیمات جاب...");
            A("Invert", "معکوس کردن انتخاب");
            A("Tick highlighted", "تیک زدن موارد هایلایت");
            A("Untick highlighted", "برداشتن تیک موارد هایلایت");
            A("Preview data", "پیش‌نمایش داده");
            A("Tick the tables (checkbox).  Double-click a table to preview its data.  Checked tables -> Create job / Export CSV / Select.",
              "جدول‌ها را تیک بزنید.  با دابل‌کلیک روی هر جدول داده‌اش را ببینید.  جدول‌های تیک‌خورده ← ساخت جاب / خروجی CSV / Select.");

            // ---------- jobs tab
            A("Source → Dest: (not set)", "مبدأ ← مقصد: (تعیین نشده)");
            A("TRANSFER ROUTE:", "مسیر انتقال:");
            A("Source (tab 2):", "مبدأ (زبانه ۲):");
            A("Dest   (tab 3):", "مقصد (زبانه ۳):");
            A("▶  Send to Database 2 (Run selected job)", "▶  ارسال به دیتابیس ۲ (اجرای جاب انتخاب‌شده)");
            A("■  Stop job (disable)", "■  توقف جاب (غیرفعال‌سازی)");
            A("Refresh route", "به‌روزرسانی مسیر");
            A("Result OK/Error", "نتیجه موفق/خطا");
            A("Result  OK / Error", "نتیجه  موفق / خطا");
            A("Result OK / Error", "نتیجه موفق / خطا");

            // ---------- Job History window + live transfer status window
            A("Job History", "تاریخچهٔ جاب‌ها");
            A("Job History...", "تاریخچهٔ جاب‌ها...");
            A("Job &History...", "تاریخچهٔ جاب‌ها...");
            A("Transfer status (live)...", "وضعیت انتقال (زنده)...");
            A("Job History (last 30 days)", "تاریخچهٔ جاب‌ها (۳۰ روز اخیر)");
            A("Transfer status (live)", "وضعیت انتقال (زنده)");
            A("Select logs", "انتخاب لاگ‌ها");
            A("Click a name = only that job.\r\nTick the boxes = several jobs together.",
              "کلیک روی نام = فقط همان جاب.\r\nتیک زدن مربع‌ها = چند جاب با هم.");
            A("Click a job name, or tick at least one log on the left.", "روی نام یک جاب کلیک کنید، یا دست‌کم یک لاگ را تیک بزنید.");
            A("Open history folder", "باز کردن پوشهٔ تاریخچه");
            A("Clear history", "پاک کردن تاریخچه");
            A("Drop into (DROP table + INSERT)", "Drop into (حذف جدول + درج)");
            A("All off by default. Tick only what you want. Order when enabled: Change Tracking → CDC → RV → COL → HASH. HASH is heavy on large tables.",
              "همه خاموش‌اند تا خودتان تیک بزنید. ترتیب در صورت فعال‌بودن: Change Tracking → CDC → RV → COL → HASH. HASH روی جدول بزرگ سنگین است.");
            A("Archive", "بایگانی");
            A("Active history", "تاریخچهٔ فعال");
            A("Delete from archive", "حذف از بایگانی");
            A("Job History — Archive (last 4 days)", "تاریخچهٔ جاب‌ها — بایگانی (۴ روز اخیر)");
            A("Clear list", "پاک کردن فهرست");
            A("Stop job", "توقف جاب");
            A("Date", "تاریخ");
            A("Job", "جاب");
            A("Status", "وضعیت");
            A("Records", "تعداد رکورد");
            A("Elapsed (sec)", "مدت زمان (ثانیه)");
            A("Source", "منبع اجرا");
            A("Tables", "جدول‌ها");
            A("Transferred (table : records)", "منتقل‌شده (جدول : رکورد)");
            A("Message", "پیام");
            A("Statement / table", "دستور / جدول");
            A("Kind", "نوع");
            A("Took", "مدت");
            A("Time", "زمان");
            A("No transfer is running.", "هیچ انتقالی در حال اجرا نیست.");
            A("Transfer is starting ...", "انتقال در حال شروع است ...");
            A("Last transfer finished - the list is up to date.", "آخرین انتقال تمام شد — فهرست به‌روز است.");
            A("Stop requested for", "درخواست توقف برای");
            A("Could not find the running job in the list.", "جاب در حال اجرا در فهرست پیدا نشد.");
            A("Transfer status: ready - select a job in the Jobs tab and press Run",
              "وضعیت انتقال: آماده — در زبانهٔ جاب‌ها یک جاب انتخاب کنید و Run بزنید");
            A("Jobs — Transfer uses Source (tab 2) and Dest (tab 3)", "جاب‌ها — انتقال از مبدأ (زبانه ۲) و مقصد (زبانه ۳) استفاده می‌کند");
            A("Schedule", "زمان‌بندی");
            A("Enabled", "فعال");
            A("Steps", "مراحل");
            A("State", "وضعیت");
            A("Last status", "آخرین نتیجه");
            A("Add job", "افزودن جاب");
            A("Duplicate", "کپی");
            A("Edit job...", "ویرایش جاب...");
            A("Tables / Resources...", "جدول‌ها / منابع...");
            A("Export...", "خروجی...");
            A("Import...", "ورودی...");
            A("▶  Start job (enable and run now)", "▶  شروع جاب (فعال‌سازی و اجرای فوری)");
            A("■  Stop job (stop and disable)", "■  توقف جاب (توقف و غیرفعال‌سازی)");
            A("✔  Enable job (without running)", "✔  فعال‌سازی جاب (بدون اجرا)");
            A("⚙  Tables: use / RAM / CPU / Disk / Index...", "⚙  جدول‌ها: استفاده / RAM / CPU / دیسک / ایندکس...");
            A("▶  Start Service (scheduler)", "▶  شروع سرویس (زمان‌بند)");
            A("■  Stop Service (scheduler)", "■  توقف سرویس (زمان‌بند)");
            A("Move job up", "جابجایی جاب به بالا");
            A("Move job down", "جابجایی جاب به پایین");
            A("Running", "در حال اجرا");
            A("Stopping", "در حال توقف");
            A("Idle", "بیکار");
            A("Disabled", "غیرفعال");
            A("Yes", "بله");
            A("No", "خیر");
            A("NO (skipped)", "خیر (رد می‌شود)");

            // ---------- job designer tab / logs / settings
            A("Job designer (SQL Server Agent style)", "طراحی جاب (به سبک SQL Server Agent)");
            A("General / Steps / Schedules\r\nDouble-click a job in Jobs tab, or use the button below.",
              "عمومی / مراحل / زمان‌بندی\r\nروی یک جاب در زبانه جاب‌ها دابل‌کلیک کنید یا از دکمه زیر استفاده کنید.");
            A("Open Job Designer...", "باز کردن طراح جاب...");
            A("New job...", "جاب جدید...");
            A("No job selected", "جابی انتخاب نشده");
            A("No job selected.", "جابی انتخاب نشده.");
            A("View day:", "نمایش روز:");
            A("Load day", "بارگذاری روز");
            A("Open folder", "باز کردن پوشه");
            A("Delete this day", "حذف این روز");
            A("Purge old", "پاک‌سازی قدیمی‌ها");
            A("Delete ALL logs", "حذف همه لاگ‌ها");
            A("Service is manual only (Start/Stop buttons)", "سرویس فقط دستی است (دکمه‌های شروع/توقف)");
            A("Service mode", "حالت سرویس");
            A("Scheduler poll (sec)", "فاصله بررسی زمان‌بند (ثانیه)");
            A("Log keep days (1–1095)", "نگهداری لاگ (روز، ۱ تا ۱۰۹۵)");
            A("Log folder", "پوشه لاگ");
            A("Save settings", "ذخیره تنظیمات");
            A("Browse…", "مرور…");
            A("Language / زبان", "Language / زبان");
            A("&Language / زبان", "&Language / زبان");

            // ---------- job editor dialog
            A("Job — {0}", "جاب — {0}");
            A("Job — New Job", "جاب — جاب جدید");
            A("Select a page", "یک صفحه انتخاب کنید");
            A("  General", "  عمومی");
            A("  Steps", "  مراحل");
            A("  Schedules", "  زمان‌بندی");
            A("Cancel", "انصراف");
            A("OK", "تأیید");
            A("Name:", "نام:");
            A("Description:", "توضیحات:");
            A("Connections (Source / Destination) are chosen in the main window tabs.\r\nSteps define what this job runs (Transfer or T-SQL).",
              "اتصال‌ها (مبدأ / مقصد) در زبانه‌های پنجره اصلی انتخاب می‌شوند.\r\nمراحل مشخص می‌کنند این جاب چه چیزی را اجرا کند (انتقال یا T-SQL).");
            A("Job step list:", "فهرست مراحل جاب:");
            A("Step", "مرحله");
            A("Type", "نوع");
            A("On Success", "در صورت موفقیت");
            A("On Fail", "در صورت خطا");
            A("Use", "استفاده");
            A("New...", "جدید...");
            A("Edit", "ویرایش");
            A("Use on/off", "استفاده روشن/خاموش");
            A("  Move:", "  جابجایی:");
            A("Move to #", "انتقال به #");
            A("Enable (Use on)", "فعال (استفاده روشن)");
            A("Disable (Use off)", "غیرفعال (استفاده خاموش)");
            A("Move up", "بالا");
            A("Move down", "پایین");
            A("Transfer", "انتقال");
            A("T-SQL (Source)", "T-SQL (مبدأ)");
            A("T-SQL (Dest)", "T-SQL (مقصد)");
            A("Web API → Dest", "Web API ← مقصد");
            A("Go to next step", "رفتن به مرحله بعد");
            A("Quit success", "خروج با موفقیت");
            A("Quit failure", "خروج با خطا");
            A("Schedule type:", "نوع زمان‌بندی:");
            A("Manual only", "فقط دستی");
            A("Every N minutes", "هر N دقیقه");
            A("Every N hours", "هر N ساعت");
            A("Daily", "روزانه");
            A("Weekly", "هفتگی");
            A("Monthly", "ماهانه");
            A("Recurs every:", "تکرار هر:");
            A("  (N)", "  (N)");
            A("  minute(s)", "  دقیقه");
            A("  hour(s)", "  ساعت");
            A("  day(s)", "  روز");
            A("  week(s)", "  هفته");
            A("Frequency", "فرکانس");
            A("On days:", "در روزهای:");
            A("Sunday", "یکشنبه"); A("Monday", "دوشنبه"); A("Tuesday", "سه‌شنبه"); A("Wednesday", "چهارشنبه");
            A("Thursday", "پنجشنبه"); A("Friday", "جمعه"); A("Saturday", "شنبه");
            A("Day:", "روز:");
            A("Day", "روز");
            A("  of every", "  از هر");
            A(" month(s)", " ماه");
            A("Daily frequency", "فرکانس روزانه");
            A("Occurs once at:", "یک بار در ساعت:");
            A("Occurs every:", "تکرار هر:");
            A("  (HH:MM)  — start time", "  (ساعت:دقیقه) — زمان شروع");
            A(" hour(s)   Ending at ", " ساعت   پایان در ");
            A("Job name is required.", "نام جاب الزامی است.");
            A("Command timeout (sec):", "مهلت هر دستور (ثانیه):");
            A("0 = no limit. Raise it when a long INSERT / SELECT stops with \"Timeout expired\".",
              "۰ = بدون محدودیت. اگر INSERT / SELECT طولانی با خطای Timeout expired می‌ایستد، این را زیاد کنید.");
            A("Protect refills: \"DELETE FROM t\" + the next \"INSERT INTO t\" run as ONE transaction",
              "محافظت از پرکردن جدول: «DELETE FROM t» و «INSERT INTO t» بعدی در یک تراکنش");

            // ---------- step editor dialog
            A("Job Step — {0}", "مرحله جاب — {0}");
            A("Job Step — New", "مرحله جاب — جدید");
            A("◀ Previous", "◀ قبلی");
            A("◀ Previous job", "◀ جاب قبلی");
            A("Next job ▶", "جاب بعدی ▶");
            A("Next ▶", "بعدی ▶");
            A("Step name:", "نام مرحله:");
            A("Type:", "نوع:");
            A("Database:", "دیتابیس:");
            A("Command (T-SQL / SELECT):", "دستور (T-SQL / SELECT):");
            A("Transfer options:", "گزینه‌های انتقال:");
            A("Web API options:", "گزینه‌های Web API:");
            A("On success:", "در صورت موفقیت:");
            A("On failure:", "در صورت خطا:");
            A("Retry:", "تلاش مجدد:");
            A("Retry attempts", "تعداد تلاش");
            A("  Interval (min)", "  فاصله (دقیقه)");
            A("Transfer (Source → Dest)", "انتقال (مبدأ ← مقصد)");
            A("T-SQL on Source", "T-SQL روی مبدأ");
            A("T-SQL on Destination", "T-SQL روی مقصد");
            A("Web API → Destination", "Web API ← مقصد");
            A("(default: Source / Dest from main window)", "(پیش‌فرض: مبدأ / مقصد پنجره اصلی)");
            A("Source table", "جدول مبدأ");
            A("Dest table *", "جدول مقصد *");
            A("Write mode", "حالت نوشتن");
            A("DELETE WHERE", "شرط DELETE");
            A("Key columns *", "ستون‌های کلید *");
            A("Last changes col", "ستون آخرین تغییر");
            A("Smart Delta methods", "روش‌های Smart Delta");
            A("RV (rowversion)", "RV (نسخه ردیف)");
            A("COL (incremental col)", "COL (ستون افزایشی)");
            A("HASH", "HASH");
            A("Tick any combination. Auto order: Change Tracking → CDC → RV → COL → HASH. HASH alone is heavy on 100GB tables.",
              "هر ترکیبی را تیک بزنید. ترتیب خودکار: Change Tracking ← CDC ← RV ← COL ← HASH. فقط HASH روی جدول ۱۰۰ گیگ سنگین است.");
            A("Batch (RAM)", "اندازه دسته (RAM)");
            A("Append (INSERT only)", "افزودن (فقط INSERT)");
            A("Truncate + INSERT (full reload)", "Truncate + INSERT (بارگذاری کامل)");
            A("DELETE + INSERT", "DELETE + INSERT");
            A("Merge UPSERT (INSERT+UPDATE)", "Merge UPSERT (INSERT+UPDATE)");
            A("Sync changes AUTO (INSERT+UPDATE+DELETE)", "همگام‌سازی خودکار (INSERT+UPDATE+DELETE)");
            A("Multi-thread DEST ON  (unticked = 1 writer)", "چندنخی مقصد روشن  (بدون تیک = ۱ نویسنده)");
            A("   DEST threads (0=Auto)", "   نخ‌های مقصد (۰ = خودکار)");
            A("Multi-thread SOURCE ON  (unticked = 1 reader)", "چندنخی مبدأ روشن  (بدون تیک = ۱ خواننده)");
            A("   SOURCE threads (0=Auto)", "   نخ‌های مبدأ (۰ = خودکار)");
            A("SOURCE readers: 0 = Auto (big tables only), 1 = single reader. >1 splits the read by key hash (RAM mode, plain table / SELECT without ORDER BY).",
              "خواننده‌های مبدأ: ۰ = خودکار (فقط جدول‌های بزرگ)، ۱ = یک خواننده. بیشتر از ۱ = خواندن موازی با تقسیم بر اساس هش کلید (حالت RAM، جدول ساده / SELECT بدون ORDER BY).");
            A("Rebuild indexes (DEST)", "بازسازی ایندکس (مقصد)");
            A("... every N days", "... هر N روز");
            A("Off", "خاموش");
            A("After every run (only if the table has indexes)", "بعد از هر اجرا (فقط اگر جدول ایندکس دارد)");
            A("Every N days (message in log/result)", "هر N روز (پیام در لاگ/نتیجه)");
            A("Last rebuild: never", "آخرین بازسازی: هرگز");
            A("Last rebuild: {0}", "آخرین بازسازی: {0}");
            A("Delay (ms)", "تأخیر (میلی‌ثانیه)");
            A("Priority", "اولویت");
            A("Low", "کم"); A("Normal", "معمولی"); A("High", "زیاد");
            A("Memory mode", "حالت حافظه");
            A("RAM limit (MB, Auto)", "حد RAM (مگابایت، خودکار)");
            A("Auto (RAM if small, Disk if heavy)", "خودکار (جدول کوچک RAM، سنگین دیسک)");
            A("RAM (whole table in memory)", "RAM (کل جدول در حافظه)");
            A("Stream (low RAM)", "Stream (RAM کم)");
            A("Disk buffer (heavy tables)", "بافر دیسک (جدول‌های سنگین)");
            A("RAM limit (MB):", "حد RAM (مگابایت):");
            A("Cache provider", "ارائه‌دهنده کش");
            A("LiteDB (general / light)", "LiteDB (عمومی / سبک)");
            A("LevelDB (fast)", "LevelDB (سریع)");
            A("FASTER (very fast)", "FASTER (خیلی سریع)");
            A("LiteDB: general cache. LevelDB / FASTER: high-speed key-value (optional).",
              "LiteDB: کش عمومی. LevelDB / FASTER: کلید-مقدار پرسرعت (اختیاری).");
            A("Auto", "خودکار");
            A("RAM", "RAM");
            A("Stream", "Stream");
            A("Disk", "دیسک");
            A("URL", "آدرس (URL)");
            A("Method", "متد");
            A("Auth URL (get token)", "آدرس احراز هویت (دریافت توکن)");
            A("Authentication", "احراز هویت");
            A("Token / API Key", "توکن / کلید API");
            A("API Key header name", "نام هدر کلید API");
            A("User / Email", "کاربر / ایمیل");
            A("Headers (Name: Value)", "هدرها (نام: مقدار)");
            A("POST body", "بدنه POST");
            A("JSON path to array", "مسیر JSON تا آرایه");
            A("Page param", "پارامتر صفحه");
            A("Page-size param", "پارامتر اندازه صفحه");
            A("Page size", "اندازه صفحه");
            A("Max pages", "حداکثر صفحه");
            A("Ignore SSL certificate errors", "نادیده گرفتن خطای گواهی SSL");
            A("None", "هیچ");
            A("Bearer token", "توکن Bearer");
            A("Basic (user/password)", "Basic (کاربر/رمز)");
            A("API Key (header)", "کلید API (هدر)");
            A("Go to the next step", "رفتن به مرحله بعد");
            A("Quit the job reporting success", "خروج از جاب با گزارش موفقیت");
            A("Quit the job reporting failure", "خروج از جاب با گزارش خطا");
            A("Step name is required.", "نام مرحله الزامی است.");
            A("T-SQL command is required for this step type.", "برای این نوع مرحله دستور T-SQL الزامی است.");

            // ---------- resources dialog
            A("Tables: use + order + RAM / CPU / Disk / Index — {0}", "جدول‌ها: استفاده + ترتیب + RAM / CPU / دیسک / ایندکس — {0}");
            A("Use: tick = table runs*",
              "استفاده: تیک = جدول اجرا می‌شود و تنظیماتش فعال است؛ بدون تیک = جدول رد می‌شود و ردیفش غیرفعال (خاکستری) می‌شود. دوباره تیک بزنید تا فعال شود.   شماره: ترتیب اجرا - عدد بنویسید یا از بالا / پایین استفاده کنید.\r\n" +
              "اندازه دسته: تعداد ردیف در هر دسته (RAM).   نخ‌های مقصد: نویسنده‌های موازی، ۰ = خودکار (هسته‌های CPU).   نخ‌های مبدأ: خواننده‌های موازی، ۰ = خودکار، ۱ = یک خواننده (فقط حالت RAM).\r\n" +
              "حالت حافظه: خودکار = RAM اگر کوچک باشد، بافر دیسک اگر حجم تخمینی > حد RAM.  RAM = کل جدول در حافظه.  Stream = RAM کم.  Disk = فایل موقت (Merge / Sync همیشه RAM).\r\n" +
              "ایندکس: خاموش / بعد از هر اجرا / هر N روز.   روی جدول راست‌کلیک کنید: فعال / غیرفعال / انتخاب همه / جابجایی.   (مرحله‌های Web API: حالت حافظه و ایندکس ندارند.)\r\n" +
              "جدول مقصد: از لیست انتخاب کنید (از اتصال مقصد خوانده می‌شود) یا نام جدید را تایپ کنید.");
            A("No.", "ردیف");
            A("Dest table", "جدول مقصد");
            A("Batch size (RAM)", "اندازه دسته (RAM)");
            A("DEST threads (0=Auto)", "نخ‌های مقصد (۰=خودکار)");
            A("SOURCE threads (0=Auto)", "نخ‌های مبدأ (۰=خودکار)");
            A("Delay (ms)", "تأخیر (ms)");
            A("RAM limit MB", "حد RAM (MB)");
            A("Rebuild index", "بازسازی ایندکس");
            A("Every N days", "هر N روز");
            A("▼ Down", "▼ پایین");
            A("▲ Up", "▲ بالا");
            A("Enable selected (Use on)", "فعال‌سازی انتخاب‌شده‌ها");
            A("Disable selected (Use off)", "غیرفعال‌سازی انتخاب‌شده‌ها");
            A("Include connections WITH passwords (clear text in the file)?", "اتصال‌ها همراه با رمز عبور خروجی گرفته شود؟ (رمز در فایل به‌صورت متن ساده است)");
            A("Export", "خروجی");
            A("Exported:\r\n{0}", "خروجی گرفته شد:\r\n{0}");

            // ---------- export dialog
            A("Export jobs", "خروجی گرفتن از جاب‌ها");
            A("Tick the jobs to export (steps, tables, schedules). App settings are always included:", "جاب‌های موردنظر را تیک بزنید (مراحل، جدول‌ها، زمان‌بندی). تنظیمات برنامه همیشه همراه است:");
            A("Include connections WITH passwords (clear text in the file - keep it safe)", "اتصال‌ها همراه با رمز عبور (متن ساده در فایل - فایل را امن نگه دارید)");
            A("All", "همه");
            A("Tick at least one job.", "حداقل یک جاب را تیک بزنید.");

            // ---------- preview dialog
            A("Select / Preview — {0}", "مشاهده / پیش‌نمایش — {0}");
            A("Preview / Run SELECT", "پیش‌نمایش / اجرای SELECT");
            A("Generated SQL (linked-server style)", "SQL ساخته‌شده (به سبک linked-server)");
            A("Copy to clipboard", "کپی در کلیپ‌بورد");
            A("Object:", "شیء:");
            A("Rows:", "ردیف‌ها:");
            A("▶ Run (F5)", "▶ اجرا (F5)");
            A("■ Cancel", "■ انصراف");
            A("Export CSV", "خروجی CSV");
            A("Read-only: only SELECT / WITH queries can be run here.", "فقط‌خواندنی: در اینجا فقط کوئری‌های SELECT / WITH اجرا می‌شوند.");

            // ---------- login / change password / result
            A("SyncDB — Login", "SyncDB — ورود");
            A("Change password", "تغییر رمز عبور");
            A("Current", "فعلی");
            A("New", "جدید");
            A("Confirm new", "تکرار رمز جدید");
            A("Close", "بستن");
            A("  SUCCESS", "  موفق");
            A("  FAILED", "  ناموفق");

            // ---------- message boxes
            A("Saved.", "ذخیره شد.");
            A("Settings saved.", "تنظیمات ذخیره شد.");
            A("Outbox", "صف Outbox");
            A("Outbox worker", "سرویس‌دهندهٔ Outbox");
            A("Outbox max retries", "حداکثر تلاش مجدد Outbox");
            A("Outbox batch size", "اندازهٔ دستهٔ Outbox");
            A("Outbox idle (ms)", "تأخیر بیکاری Outbox (میلی‌ثانیه)");
            A("Keep sent (days)", "نگه‌داشتن ارسال‌شده‌ها (روز)");
            A("Origin ID (this node)", "شناسهٔ مبدأ (این گره)");
            A("Outbox stats", "آمار Outbox");
            A("Manage outbox…", "مدیریت Outbox…");
            A("Process outbox now", "پردازش فوری Outbox");
            A("SyncDB — Outbox / Dead-letter queue", "SyncDB — Outbox / صف پیام‌های ناموفق");
            A("Status:", "وضعیت:");
            A("All", "همه");
            A("Pending", "در انتظار");
            A("Processing", "در حال پردازش");
            A("Dead", "ناموفق دائمی");
            A("Sent", "ارسال‌شده");
            A("Skipped", "رد‌شده");
            A("Attempts", "تلاش‌ها");
            A("Next attempt", "تلاش بعدی");
            A("Transport", "انتقال");
            A("Last error", "آخرین خطا");
            A("Refresh", "به‌روزرسانی");
            A("Retry selected", "تلاش مجدد موارد انتخاب‌شده");
            A("Force replay…", "اجرای اجباری Replay…");
            A("Retry all dead", "تلاش مجدد همهٔ ناموفق‌ها");
            A("Delete", "حذف");
            A("Purge sent", "پاک‌سازی ارسال‌شده‌ها");
            // ---------- data-folder housekeeping (buffer / stream / cache / outbox)
            A("Auto cleanup", "پاک‌سازی خودکار");
            A("Disk buffer", "بافر دیسکی");
            A("Keep cache/stream (days)", "نگهداری کش/استریم (روز)");
            A("Data folder", "پوشه داده‌ها");
            A("Clean buffer/cache now", "پاک‌سازی بافر/کش هم‌اکنون");
            A("Open data folder", "بازکردن پوشه داده‌ها");
            A("Cleanup done.", "پاک‌سازی انجام شد.");
            A("Disk buffer enabled.", "بافر دیسکی فعال شد.");
            A("Service: RUNNING (Windows service)", "سرویس: در حال اجرا (سرویس ویندوز)");
            A("Start the Windows service 'SyncDB'?", "سرویس ویندوزِ «SyncDB» استارت شود؟");
            A("Yes = start the Windows service (jobs keep running after this window is closed)",
              "بله = استارت سرویس ویندوز (جاب‌ها بعد از بستن این پنجره هم اجرا می‌شوند)");
            A("No  = run the scheduler inside this window instead",
              "خیر = زمان‌بند داخل همین پنجره اجرا شود");
            A("Scheduler is OFF - automatic runs are disabled", "زمان‌بند خاموش است — اجرای خودکار غیرفعال است");
            A("Service: RUNNING (this window)", "سرویس: در حال اجرا (همین پنجره)");
            A("The Windows service is already running.", "سرویس ویندوز از قبل در حال اجراست.");
            A("Starting the Windows service… (allow the administrator prompt)",
              "در حال استارت سرویس ویندوز… (به پیام دسترسی مدیر اجازه بدهید)");
            A("Stopping the Windows service… (allow the administrator prompt)",
              "در حال توقف سرویس ویندوز… (به پیام دسترسی مدیر اجازه بدهید)");
            A("▶  Start the scheduler in this window", "▶  اجرای زمان‌بند در همین پنجره");
            A("■  Stop the scheduler in this window", "■  توقف زمان‌بند در همین پنجره");
            A("Disk buffer disabled - transfers use Stream mode.",
              "بافر دیسکی غیرفعال شد — انتقال‌ها با حالت Stream انجام می‌شوند.");
            A("Auto-clean the data folder (disk buffer, stream, cache, outbox) at startup and hourly",
              "پاک‌سازی خودکار پوشه داده‌ها (بافر دیسکی، استریم، کش، صندوق خروج) در شروع برنامه و هر ساعت");
            A("Use a disk buffer for huge tables (OFF = Stream mode, nothing is written to disk)",
              "استفاده از بافر دیسکی برای جدول‌های خیلی بزرگ (خاموش = حالت Stream، هیچ چیزی روی دیسک نوشته نمی‌شود)");
            A("Details", "جزئیات");
            A("Open payload", "باز کردن Payload");
            A("Process now", "پردازش فوری");
            A("Close", "بستن");
            A("Connection saved.", "اتصال ذخیره شد.");
            A("Purged.", "پاک‌سازی شد.");
            A("Confirm", "تأیید");
            A("Are you sure you want to stop and remove the SyncDB service?", "آیا مطمئن هستید می‌خواهید سرویس SyncDB متوقف و حذف شود؟");
            A("Are you sure you want to stop the scheduler in this window?", "آیا مطمئن هستید می‌خواهید زمان‌بندی این پنجره متوقف شود؟");
            A("Service installed successfully.", "سرویس با موفقیت نصب شد.");
            A("The Windows service is still running an OLD copy of SyncDB:", "سرویس ویندوز هنوز یک نسخه قدیمی SyncDB را اجرا می‌کند:");
            A("Switch the service to this version now?", "سرویس به همین نسخه منتقل شود؟");
            A("Async: next check in {0} s  (every {1} s - {2})", "Async: چک بعدی {0} ثانیه دیگر  (هر {1} ثانیه - {2})");
            A("Async: checking now…  ({0})", "Async: در حال چک…  ({0})");
            A("run by the Windows service", "اجرا توسط سرویس ویندوز");
            A("run by this window", "اجرا توسط همین پنجره");
            A("Service: RUNNING - OLD COPY (press Start)", "سرویس: در حال اجرا — نسخه قدیمی (Start را بزنید)");
            A("Installing and starting the Windows service… (allow the administrator prompt)",
              "در حال نصب و استارت سرویس ویندوز… (به پیام دسترسی مدیر اجازه بدهید)");
            A("Stopping and removing the Windows service… (allow the administrator prompt)",
              "در حال توقف و حذف سرویس ویندوز… (به پیام دسترسی مدیر اجازه بدهید)");
            A("The SyncDB service is not installed yet.", "سرویس SyncDB هنوز نصب نشده است.");
            A("Use \"Install service\" first.", "اول «نصب سرویس» را بزنید.");
            A("The service did not start.", "سرویس استارت نشد.");
            A("See tab 6) Logs for the reason.", "علت را در تب «۶) Logs» ببینید.");
            A("The service points at another folder. Run \"Install service\" once, then start it again.",
              "سرویس به پوشه دیگری اشاره می‌کند. یک‌بار «نصب سرویس» را بزنید، بعد دوباره استارت کنید.");
            A("Status: ", "وضعیت: ");
            A("Data folder: ", "پوشه داده‌ها: ");
            A("Service removed successfully.", "سرویس با موفقیت حذف شد.");
            A("Service started successfully.", "سرویس با موفقیت استارت شد.");
            A("Service stopped successfully.", "سرویس با موفقیت متوقف شد.");
            A("This job is running right now.", "این جاب هم‌اکنون در حال اجراست.");
            A("If you delete it, the run is stopped first.", "اگر حذفش کنید، اول اجرای آن متوقف می‌شود.");
            A("Stopping the job before deleting…", "در حال توقف جاب پیش از حذف…");
            A("Job stopped and deleted: ", "جاب متوقف و حذف شد: ");
            A("Job deleted: ", "جاب حذف شد: ");
            A("Note: the Windows service may be running this job; it stops at the end of its current step.",
              "توجه: ممکن است سرویس ویندوز در حال اجرای این جاب باشد؛ در پایان مرحله جاری متوقف می‌شود.");
            A("No job selected.", "هیچ جابی انتخاب نشده است.");
            A("Delete \"{0}\"?", "«{0}» حذف شود؟");
            A("Select a job first.", "ابتدا یک جاب را انتخاب کنید.");
            A("Select a job in Jobs tab first.", "ابتدا یک جاب را در زبانه جاب‌ها انتخاب کنید.");
            A("Select a connection in the list first.", "ابتدا یک اتصال را از لیست انتخاب کنید.");
            A("Select a connection first.", "ابتدا یک اتصال را انتخاب کنید.");
            A("Server is empty. Type host/IP in Server box.", "سرور خالی است. آدرس یا IP را در کادر سرور بنویسید.");
            A("Fill Server / Database first.", "ابتدا سرور / دیتابیس را پر کنید.");
            A("No connection selected.", "اتصالی انتخاب نشده.");
            A("Connection invalid.", "اتصال نامعتبر است.");
            A("There are no jobs to export.", "جابی برای خروجی گرفتن وجود ندارد.");
            A("Delete log for this day?", "لاگ این روز حذف شود؟");
            A("Delete ALL logs?", "همه لاگ‌ها حذف شوند؟");
            A("Really replace ALL current jobs?", "واقعاً همه جاب‌های فعلی جایگزین شوند؟");
            A("New passwords do not match.", "رمزهای جدید یکسان نیستند.");
            A("New password cannot be empty.", "رمز جدید نمی‌تواند خالی باشد.");
            A("Current password is wrong.", "رمز فعلی اشتباه است.");
            A("Password changed.", "رمز عبور تغییر کرد.");
            A("List is empty. Click List tables & views first.", "لیست خالی است. ابتدا «فهرست جدول‌ها و ویوها» را بزنید.");
            A("Tick (or select) one or more tables/views.", "یک یا چند جدول/ویو را تیک بزنید (یا انتخاب کنید).");
            A("Connection must have Server and Database.", "اتصال باید سرور و دیتابیس داشته باشد.");
            A("Tick the tables to export (List tables & views first).", "جدول‌های موردنظر را تیک بزنید (ابتدا فهرست جدول‌ها را بگیرید).");
            A("In Database 1 (Source): click List tables & views, then tick the tables you want (checkbox).", "در دیتابیس ۱ (مبدأ): «فهرست جدول‌ها و ویوها» را بزنید، سپس جدول‌های موردنظر را تیک بزنید.");
            A("No tables ticked (views are skipped).", "جدولی تیک نخورده (ویوها نادیده گرفته می‌شوند).");
            A("Select a job first.\r\nAdd a job with a Transfer step, then select it.", "ابتدا یک جاب انتخاب کنید.\r\nجابی با مرحله انتقال اضافه کنید و آن را انتخاب کنید.");
            A("Source connection is not selected.\r\nGo to tab 2) Database 1.", "اتصال مبدأ انتخاب نشده.\r\nبه زبانه ۲) دیتابیس ۱ بروید.");
            A("Destination connection is not selected.\r\nGo to tab 3) Database 2.", "اتصال مقصد انتخاب نشده.\r\nبه زبانه ۳) دیتابیس ۲ بروید.");
            A("Source and Destination are the SAME connection. Continue?", "مبدأ و مقصد یک اتصال یکسان هستند. ادامه می‌دهید؟");
            A("This job has no steps yet. Use Edit job... to add steps.", "این جاب هنوز مرحله‌ای ندارد. از «ویرایش جاب...» مرحله اضافه کنید.");
            A("Success", "موفق");
            A("Failed", "ناموفق");
            A("Import failed", "ورود ناموفق بود");
            A("Export failed", "خروجی ناموفق بود");
            A("Nothing to export. Run a SELECT first.", "چیزی برای خروجی نیست. ابتدا یک SELECT اجرا کنید.");
            A("Job creation cancelled.", "ساخت جاب لغو شد.");
            A("Language will change to English.\r\nThe program will close and open again (enter the password again).\r\nContinue?",
              "Language will change to English.\r\nThe program will close and open again (enter the password again).\r\nContinue?");

            // ---------- Build 35h: T-SQL command box buttons, Parse, CT/CDC help
            A("Open...", "باز کردن...");
            A("Select All", "انتخاب همه");
            A("Copy", "کپی");
            A("Paste", "چسباندن");
            A("Parse", "Parse");
            A("Open", "باز کردن");
            A("Parse Command Text", "بررسی متن دستور (Parse)");
            A("The command was successfully parsed.", "دستور با موفقیت Parse شد (خطای نحوی ندارد).");
            A("Removed {0} markdown code-fence line(s)", "حذف {0} خط ``` (علامت کد در چت/وب)");
            A("Replaced {0} curly quote(s) with normal quotes", "تبدیل {0} کوتیشن خمیده به کوتیشن معمولی");
            A("Replaced {0} long dash(es) with normal hyphen(s)", "تبدیل {0} خط‌تیرهٔ بلند به خط‌تیرهٔ معمولی");
            A("Replaced {0} non-breaking space(s)", "تبدیل {0} فاصلهٔ غیرقابل‌شکست (NBSP) به فاصلهٔ معمولی");
            A("Removed {0} invisible character(s)", "حذف {0} کاراکتر نامرئی");
        }

        // ------------------------------------------------------------------ lookup
        /// <summary>Returns the Persian text when Persian is selected and a translation exists; otherwise the original.</summary>
        public static string T(string s)
        {
            if (!Fa || string.IsNullOrEmpty(s)) return s;
            string core = s.Trim();
            if (core.Length == 0) return s;
            string lead = s.Substring(0, s.IndexOf(core[0]));
            string trail = s.Substring(s.LastIndexOf(core[core.Length - 1]) + 1);
            string r = Find(s);
            if (r == null) r = Find(core);
            if (r == null) return s;
            // keep the original leading / trailing blanks only when the exact (untrimmed) key was not used
            return D.ContainsKey(s) ? r : lead + r + trail;
        }

        private static string Find(string key)
        {
            string r;
            if (D.TryGetValue(key, out r)) return r;
            if (key.IndexOf('&') >= 0)
            {
                string k2 = key.Replace("&", "");
                if (D.TryGetValue(k2, out r)) return r;
            }
            foreach (KeyValuePair<string, string> p in Prefix)
                if (key.StartsWith(p.Key, StringComparison.Ordinal)) return p.Value;
            foreach (KeyValuePair<Regex, string> p in Patterns)
            {
                Match m = p.Key.Match(key);
                if (!m.Success) continue;
                string val = p.Value;
                for (int i = 0; i < 4; i++)
                    val = val.Replace("{" + i + "}", m.Groups["g" + i].Success ? m.Groups["g" + i].Value : "");
                return val;
            }
            return null;
        }

        /// <summary>Schedule text like "Mon,Wed 12:00" / "Every 5 min" -> Persian words (numbers stay).</summary>
        public static string Sched(string s)
        {
            if (!Fa || string.IsNullOrEmpty(s)) return s;
            string[,] m = {
                { @"\bManual\b", "دستی" }, { @"\bDaily\b", "روزانه" }, { @"\bEvery\b", "هر" }, { @"\bevery\b", "هر" },
                { @"\bmin\b", "دقیقه" }, { @"(?<=\d)h\b", " ساعت" }, { @"\bh\b", "ساعت" },
                { @"(?<=\d)d\b", " روز" }, { @"(?<=\d)w\b", " هفته" }, { @"\bmo\b", "ماه" }, { @"\bDay\b", "روز" },
                { @"\bSun\b", "یک‌شنبه" }, { @"\bMon\b", "دوشنبه" }, { @"\bTue\b", "سه‌شنبه" }, { @"\bWed\b", "چهارشنبه" },
                { @"\bThu\b", "پنج‌شنبه" }, { @"\bFri\b", "جمعه" }, { @"\bSat\b", "شنبه" }
            };
            for (int i = 0; i < m.GetLength(0); i++) s = Regex.Replace(s, m[i, 0], m[i, 1]);
            return s;
        }

        // ------------------------------------------------------------------ apply to a form / control tree
        public static void Apply(Control root)
        {
            if (!Fa || root == null) return;
            try
            {
                Form f = root as Form;
                if (f != null)
                {
                    // Keep main menu bar LTR so captions stay on the left; body can still be RTL
                    f.RightToLeft = RightToLeft.Yes;
                    f.RightToLeftLayout = true;
                    if (f.MainMenuStrip != null)
                        f.MainMenuStrip.RightToLeft = RightToLeft.No;
                }
                Walk(root);
            }
            catch { }
        }

        private static void Walk(Control c)
        {
            if (c is Label || c is ButtonBase || c is GroupBox || c is TabPage || c is Form)
                c.Text = T(c.Text);

            TabControl tc = c as TabControl;
            if (tc != null) tc.RightToLeftLayout = true;

            ListView lv = c as ListView;
            if (lv != null)
                foreach (ColumnHeader h in lv.Columns) h.Text = T(h.Text);

            DataGridView g = c as DataGridView;
            if (g != null)
                foreach (DataGridViewColumn col in g.Columns) col.HeaderText = T(col.HeaderText);

            ComboBox cb = c as ComboBox;
            if (cb != null) TranslateItems(cb, cb.Items, true);

            ListBox lb = c as ListBox;
            if (lb != null && !(c is CheckedListBox)) TranslateItems(lb, lb.Items, false);

            ToolStrip ts = c as ToolStrip;
            if (ts != null) foreach (ToolStripItem it in ts.Items) WalkItem(it);

            if (c.ContextMenuStrip != null) WalkMenu(c.ContextMenuStrip);

            foreach (Control ch in c.Controls) Walk(ch);
        }

        private static void WalkMenu(ToolStrip ts)
        {
            foreach (ToolStripItem it in ts.Items) WalkItem(it);
        }

        private static void WalkItem(ToolStripItem it)
        {
            if (it is ToolStripSeparator) return;
            it.Text = T(it.Text);
            ToolStripDropDownItem dd = it as ToolStripDropDownItem;
            if (dd != null) foreach (ToolStripItem sub in dd.DropDownItems) WalkItem(sub);
        }

        private static void TranslateItems(Control owner, System.Collections.IList items, bool combo)
        {
            if (items.Count == 0) return;
            string[] tr = new string[items.Count];
            bool changed = false;
            for (int i = 0; i < items.Count; i++)
            {
                string s = items[i] as string;
                if (s == null) return;                  // not a plain-text list (e.g. connection objects)
                tr[i] = T(s);
                if (tr[i] != s) changed = true;
            }
            if (!changed) return;
            int sel = -1;
            ComboBox cb = owner as ComboBox; ListBox lb = owner as ListBox;
            if (cb != null) sel = cb.SelectedIndex; else if (lb != null) sel = lb.SelectedIndex;
            for (int i = 0; i < tr.Length; i++) if (tr[i] != (string)items[i]) items[i] = tr[i];
            if (cb != null && cb.SelectedIndex != sel) cb.SelectedIndex = sel;
            if (lb != null && lb.SelectedIndex != sel) lb.SelectedIndex = sel;
        }
    }

    /// <summary>Same API as System.Windows.Forms.MessageBox, but texts are translated and shown right-to-left in Persian.
    /// (Being in namespace SyncDB it is picked up automatically by every MessageBox.Show(...) call in the program.)</summary>
    public static class MessageBox
    {
        private static MessageBoxOptions Opt
        {
            get { return Lang.Fa ? (MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading) : (MessageBoxOptions)0; }
        }

        public static DialogResult Show(string text)
        {
            return Show(text, "", MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        public static DialogResult Show(string text, string caption)
        {
            return Show(text, caption, MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons)
        {
            return Show(text, caption, buttons, MessageBoxIcon.None);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return System.Windows.Forms.MessageBox.Show(Lang.T(text), Lang.T(caption), buttons, icon, MessageBoxDefaultButton.Button1, Opt);
        }

        public static DialogResult Show(System.Windows.Forms.IWin32Window owner, string text)
        {
            return Show(owner, text, "", MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        public static DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption)
        {
            return Show(owner, text, caption, MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        public static DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, MessageBoxButtons buttons)
        {
            return Show(owner, text, caption, buttons, MessageBoxIcon.None);
        }

        public static DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return System.Windows.Forms.MessageBox.Show(owner, Lang.T(text), Lang.T(caption), buttons, icon, MessageBoxDefaultButton.Button1, Opt);
        }

        /// <summary>With an explicit default button — used by destructive prompts, which default to "No".</summary>
        public static DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption,
                                        MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
        {
            return System.Windows.Forms.MessageBox.Show(owner, Lang.T(text), Lang.T(caption), buttons, icon, defaultButton, Opt);
        }
    }
}
