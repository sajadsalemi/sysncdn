using System;
using Newtonsoft.Json;

namespace SyncDB
{
    public sealed class OutboxReplayResult
    {
        public bool Ok;
        public bool Permanent;
        public string Message;
        public long Rows;
        public string Table;
    }

    /// <summary>
    /// Real local delivery for failed transfers: load the current config, resolve the same
    /// job/step, and execute that one step again. No password is copied into the outbox.
    /// </summary>
    public static class OutboxReplay
    {
        public static OutboxReplayResult Replay(OutboxStore.OutboxItem item, AppConfig cfg)
        {
            OutboxReplayResult result = new OutboxReplayResult();
            if (item == null) { result.Permanent = true; result.Message = "Outbox item is null."; return result; }
            if (cfg == null) { result.Permanent = true; result.Message = "Configuration is unavailable."; return result; }

            SyncJob job = null;
            foreach (SyncJob j in cfg.Jobs)
                if (j != null && string.Equals(j.Id, item.JobId, StringComparison.OrdinalIgnoreCase)) { job = j; break; }
            if (job == null)
            {
                result.Permanent = true;
                result.Message = "Job '" + item.JobName + "' (" + item.JobId + ") no longer exists in config.json.";
                return result;
            }
            if (!job.Enabled)
            {
                result.Message = "Job '" + job.Name + "' is disabled; replay will be retried after it is enabled.";
                return result;
            }

            JobStep step = null;
            foreach (JobStep s in job.Steps)
            {
                if (s == null) continue;
                if (item.StepId > 0 && s.StepId == item.StepId) { step = s; break; }
                if (string.Equals(s.Name ?? "", item.StepName ?? "", StringComparison.OrdinalIgnoreCase)) { step = s; break; }
            }
            if (step == null)
            {
                result.Permanent = true;
                result.Message = "Step '" + item.StepName + "' (" + item.StepId + ") no longer exists in job '" + job.Name + "'.";
                return result;
            }
            if (!step.Enabled)
            {
                result.Message = "Step '" + step.Name + "' is disabled; replay will be retried after it is enabled.";
                return result;
            }
            if (step.Type != StepType.Transfer)
            {
                result.Permanent = true;
                result.Message = "Only Transfer steps can be replayed automatically; step type is " + step.TypeText() + ".";
                return result;
            }
            if (Engine.IsRunning(job.Id))
            {
                result.Message = "Job '" + job.Name + "' is running now; replay will be retried.";
                return result;
            }

            string srcConn = cfg.ResolveStepConnectionString(step, true);
            string dstConn = cfg.ResolveStepConnectionString(step, false);
            if (string.IsNullOrEmpty(srcConn) || string.IsNullOrEmpty(dstConn))
            {
                result.Message = "Source or destination connection is not configured for job '" + job.Name +
                                 "'; replay will be retried after the connection is fixed.";
                return result;
            }

            int timeout = job.CommandTimeoutSec >= 0 ? job.CommandTimeoutSec : 0;   // 0 = no limit
            result.Table = step.DestTable;
            AppLog.Info(job.Name, "Outbox replay: step " + step.StepId + " [" + step.Name + "] item=" + item.Id);
            try
            {
                RunResult run = Engine.ExecuteOutboxReplay(job, step, cfg, srcConn, dstConn, timeout);
                result.Ok = run != null && run.Ok;
                result.Rows = run != null ? run.Rows : 0;
                result.Message = run != null ? run.Message : "Replay returned no result.";
                if (!result.Ok) AppLog.Warn(job.Name, "Outbox replay failed: " + result.Message);
                return result;
            }
            catch (Exception ex)
            {
                result.Ok = false;
                result.Message = ex.Message;
                AppLog.Warn(job.Name, "Outbox replay error: " + ex.Message);
                return result;
            }
        }
    }

    public static partial class Engine
    {
        /// <summary>
        /// Executes exactly one transfer step for the outbox. Outbox enqueueing is suppressed so a
        /// permanently failing replay does not create an infinite chain of new outbox rows.
        /// </summary>
        public static RunResult ExecuteOutboxReplay(SyncJob job, JobStep step, AppConfig cfg,
            string srcConn, string dstConn, int timeout)
        {
            string oldJobId = _currentJobId;
            string oldJobName = _currentJobName;
            AppConfig oldCfg = _currentConfig;
            bool oldSuppress = _suppressOutbox;

            _currentJobId = job != null ? job.Id : "";
            _currentJobName = job != null ? job.Name : "";
            _currentConfig = cfg;
            _suppressOutbox = true;
            try
            {
                RunResult r = ExecuteStep(step, srcConn, dstConn, timeout);
                if (r != null && r.Ok)
                {
                    try
                    {
                        // Persist only the delta/watermark fields that the step may have advanced.
                        JobStep snapshot = JsonConvert.DeserializeObject<JobStep>(JsonConvert.SerializeObject(step));
                        AppConfig.UpdateStepState(job.Id, step.StepId, snapshot);
                    }
                    catch (Exception ex)
                    {
                        AppLog.Warn(job != null ? job.Name : "-", "Outbox replay state could not be saved: " + ex.Message);
                    }
                    try
                    {
                        string table = step != null ? step.DestTable : "";
                        CacheStoreFactory.Current.SetLastSuccess(job.Id, table, new SyncStateInfo
                        {
                            JobId = job.Id,
                            Table = table,
                            LastSuccessUtc = DateTime.UtcNow,
                            LastMessage = "Outbox replay step " + step.StepId + " (" + r.Rows + " rows)",
                            RowsAffected = r.Rows,
                            Direction = "Forward",
                            OriginId = cfg != null ? cfg.OriginId : ""
                        });
                        long wm = 0;
                        if (step != null && step.ChangeTrackingVersion.HasValue) wm = step.ChangeTrackingVersion.Value;
                        if (wm > 0) CacheStoreFactory.Current.SetWatermark(job.Id, table, wm, DateTime.UtcNow);
                    }
                    catch { }
                }
                return r;
            }
            finally
            {
                _currentJobId = oldJobId;
                _currentJobName = oldJobName;
                _currentConfig = oldCfg;
                _suppressOutbox = oldSuppress;
            }
        }
    }
}
