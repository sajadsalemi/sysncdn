using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace SyncDB
{
    /// <summary>
    /// Smart Delta: RV / COL / HASH + batched dest writes (temp table → UPDATE/INSERT/DELETE per ~1M rows).
    /// Weekly HASH catch-up for deletes when using RV or COL.
    /// </summary>
    public static partial class Engine
    {
        private const long DeltaChunkDefault = 1000000;
        private const int HashRetentionDays = 7;

        /// <summary>
        /// Try Smart Delta path. Returns null if not applicable (caller uses classic transfer).
        /// </summary>
        public static RunResult TryExecuteSmartDelta(JobStep step, string srcConn, string dstConn, int timeout)
        {
            if (step == null || step.Type != StepType.Transfer) return null;
            if (step.Mode != WriteMode.MergeUpsert && step.Mode != WriteMode.SyncChanges) return null;
            if (string.IsNullOrWhiteSpace(step.KeyColumns)) return null;
            if (!string.IsNullOrWhiteSpace(step.SqlCommand)) return null; // custom SQL → classic

            string[] keys = SplitKeys(step.KeyColumns);
            if (keys.Length == 0) return null;

            string srcTable = NormalizeTableName(step.SourceTable);
            string dstTable = NormalizeTableName(string.IsNullOrWhiteSpace(step.DestTable) ? step.SourceTable : step.DestTable);

            // fingerprint: if source/dest/keys changed → full resync
            string fp = (srcConn ?? "") + "|" + (dstConn ?? "") + "|" + srcTable + "|" + dstTable + "|" + string.Join(",", keys);
            bool forceFull = !string.Equals(step.DeltaFingerprint ?? "", fp, StringComparison.Ordinal);
            if (forceFull)
            {
                AppLog.Info("-", "Smart Delta: fingerprint changed — full baseline.");
                step.IncrementalLastValue = "";
                step.ChangeTrackingVersion = null;
                step.CdcLastLsn = "";
                step.LastHashFullUtc = null;
            }
            step.DeltaFingerprint = fp;

            long chunk = step.DeltaChunkRows > 0 ? step.DeltaChunkRows : DeltaChunkDefault;
            if (chunk < 10000) chunk = 10000;

            // User must tick at least one method (or CT/CDC). Nothing auto-enabled.
            bool useRv0, useCol0, useHash0;
            ResolveDeltaFlags(step, out useRv0, out useCol0, out useHash0);
            if (!step.UseChangeTracking && !step.UseCdc && !useRv0 && !useCol0 && !useHash0)
            {
                AppLog.Info("-", "Smart Delta: no method enabled (RV/COL/HASH/CT/CDC all off) — classic transfer.");
                return null;
            }

            // empty dest → bulk first load (parallel ranges if numeric PK and big)
            if (IsDestEmpty(dstConn, dstTable, timeout))
            {
                AppLog.Info("-", "Smart Delta: destination empty — bulk seed.");
                return BulkSeed(step, srcConn, dstConn, srcTable, dstTable, keys, timeout);
            }

            string method = DetectMethod(step, srcConn, srcTable, timeout);
            if (method == null || method == "NONE")
            {
                AppLog.Info("-", "Smart Delta: no applicable method — classic transfer.");
                return null;
            }
            AppLog.Info("-", "Smart Delta method=" + method + " table=" + srcTable);

            // Large-table guidance (especially important for ~100 GB)
            long estRows = EstimateRowCount(srcConn, srcTable, timeout);
            if (estRows > 2000000 && method == "HASH")
            {
                AppLog.Warn("-", "LARGE TABLE (" + estRows + " rows): HASH comparison loads keys into memory and is not ideal for very large tables. " +
                    "Strongly recommend enabling SQL Server Change Tracking on the source database and table (best official method for 10–100+ GB). " +
                    "Or add a rowversion / ModifiedDate column. See README for 100GB advice.");
            }

            // weekly HASH reconciliation for RV/COL (catch deletes) — only if HASH checkbox is on
            bool useRvF, useColF, useHashF;
            ResolveDeltaFlags(step, out useRvF, out useColF, out useHashF);
            bool needHash = method == "HASH";
            if ((method == "RV" || method == "COL") && useHashF)
            {
                DateTime? last = step.LastHashFullUtc;
                if (!last.HasValue || (DateTime.UtcNow - last.Value).TotalDays >= HashRetentionDays)
                {
                    AppLog.Info("-", "Smart Delta: weekly HASH reconciliation for deletes.");
                    needHash = true;
                }
            }
            else if ((method == "RV" || method == "COL") && !useHashF)
            {
                AppLog.Info("-", "Smart Delta: HASH checkbox off — skip weekly delete reconciliation.");
            }

            RunResult total = new RunResult();
            total.Ok = true;
            StringBuilder msg = new StringBuilder();

            if (method == "CT")
            {
                long? ctVer = null;
                string ctSql = TryBuildChangeTrackingSelect(step, srcConn, timeout, out ctVer);
                if (ctSql != null)
                {
                    RunResult r = ApplyBatchedMerge(step, srcConn, dstConn, ctSql, srcTable, dstTable, keys, chunk, timeout, false);
                    MergeResult(total, r, msg);
                    // CHANGETABLE has no row body for deletes, so the SELECT above excludes them.
                    // Apply deleted primary keys explicitly for true INSERT/UPDATE/DELETE sync.
                    if (step.Mode == WriteMode.SyncChanges && step.ChangeTrackingVersion.HasValue && ctVer.HasValue)
                    {
                        long removed = DeleteChangeTrackingRows(srcConn, dstConn, srcTable, dstTable,
                            step.ChangeTrackingVersion.Value, ctVer.Value, timeout);
                        if (removed > 0) msg.Append(removed).Append(" deleted. ");
                    }
                    if (ctVer.HasValue) CommitChangeTrackingVersion(step, ctVer);
                    total.Message = "Smart Delta [CT] " + msg.ToString() + " (Change Tracking — recommended for large tables)";
                    return total;
                }
                AppLog.Warn("-", "Change Tracking requested but unavailable; falling back.");
                method = FindRowVersionColumn(srcConn, srcTable, timeout) != null ? "RV" :
                         (!string.IsNullOrWhiteSpace(step.IncrementalColumn) ? "COL" : "HASH");
            }
            else if (method == "CDC")
            {
                string cdcSql = TryBuildCdcSelect(step, srcConn, timeout);
                if (cdcSql != null)
                {
                    RunResult r = ApplyBatchedMerge(step, srcConn, dstConn, cdcSql, srcTable, dstTable, keys, chunk, timeout, false);
                    MergeResult(total, r, msg);
                    CommitCdcLsn(step);
                    total.Message = "Smart Delta [CDC] " + msg.ToString();
                    return total;
                }
                AppLog.Warn("-", "CDC requested but unavailable; falling back.");
                method = FindRowVersionColumn(srcConn, srcTable, timeout) != null ? "RV" :
                         (!string.IsNullOrWhiteSpace(step.IncrementalColumn) ? "COL" : "HASH");
            }

            if (method == "RV")
            {
                RunResult r = DeltaByRowVersion(step, srcConn, dstConn, srcTable, dstTable, keys, chunk, timeout);
                MergeResult(total, r, msg);
            }
            else if (method == "COL")
            {
                RunResult r = DeltaByColumn(step, srcConn, dstConn, srcTable, dstTable, keys, chunk, timeout);
                MergeResult(total, r, msg);
            }

            if (needHash || method == "HASH")
            {
                RunResult r = DeltaByHash(step, srcConn, dstConn, srcTable, dstTable, keys, chunk, timeout,
                    step.Mode == WriteMode.SyncChanges || needHash);
                MergeResult(total, r, msg);
                step.LastHashFullUtc = DateTime.UtcNow;
            }

            total.Message = "Smart Delta [" + method + (needHash && method != "HASH" ? "+HASH" : "") + "] " + msg.ToString();
            return total;
        }

        private static void MergeResult(RunResult total, RunResult r, StringBuilder msg)
        {
            if (r == null) return;
            total.Rows += r.Rows;
            if (!string.IsNullOrEmpty(r.Message)) msg.Append(r.Message).Append(" ");
            if (!r.Ok) total.Ok = false;
        }

        private static string[] SplitKeys(string keyColumns)
        {
            string[] raw = (keyColumns ?? "").Split(new char[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
            List<string> keys = new List<string>();
            foreach (string k in raw)
            {
                string t = k.Trim().Trim('[', ']');
                if (t.Length > 0) keys.Add(t);
            }
            return keys.ToArray();
        }

        private static long DeleteChangeTrackingRows(string srcConn, string dstConn, string srcTable,
            string dstTable, long lastVersion, long currentVersion, int timeout)
        {
            if (lastVersion >= currentVersion) return 0;
            string[] pks = SplitKeys(GetPrimaryKeyColumns(srcConn, srcTable));
            if (pks.Length == 0) return 0;
            List<object[]> deletedKeys = new List<object[]>();
            using (SqlConnection src = new SqlConnection(srcConn))
            {
                src.Open();
                StringBuilder cols = new StringBuilder();
                for (int i = 0; i < pks.Length; i++)
                {
                    if (i > 0) cols.Append(",");
                    cols.Append("[").Append(pks[i].Replace("]", "]]" )).Append("]");
                }
                string sql = "SELECT " + cols + " FROM CHANGETABLE(CHANGES " + srcTable + ", " + lastVersion + ") AS ct WHERE ct.SYS_CHANGE_OPERATION = N'D'";
                using (SqlCommand q = new SqlCommand(sql, src))
                {
                    q.CommandTimeout = timeout;
                    using (SqlDataReader rd = q.ExecuteReader())
                        while (rd.Read())
                        {
                            object[] vals = new object[pks.Length];
                            rd.GetValues(vals);
                            deletedKeys.Add(vals);
                        }
                }
            }
            if (deletedKeys.Count == 0) return 0;
            long removedCount = 0;
            using (SqlConnection dst = new SqlConnection(dstConn))
            {
                dst.Open();
                foreach (object[] vals in deletedKeys)
                {
                    StringBuilder where = new StringBuilder();
                    for (int i = 0; i < pks.Length; i++)
                    {
                        if (i > 0) where.Append(" AND ");
                        where.Append("[").Append(pks[i].Replace("]", "]]" )).Append("]=@k").Append(i);
                    }
                    using (SqlCommand d = new SqlCommand("DELETE FROM " + dstTable + " WHERE " + where, dst))
                    {
                        d.CommandTimeout = timeout;
                        for (int i = 0; i < vals.Length; i++)
                            d.Parameters.AddWithValue("@k" + i, vals[i] ?? DBNull.Value);
                        removedCount += d.ExecuteNonQuery();
                    }
                }
            }
            if (removedCount > 0)
                AppLog.Info("-", "Change Tracking deleted " + removedCount + " row(s) from " + dstTable);
            return removedCount;
        }

        private static string DetectMethod(JobStep step, string srcConn, string srcTable, int timeout)
        {
            // Resolve which methods the user enabled (checkboxes). Legacy DeltaMethod still supported.
            bool useRv, useCol, useHash;
            ResolveDeltaFlags(step, out useRv, out useCol, out useHash);

            string prefer = (step.DeltaMethod ?? "Auto").Trim();
            // Explicit single method from old dropdown (when flags all true / Auto)
            if (prefer.Equals("HASH", StringComparison.OrdinalIgnoreCase) && useHash) return "HASH";
            if (prefer.Equals("COL", StringComparison.OrdinalIgnoreCase) && useCol
                && !string.IsNullOrWhiteSpace(step.IncrementalColumn))
                return "COL";
            if (prefer.Equals("RV", StringComparison.OrdinalIgnoreCase) && useRv)
            {
                if (FindRowVersionColumn(srcConn, srcTable, timeout) != null) return "RV";
                if (useHash) return "HASH";
                if (useCol && !string.IsNullOrWhiteSpace(step.IncrementalColumn)) return "COL";
                return "NONE";
            }

            // Auto / combination: pick best enabled method first
            if (step.UseChangeTracking)
                return "CT";
            if (step.UseCdc)
                return "CDC";
            if (useRv && FindRowVersionColumn(srcConn, srcTable, timeout) != null) return "RV";
            if (useCol && !string.IsNullOrWhiteSpace(step.IncrementalColumn)) return "COL";
            if (useHash) return "HASH";
            // Nothing enabled → caller falls back to classic transfer (no silent HASH)
            AppLog.Info("-", "Smart Delta: no method checkbox enabled — skip smart delta.");
            return "NONE";
        }

        /// <summary>Map checkboxes + legacy DeltaMethod into three flags.</summary>
        private static void ResolveDeltaFlags(JobStep step, out bool useRv, out bool useCol, out bool useHash)
        {
            // New fields: if any explicit false was saved we trust the three bools.
            // Default constructor sets all true.
            useRv = step.DeltaUseRv;
            useCol = step.DeltaUseCol;
            useHash = step.DeltaUseHash;

            string prefer = (step.DeltaMethod ?? "Auto").Trim();
            // Old jobs: only DeltaMethod set, bools may be default true
            if (prefer.Equals("RV", StringComparison.OrdinalIgnoreCase)
                && step.DeltaUseRv && step.DeltaUseCol && step.DeltaUseHash)
            {
                useRv = true; useCol = false; useHash = false;
            }
            else if (prefer.Equals("COL", StringComparison.OrdinalIgnoreCase)
                && step.DeltaUseRv && step.DeltaUseCol && step.DeltaUseHash)
            {
                useRv = false; useCol = true; useHash = false;
            }
            else if (prefer.Equals("HASH", StringComparison.OrdinalIgnoreCase)
                && step.DeltaUseRv && step.DeltaUseCol && step.DeltaUseHash)
            {
                useRv = false; useCol = false; useHash = true;
            }
            // Combination strings e.g. "RV+HASH"
            if (prefer.IndexOf('+') >= 0)
            {
                useRv = prefer.IndexOf("RV", StringComparison.OrdinalIgnoreCase) >= 0;
                useCol = prefer.IndexOf("COL", StringComparison.OrdinalIgnoreCase) >= 0;
                useHash = prefer.IndexOf("HASH", StringComparison.OrdinalIgnoreCase) >= 0;
            }
        }

        private static string FindRowVersionColumn(string conn, string table, int timeout)
        {
            try
            {
                using (SqlConnection c = new SqlConnection(conn))
                {
                    c.Open();
                    using (SqlCommand q = new SqlCommand(
                        "SELECT TOP 1 c.name FROM sys.columns c WHERE c.object_id = OBJECT_ID(@t) AND c.system_type_id = 189", c))
                    {
                        q.CommandTimeout = timeout;
                        q.Parameters.AddWithValue("@t", table);
                        object o = q.ExecuteScalar();
                        return o == null || o == DBNull.Value ? null : o.ToString();
                    }
                }
            }
            catch { return null; }
        }

        private static bool IsDestEmpty(string dstConn, string dstTable, int timeout)
        {
            try
            {
                using (SqlConnection c = new SqlConnection(dstConn))
                {
                    c.Open();
                    // table missing → treat as empty (create via bulk path)
                    using (SqlCommand exists = new SqlCommand("SELECT OBJECT_ID(@t)", c))
                    {
                        exists.Parameters.AddWithValue("@t", dstTable);
                        object id = exists.ExecuteScalar();
                        if (id == null || id == DBNull.Value) return true;
                    }
                    using (SqlCommand q = new SqlCommand("SELECT CASE WHEN EXISTS (SELECT 1 FROM " + dstTable + ") THEN 0 ELSE 1 END", c))
                    {
                        q.CommandTimeout = timeout;
                        return Convert.ToInt32(q.ExecuteScalar()) == 1;
                    }
                }
            }
            catch { return true; }
        }

        private static long EstimateRowCount(string conn, string table, int timeout)
        {
            try
            {
                using (SqlConnection c = new SqlConnection(conn))
                {
                    c.Open();
                    using (SqlCommand q = new SqlCommand(
                        "SELECT SUM(p.rows) FROM sys.partitions p WHERE p.object_id = OBJECT_ID(@t) AND p.index_id IN (0,1)", c))
                    {
                        q.CommandTimeout = timeout;
                        q.Parameters.AddWithValue("@t", table);
                        object o = q.ExecuteScalar();
                        if (o == null || o == DBNull.Value) return 0;
                        return Convert.ToInt64(o);
                    }
                }
            }
            catch { return 0; }
        }

        private static bool IsNumericType(string conn, string table, string col, int timeout)
        {
            try
            {
                using (SqlConnection c = new SqlConnection(conn))
                {
                    c.Open();
                    using (SqlCommand q = new SqlCommand(
                        "SELECT t.name FROM sys.columns c JOIN sys.types t ON c.user_type_id = t.user_type_id " +
                        "WHERE c.object_id = OBJECT_ID(@tbl) AND c.name = @c", c))
                    {
                        q.CommandTimeout = timeout;
                        q.Parameters.AddWithValue("@tbl", table);
                        q.Parameters.AddWithValue("@c", col);
                        object o = q.ExecuteScalar();
                        string n = (o ?? "").ToString().ToLowerInvariant();
                        return n == "int" || n == "bigint" || n == "smallint" || n == "tinyint" || n == "decimal" || n == "numeric";
                    }
                }
            }
            catch { return false; }
        }

        /// <summary>First load: SqlBulkCopy; parallel key-range readers when single numeric PK and &gt; 2M rows.</summary>
        private static RunResult BulkSeed(JobStep step, string srcConn, string dstConn,
            string srcTable, string dstTable, string[] keys, int timeout)
        {
            RunResult r = new RunResult();
            long rowsEst = EstimateRowCount(srcConn, srcTable, timeout);
            bool parallel = keys.Length == 1 && IsNumericType(srcConn, srcTable, keys[0], timeout) && rowsEst > 2000000;

            if (parallel)
            {
                int n = Math.Min(Math.Max(Environment.ProcessorCount, 2), 8);
                AppLog.Info("-", "Smart Delta bulk seed parallel ranges x" + n + " estRows=" + rowsEst);
                // min/max key
                long minK = 0, maxK = 0;
                using (SqlConnection c = new SqlConnection(srcConn))
                {
                    c.Open();
                    string k = "[" + keys[0].Replace("]", "]]") + "]";
                    using (SqlCommand q = new SqlCommand("SELECT MIN(" + k + "), MAX(" + k + ") FROM " + srcTable, c))
                    {
                        q.CommandTimeout = timeout;
                        using (SqlDataReader rd = q.ExecuteReader())
                        {
                            if (!rd.Read() || rd.IsDBNull(0)) { parallel = false; }
                            else { minK = Convert.ToInt64(rd.GetValue(0)); maxK = Convert.ToInt64(rd.GetValue(1)); }
                        }
                    }
                }
                if (parallel && maxK > minK)
                {
                    long span = maxK - minK + 1;
                    long slice = Math.Max(1, span / n);
                    long totalRows = 0;
                    object gate = new object();
                    Parallel.For(0, n, i =>
                    {
                        long lo = minK + i * slice;
                        long hi = (i == n - 1) ? maxK : (lo + slice - 1);
                        string baseSel = BuildSafeSelectFromTable(srcConn, srcTable, timeout);
                        string sql = "SELECT * FROM (" + baseSel + ") AS __sd WHERE [" + keys[0].Replace("]", "]]") + "] BETWEEN " + lo + " AND " + hi;
                        long part = BulkCopySql(srcConn, dstConn, sql, dstTable, timeout, i == 0);
                        lock (gate) totalRows += part;
                    });
                    r.Ok = true;
                    r.Rows = totalRows;
                    r.Message = "bulk seed parallel " + totalRows + " rows";
                    return r;
                }
            }

            long all = BulkCopySql(srcConn, dstConn, BuildSafeSelectFromTable(srcConn, srcTable, timeout), dstTable, timeout, true);
            r.Ok = true;
            r.Rows = all;
            r.Message = "bulk seed " + all + " rows";
            return r;
        }

        private static long BulkCopySql(string srcConn, string dstConn, string selectSql, string dstTable, int timeout, bool ensureTable)
        {
            long count = 0;
            using (SqlConnection src = new SqlConnection(srcConn))
            using (SqlConnection dst = new SqlConnection(dstConn))
            {
                src.Open();
                dst.Open();
                using (SqlCommand cmd = new SqlCommand(selectSql, src))
                {
                    cmd.CommandTimeout = timeout;
                    using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess))
                    {
                        if (ensureTable)
                            EnsureDestFromReader(dst, dstTable, rd, timeout);
                        using (SqlBulkCopy bulk = new SqlBulkCopy(dst))
                        {
                            bulk.DestinationTableName = dstTable;
                            bulk.BulkCopyTimeout = timeout;
                            bulk.BatchSize = 5000;
                            for (int i = 0; i < rd.FieldCount; i++)
                                bulk.ColumnMappings.Add(rd.GetName(i), rd.GetName(i));
                            // count via wrapper
                            DataTable buf = new DataTable();
                            for (int i = 0; i < rd.FieldCount; i++)
                            {
                                Type ft = typeof(string);
                                try { ft = rd.GetFieldType(i) ?? typeof(string); } catch { ft = typeof(string); }
                                buf.Columns.Add(rd.GetName(i), ft);
                            }
                            object[] vals = new object[rd.FieldCount];
                            bool rebuilt = false;
                            while (rd.Read())
                            {
                                rd.GetValues(vals);
                                buf.Rows.Add((object[])vals.Clone());
                                count++;
                                if (buf.Rows.Count >= 5000)
                                {
                                    try { bulk.WriteToServer(buf); }
                                    catch (Exception ex)
                                    {
                                        if (!rebuilt && IsTypeMismatchMsg(ex.Message) && TryRebuildDestFromBuf(dst, dstTable, buf, timeout))
                                        {
                                            rebuilt = true;
                                            bulk.WriteToServer(buf);
                                        }
                                        else throw;
                                    }
                                    buf.Clear();
                                }
                            }
                            if (buf.Rows.Count > 0)
                            {
                                try { bulk.WriteToServer(buf); }
                                catch (Exception ex)
                                {
                                    if (!rebuilt && IsTypeMismatchMsg(ex.Message) && TryRebuildDestFromBuf(dst, dstTable, buf, timeout))
                                        bulk.WriteToServer(buf);
                                    else throw;
                                }
                            }
                        }
                    }
                }
            }
            return count;
        }

        private static void EnsureDestFromReader(SqlConnection dst, string dstTable, SqlDataReader rd, int timeout)
        {
            bool exists = false;
            using (SqlCommand chk = new SqlCommand("SELECT OBJECT_ID(@t, N'U')", dst))
            {
                chk.Parameters.AddWithValue("@t", dstTable);
                object id = chk.ExecuteScalar();
                exists = id != null && id != DBNull.Value && Convert.ToInt32(id) != 0;
            }
            if (exists)
            {
                // empty + wrong types (e.g. TIME stored as NVARCHAR) → drop and rebuild
                bool empty = true;
                try
                {
                    using (SqlCommand q = new SqlCommand(
                        "SELECT CASE WHEN EXISTS (SELECT 1 FROM " + dstTable + ") THEN 0 ELSE 1 END", dst))
                    {
                        q.CommandTimeout = timeout;
                        empty = Convert.ToInt32(q.ExecuteScalar()) == 1;
                    }
                }
                catch { empty = true; }

                if (!empty) return; // keep existing data

                // Compare: any dest column that cannot hold reader CLR type → force recreate
                bool needRebuild = false;
                try
                {
                    Dictionary<string, string> destTypes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    using (SqlCommand q = new SqlCommand(
                        "SELECT c.name, TYPE_NAME(c.user_type_id) FROM sys.columns c WHERE c.object_id = OBJECT_ID(@t)", dst))
                    {
                        q.Parameters.AddWithValue("@t", dstTable);
                        using (SqlDataReader r = q.ExecuteReader())
                            while (r.Read())
                                destTypes[r.GetString(0)] = (r.GetString(1) ?? "").ToLowerInvariant();
                    }
                    for (int i = 0; i < rd.FieldCount; i++)
                    {
                        string name = rd.GetName(i);
                        Type ft = typeof(string);
                        try { ft = rd.GetFieldType(i) ?? typeof(string); } catch { ft = typeof(string); }
                        string want = ClrToSql(ft).ToLowerInvariant();
                        // simplify want to base type word
                        int p = want.IndexOf('(');
                        if (p > 0) want = want.Substring(0, p);
                        string have;
                        if (!destTypes.TryGetValue(name, out have)) { needRebuild = true; break; }
                        if (ft == typeof(TimeSpan) && have != "time") { needRebuild = true; break; }
                        if (ft == typeof(DateTime) && have != "datetime" && have != "datetime2" && have != "smalldatetime" && have != "date")
                        { needRebuild = true; break; }
                        if (ft == typeof(int) && have != "int") { needRebuild = true; break; }
                        if (ft == typeof(Guid) && have != "uniqueidentifier") { needRebuild = true; break; }
                        if (ft == typeof(byte[]) && have.IndexOf("binary") < 0 && have != "image") { needRebuild = true; break; }
                    }
                }
                catch { needRebuild = true; }

                if (!needRebuild) return;

                using (SqlCommand drop = new SqlCommand("DROP TABLE " + dstTable, dst))
                {
                    drop.CommandTimeout = timeout;
                    drop.ExecuteNonQuery();
                }
                AppLog.Warn("-", "Dropped empty dest " + dstTable + " to rebuild column types (e.g. TIME was NVARCHAR).");
            }

            EnsureSchemaExists(dst, null, dstTable, timeout);
            StringBuilder sb = new StringBuilder();
            sb.Append("CREATE TABLE ").Append(dstTable).Append(" (");
            for (int i = 0; i < rd.FieldCount; i++)
            {
                if (i > 0) sb.Append(", ");
                string name = rd.GetName(i).Replace("]", "]]");
                Type t = typeof(string);
                try { t = rd.GetFieldType(i) ?? typeof(string); } catch { t = typeof(string); }
                sb.Append("[").Append(name).Append("] ").Append(ClrToSql(t)).Append(" NULL");
            }
            sb.Append(")");
            using (SqlCommand cr = new SqlCommand(sb.ToString(), dst))
            {
                cr.CommandTimeout = timeout;
                cr.ExecuteNonQuery();
            }
            AppLog.Info("-", "Created dest table " + dstTable + " from source reader types.");
        }

        private static string ClrToSql(Type t)
        {
            if (t == typeof(int)) return "INT";
            if (t == typeof(long)) return "BIGINT";
            if (t == typeof(short)) return "SMALLINT";
            if (t == typeof(byte)) return "TINYINT";
            if (t == typeof(bool)) return "BIT";
            if (t == typeof(DateTime)) return "DATETIME2";
            if (t == typeof(DateTimeOffset)) return "DATETIMEOFFSET";
            if (t == typeof(TimeSpan)) return "TIME(7)"; // was NVARCHAR — broke HumanResources.Shift
            if (t == typeof(decimal)) return "DECIMAL(38,10)";
            if (t == typeof(double) || t == typeof(float)) return "FLOAT";
            if (t == typeof(Guid)) return "UNIQUEIDENTIFIER";
            if (t == typeof(byte[])) return "VARBINARY(MAX)";
            return "NVARCHAR(MAX)";
        }

        private static bool IsTypeMismatchMsg(string m)
        {
            if (string.IsNullOrEmpty(m)) return false;
            return m.IndexOf("cannot be converted", StringComparison.OrdinalIgnoreCase) >= 0
                || m.IndexOf("type mismatch", StringComparison.OrdinalIgnoreCase) >= 0
                || m.IndexOf("failed to convert", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool TryRebuildDestFromBuf(SqlConnection dst, string dstTable, DataTable buf, int timeout)
        {
            try
            {
                // only if empty
                using (SqlCommand q = new SqlCommand(
                    "SELECT CASE WHEN OBJECT_ID(@t, N'U') IS NULL THEN 1 WHEN EXISTS (SELECT 1 FROM " + dstTable + ") THEN 0 ELSE 1 END", dst))
                {
                    q.Parameters.AddWithValue("@t", dstTable);
                    q.CommandTimeout = timeout;
                    if (Convert.ToInt32(q.ExecuteScalar()) != 1) return false;
                }
                using (SqlCommand drop = new SqlCommand(
                    "IF OBJECT_ID(@t, N'U') IS NOT NULL EXEC(N'DROP TABLE " + dstTable.Replace("'", "''") + "')", dst))
                {
                    drop.Parameters.AddWithValue("@t", dstTable);
                    drop.CommandTimeout = timeout;
                    drop.ExecuteNonQuery();
                }
                EnsureSchemaExists(dst, null, dstTable, timeout);
                StringBuilder sb = new StringBuilder();
                sb.Append("CREATE TABLE ").Append(dstTable).Append(" (");
                for (int i = 0; i < buf.Columns.Count; i++)
                {
                    if (i > 0) sb.Append(", ");
                    DataColumn dc = buf.Columns[i];
                    sb.Append("[").Append(dc.ColumnName.Replace("]", "]]")).Append("] ")
                      .Append(ClrToSql(dc.DataType)).Append(" NULL");
                }
                sb.Append(")");
                using (SqlCommand cr = new SqlCommand(sb.ToString(), dst))
                {
                    cr.CommandTimeout = timeout;
                    cr.ExecuteNonQuery();
                }
                AppLog.Warn("-", "Rebuilt dest " + dstTable + " after type mismatch (TIME/etc.).");
                return true;
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "TryRebuildDestFromBuf: " + ex.Message);
                return false;
            }
        }

        private static RunResult DeltaByRowVersion(JobStep step, string srcConn, string dstConn,
            string srcTable, string dstTable, string[] keys, long chunk, int timeout)
        {
            string rv = FindRowVersionColumn(srcConn, srcTable, timeout);
            if (rv == null) return DeltaByHash(step, srcConn, dstConn, srcTable, dstTable, keys, chunk, timeout, false);

            string last = step.IncrementalLastValue ?? "";
            string baseSel = BuildSafeSelectFromTable(srcConn, srcTable, timeout);
            string sql;
            if (string.IsNullOrWhiteSpace(last))
                sql = baseSel;
            else
                sql = "SELECT * FROM (" + baseSel + ") AS __sd WHERE [" + rv.Replace("]", "]]") + "] > " + last;

            RunResult r = ApplyBatchedMerge(step, srcConn, dstConn, sql, srcTable, dstTable, keys, chunk, timeout, false);
            // advance watermark
            try
            {
                using (SqlConnection c = new SqlConnection(srcConn))
                {
                    c.Open();
                    using (SqlCommand q = new SqlCommand(
                        "SELECT MAX(CONVERT(bigint, [" + rv.Replace("]", "]]") + "])) FROM " + srcTable, c))
                    {
                        q.CommandTimeout = timeout;
                        object o = q.ExecuteScalar();
                        if (o != null && o != DBNull.Value)
                            step.IncrementalLastValue = Convert.ToInt64(o).ToString();
                    }
                }
            }
            catch { }
            return r;
        }

        private static RunResult DeltaByColumn(JobStep step, string srcConn, string dstConn,
            string srcTable, string dstTable, string[] keys, long chunk, int timeout)
        {
            string col = (step.IncrementalColumn ?? "").Trim().Trim('[', ']');
            if (col.Length == 0)
                return DeltaByHash(step, srcConn, dstConn, srcTable, dstTable, keys, chunk, timeout, false);

            string last = step.IncrementalLastValue ?? "";
            string baseSel = BuildSafeSelectFromTable(srcConn, srcTable, timeout);
            string sql;
            if (string.IsNullOrWhiteSpace(last))
                sql = baseSel;
            else
            {
                // try as date/number string literal-safe
                sql = "SELECT * FROM (" + baseSel + ") AS __sd WHERE [" + col.Replace("]", "]]") + "] > @last";
            }

            RunResult r;
            if (string.IsNullOrWhiteSpace(last))
                r = ApplyBatchedMerge(step, srcConn, dstConn, sql, srcTable, dstTable, keys, chunk, timeout, false);
            else
                r = ApplyBatchedMergeParam(step, srcConn, dstConn, sql, last, srcTable, dstTable, keys, chunk, timeout, false);

            try
            {
                using (SqlConnection c = new SqlConnection(srcConn))
                {
                    c.Open();
                    using (SqlCommand q = new SqlCommand("SELECT MAX([" + col.Replace("]", "]]") + "]) FROM " + srcTable, c))
                    {
                        q.CommandTimeout = timeout;
                        object o = q.ExecuteScalar();
                        if (o != null && o != DBNull.Value)
                        {
                            if (o is DateTime) step.IncrementalLastValue = ((DateTime)o).ToString("o");
                            else step.IncrementalLastValue = Convert.ToString(o);
                        }
                    }
                }
            }
            catch { }
            return r;
        }

        /// <summary>
        /// HASH: compare key hashes on both servers (data stays on each server).
        /// Without RV/COL this scans both sides — can take minutes..hours on 100GB but no full data ship for compare.
        /// CHECKSUM(*) is NOT used: XML/text/image/geography etc. are invalid for CHECKSUM (SQL 8116).
        /// </summary>
        private static RunResult DeltaByHash(JobStep step, string srcConn, string dstConn,
            string srcTable, string dstTable, string[] keys, long chunk, int timeout, bool doDeletes)
        {
            RunResult r = new RunResult { Ok = true };
            string keyList = KeyListSqlSafe(srcConn, srcTable, keys, timeout);
            // Build a CHECKSUM of only types SQL Server accepts (cast XML → nvarchar)
            string csExpr = BuildSafeChecksumExpr(srcConn, srcTable, timeout);
            if (string.IsNullOrEmpty(csExpr)) csExpr = "CHECKSUM(" + keyList + ")";
            string srcHashSql =
                "SELECT " + keyList + ", " + csExpr + " AS _sd_cs FROM " + srcTable;
            string dstHashSql =
                "SELECT " + keyList + ", " + csExpr + " AS _sd_cs FROM " + dstTable;

            Dictionary<string, int> srcMap = LoadKeyHash(srcConn, srcHashSql, keys, timeout);
            Dictionary<string, int> dstMap = new Dictionary<string, int>(StringComparer.Ordinal);
            try { dstMap = LoadKeyHash(dstConn, dstHashSql, keys, timeout); }
            catch (Exception ex) { AppLog.Warn("-", "HASH dest read: " + ex.Message); }

            List<string> changedKeys = new List<string>();
            foreach (KeyValuePair<string, int> kv in srcMap)
            {
                int dcs;
                if (!dstMap.TryGetValue(kv.Key, out dcs) || dcs != kv.Value)
                    changedKeys.Add(kv.Key);
            }
            List<string> deletedKeys = new List<string>();
            if (doDeletes)
            {
                foreach (string dk in dstMap.Keys)
                    if (!srcMap.ContainsKey(dk)) deletedKeys.Add(dk);
            }

            AppLog.Info("-", "HASH: src=" + srcMap.Count + " dst=" + dstMap.Count +
                " changed=" + changedKeys.Count + " deleted=" + deletedKeys.Count);

            long applied = 0;
            // apply changed in chunks: SELECT * WHERE keys IN (...)
            for (int i = 0; i < changedKeys.Count; i += (int)Math.Min(chunk, 5000))
            {
                int take = Math.Min(changedKeys.Count - i, (int)Math.Min(chunk, 5000));
                List<string> batch = changedKeys.GetRange(i, take);
                string select = BuildSelectByKeys(srcConn, srcTable, keys, batch, timeout);
                RunResult part = ApplyBatchedMerge(step, srcConn, dstConn, select, srcTable, dstTable, keys, chunk, timeout, false);
                applied += part.Rows;
            }

            long del = 0;
            if (deletedKeys.Count > 0)
                del = DeleteByKeys(dstConn, dstTable, keys, deletedKeys, timeout);

            r.Rows = applied + del;
            r.Message = "HASH applied=" + applied + " deleted=" + del;
            return r;
        }

        private static string KeyListSql(string[] keys)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < keys.Length; i++)
            {
                if (i > 0) sb.Append(", ");
                sb.Append("[").Append(keys[i].Replace("]", "]]")).Append("]");
            }
            return sb.ToString();
        }

        /// <summary>
        /// Key list for SELECT that casts hierarchyid/geography/geometry to nvarchar
        /// so SqlClient never loads Microsoft.SqlServer.Types (Version 10.0.0.0).
        /// </summary>
        private static string KeyListSqlSafe(string connStr, string table, string[] keys, int timeout)
        {
            Dictionary<string, string> types = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                string plain = table.Replace("[", "").Replace("]", "");
                using (SqlConnection c = new SqlConnection(connStr))
                {
                    c.Open();
                    using (SqlCommand q = new SqlCommand(@"
SELECT c.name, t.name FROM sys.columns c
JOIN sys.types t ON c.user_type_id = t.user_type_id
WHERE c.object_id = OBJECT_ID(@t)", c))
                    {
                        q.Parameters.AddWithValue("@t", plain);
                        q.CommandTimeout = Math.Max(timeout, 30);
                        using (SqlDataReader r = q.ExecuteReader())
                            while (r.Read())
                                types[r.GetString(0)] = (r.GetString(1) ?? "").ToLowerInvariant();
                    }
                }
            }
            catch { }
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < keys.Length; i++)
            {
                if (i > 0) sb.Append(", ");
                string k = keys[i].Replace("]", "]]");
                string col = "[" + k + "]";
                string tn;
                if (types.TryGetValue(keys[i], out tn) &&
                    (tn == "hierarchyid" || tn == "geography" || tn == "geometry"))
                    sb.Append("CONVERT(nvarchar(max), ").Append(col).Append(") AS ").Append(col);
                else
                    sb.Append(col);
            }
            return sb.ToString();
        }

        /// <summary>
        /// CHECKSUM of table columns, skipping / casting types that SQL Server rejects in CHECKSUM
        /// (xml, text, ntext, image, geography, geometry, hierarchyid, sql_variant, timestamp).
        /// XML is included via CONVERT(nvarchar(max), col) so content changes still affect the hash.
        /// </summary>
        private static string BuildSafeChecksumExpr(string connStr, string table, int timeout)
        {
            List<string> parts = new List<string>();
            try
            {
                using (SqlConnection c = new SqlConnection(connStr))
                {
                    c.Open();
                    // Resolve object_id for schema.table or [schema].[table]
                    using (SqlCommand q = new SqlCommand(@"
SELECT c.name, t.name AS type_name
FROM sys.columns c
JOIN sys.types t ON c.user_type_id = t.user_type_id
WHERE c.object_id = OBJECT_ID(@t)
ORDER BY c.column_id", c))
                    {
                        q.CommandTimeout = Math.Max(timeout, 60);
                        q.Parameters.AddWithValue("@t", table.Replace("[", "").Replace("]", ""));
                        // also try with brackets stripped differently
                        using (SqlDataReader r = q.ExecuteReader())
                        {
                            while (r.Read())
                            {
                                string name = r.GetString(0);
                                string tn = (r.GetString(1) ?? "").ToLowerInvariant();
                                string col = "[" + name.Replace("]", "]]") + "]";
                                switch (tn)
                                {
                                    case "xml":
                                    case "text":
                                    case "ntext":
                                    case "geography":
                                    case "geometry":
                                    case "hierarchyid":
                                        parts.Add("CONVERT(nvarchar(max), " + col + ")");
                                        break;
                                    case "image":
                                        // skip large binary — not useful in CHECKSUM and invalid
                                        break;
                                    case "sql_variant":
                                    case "timestamp":
                                    case "rowversion":
                                        break;
                                    default:
                                        parts.Add(col);
                                        break;
                                }
                            }
                        }
                    }
                    // If OBJECT_ID failed (0 rows), try INFORMATION_SCHEMA
                    if (parts.Count == 0)
                    {
                        string schema = "dbo", obj = table;
                        string raw = table.Replace("[", "").Replace("]", "");
                        int dot = raw.LastIndexOf('.');
                        if (dot > 0) { schema = raw.Substring(0, dot); obj = raw.Substring(dot + 1); }
                        using (SqlCommand q2 = new SqlCommand(@"
SELECT COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = @s AND TABLE_NAME = @o
ORDER BY ORDINAL_POSITION", c))
                        {
                            q2.Parameters.AddWithValue("@s", schema);
                            q2.Parameters.AddWithValue("@o", obj);
                            q2.CommandTimeout = Math.Max(timeout, 60);
                            using (SqlDataReader r2 = q2.ExecuteReader())
                            {
                                while (r2.Read())
                                {
                                    string name = r2.GetString(0);
                                    string tn = (r2.GetString(1) ?? "").ToLowerInvariant();
                                    string col = "[" + name.Replace("]", "]]") + "]";
                                    if (tn == "xml" || tn == "text" || tn == "ntext")
                                        parts.Add("CONVERT(nvarchar(max), " + col + ")");
                                    else if (tn == "image" || tn == "sql_variant" || tn == "timestamp")
                                    { /* skip */ }
                                    else if (tn == "geography" || tn == "geometry" || tn == "hierarchyid")
                                        parts.Add("CONVERT(nvarchar(max), " + col + ")");
                                    else
                                        parts.Add(col);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "BuildSafeChecksumExpr: " + ex.Message);
            }
            if (parts.Count == 0) return null;
            // CHECKSUM accepts max 100 arguments in practice; if more, nest
            if (parts.Count <= 80)
                return "CHECKSUM(" + string.Join(", ", parts.ToArray()) + ")";
            StringBuilder nested = new StringBuilder("CHECKSUM(");
            for (int i = 0; i < parts.Count; i += 80)
            {
                if (i > 0) nested.Append(", ");
                int take = Math.Min(80, parts.Count - i);
                nested.Append("CHECKSUM(");
                for (int j = 0; j < take; j++)
                {
                    if (j > 0) nested.Append(", ");
                    nested.Append(parts[i + j]);
                }
                nested.Append(")");
            }
            nested.Append(")");
            return nested.ToString();
        }

        private static Dictionary<string, int> LoadKeyHash(string conn, string sql, string[] keys, int timeout)
        {
            Dictionary<string, int> map = new Dictionary<string, int>(StringComparer.Ordinal);
            using (SqlConnection c = new SqlConnection(conn))
            {
                c.Open();
                using (SqlCommand q = new SqlCommand(sql, c))
                {
                    q.CommandTimeout = Math.Max(timeout, 600);
                    using (SqlDataReader rd = q.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            StringBuilder kb = new StringBuilder();
                            for (int i = 0; i < keys.Length; i++)
                            {
                                if (i > 0) kb.Append('\x1f');
                                object v = rd.GetValue(i);
                                kb.Append(v == null || v == DBNull.Value ? "" : Convert.ToString(v));
                            }
                            int cs = rd.IsDBNull(keys.Length) ? 0 : Convert.ToInt32(rd.GetValue(keys.Length));
                            map[kb.ToString()] = cs;
                        }
                    }
                }
            }
            return map;
        }

        private static string BuildSelectByKeys(string srcConn, string table, string[] keys, List<string> keyRows, int timeout)
        {
            string baseSel = BuildSafeSelectFromTable(srcConn, table, timeout);
            // single-column PK: WHERE k IN (...)
            if (keys.Length == 1)
            {
                StringBuilder inList = new StringBuilder();
                for (int i = 0; i < keyRows.Count; i++)
                {
                    if (i > 0) inList.Append(',');
                    inList.Append(FormatSqlLiteral(keyRows[i]));
                }
                return "SELECT * FROM (" + baseSel + ") AS __sd WHERE [" + keys[0].Replace("]", "]]") + "] IN (" + inList + ")";
            }
            // multi-key: OR groups
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT * FROM (").Append(baseSel).Append(") AS __sd WHERE ");
            for (int i = 0; i < keyRows.Count; i++)
            {
                if (i > 0) sb.Append(" OR ");
                string[] parts = keyRows[i].Split(new char[] { '\x1f' });
                sb.Append("(");
                for (int k = 0; k < keys.Length; k++)
                {
                    if (k > 0) sb.Append(" AND ");
                    sb.Append("[").Append(keys[k].Replace("]", "]]")).Append("]=");
                    string pv = k < parts.Length ? parts[k] : "";
                    sb.Append(pv.Length == 0 ? "NULL" : FormatSqlLiteral(pv));
                }
                sb.Append(")");
            }
            return sb.ToString();
        }

        private static long DeleteByKeys(string dstConn, string dstTable, string[] keys, List<string> keyRows, int timeout)
        {
            long deleted = 0;
            using (SqlConnection c = new SqlConnection(dstConn))
            {
                c.Open();
                foreach (string kr in keyRows)
                {
                    string[] parts = kr.Split(new char[] { '\x1f' });
                    StringBuilder where = new StringBuilder();
                    for (int k = 0; k < keys.Length; k++)
                    {
                        if (k > 0) where.Append(" AND ");
                        where.Append("[").Append(keys[k].Replace("]", "]]")).Append("]=");
                        string pv = k < parts.Length ? parts[k] : "";
                        where.Append(pv.Length == 0 ? "NULL" : FormatSqlLiteral(pv));
                    }
                    // Keep the row in the recycle schema before it disappears
                    CopyToRecycle(c, dstTable, where.ToString(), "D", timeout);
                    using (SqlCommand del = new SqlCommand("DELETE FROM " + dstTable + " WHERE " + where, c))
                    {
                        del.CommandTimeout = timeout;
                        deleted += del.ExecuteNonQuery();
                    }
                }
            }
            return deleted;
        }

        /// <summary>
        /// Load source rows into #sd_stage in dest (bulk), then one UPDATE + one INSERT (+ optional DELETE) per chunk.
        /// </summary>
        private static RunResult ApplyBatchedMerge(JobStep step, string srcConn, string dstConn, string selectSql,
            string srcTable, string dstTable, string[] keys, long chunk, int timeout, bool deleteMissing)
        {
            return ApplyBatchedMergeParam(step, srcConn, dstConn, selectSql, null, srcTable, dstTable, keys, chunk, timeout, deleteMissing);
        }

        private static RunResult ApplyBatchedMergeParam(JobStep step, string srcConn, string dstConn, string selectSql, string paramLast,
            string srcTable, string dstTable, string[] keys, long chunk, int timeout, bool deleteMissing)
        {
            RunResult r = new RunResult { Ok = true };
            long total = 0;
            using (SqlConnection src = new SqlConnection(srcConn))
            {
                src.Open();
                using (SqlCommand cmd = new SqlCommand(selectSql, src))
                {
                    cmd.CommandTimeout = Math.Max(timeout, 600);
                    if (paramLast != null)
                        cmd.Parameters.AddWithValue("@last", paramLast);
                    using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess))
                    {
                        DataTable buf = new DataTable();
                        for (int i = 0; i < rd.FieldCount; i++)
                        {
                            Type ft = typeof(string);
                            try { ft = rd.GetFieldType(i) ?? typeof(string); } catch { ft = typeof(string); }
                            buf.Columns.Add(rd.GetName(i), ft);
                        }
                        object[] vals = new object[rd.FieldCount];
                        while (rd.Read())
                        {
                            rd.GetValues(vals);
                            buf.LoadDataRow(vals, true);
                            if (buf.Rows.Count >= (int)Math.Min(chunk, int.MaxValue))
                            {
                                total += FlushStageMerge(dstConn, dstTable, keys, buf, timeout);
                                buf.Clear();
                            }
                        }
                        if (buf.Rows.Count > 0)
                            total += FlushStageMerge(dstConn, dstTable, keys, buf, timeout);
                    }
                }
            }
            r.Rows = total;
            r.Message = "batched " + total + " rows";
            return r;
        }

        private static long FlushStageMerge(string dstConn, string dstTable, string[] keys, DataTable buf, int timeout)
        {
            if (buf.Rows.Count == 0) return 0;
            using (SqlConnection dst = new SqlConnection(dstConn))
            {
                dst.Open();
                // ensure dest exists
                using (SqlCommand chk = new SqlCommand("SELECT OBJECT_ID(@t)", dst))
                {
                    chk.Parameters.AddWithValue("@t", dstTable);
                    object oid = chk.ExecuteScalar();
                    if (oid == null || oid == DBNull.Value)
                    {
                        EnsureSchemaExists(dst, null, dstTable, timeout);
                        // minimal create from buffer schema
                        StringBuilder cr = new StringBuilder("CREATE TABLE " + dstTable + " (");
                        for (int i = 0; i < buf.Columns.Count; i++)
                        {
                            if (i > 0) cr.Append(", ");
                            cr.Append("[").Append(buf.Columns[i].ColumnName.Replace("]", "]]")).Append("] ")
                              .Append(ClrToSql(buf.Columns[i].DataType)).Append(" NULL");
                        }
                        cr.Append(")");
                        using (SqlCommand c2 = new SqlCommand(cr.ToString(), dst)) { c2.CommandTimeout = timeout; c2.ExecuteNonQuery(); }
                    }
                }

                using (SqlCommand drop = new SqlCommand("IF OBJECT_ID('tempdb..#sd_stage') IS NOT NULL DROP TABLE #sd_stage", dst))
                    drop.ExecuteNonQuery();

                // create stage like dest
                using (SqlCommand ct = new SqlCommand("SELECT TOP 0 * INTO #sd_stage FROM " + dstTable, dst))
                {
                    ct.CommandTimeout = timeout;
                    ct.ExecuteNonQuery();
                }

                using (SqlBulkCopy bulk = new SqlBulkCopy(dst))
                {
                    bulk.DestinationTableName = "#sd_stage";
                    bulk.BulkCopyTimeout = timeout;
                    bulk.BatchSize = 5000;
                    foreach (DataColumn col in buf.Columns)
                    {
                        try { bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName); }
                        catch { }
                    }
                    bulk.WriteToServer(buf);
                }

                string on = JoinOn(keys, "d", "s");
                // non-key columns for UPDATE
                StringBuilder sets = new StringBuilder();
                foreach (DataColumn col in buf.Columns)
                {
                    bool isKey = false;
                    foreach (string k in keys)
                        if (string.Equals(k, col.ColumnName, StringComparison.OrdinalIgnoreCase)) { isKey = true; break; }
                    if (isKey) continue;
                    if (sets.Length > 0) sets.Append(", ");
                    string cn = col.ColumnName.Replace("]", "]]");
                    sets.Append("d.[").Append(cn).Append("]=s.[").Append(cn).Append("]");
                }
                if (sets.Length > 0)
                {
                    // Save the pre-update image of the rows that are about to change
                    RecycleCopy(dst, null, dstTable, "d", "INNER JOIN #sd_stage s ON " + on, null, "U", timeout, null);

                    using (SqlCommand up = new SqlCommand(
                        "UPDATE d SET " + sets + " FROM " + dstTable + " d INNER JOIN #sd_stage s ON " + on, dst))
                    {
                        up.CommandTimeout = timeout;
                        up.ExecuteNonQuery();
                    }
                }

                string keyNull = "d.[" + keys[0].Replace("]", "]]") + "] IS NULL";
                using (SqlCommand ins = new SqlCommand(
                    "INSERT INTO " + dstTable + " SELECT s.* FROM #sd_stage s LEFT JOIN " + dstTable + " d ON " + on + " WHERE " + keyNull, dst))
                {
                    ins.CommandTimeout = timeout;
                    ins.ExecuteNonQuery();
                }

                using (SqlCommand drop2 = new SqlCommand("DROP TABLE #sd_stage", dst))
                    drop2.ExecuteNonQuery();
            }
            return buf.Rows.Count;
        }

        private static string JoinOn(string[] keys, string left, string right)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < keys.Length; i++)
            {
                if (i > 0) sb.Append(" AND ");
                string k = keys[i].Replace("]", "]]");
                sb.Append(left).Append(".[").Append(k).Append("]=").Append(right).Append(".[").Append(k).Append("]");
            }
            return sb.ToString();
        }
    }
}
