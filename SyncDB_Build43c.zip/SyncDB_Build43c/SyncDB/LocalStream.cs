using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Newtonsoft.Json;

namespace SyncDB
{
    /// <summary>
    /// Embedded Kafka-style append-only stream (zero install, zero external process).
    /// Data lives under %APPDATA%\SyncDB\stream\{topic}\ as segment files + offsets.json.
    /// Producer: Append. Consumer: ReadFrom(offset). Same machine / same service only.
    /// </summary>
    public static class LocalStream
    {
        public class Envelope
        {
            public long Offset { get; set; }
            public DateTime Utc { get; set; }
            public string Key { get; set; }
            public string Kind { get; set; }   // e.g. transfer-fail | change | heartbeat
            public string JobId { get; set; }
            public string Step { get; set; }
            public string Body { get; set; }
        }

        /// <summary>A segment is rolled at this size so old data can be dropped file by file.</summary>
        public const long MaxSegmentBytes = 8L * 1024L * 1024L;

        private static readonly object Gate = new object();
        private static Mutex _streamMutex;

        private static string Root
        {
            get { return Path.Combine(AppConfig.DataDir, "stream"); }
        }

        /// <summary>The GUI and the Windows service are separate processes; a named mutex prevents corrupt offsets.</summary>
        private sealed class StreamFileLock : IDisposable
        {
            private readonly Mutex _mutex;
            public StreamFileLock(Mutex mutex) { _mutex = mutex; }
            public void Dispose() { try { _mutex.ReleaseMutex(); } catch { } }
        }

        private static StreamFileLock LockFile()
        {
            if (_streamMutex == null)
            {
                lock (Gate)
                {
                    if (_streamMutex == null)
                    {
                        string name;
                        using (SHA1 sha = SHA1.Create())
                        {
                            byte[] h = sha.ComputeHash(Encoding.UTF8.GetBytes(Path.GetFullPath(Root).ToLowerInvariant()));
                            StringBuilder sb = new StringBuilder("Local\\SyncDB.LocalStream.");
                            for (int i = 0; i < 8; i++) sb.Append(h[i].ToString("x2"));
                            name = sb.ToString();
                        }
                        _streamMutex = new Mutex(false, name);
                    }
                }
            }
            bool acquired = false;
            try
            {
                try { acquired = _streamMutex.WaitOne(15000); }
                catch (AbandonedMutexException) { acquired = true; }
                if (!acquired) throw new IOException("Timed out waiting for the LocalStream file lock.");
                return new StreamFileLock(_streamMutex);
            }
            catch
            {
                if (acquired) { try { _streamMutex.ReleaseMutex(); } catch { } }
                throw;
            }
        }

        private static string TopicDir(string topic)
        {
            string t = Sanitize(topic);
            string d = Path.Combine(Root, t);
            Directory.CreateDirectory(d);
            return d;
        }

        private static string Sanitize(string topic)
        {
            if (string.IsNullOrWhiteSpace(topic)) return "syncdb.changes";
            foreach (char c in Path.GetInvalidFileNameChars())
                topic = topic.Replace(c, '_');
            return topic.Trim().ToLowerInvariant();
        }

        private static string MetaPath(string topic)
        {
            return Path.Combine(TopicDir(topic), "meta.json");
        }

        private static string SegmentPath(string topic, long segment)
        {
            return Path.Combine(TopicDir(topic), segment.ToString("D8") + ".log");
        }

        private class Meta
        {
            public long NextOffset { get; set; }
            public long Segment { get; set; }
            public long ConsumerOffset { get; set; }
        }

        private static Meta LoadMeta(string topic)
        {
            string p = MetaPath(topic);
            try
            {
                if (File.Exists(p))
                {
                    Meta m = JsonConvert.DeserializeObject<Meta>(File.ReadAllText(p, Encoding.UTF8));
                    if (m != null) return m;
                }
            }
            catch { }
            return new Meta { NextOffset = 0, Segment = 0, ConsumerOffset = 0 };
        }

        private static void SaveMeta(string topic, Meta m)
        {
            File.WriteAllText(MetaPath(topic), JsonConvert.SerializeObject(m, Formatting.Indented), new UTF8Encoding(true));
        }

        /// <summary>Append one message; returns assigned offset (like Kafka produce).</summary>
        public static long Append(string topic, string key, string kind, string jobId, string step, string body)
        {
            lock (Gate)
            using (LockFile())
            {
                Directory.CreateDirectory(Root);
                Meta m = LoadMeta(topic);
                var env = new Envelope
                {
                    Offset = m.NextOffset,
                    Utc = DateTime.UtcNow,
                    Key = key ?? "",
                    Kind = kind ?? "",
                    JobId = jobId ?? "",
                    Step = step ?? "",
                    Body = body ?? ""
                };
                string line = JsonConvert.SerializeObject(env);
                // one JSON object per line
                string segFile = SegmentPath(topic, m.Segment);
                File.AppendAllText(segFile, line + "\n", new UTF8Encoding(true));
                m.NextOffset++;
                // roll the segment by size (so Trim can drop whole files) and every ~50k messages
                long segLen = 0;
                try { segLen = new FileInfo(segFile).Length; }
                catch { }
                if (segLen >= MaxSegmentBytes) m.Segment++;
                else if (m.NextOffset > 0 && m.NextOffset % 50000 == 0) m.Segment++;
                SaveMeta(topic, m);
                return env.Offset;
            }
        }

        /// <summary>Read up to max messages at or after fromOffset (exclusive consumer cursor style: >= fromOffset).</summary>
        public static List<Envelope> ReadFrom(string topic, long fromOffset, int max)
        {
            var list = new List<Envelope>();
            if (max < 1) max = 100;
            lock (Gate)
            using (LockFile())
            {
                Meta m = LoadMeta(topic);
                for (long seg = 0; seg <= m.Segment && list.Count < max; seg++)
                {
                    string path = SegmentPath(topic, seg);
                    if (!File.Exists(path)) continue;
                    foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        try
                        {
                            Envelope e = JsonConvert.DeserializeObject<Envelope>(line);
                            if (e == null || e.Offset < fromOffset) continue;
                            list.Add(e);
                            if (list.Count >= max) break;
                        }
                        catch { }
                    }
                }
            }
            return list;
        }

        public static long LatestOffset(string topic)
        {
            lock (Gate)
            using (LockFile())
            {
                Meta m = LoadMeta(topic);
                return m.NextOffset <= 0 ? 0 : m.NextOffset - 1;
            }
        }

        public static long GetConsumerOffset(string topic)
        {
            lock (Gate)
            using (LockFile()) { return LoadMeta(topic).ConsumerOffset; }
        }

        public static void CommitConsumerOffset(string topic, long offset)
        {
            lock (Gate)
            using (LockFile())
            {
                Meta m = LoadMeta(topic);
                if (offset > m.ConsumerOffset) m.ConsumerOffset = offset;
                SaveMeta(topic, m);
            }
        }

        public static string Stats(string topic)
        {
            try
            {
                lock (Gate)
                using (LockFile())
                {
                    Meta m = LoadMeta(topic);
                    long lag = m.NextOffset - m.ConsumerOffset;
                    if (lag < 0) lag = 0;
                    return "LocalStream [" + Sanitize(topic) + "]: next=" + m.NextOffset +
                           " consumer=" + m.ConsumerOffset + " lag=" + lag +
                           "  dir=" + TopicDir(topic);
                }
            }
            catch (Exception ex) { return "LocalStream: " + ex.Message; }
        }

        /// <summary>Bytes currently held by all topics under %APPDATA%\SyncDB\stream.</summary>
        public static long TotalBytes()
        {
            long n = 0;
            try
            {
                if (!Directory.Exists(Root)) return 0;
                foreach (string dir in Directory.GetDirectories(Root))
                    foreach (string f in Directory.GetFiles(dir))
                        try { n += new FileInfo(f).Length; }
                        catch { }
            }
            catch { }
            return n;
        }

        /// <summary>
        /// Retention for the embedded stream. The log is append-only, so without this the segment files
        /// grow forever (a new file every 8 MB / 50k messages and nothing ever deleted them).
        /// Drops segments older than <paramref name="keepDays"/>, then the oldest ones until the topic is
        /// below <paramref name="maxTotalBytes"/>. The segment currently being written is never deleted.
        /// </summary>
        public static int Trim(int keepDays, long maxTotalBytes, out long bytes)
        {
            bytes = 0;
            int removed = 0;
            if (keepDays < 1) keepDays = 7;
            if (maxTotalBytes < 1048576L) maxTotalBytes = 1048576L;
            try { if (!Directory.Exists(Root)) return 0; }
            catch { return 0; }

            lock (Gate)
            using (LockFile())
            {
                string[] dirs;
                try { dirs = Directory.GetDirectories(Root); }
                catch { return 0; }

                foreach (string dir in dirs)
                {
                    try
                    {
                        string topic = Path.GetFileName(dir);
                        Meta m = LoadMeta(topic);
                        string activeName = Path.GetFileName(SegmentPath(topic, m.Segment));

                        List<FileInfo> segs = new List<FileInfo>();
                        long total = 0;
                        foreach (string f in Directory.GetFiles(dir, "*.log"))
                        {
                            FileInfo fi = new FileInfo(f);
                            total += fi.Length;
                            if (string.Equals(fi.Name, activeName, StringComparison.OrdinalIgnoreCase)) continue;
                            segs.Add(fi);
                        }
                        segs.Sort(delegate(FileInfo a, FileInfo b)
                        {
                            return string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
                        });

                        DateTime cutoff = DateTime.Now.AddDays(-keepDays);
                        for (int i = 0; i < segs.Count; i++)
                        {
                            FileInfo fi = segs[i];
                            if (fi.LastWriteTime >= cutoff) continue;
                            long len = fi.Length;
                            try
                            {
                                fi.Delete();
                                removed++; bytes += len; total -= len;
                                segs.RemoveAt(i); i--;
                            }
                            catch { }
                        }
                        for (int i = 0; i < segs.Count && total > maxTotalBytes; i++)
                        {
                            long len = segs[i].Length;
                            try
                            {
                                segs[i].Delete();
                                removed++; bytes += len; total -= len;
                            }
                            catch { }
                        }
                    }
                    catch { }
                }
            }
            return removed;
        }

        public static void EnsureReady(string topic)
        {
            lock (Gate)
            using (LockFile())
            {
                Directory.CreateDirectory(TopicDir(topic));
                if (!File.Exists(MetaPath(topic)))
                    SaveMeta(topic, new Meta());
            }
        }
    }
}
