﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace SyncDB
{
    /// <summary>File format of an export (.syncdb.json).</summary>
    public class SyncDbPackage
    {
        public string Format { get; set; }
        public int Version { get; set; }
        public string ExportedAt { get; set; }
        public string ExportedBy { get; set; }
        public bool IncludesConnections { get; set; }
        public string SourceConnectionId { get; set; }
        public string DestConnectionId { get; set; }
        public bool HasSettings { get; set; }
        public int LogRetentionDays { get; set; }
        public string LogFolder { get; set; }
        public int SchedulerPollSeconds { get; set; }
        public List<SyncJob> Jobs { get; set; }
        public List<ConnectionProfile> Connections { get; set; }

        public SyncDbPackage()
        {
            Format = "SyncDB-export";
            Version = 1;
            Jobs = new List<SyncJob>();
            Connections = new List<ConnectionProfile>();
        }
    }

    public static class ProjectIO
    {
        public static void Export(string path, List<SyncJob> jobs, AppConfig cfg, bool includeConnections)
        {
            SyncDbPackage p = new SyncDbPackage();
            p.ExportedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            try { p.ExportedBy = Environment.UserDomainName + "\\" + Environment.UserName + "@" + Environment.MachineName; } catch { p.ExportedBy = ""; }
            p.IncludesConnections = includeConnections;
            p.HasSettings = true;
            p.LogRetentionDays = cfg.LogRetentionDays;
            p.LogFolder = cfg.LogFolder;
            p.SchedulerPollSeconds = cfg.SchedulerPollSeconds;
            foreach (SyncJob j in jobs)
            {
                SyncJob c = j.Clone();
                c.LastErrorDetail = null;
                if (!includeConnections)
                    foreach (JobStep st in c.Steps) { st.ApiPassword = ""; st.ApiToken = ""; }
                p.Jobs.Add(c);
            }
            if (includeConnections)
            {
                foreach (ConnectionProfile cp in cfg.Connections)
                    p.Connections.Add(JsonConvert.DeserializeObject<ConnectionProfile>(JsonConvert.SerializeObject(cp)));
                p.SourceConnectionId = cfg.SourceConnectionId;
                p.DestConnectionId = cfg.DestConnectionId;
            }
            File.WriteAllText(path, JsonConvert.SerializeObject(p, Formatting.Indented), new UTF8Encoding(true));
        }

        /// <summary>replaceAll=false: add to existing (same-Id jobs are added as "(imported)" copies, existing connections are kept).
        /// replaceAll=true: all current jobs are replaced by the file's jobs; same-Id connections are overwritten.</summary>
        public static string Import(string path, AppConfig cfg, bool replaceAll)
        {
            SyncDbPackage p = JsonConvert.DeserializeObject<SyncDbPackage>(File.ReadAllText(path, Encoding.UTF8));
            if (p == null || p.Format != "SyncDB-export")
                throw new Exception("This is not a SyncDB export file.");
            if (p.Jobs == null) p.Jobs = new List<SyncJob>();
            if (p.Connections == null) p.Connections = new List<ConnectionProfile>();

            int connAdded = 0, connUpdated = 0, connSkipped = 0;
            foreach (ConnectionProfile cp in p.Connections)
            {
                if (string.IsNullOrEmpty(cp.Id)) cp.Id = Guid.NewGuid().ToString("N");
                int idx = -1;
                for (int i = 0; i < cfg.Connections.Count; i++) if (cfg.Connections[i].Id == cp.Id) { idx = i; break; }
                if (idx < 0) { cfg.Connections.Add(cp); connAdded++; }
                else if (replaceAll) { cfg.Connections[idx] = cp; connUpdated++; }
                else connSkipped++;
            }
            if ((replaceAll || string.IsNullOrEmpty(cfg.SourceConnectionId)) && cfg.FindConnection(p.SourceConnectionId) != null) cfg.SourceConnectionId = p.SourceConnectionId;
            if ((replaceAll || string.IsNullOrEmpty(cfg.DestConnectionId)) && cfg.FindConnection(p.DestConnectionId) != null) cfg.DestConnectionId = p.DestConnectionId;
            bool settingsApplied = false;
            if (replaceAll && p.HasSettings)
            {
                if (p.LogRetentionDays >= 1 && p.LogRetentionDays <= 1095) cfg.LogRetentionDays = p.LogRetentionDays;
                cfg.LogFolder = p.LogFolder ?? "";
                if (p.SchedulerPollSeconds >= 10) cfg.SchedulerPollSeconds = p.SchedulerPollSeconds;
                settingsApplied = true;
            }

            if (replaceAll) cfg.Jobs.Clear();
            int jobs = 0, copies = 0;
            foreach (SyncJob j in p.Jobs)
            {
                j.EnsureSteps();
                bool exists = false;
                foreach (SyncJob e in cfg.Jobs) if (e.Id == j.Id) { exists = true; break; }
                if (string.IsNullOrEmpty(j.Id) || exists)
                {
                    j.Id = Guid.NewGuid().ToString("N");
                    j.Name = (j.Name ?? "Job") + " (imported)";
                    copies++;
                }
                j.LastRunUtc = null;
                j.LastStatus = "Imported - never run";
                j.LastRows = 0;
                j.LastErrorDetail = null;
                j.NextRunUtc = j.Schedule != ScheduleKind.Manual ? JobScheduler.ComputeNextRunUtc(j, DateTime.UtcNow) : null;
                cfg.Jobs.Add(j);
                jobs++;
            }
            string s = "Imported " + jobs + " job(s)" + (copies > 0 ? " (" + copies + " renamed as copies)" : "") + ".";
            if (p.IncludesConnections)
                s += "\r\nConnections: " + connAdded + " added, " + connUpdated + " updated, " + connSkipped + " already existed (kept).";
            else
                s += "\r\nThe file has no connections: pick Source / Dest in tabs 2 and 3 (or the Database in each step).";
            if (settingsApplied) s += "\r\nSettings (log retention, log folder, scheduler poll, Source/Dest roles) restored.";
            else if (p.HasSettings) s += "\r\nSettings in the file were ignored (Merge keeps your current settings; use Replace to restore them).";
            s += "\r\nFile: " + path + (string.IsNullOrEmpty(p.ExportedAt) ? "" : "\r\nExported: " + p.ExportedAt + " by " + p.ExportedBy);
            return s;
        }
    }

    /// <summary>Choose which jobs to export and whether to include connections.</summary>
    public class ExportForm : Form
    {
        private CheckedListBox lst;
        private CheckBox chkConn;
        private readonly List<SyncJob> jobs;

        public bool IncludeConnections { get { return chkConn.Checked; } }

        public List<SyncJob> SelectedJobs
        {
            get
            {
                List<SyncJob> r = new List<SyncJob>();
                for (int i = 0; i < lst.Items.Count; i++) if (lst.GetItemChecked(i)) r.Add(jobs[i]);
                return r;
            }
        }

        public ExportForm(List<SyncJob> jobs, SyncJob preselect)
        {
            this.jobs = jobs;
            Text = "Export jobs";
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(520, 460);
            MinimizeBox = false; MaximizeBox = false; ShowInTaskbar = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;

            Label l = new Label { Dock = DockStyle.Top, Height = 28, Padding = new Padding(8, 8, 0, 0), Text = "Tick the jobs to export (steps, tables, schedules). App settings are always included:" };
            lst = new CheckedListBox { Dock = DockStyle.Fill, CheckOnClick = true };
            foreach (SyncJob j in jobs) lst.Items.Add((j.Name ?? "Job") + "   [" + (j.Steps != null ? j.Steps.Count : 0) + " step(s)]", true);

            chkConn = new CheckBox
            {
                Text = "Include connections WITH passwords (clear text in the file - keep it safe)",
                Dock = DockStyle.Top, Height = 28, Padding = new Padding(8, 0, 0, 0)
            };
            FlowLayoutPanel bar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 44, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(6) };
            Button cancel = new Button { Text = "Cancel", Width = 85, DialogResult = DialogResult.Cancel };
            Button ok = new Button { Text = "Export...", Width = 95 };
            ok.Click += (s, e) =>
            {
                if (SelectedJobs.Count == 0) { MessageBox.Show("Tick at least one job."); return; }
                DialogResult = DialogResult.OK;
            };
            Button none = new Button { Text = "None", Width = 70 };
            Button all = new Button { Text = "All", Width = 70 };
            all.Click += (s, e) => { for (int i = 0; i < lst.Items.Count; i++) lst.SetItemChecked(i, true); };
            none.Click += (s, e) => { for (int i = 0; i < lst.Items.Count; i++) lst.SetItemChecked(i, false); };
            bar.Controls.Add(cancel); bar.Controls.Add(ok); bar.Controls.Add(none); bar.Controls.Add(all);
            AcceptButton = ok; CancelButton = cancel;

            Controls.Add(lst);
            Controls.Add(chkConn);
            Controls.Add(l);
            Controls.Add(bar);
            Theme.Apply(this);
        }
    }
}
