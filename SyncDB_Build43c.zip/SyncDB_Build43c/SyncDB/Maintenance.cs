﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

namespace SyncDB
{
    /// <summary>Build / version of the EXE that is actually running (title bar + log + service log).</summary>
    public static class AppBuild
    {
        public const string Name = "Build 43c";

        public static string Text
        {
            get
            {
                string v = "";
                try { v = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString(); }
                catch { }
                return v.Length > 0 ? Name + " (" + v + ")" : Name;
            }
        }
    }

    /// <summary>
    /// Settings the transfer engine must honour immediately, in EVERY process.
    ///
    /// The GUI, the Windows service and a scheduled run each hold their own AppConfig object, and the
    /// engine used to read the flag from a [ThreadStatic] field, so ticking "disk buffer off" in the GUI
    /// did not necessarily reach the process that was actually running the job. This class keeps a
    /// process-wide copy AND re-reads config.json (at most every 15 seconds) when nobody has pushed a
    /// fresh config, so the setting takes effect within seconds even in a running service.
    /// </summary>
    public static class RuntimeSettings
    {
        private static readonly object Gate = new object();
        private static bool _useDiskBuffer;              // default: no disk buffer at all
        private static DateTime _checkedUtc = DateTime.MinValue;
        private static DateTime _stampUtc = DateTime.MinValue;

        /// <summary>Called wherever a config is loaded, saved or pushed (GUI, service, scheduler, engine).</summary>
        public static void Apply(AppConfig cfg)
        {
            if (cfg == null) return;
            lock (Gate)
            {
                _useDiskBuffer = cfg.UseDiskBuffer;
                _checkedUtc = DateTime.UtcNow;
                try { _stampUtc = File.GetLastWriteTimeUtc(AppConfig.ConfigPath); }
                catch { }
            }
        }

        /// <summary>True only when the user explicitly switched the disk buffer on.</summary>
        public static bool UseDiskBuffer
        {
            get
            {
                lock (Gate)
                {
                    if ((DateTime.UtcNow - _checkedUtc).TotalSeconds >= 15)
                    {
                        _checkedUtc = DateTime.UtcNow;
                        try
                        {
                            string p = AppConfig.ConfigPath;
                            if (File.Exists(p))
                            {
                                DateTime st = File.GetLastWriteTimeUtc(p);
                                if (st != _stampUtc)
                                {
                                    _stampUtc = st;
                                    _useDiskBuffer = ReadFlag(p);
                                }
                            }
                        }
                        catch { }
                    }
                    return _useDiskBuffer;
                }
            }
        }

        /// <summary>Reads one boolean out of config.json without deserialising the whole file.</summary>
        private static bool ReadFlag(string path)
        {
            try
            {
                string txt = File.ReadAllText(path, Encoding.UTF8);
                int i = txt.IndexOf("\"UseDiskBuffer\"", StringComparison.OrdinalIgnoreCase);
                if (i < 0) return false;                       // key missing (old config) -> off
                int c = txt.IndexOf(':', i);
                if (c < 0) return false;
                string tail = txt.Substring(c + 1, Math.Min(12, txt.Length - c - 1)).Trim().ToLowerInvariant();
                return tail.StartsWith("true");
            }
            catch { return false; }
        }
    }

    /// <summary>
    /// Disk-spill buffer folder of ONE transfer run (BufferMode.Disk / Auto on huge tables).
    ///
    /// Build 42k: every run used to create %APPDATA%\SyncDB\buffer\{guid} and delete it only in a
    /// swallowed try/catch at the end of the run. A crash, a kill, a reboot, a stopped service or a
    /// single locked .bin file left the whole folder behind forever, so the buffer folder kept growing
    /// with one orphan subfolder per run.
    ///
    /// Now the folder holds an open ".inuse" lock file (FileShare.None + DeleteOnClose):
    ///   • while the run is alive  -> no other process can delete the folder (the lock cannot be opened),
    ///   • when the process dies   -> Windows closes the handle, ".inuse" disappears by itself and the
    ///     next sweep (startup + hourly) removes the orphan folder.
    /// Dispose() deletes the files one by one with retries, so a single locked file no longer keeps
    /// gigabytes of spill data on disk.
    /// </summary>
    public sealed class SpillBuffer : IDisposable
    {
        public const string LockFileName = ".inuse";

        private readonly string _dir;
        private FileStream _lock;
        private bool _disposed;

        /// <summary>%APPDATA%\SyncDB\buffer (or the /datadir: folder of the service).</summary>
        public static string Root
        {
            get { return Path.Combine(AppConfig.DataDir, "buffer"); }
        }

        public string Dir { get { return _dir; } }

        public SpillBuffer()
        {
            string root = Root;
            Directory.CreateDirectory(root);
            _dir = Path.Combine(root, DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture)
                                      + "-" + Guid.NewGuid().ToString("N").Substring(0, 8));
            Directory.CreateDirectory(_dir);
            Maintenance.MarkActive(_dir);
            try
            {
                _lock = new FileStream(Path.Combine(_dir, LockFileName), FileMode.Create, FileAccess.Write,
                                       FileShare.None, 128, FileOptions.DeleteOnClose);
                int pid = 0;
                try { pid = Process.GetCurrentProcess().Id; }
                catch { }
                byte[] b = Encoding.UTF8.GetBytes("pid=" + pid + " started=" +
                                                  DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                _lock.Write(b, 0, b.Length);
                _lock.Flush();
            }
            catch
            {
                // No lock file (rare: AV / permissions). The folder is still cleaned by Dispose and the
                // sweep keeps a freshness grace period for lock-less folders, so a running job is safe.
                _lock = null;
            }
        }

        /// <summary>Path of spill file number <paramref name="no"/> inside this run's folder.</summary>
        public string FilePath(int no)
        {
            return Path.Combine(_dir, no.ToString("D6", CultureInfo.InvariantCulture) + ".bin");
        }

        /// <summary>Total bytes currently held on disk by this buffer.</summary>
        public long SizeBytes()
        {
            return Maintenance.DirSize(_dir);
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            try { if (_lock != null) { _lock.Dispose(); _lock = null; } }
            catch { }
            bool gone = Maintenance.DeleteDirHard(_dir, 4);
            Maintenance.UnmarkActive(_dir);
            if (!gone)
            {
                // Something still holds a file: leave no lock file behind, the next sweep finishes the job.
                AppLog.Warn("-", "Disk buffer folder could not be deleted yet, it will be removed by the next cleanup: " + _dir);
            }
        }
    }

    /// <summary>
    /// Housekeeping for everything SyncDB writes under %APPDATA%\SyncDB (or /datadir:).
    /// Runs once at startup and then every hour, in the GUI and in the Windows service.
    /// Nothing in the data folder is unbounded any more:
    ///   buffer\        orphan spill folders of dead runs      -> deleted
    ///   stream\        LocalStream segments                   -> trimmed by age + total size
    ///   cache.db       row hashes / origin marks              -> purged by age, file compacted
    ///   outbox.db      sent/skipped rows + payload files      -> purged by age, orphans removed, compacted
    ///   history\       archive of deleted jobs                -> purged (JobHistory.ArchiveDays)
    ///   logs\          daily log files                        -> purged (LogRetentionDays)
    ///   startup.log    boot trace                             -> trimmed at 1 MB
    /// </summary>
    public static class Maintenance
    {
        private static readonly object Gate = new object();
        private static readonly Dictionary<string, bool> Active =
            new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

        private static Thread _thread;
        private static bool _stop;
        private static AppConfig _cfg;
        private static DateTime _lastCompactUtc = DateTime.MinValue;
        private static bool _sweeping;

        /// <summary>A lock-less buffer folder newer than this is never touched by the sweep.</summary>
        private const int LocklessGraceMinutes = 20;

        private const long StartupLogMaxBytes = 1024L * 1024L;

        public static string LastSummary = "";

        #region active-folder registry (this process)

        internal static void MarkActive(string dir)
        {
            if (string.IsNullOrEmpty(dir)) return;
            lock (Gate) Active[Full(dir)] = true;
        }

        internal static void UnmarkActive(string dir)
        {
            if (string.IsNullOrEmpty(dir)) return;
            lock (Gate) Active.Remove(Full(dir));
        }

        private static bool IsActive(string dir)
        {
            lock (Gate) return Active.ContainsKey(Full(dir));
        }

        private static string Full(string p)
        {
            try { return Path.GetFullPath(p).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar); }
            catch { return p ?? ""; }
        }

        #endregion

        #region background runner

        /// <summary>Starts the hourly cleanup (idempotent). Sweeps once right away on a background thread.</summary>
        public static void Start(AppConfig cfg)
        {
            _cfg = cfg;
            lock (Gate)
            {
                if (_thread != null && _thread.IsAlive) return;
                _stop = false;
                _thread = new Thread(Loop);
                _thread.IsBackground = true;
                _thread.Name = "SyncDB.Maintenance";
                _thread.Priority = ThreadPriority.BelowNormal;
                _thread.Start();
            }
        }

        /// <summary>Called when settings are saved so the next sweep uses the new retention values.</summary>
        public static void Reconfigure(AppConfig cfg)
        {
            if (cfg != null) _cfg = cfg;
        }

        public static void Stop()
        {
            _stop = true;
        }

        private static void Loop()
        {
            // let the app finish starting first
            for (int i = 0; i < 50 && !_stop; i++) Thread.Sleep(100);
            while (!_stop)
            {
                try { SweepNow(_cfg, false); }
                catch (Exception ex) { AppLog.Warn("-", "Cleanup failed: " + ex.Message); }
                for (int i = 0; i < 3600 && !_stop; i++) Thread.Sleep(1000);   // ~1 hour
            }
        }

        #endregion

        /// <summary>
        /// One full housekeeping pass. Safe to call from the UI thread (it is quick: only file metadata
        /// is read) and safe to call while jobs are running — active buffers are skipped.
        /// </summary>
        public static string SweepNow(AppConfig cfg, bool force)
        {
            if (cfg == null) cfg = _cfg;
            if (force)
            {
                // "Clean now" from the UI: wait for the hourly pass instead of reporting its old result.
                for (int i = 0; i < 100; i++)
                {
                    lock (Gate) { if (!_sweeping) break; }
                    Thread.Sleep(100);
                }
            }
            lock (Gate)
            {
                if (_sweeping)
                    return LastSummary.Length > 0 ? LastSummary : "A cleanup is already running.";
                _sweeping = true;
            }
            try
            {
                bool auto = cfg == null || cfg.BufferAutoClean;
                if (!auto && !force)
                {
                    LastSummary = "Cleanup is off (Settings -> Auto-clean buffer/cache).";
                    return LastSummary;
                }

                int keepDays = cfg != null ? cfg.CacheKeepDays : 7;
                if (keepDays < 1) keepDays = 7;
                long streamMax = (long)(cfg != null && cfg.StreamMaxMB > 0 ? cfg.StreamMaxMB : 64) * 1048576L;
                DateTime cutoff = DateTime.UtcNow.AddDays(-keepDays);

                StringBuilder s = new StringBuilder();
                long freed = 0;

                // 1) orphan disk-spill buffers
                long bufBytes;
                int bufDirs = CleanBufferRoot(out bufBytes);
                freed += bufBytes;
                s.Append("buffer: ").Append(bufDirs).Append(" folder(s)");

                // 2) LocalStream segments
                long strBytes;
                int strFiles = 0;
                try { strFiles = LocalStream.Trim(keepDays, streamMax, out strBytes); }
                catch (Exception ex) { strBytes = 0; AppLog.Warn("-", "Stream trim: " + ex.Message); }
                freed += strBytes;
                s.Append(" | stream: ").Append(strFiles).Append(" segment(s)");

                // 3) cache.db (row hashes + origin marks)
                int cacheRows = 0;
                try { cacheRows = CacheStoreFactory.Current.PurgeBefore(cutoff); }
                catch (Exception ex) { AppLog.Warn("-", "Cache purge: " + ex.Message); }
                s.Append(" | cache: ").Append(cacheRows).Append(" record(s)");

                // 4) outbox rows + payload files
                int obRows = 0, obOrphans = 0;
                try
                {
                    int obDays = cfg != null && cfg.OutboxSentRetentionDays > 0 ? cfg.OutboxSentRetentionDays : 7;
                    obRows = OutboxStore.PurgeCompleted(DateTime.UtcNow.AddDays(-obDays));
                    obOrphans = OutboxStore.SweepOrphanPayloads();
                }
                catch (Exception ex) { AppLog.Warn("-", "Outbox purge: " + ex.Message); }
                s.Append(" | outbox: ").Append(obRows).Append(" row(s), ").Append(obOrphans).Append(" orphan payload(s)");

                // 5) merge the LiteDB write-ahead logs (cheap, keeps *-log.db small)
                try
                {
                    LiteCacheStore ck = CacheStoreFactory.Current as LiteCacheStore;
                    if (ck != null) freed += ck.Checkpoint();
                }
                catch { }
                try { freed += OutboxStore.Checkpoint(); }
                catch { }

                // 6) history archive + logs + startup trace
                try { JobHistory.PurgeArchive(); } catch { }
                try { AppLog.PurgeOldLogs(); } catch { }
                try { TrimStartupLog(); } catch { }

                // 7) compact the LiteDB files — only on an explicit "Clean buffer/cache now".
                // A LiteDB rebuild takes an exclusive lock on the file, so it must never run by itself
                // while the service is executing jobs that write to the outbox.
                if (force)
                {
                    _lastCompactUtc = DateTime.UtcNow;
                    long c1 = 0, c2 = 0;
                    try
                    {
                        LiteCacheStore lcs = CacheStoreFactory.Current as LiteCacheStore;
                        if (lcs != null) c1 = lcs.Compact();
                    }
                    catch (Exception ex) { AppLog.Warn("-", "Cache compact: " + ex.Message); }
                    try { c2 = OutboxStore.Compact(); }
                    catch (Exception ex) { AppLog.Warn("-", "Outbox compact: " + ex.Message); }
                    if (c1 + c2 > 0)
                    {
                        freed += c1 + c2;
                        s.Append(" | compacted: ").Append(Mb(c1 + c2));
                    }
                }

                s.Append(" | freed ").Append(Mb(freed));
                LastSummary = s.ToString();
                if (freed > 0 || bufDirs > 0 || strFiles > 0 || cacheRows > 0 || obRows > 0 || obOrphans > 0)
                    AppLog.Info("-", "Cleanup: " + LastSummary);
                return LastSummary;
            }
            finally
            {
                lock (Gate) _sweeping = false;
            }
        }

        /// <summary>
        /// Deletes every spill folder under buffer\ that is not in use:
        /// a folder is "in use" when its .inuse lock cannot be opened exclusively, or when it belongs to
        /// a run of this process, or (lock-less fallback) when it was written in the last 20 minutes.
        /// </summary>
        /// <summary>Convenience overload for callers that do not care how many bytes were freed.</summary>
        public static int CleanBufferRoot()
        {
            long bytes;
            return CleanBufferRoot(out bytes);
        }

        public static int CleanBufferRoot(out long bytes)
        {
            bytes = 0;
            int removed = 0;
            string root = SpillBuffer.Root;
            try
            {
                if (!Directory.Exists(root)) return 0;
            }
            catch { return 0; }

            string[] dirs;
            try { dirs = Directory.GetDirectories(root); }
            catch { return 0; }

            foreach (string dir in dirs)
            {
                try
                {
                    if (IsActive(dir)) continue;
                    if (IsBufferInUse(dir)) continue;
                    long size = DirSize(dir);
                    if (DeleteDirHard(dir, 2)) { removed++; bytes += size; }
                }
                catch { }
            }

            // stray files directly in buffer\ (older builds spilled without a subfolder)
            try
            {
                foreach (string f in Directory.GetFiles(root, "*.bin"))
                {
                    try
                    {
                        FileInfo fi = new FileInfo(f);
                        if ((DateTime.Now - fi.LastWriteTime).TotalMinutes < LocklessGraceMinutes) continue;
                        long len = fi.Length;
                        File.Delete(f);
                        bytes += len;
                    }
                    catch { }
                }
            }
            catch { }

            return removed;
        }

        private static bool IsBufferInUse(string dir)
        {
            string lockFile = Path.Combine(dir, SpillBuffer.LockFileName);
            bool hasLock;
            try { hasLock = File.Exists(lockFile); }
            catch { return true; }

            if (hasLock)
            {
                try
                {
                    // The owner holds it with FileShare.None: if we can open it, the owner is gone.
                    using (new FileStream(lockFile, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
                    return false;
                }
                catch { return true; }     // still running
            }

            // No lock file: only touch it when it has been idle for a while (safety for other processes).
            try
            {
                DateTime last = Directory.GetLastWriteTime(dir);
                foreach (string f in Directory.GetFiles(dir))
                {
                    DateTime t = File.GetLastWriteTime(f);
                    if (t > last) last = t;
                }
                return (DateTime.Now - last).TotalMinutes < LocklessGraceMinutes;
            }
            catch { return true; }
        }

        /// <summary>Deletes a folder, file by file, retrying locked entries. Returns true when it is gone.</summary>
        public static bool DeleteDirHard(string path, int attempts)
        {
            if (string.IsNullOrEmpty(path)) return true;
            if (attempts < 1) attempts = 1;
            for (int i = 0; i < attempts; i++)
            {
                try
                {
                    if (!Directory.Exists(path)) return true;
                    foreach (string f in Directory.GetFiles(path))
                    {
                        try { File.SetAttributes(f, FileAttributes.Normal); }
                        catch { }
                        try { File.Delete(f); }
                        catch { }
                    }
                    foreach (string d in Directory.GetDirectories(path)) DeleteDirHard(d, 1);
                    Directory.Delete(path, true);
                    if (!Directory.Exists(path)) return true;
                }
                catch { }
                if (i + 1 < attempts) Thread.Sleep(200);
            }
            try { return !Directory.Exists(path); }
            catch { return false; }
        }

        public static long DirSize(string path)
        {
            long n = 0;
            try
            {
                if (!Directory.Exists(path)) return 0;
                foreach (string f in Directory.GetFiles(path))
                {
                    try { n += new FileInfo(f).Length; }
                    catch { }
                }
                foreach (string d in Directory.GetDirectories(path)) n += DirSize(d);
            }
            catch { }
            return n;
        }

        private static void TrimStartupLog()
        {
            string p = Path.Combine(AppConfig.DataDir, "startup.log");
            if (!File.Exists(p)) return;
            if (new FileInfo(p).Length <= StartupLogMaxBytes) return;
            try
            {
                string[] all = File.ReadAllLines(p, Encoding.UTF8);
                int keep = Math.Min(all.Length, 400);
                string[] tail = new string[keep];
                Array.Copy(all, all.Length - keep, tail, 0, keep);
                File.WriteAllLines(p, tail, Encoding.UTF8);
            }
            catch { }
        }

        /// <summary>Size report of the data folder, for the Settings tab.</summary>
        public static string DataFolderStats()
        {
            try
            {
                string root = AppConfig.DataDir;
                long buf = DirSize(Path.Combine(root, "buffer"));
                int bufDirs = 0;
                try { bufDirs = Directory.Exists(Path.Combine(root, "buffer")) ? Directory.GetDirectories(Path.Combine(root, "buffer")).Length : 0; }
                catch { }
                long str = DirSize(Path.Combine(root, "stream"));
                long cache = FileSize(Path.Combine(root, "cache.db")) + FileSize(Path.Combine(root, "cache-log.db"));
                long ob = FileSize(Path.Combine(root, "outbox.db")) + FileSize(Path.Combine(root, "outbox-log.db"))
                          + DirSize(Path.Combine(root, "outbox"));
                long logs = DirSize(Path.Combine(root, "logs")) + DirSize(Path.Combine(root, "Log"));
                long hist = DirSize(Path.Combine(root, "history"));
                return "buffer " + Mb(buf) + " (" + bufDirs + " folder(s)) | stream " + Mb(str) +
                       " | cache " + Mb(cache) + " | outbox " + Mb(ob) +
                       " | history " + Mb(hist) + " | logs " + Mb(logs) +
                       " | total " + Mb(DirSize(root));
            }
            catch (Exception ex) { return "data folder: " + ex.Message; }
        }

        private static long FileSize(string p)
        {
            try { return File.Exists(p) ? new FileInfo(p).Length : 0; }
            catch { return 0; }
        }

        public static string Mb(long bytes)
        {
            if (bytes <= 0) return "0 MB";
            double mb = bytes / 1048576.0;
            if (mb < 0.1) return (bytes / 1024.0).ToString("0.#", CultureInfo.InvariantCulture) + " KB";
            if (mb < 1024) return mb.ToString("0.#", CultureInfo.InvariantCulture) + " MB";
            return (mb / 1024.0).ToString("0.##", CultureInfo.InvariantCulture) + " GB";
        }
    }
}
