﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.ServiceProcess;
using System.Threading;
using System.Windows.Forms;

namespace SyncDB
{
    internal static class Program
    {
        private static Mutex _singleInstanceMutex;

        [DllImport("user32.dll")]
        private static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        private const int SW_RESTORE = 9;

        [STAThread]
        private static void Main(string[] args)
        {
            bool serviceMode = false;
            foreach (string a in args)
            {
                if (a.StartsWith("/datadir:", StringComparison.OrdinalIgnoreCase))
                    AppConfig.DataDirOverride = a.Substring(9).Trim().Trim('"');
                else if (string.Equals(a, "/service", StringComparison.OrdinalIgnoreCase))
                    serviceMode = true;
            }

            if (serviceMode)
            {
                // Windows Service host (no UI)
                ServiceBase.Run(new SyncDbService());
                return;
            }

            string logDir = AppConfig.DataDir;
            string bootLog = Path.Combine(logDir, "startup.log");
            try { Directory.CreateDirectory(logDir); } catch { }

            Action<string> boot = msg =>
            {
                try
                {
                    File.AppendAllText(bootLog,
                        DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + msg + Environment.NewLine,
                        Encoding.UTF8);
                }
                catch { }
            };

            boot("Main() entered. Exe=" + Application.ExecutablePath);
            Lang.Load();     // language chosen in the Language menu (lang.txt)

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // /install  /uninstall  /svcstart  /svcstop  (Windows service management, self-elevating)
            if (WinSvc.HandleCommand(args)) return;

            if (!TakeSingleInstanceOwnership())
            {
                MessageBox.Show(
                    "SyncDB is already running.\r\n\r\nThe existing program is already running.\r\n"
                    + "Its window has been brought to the front.",
                    "SyncDB", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ActivateExistingInstance();
                return;
            }

            Application.ThreadException += (s, e) =>
            {
                boot("ThreadException: " + e.Exception);
                MessageBox.Show(e.Exception.Message + "\r\n\r\n" + e.Exception, "SyncDB error");
            };
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                Exception ex = e.ExceptionObject as Exception;
                boot("Unhandled: " + (ex != null ? ex.ToString() : "unknown"));
                MessageBox.Show(ex != null ? ex.ToString() : "Unknown error", "SyncDB fatal");
            };

            // Check Newtonsoft.Json.dll is next to the exe
            try
            {
                string dir = Path.GetDirectoryName(Application.ExecutablePath);
                string dll = Path.Combine(dir ?? "", "Newtonsoft.Json.dll");
                if (!File.Exists(dll))
                {
                    boot("MISSING Newtonsoft.Json.dll at " + dll);
                    MessageBox.Show(
                        "فایل Newtonsoft.Json.dll کنار برنامه نیست.\r\n\r\n" +
                        "این فایل را در همان پوشه SyncDB.exe بگذارید و دوباره اجرا کنید.\r\n\r\n" +
                        dll,
                        "SyncDB", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                // force load
                Assembly.LoadFrom(dll);
                Type jt = Type.GetType("Newtonsoft.Json.JsonConvert, Newtonsoft.Json");
                boot("Newtonsoft.Json OK. JsonConvert=" + (jt != null ? "found" : "null"));
            }
            catch (Exception ex)
            {
                boot("Newtonsoft load failed: " + ex);
                MessageBox.Show(
                    "نتوانست Newtonsoft.Json.dll را بارگذاری کند:\r\n\r\n" + ex.Message,
                    "SyncDB", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // password prompt (all attempts are written to the log and to audit_syncdb.txt)
            try
            {
                AppConfig lc = AppConfig.Load();
                AppLog.Configure(lc.EffectiveLogFolder, lc.LogRetentionDays);
            }
            catch { }
            if (!LoginForm.Authenticate()) { boot("Login failed / cancelled - exit."); return; }

            LoadingForm splash = null;
            try
            {
                boot("Showing loading screen...");
                splash = new LoadingForm();
                splash.Show();
                Application.DoEvents();
                // Let the green bar start moving
                for (int i = 0; i < 8; i++) { Application.DoEvents(); System.Threading.Thread.Sleep(40); }

                boot("Creating MainForm...");
                MainForm form = new MainForm();
                form.StartPosition = FormStartPosition.CenterScreen;
                form.WindowState = FormWindowState.Normal;
                form.ShowInTaskbar = true;
                form.Opacity = 0;
                form.Show();
                Application.DoEvents();
                form.Opacity = 1;

                try { splash.SetProgress(100); Application.DoEvents(); System.Threading.Thread.Sleep(120); } catch { }
                try { splash.Close(); splash.Dispose(); } catch { }
                splash = null;

                boot("Running message loop...");
                Application.Run(form);
                boot("Application.Run ended.");
            }
            catch (Exception ex)
            {
                try { if (splash != null) { splash.Close(); splash.Dispose(); } } catch { }
                boot("Startup exception: " + ex);
                MessageBox.Show(
                    "برنامه باز نشد:\r\n\r\n" + ex.Message + "\r\n\r\nجزئیات:\r\n" + ex,
                    "SyncDB failed to start",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static bool TakeSingleInstanceOwnership()
        {
            try
            {
                string key = (AppConfig.DataDir ?? "").ToLowerInvariant();
                int hash = 0;
                foreach (char c in key) hash = unchecked(hash * 31 + c);
                string name = "Global\\SyncDB.GUI." + hash.ToString("X8");
                bool created;
                try { _singleInstanceMutex = new Mutex(false, name, out created); }
                catch
                {
                    _singleInstanceMutex = new Mutex(false, "Local\\SyncDB.GUI." + hash.ToString("X8"), out created);
                }
                try
                {
                    return _singleInstanceMutex.WaitOne(0);
                }
                catch (AbandonedMutexException)
                {
                    // The previous process exited unexpectedly; this process now owns it.
                    return true;
                }
            }
            catch { return true; }
        }

        private static void ActivateExistingInstance()
        {
            try
            {
                int current = Process.GetCurrentProcess().Id;
                string name = Process.GetCurrentProcess().ProcessName;
                foreach (Process p in Process.GetProcessesByName(name))
                {
                    try
                    {
                        if (p.Id == current || p.MainWindowHandle == IntPtr.Zero) continue;
                        ShowWindowAsync(p.MainWindowHandle, SW_RESTORE);
                        SetForegroundWindow(p.MainWindowHandle);
                        break;
                    }
                    finally { p.Dispose(); }
                }
            }
            catch { }
        }
    }
}
