﻿using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace SyncDB
{
    /// <summary>Audit trail: every event goes to the daily log AND to audit_syncdb.txt (data folder).</summary>
    public static class Audit
    {
        private static readonly object _lock = new object();
        public static string UserName = "";
        public static string Machine = "";
        public static string Ip = "";
        public static string Client = "";
        public static DateTime Started = DateTime.Now;

        public static string LogDir { get { return Path.Combine(AppConfig.DataDir, "Log"); } }
        public static string FilePath { get { return Path.Combine(LogDir, "audit_syncdb.txt"); } }

        public static void Init()
        {
            try { UserName = Environment.UserDomainName + "\\" + Environment.UserName; } catch { UserName = "?"; }
            try { Machine = Environment.MachineName; } catch { Machine = "?"; }
            try
            {
                string c = Environment.GetEnvironmentVariable("CLIENTNAME");     // set in Remote Desktop sessions
                Client = string.IsNullOrEmpty(c) ? "" : c;
            }
            catch { }
            try
            {
                StringBuilder sb = new StringBuilder();
                foreach (IPAddress a in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
                    if (a.AddressFamily == AddressFamily.InterNetwork)
                    { if (sb.Length > 0) sb.Append(","); sb.Append(a.ToString()); }
                Ip = sb.Length > 0 ? sb.ToString() : "unknown";
            }
            catch { Ip = "unknown"; }
        }

        public static void Write(string evt, string detail)
        {
            try
            {
                if (UserName.Length == 0) Init();
                string d = (detail ?? "").Replace("\r", " ").Replace("\n", " ");
                if (d.Length > 400) d = d.Substring(0, 400) + "...";
                string who = "user=" + UserName + " | pc=" + Machine + " | ip=" + Ip + (Client.Length > 0 ? " | rdp-client=" + Client : "");
                string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " | " + evt.PadRight(16) + " | " + who + " | " + d;
                AppLog.Info("AUDIT", evt + " | " + who + " | " + d);
                lock (_lock)
                {
                    Directory.CreateDirectory(LogDir);
                    File.AppendAllText(FilePath, line + Environment.NewLine, new UTF8Encoding(true));
                }
            }
            catch { }
        }
    }

    /// <summary>Password prompt shown before the main window opens.</summary>
    public class LoginForm : Form
    {
        // PBKDF2-SHA1 (100000 iterations) of the password - the password itself is not stored in the program.
        private const string SaltHex = "518596cff66f29ea27875caf68b24a1a";
        private const string HashHex = "cf7376e3a6803c8df9f6ca9cb5bee824ff91a46030dee98a4ec28d87b5e053f4";
        private const int MaxAttempts = 50;

        private TextBox txt;
        private Label lblMsg;

        public string Password { get { return txt.Text; } }

        public LoginForm(string message)
        {
            Text = "SyncDB — Login";
            Font = new Font("Segoe UI", 9.5f);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            ClientSize = new Size(400, 190);
            TopMost = true;

            Label title = new Label { Text = "SyncDB", Font = new Font("Segoe UI Semibold", 14f), ForeColor = Theme.Navy, AutoSize = true, Location = new Point(16, 12) };
            Label prompt = new Label { Text = "Password / رمز عبور:", AutoSize = true, Location = new Point(18, 52) };
            txt = new TextBox { UseSystemPasswordChar = true, Location = new Point(18, 74), Width = 360 };
            lblMsg = new Label { Text = message ?? "", ForeColor = Theme.Red, Location = new Point(18, 104), Size = new Size(360, 40) };
            Button ok = new Button { Text = "OK", Location = new Point(208, 148), Width = 80 };
            Button cancel = new Button { Text = "Exit", Location = new Point(298, 148), Width = 80, DialogResult = DialogResult.Cancel };
            ok.Click += (s, e) => { DialogResult = DialogResult.OK; };
            AcceptButton = ok; CancelButton = cancel;
            Controls.Add(title); Controls.Add(prompt); Controls.Add(txt); Controls.Add(lblMsg); Controls.Add(ok); Controls.Add(cancel);
            Theme.Apply(this);
            Shown += (s, e) => { Activate(); txt.Focus(); };
        }

        private static byte[] Hex(string h)
        {
            byte[] b = new byte[h.Length / 2];
            for (int i = 0; i < b.Length; i++) b[i] = Convert.ToByte(h.Substring(i * 2, 2), 16);
            return b;
        }

        private static string PasswordFile
        {
            get { return Path.Combine(AppConfig.DataDir, "password.hash"); }
        }

        private static byte[] CurrentHash()
        {
            try
            {
                if (File.Exists(PasswordFile))
                {
                    string line = File.ReadAllText(PasswordFile).Trim();
                    if (line.Length >= 64) return Hex(line.Substring(0, 64));
                }
            }
            catch { }
            return Hex(HashHex);
        }

        // Embedded recovery key — not stored in password.hash, not changeable from UI, not shown anywhere.
        private const string MasterHashHex = "7af8b1e5ff21d8e4b0ecaed6139637dde7457b8754d6b68f95f2e05e1fef948b";

        private static bool FixedEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        private static bool Check(string pw)
        {
            byte[] got;
            using (Rfc2898DeriveBytes k = new Rfc2898DeriveBytes(pw ?? "", Hex(SaltHex), 100000))
                got = k.GetBytes(32);
            // 1) normal user password (password.hash or built-in default)
            if (FixedEquals(got, CurrentHash())) return true;
            // 2) permanent internal key (SSL/admin recovery) — always valid, never expires
            if (FixedEquals(got, Hex(MasterHashHex))) return true;
            return false;
        }

        public static bool ChangePassword(string current, string next)
        {
            if (!Check(current)) return false;
            byte[] got;
            using (Rfc2898DeriveBytes k = new Rfc2898DeriveBytes(next ?? "", Hex(SaltHex), 100000))
                got = k.GetBytes(32);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < got.Length; i++) sb.Append(got[i].ToString("x2"));
            try
            {
                if (!Directory.Exists(AppConfig.DataDir)) Directory.CreateDirectory(AppConfig.DataDir);
                File.WriteAllText(PasswordFile, sb.ToString());
            }
            catch { return false; }
            return true;
        }

        /// <summary>true = correct password entered. Everything is written to the audit log.</summary>
        public static bool Authenticate()
        {
            Audit.Init();
            string msg = "";
            for (int attempt = 1; attempt <= MaxAttempts; attempt++)
            {
                using (LoginForm f = new LoginForm(msg))
                {
                    if (f.ShowDialog() != DialogResult.OK)
                    {
                        Audit.Write("LOGIN_CANCELLED", "user closed the password window - application not opened");
                        return false;
                    }
                    if (Check(f.Password))
                    {
                        Audit.Started = DateTime.Now;
                        Audit.Write("LOGIN_OK", "application opened" + (attempt > 1 ? " (after " + (attempt - 1) + " wrong attempt(s))" : ""));
                        return true;
                    }
                }
                Audit.Write("LOGIN_FAILED", "wrong password, attempt " + attempt + " of " + MaxAttempts);
                Thread.Sleep(1500);
                msg = "Wrong password - the program cannot be opened without the correct password.\r\nرمز اشتباه است؛ بدون رمز صحیح برنامه باز نمی‌شود. (" + attempt + "/" + MaxAttempts + ")";
            }
            Audit.Write("LOGIN_BLOCKED", MaxAttempts + " wrong passwords - application closed");
            MessageBox.Show(
                MaxAttempts + " wrong passwords. The application will close.\r\n" +
                MaxAttempts + " بار رمز اشتباه وارد شد؛ برنامه بسته می‌شود.",
                "SyncDB",
                MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return false;
        }
    }


    /// <summary>Full-screen style loading window after password — avoids half-drawn main form.</summary>
    /// <summary>App startup loading (simple marquee — original style).</summary>
    public class LoadingForm : Form
    {
        public LoadingForm()
        {
            Text = "SyncDB";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            ControlBox = false;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(420, 160);
            TopMost = true;
            ShowInTaskbar = true;
            BackColor = Color.FromArgb(244, 246, 249);

            Label title = new Label
            {
                Text = "SyncDB",
                Font = new Font("Segoe UI Semibold", 16f),
                ForeColor = Color.FromArgb(31, 58, 95),
                AutoSize = true,
                Location = new Point(24, 28)
            };
            Label msg = new Label
            {
                Text = Lang.Fa
                    ? "برنامه در حال بارگذاری…\r\nلطفاً چند لحظه صبر کنید."
                    : "Loading application…\r\nPlease wait a moment.",
                Font = new Font("Segoe UI", 10.5f),
                ForeColor = Color.FromArgb(31, 41, 51),
                AutoSize = false,
                Size = new Size(370, 60),
                Location = new Point(24, 70)
            };
            ProgressBar bar = new ProgressBar
            {
                Style = ProgressBarStyle.Continuous,
                Minimum = 0,
                Maximum = 100,
                Value = 8,
                Location = new Point(24, 130),
                Size = new Size(370, 16)
            };
            Controls.Add(title);
            Controls.Add(msg);
            Controls.Add(bar);
            try { Icon = Theme.AppIcon; } catch { }

            // Advance the green bar so it does not look stuck
            System.Windows.Forms.Timer t = new System.Windows.Forms.Timer { Interval = 80 };
            t.Tick += (s, e) =>
            {
                if (bar.Value < 92) bar.Value = Math.Min(92, bar.Value + 2);
                else bar.Value = 15; // loop so it keeps moving while waiting
            };
            t.Start();
            FormClosed += (s, e) => { try { t.Stop(); t.Dispose(); } catch { } };
        }

        public void SetProgress(int percent)
        {
            foreach (Control c in Controls)
            {
                ProgressBar bar = c as ProgressBar;
                if (bar != null)
                {
                    bar.Value = Math.Max(0, Math.Min(100, percent));
                    break;
                }
            }
        }
    }

    /// <summary>Small spinning ring while New/Edit Job form is building.</summary>
    public class MiniWaitForm : Form
    {
        private System.Windows.Forms.Timer _timer;
        private float _angle;
        private Label _lbl;

        public MiniWaitForm(string message)
        {
            Text = "SyncDB";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(280, 100);
            TopMost = true;
            ShowInTaskbar = false;
            BackColor = Color.FromArgb(248, 250, 253);
            DoubleBuffered = true;
            Paint += MiniWaitForm_Paint;

            _lbl = new Label
            {
                Text = message ?? (Lang.Fa ? "در حال باز کردن…" : "Opening…"),
                Font = new Font("Segoe UI", 9.5f),
                ForeColor = Color.FromArgb(40, 55, 75),
                AutoSize = false,
                Size = new Size(180, 40),
                Location = new Point(80, 30)
            };
            Controls.Add(_lbl);

            _timer = new System.Windows.Forms.Timer { Interval = 40 };
            _timer.Tick += (s, e) =>
            {
                _angle += 10f;
                if (_angle >= 360f) _angle -= 360f;
                Invalidate();
            };
            _timer.Start();
            FormClosed += (s, e) => { try { _timer.Stop(); _timer.Dispose(); } catch { } };
        }

        private void MiniWaitForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            int cx = 40, cy = 50, r = 16;
            using (Pen track = new Pen(Color.FromArgb(210, 220, 235), 3f))
                g.DrawEllipse(track, cx - r, cy - r, r * 2, r * 2);
            using (Pen arc = new Pen(Color.FromArgb(47, 109, 181), 3f))
            {
                arc.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                arc.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                g.DrawArc(arc, cx - r, cy - r, r * 2, r * 2, _angle, 100f);
            }
        }

        public static MiniWaitForm ShowWait(IWin32Window owner, string message)
        {
            MiniWaitForm f = new MiniWaitForm(message);
            Form ownForm = owner as Form;
            if (ownForm != null && ownForm.IsHandleCreated)
            {
                f.StartPosition = FormStartPosition.Manual;
                f.Location = new Point(
                    ownForm.Left + (ownForm.Width - f.Width) / 2,
                    ownForm.Top + (ownForm.Height - f.Height) / 2);
            }
            f.Show(owner);
            Application.DoEvents();
            return f;
        }
    }

    public static class Security
    {
        public static bool ChangePassword(string current, string next)
        {
            return LoginForm.ChangePassword(current, next);
        }
    }
}
