using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SyncDB
{
    /// <summary>
    /// Job History window: every finished run of every job (last 30 days), with the exact figures -
    /// date, job, status, records, how long it took (minutes), who started it, which tables moved.
    /// The status bar at the bottom follows the transfer that is running right now.
    /// </summary>
    public class JobHistoryForm : Form
    {
        private readonly AppConfig _config;

        private ListView _logs;             // left: jobs with checkbox + status icon
        private ListView _grid;
        private TextBox _detail;
        private ImageList _icons;
        private StatusStrip _status;
        private ToolStripStatusLabel _lblCount, _lblLive;
        private Button _btnStop;
        private Timer _timer;
        private bool _wasRunning;
        private bool _loading;
        private string _sticky;          // last message that stays until the next run
        private string _focusJob;        // name clicked in the list = show only this job
        private bool _archiveMode;       // true = show archive (deleted/cleared history, last ArchiveDays)
        private Button _btnArchive;
        private readonly Dictionary<string, string> _lastStatus = new Dictionary<string, string>();

        public JobHistoryForm(AppConfig config)
        {
            _config = config;
            Text = "Job History (last " + JobHistory.KeepDays + " days)";
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(1080, 600);
            MinimumSize = new Size(780, 420);
            ShowInTaskbar = false;
            MinimizeBox = true;
            MaximizeBox = true;
            try { Icon = MakeJobIcon(); } catch { }

            BuildIcons();
            BuildUi();
            try { Theme.Apply(this); } catch { }      // colours + Persian captions
            // Theme overwrites Form.Icon and turns OwnerDraw on ListViews — restore ours
            try
            {
                Icon = MakeJobIcon();
                _logs.OwnerDraw = false;
                _logs.CheckBoxes = true;
                _logs.SmallImageList = _icons;
                _logs.View = View.Details;
                _logs.HeaderStyle = ColumnHeaderStyle.None;
            }
            catch { }
            try { JobHistory.PurgeArchive(); } catch { }
            LoadLogList();
            Reload();

            _timer = new Timer { Interval = 1000 };
            _timer.Tick += (s, e) => TickLive();
            _timer.Start();
            FormClosed += (s, e) => { try { _timer.Stop(); _timer.Dispose(); } catch { } };
        }

        // ------------------------------------------------------------------ UI

        private void BuildIcons()
        {
            _icons = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
            // colours matched to the target screenshot
            _icons.Images.Add("OK", MakeMark(Color.FromArgb(40, 180, 70), true));   // bright green ✓
            _icons.Images.Add("WARN", MakeMark(Color.FromArgb(220, 150, 20), false));
            _icons.Images.Add("FAIL", MakeMark(Color.FromArgb(220, 40, 40), false)); // bright red ✗
            _icons.Images.Add("LOG", MakeJobMark());   // blue list icon
            _icons.Images.Add("NONE", MakeJobMark());
        }

        /// <summary>Blue list/document icon — same style as the target screenshot (Job 4 / Job 5).</summary>
        private static Bitmap MakeJobMark()
        {
            Bitmap bmp = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                // flat blue document with 3 lines (matches target UI)
                using (SolidBrush body = new SolidBrush(Color.FromArgb(70, 130, 200)))
                using (SolidBrush line = new SolidBrush(Color.White))
                {
                    // rounded-ish doc via filled rect
                    g.FillRectangle(body, 2, 1, 12, 14);
                    // white text lines
                    g.FillRectangle(line, 4, 4, 8, 1);
                    g.FillRectangle(line, 4, 7, 8, 1);
                    g.FillRectangle(line, 4, 10, 5, 1);
                }
            }
            return bmp;
        }

        private static Icon MakeJobIcon()
        {
            Bitmap bmp = new Bitmap(32, 32);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (SolidBrush body = new SolidBrush(Color.FromArgb(70, 130, 200)))
                using (SolidBrush line = new SolidBrush(Color.White))
                {
                    g.FillRectangle(body, 6, 3, 20, 26);
                    g.FillRectangle(line, 10, 9, 12, 2);
                    g.FillRectangle(line, 10, 15, 12, 2);
                    g.FillRectangle(line, 10, 21, 8, 2);
                }
            }
            IntPtr h = bmp.GetHicon();
            Icon ic = Icon.FromHandle(h);
            Icon clone = (Icon)ic.Clone();
            try { DestroyIcon(h); } catch { }
            bmp.Dispose();
            return clone;
        }

        [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        private static extern bool DestroyIcon(IntPtr handle);

        /// <summary>Green check / red X — same style as the target screenshot.</summary>
        private static Bitmap MakeMark(Color c, bool check)
        {
            Bitmap bmp = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (Pen p = new Pen(c, 2.4f))
                {
                    p.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                    p.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                    if (check)
                    {
                        // bright green ✓
                        g.DrawLine(p, 2, 8, 6, 12);
                        g.DrawLine(p, 6, 12, 13, 3);
                    }
                    else
                    {
                        // red ✗
                        g.DrawLine(p, 3, 3, 12, 12);
                        g.DrawLine(p, 12, 3, 3, 12);
                    }
                }
            }
            return bmp;
        }

        private void BuildUi()
        {
            // ---- left: which logs to show (ListView = reliable checkbox + icon) ----
            Panel left = new Panel { Dock = DockStyle.Left, Width = 250, Padding = new Padding(8, 8, 4, 8) };
            Label lblLogs = new Label { Dock = DockStyle.Top, Height = 22, Text = "Select logs", Font = new Font(Font, FontStyle.Bold), ForeColor = Color.FromArgb(20, 120, 60) };
            _logs = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                HeaderStyle = ColumnHeaderStyle.None,
                FullRowSelect = true,
                CheckBoxes = true,
                MultiSelect = false,
                HideSelection = false,
                BorderStyle = BorderStyle.FixedSingle,
                SmallImageList = _icons,
                Font = new Font("Segoe UI", 9f)
            };
            _logs.Columns.Add("Job", 220);
            // hand cursor over a job row
            _logs.MouseMove += (s, e) =>
            {
                try
                {
                    ListViewHitTestInfo hit = _logs.HitTest(e.Location);
                    bool overJob = hit.Item != null &&
                        hit.Location != ListViewHitTestLocations.StateImage; // not the checkbox
                    _logs.Cursor = overJob ? Cursors.Hand : Cursors.Default;
                }
                catch { _logs.Cursor = Cursors.Default; }
            };
            _logs.MouseLeave += (s, e) => { try { _logs.Cursor = Cursors.Default; } catch { } };

            // tick box = several jobs together
            _logs.ItemChecked += (s, e) =>
            {
                if (_loading) return;
                _focusJob = null;
                BeginInvoke(new Action(Reload));
            };

            // ONE click on the name / icon = show only that job (no double-click needed)
            _logs.MouseUp += (s, e) =>
            {
                if (_loading || e.Button != MouseButtons.Left) return;
                try
                {
                    ListViewHitTestInfo hit = _logs.HitTest(e.Location);
                    if (hit.Item == null) return;
                    // ignore pure checkbox clicks — ItemChecked already handles those
                    if (hit.Location == ListViewHitTestLocations.StateImage) return;
                    _focusJob = hit.Item.Text;
                    hit.Item.Selected = true;
                    Reload();
                }
                catch { }
            };
            Label hint = new Label
            {
                Dock = DockStyle.Bottom,
                Height = 32,
                ForeColor = SystemColors.GrayText,
                Text = "Click a name = only that job.\r\nTick the boxes = several jobs together."
            };
            ContextMenuStrip cm = new ContextMenuStrip();
            cm.Items.Add("Select all", null, (s, e) => CheckAll(true));
            cm.Items.Add("Select none", null, (s, e) => CheckAll(false));
            cm.Items.Add(new ToolStripSeparator());
            cm.Items.Add("Open history folder", null, (s, e) => OpenFolder());
            _logs.ContextMenuStrip = cm;
            left.Controls.Add(_logs);
            left.Controls.Add(hint);
            left.Controls.Add(lblLogs);

            // ---- right: runs on top, the detail of the selected run below ----
            SplitContainer split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal,
                SplitterWidth = 6,
                Panel1MinSize = 120,
                Panel2MinSize = 60
            };
            split.SizeChanged += (s, e) =>
            {
                try
                {
                    int h = split.Height;
                    if (h > 300 && !_splitSized)
                    {
                        split.SplitterDistance = Math.Max(split.Panel1MinSize, h - 150);
                        _splitSized = true;
                    }
                }
                catch { }
            };

            _grid = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                HideSelection = false,
                MultiSelect = false,
                SmallImageList = _icons
            };
            _grid.Columns.Add("Date", 150);
            _grid.Columns.Add("Job", 165);
            _grid.Columns.Add("Status", 65);
            _grid.Columns.Add("Records", 90, HorizontalAlignment.Right);
            _grid.Columns.Add("Elapsed (sec)", 180);
            _grid.Columns.Add("Source", 65);
            _grid.Columns.Add("Tables", 62, HorizontalAlignment.Right);
            _grid.Columns.Add("Transferred (table : records)", 260);
            _grid.Columns.Add("Message", 420);
            _grid.SelectedIndexChanged += (s, e) => ShowDetail();
            _grid.ColumnClick += Grid_ColumnClick;

            _detail = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Both,
                WordWrap = false,
                BackColor = Color.White,
                Font = new Font("Consolas", 9f)
            };

            split.Panel1.Controls.Add(_grid);
            split.Panel2.Controls.Add(_detail);

            // ---- buttons ----
            FlowLayoutPanel bar = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 44,
                FlowDirection = FlowDirection.RightToLeft,
                Padding = new Padding(8, 7, 8, 7)
            };
            Button btnClose = MkBtn("Close", (s, e) => Close());
            Button btnStop = MkBtn("Stop", (s, e) => StopRunningJob());
            Button btnClear = MkBtn("Clear history", (s, e) => ClearHistory());
            _btnArchive = MkBtn("Archive", (s, e) => ToggleArchiveMode());
            Button btnRefresh = MkBtn("Refresh", (s, e) => { try { JobHistory.PurgeArchive(); } catch { } LoadLogList(); Reload(); });
            _btnStop = btnStop;
            _btnStop.Enabled = false;
            bar.Controls.Add(btnClose);
            bar.Controls.Add(btnStop);
            bar.Controls.Add(btnClear);
            bar.Controls.Add(_btnArchive);
            bar.Controls.Add(btnRefresh);

            // ---- status bar: record count + the transfer that is running now ----
            _status = new StatusStrip();
            _lblCount = new ToolStripStatusLabel("Status: 0 record(s)  |  keep " + JobHistory.KeepDays + " days  |  archive " + JobHistory.ArchiveDays + " days")
            {
                BorderSides = ToolStripStatusLabelBorderSides.Right,
                BorderStyle = Border3DStyle.Etched
            };
            _lblLive = new ToolStripStatusLabel("No transfer is running.")
            {
                Spring = true,
                TextAlign = ContentAlignment.MiddleLeft
            };
            _status.Items.Add(_lblCount);
            _status.Items.Add(_lblLive);

            Panel main = new Panel { Dock = DockStyle.Fill, Padding = new Padding(4, 8, 8, 0) };
            main.Controls.Add(split);

            Controls.Add(main);
            Controls.Add(left);
            Controls.Add(bar);
            Controls.Add(_status);
        }

        private bool _splitSized;

        private Button MkBtn(string text, EventHandler h)
        {
            Button b = new Button { Text = text, AutoSize = false, Width = 110, Height = 28, Margin = new Padding(6, 0, 0, 0) };
            if (h != null) b.Click += h;
            return b;
        }

        private void CheckAll(bool on)
        {
            _focusJob = null;
            _loading = true;
            try
            {
                foreach (ListViewItem it in _logs.Items) it.Checked = on;
            }
            finally { _loading = false; }
            Reload();
        }

        /// <summary>Image key for a job's last status.</summary>
        private static string StatusKey(string st)
        {
            if (string.IsNullOrEmpty(st)) return "LOG";
            st = st.Trim().ToUpperInvariant();
            if (st == "OK") return "OK";
            if (st == "FAIL") return "FAIL";
            if (st == "WARN") return "WARN";
            return "LOG";
        }

        /// <summary>Refresh icons + text colour on every left-list row from _lastStatus.</summary>
        private void RefreshLogIcons()
        {
            foreach (ListViewItem it in _logs.Items)
            {
                string st = "";
                if (_lastStatus.ContainsKey(it.Text)) st = _lastStatus[it.Text] ?? "";
                it.ImageKey = StatusKey(st);
                if (st == "OK") it.ForeColor = Color.FromArgb(20, 100, 50);
                else if (st == "FAIL") it.ForeColor = Color.FromArgb(170, 30, 30);
                else if (st == "WARN") it.ForeColor = Color.FromArgb(150, 100, 0);
                else it.ForeColor = SystemColors.ControlText;
            }
        }

        private void OpenFolder()
        {
            try
            {
                System.IO.Directory.CreateDirectory(JobHistory.Dir);
                System.Diagnostics.Process.Start("explorer.exe", "\"" + JobHistory.Dir + "\"");
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "History folder"); }
        }

        // ------------------------------------------------------------------ data

        /// <summary>Fills the left list with every job that has history.</summary>
        private void LoadLogList()
        {
            List<string> have;
            if (_archiveMode)
            {
                have = JobHistory.ListArchivedJobs();
            }
            else
            {
                have = JobHistory.ListJobs();
                if (_config != null && _config.Jobs != null)
                    foreach (SyncJob j in _config.Jobs)
                    {
                        string n = JobHistory.SafeName(j.Name ?? j.Id);
                        if (!have.Contains(n)) have.Add(n);
                    }
            }
            have.Sort(StringComparer.CurrentCultureIgnoreCase);

            // keep the ticks the user already set
            List<string> wasChecked = new List<string>();
            foreach (ListViewItem it in _logs.Items)
                if (it.Checked) wasChecked.Add(it.Text);

            _loading = true;
            try
            {
                _logs.BeginUpdate();
                _logs.Items.Clear();
                foreach (string n in have)
                {
                    ListViewItem it = new ListViewItem(n);
                    it.Checked = wasChecked.Contains(n);
                    it.ImageKey = "LOG";
                    _logs.Items.Add(it);
                }
                _logs.EndUpdate();

                _lastStatus.Clear();
                foreach (string n in have)
                {
                    try
                    {
                        if (_archiveMode)
                        {
                            List<HistoryRun> ar = JobHistory.LoadArchived(n);
                            _lastStatus[n] = ar.Count > 0 ? ar[0].Status : "";
                        }
                        else
                            _lastStatus[n] = JobHistory.LastStatus(n);
                    }
                    catch { _lastStatus[n] = ""; }
                }
                RefreshLogIcons();

                if (_focusJob != null)
                {
                    foreach (ListViewItem it in _logs.Items)
                        if (string.Equals(it.Text, _focusJob, StringComparison.CurrentCultureIgnoreCase))
                        { it.Selected = true; it.EnsureVisible(); break; }
                }
            }
            finally { _loading = false; }
        }

        private List<string> CheckedLogs()
        {
            List<string> l = new List<string>();
            foreach (ListViewItem it in _logs.Items)
                if (it.Checked) l.Add(it.Text);
            return l;
        }

        private int _sortCol = 0;
        private bool _sortAsc;

        private void Grid_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == _sortCol) _sortAsc = !_sortAsc; else { _sortCol = e.Column; _sortAsc = true; }
            Reload();
        }

        private void Reload()
        {
            // a clicked name shows only that job; otherwise every ticked job
            List<string> show;
            if (_focusJob != null) { show = new List<string>(); show.Add(_focusJob); }
            else show = CheckedLogs();

            List<HistoryRun> runs = new List<HistoryRun>();
            foreach (string name in show)
            {
                try
                {
                    if (_archiveMode) runs.AddRange(JobHistory.LoadArchived(name));
                    else runs.AddRange(JobHistory.Load(name));
                }
                catch { }
            }

            // keep the mark of the job that just ran up to date
            foreach (string n in show)
            {
                HistoryRun newest = null;
                foreach (HistoryRun r in runs)
                    if (string.Equals(r.Job, n, StringComparison.CurrentCultureIgnoreCase))
                        if (newest == null || r.Time > newest.Time) newest = r;
                _lastStatus[n] = newest != null ? newest.Status : "";
            }
            RefreshLogIcons();

            runs.Sort(delegate (HistoryRun a, HistoryRun b)
            {
                int c;
                switch (_sortCol)
                {
                    case 1: c = string.Compare(a.Job, b.Job, StringComparison.CurrentCultureIgnoreCase); break;
                    case 2: c = string.Compare(a.Status, b.Status, StringComparison.OrdinalIgnoreCase); break;
                    case 3: c = a.Rows.CompareTo(b.Rows); break;
                    case 4: c = a.ElapsedMs.CompareTo(b.ElapsedMs); break;
                    case 5: c = string.Compare(a.Source, b.Source, StringComparison.OrdinalIgnoreCase); break;
                    case 6: c = a.Tables.CompareTo(b.Tables); break;
                    default: c = a.Time.CompareTo(b.Time); break;
                }
                if (c == 0) c = a.Time.CompareTo(b.Time);
                return _sortAsc ? c : -c;
            });

            _grid.BeginUpdate();
            _grid.Items.Clear();
            long totalRows = 0;
            int fail = 0, warn = 0;
            foreach (HistoryRun r in runs)
            {
                ListViewItem it = new ListViewItem(JobHistory.Fmt(r.Time));
                it.ImageKey = r.Status == "FAIL" ? "FAIL" : (r.Status == "WARN" ? "WARN" : "OK");
                it.SubItems.Add(r.Job);
                it.SubItems.Add(r.Status);
                it.SubItems.Add(r.Rows.ToString("N0"));
                it.SubItems.Add(r.Elapsed);
                it.SubItems.Add(r.Source);
                it.SubItems.Add(r.Tables > 0 ? r.Tables.ToString() : "-");
                it.SubItems.Add(r.TableList);
                it.SubItems.Add(r.Message);
                if (r.Status == "FAIL") { it.BackColor = Color.FromArgb(255, 226, 226); fail++; }
                else if (r.Status == "WARN") { it.BackColor = Color.FromArgb(255, 246, 205); warn++; }
                it.Tag = r;
                _grid.Items.Add(it);
                totalRows += r.Rows;
            }
            _grid.EndUpdate();

            string sum = "Status: " + runs.Count + " record(s)";
            if (_focusJob != null) sum += "  |  " + _focusJob;
            if (fail > 0) sum += "  |  " + fail + " failed";
            if (warn > 0) sum += "  |  " + warn + " warning";
            sum += "  |  " + totalRows.ToString("N0") + " records in total  |  keep " + JobHistory.KeepDays + " days  |  archive " + JobHistory.ArchiveDays + " days";
            if (_archiveMode) sum += "  |  ARCHIVE VIEW";
            _lblCount.Text = sum;

            if (_grid.Items.Count > 0) { _grid.Items[0].Selected = true; _grid.Items[0].Focused = true; }
            else
            {
                if (_archiveMode)
                {
                    _detail.Text =
                        "Archive is empty for the selected job(s).\r\n\r\n" +
                        "When you delete a job or use Clear history, records move here for "
                        + JobHistory.ArchiveDays + " days, then are removed automatically.\r\n\r\n" +
                        "Archive folder:\r\n" + JobHistory.ArchiveDir + "\r\n\r\n" +
                        "Use Clear history in this view to permanently delete selected archive entries.";
                }
                else
                {
                    string path = JobHistory.Dir;
                    _detail.Text =
                        "No history records found for the selected job(s).\r\n\r\n" +
                        "History is written only AFTER a job finishes (success, fail or stop).\r\n" +
                        "If a job is still running (see the status bar at the bottom), its record will appear here after it completes — then click Refresh.\r\n\r\n" +
                        "History files are stored in:\r\n" + path + "\r\n\r\n" +
                        "Clear history moves records to Archive for " + JobHistory.ArchiveDays + " days (button Archive).\r\n" +
                        "Deleting a job also archives its history for " + JobHistory.ArchiveDays + " days.";
                }
            }
        }

        private void ShowDetail()
        {
            if (_grid.SelectedItems.Count == 0) { _detail.Text = ""; return; }
            HistoryRun r = _grid.SelectedItems[0].Tag as HistoryRun;
            if (r == null) { _detail.Text = ""; return; }
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("Job:        " + r.Job);
            sb.AppendLine("Finished:   " + JobHistory.Fmt(r.Time));
            sb.AppendLine("Status:     " + r.Status + "   (started by: " + r.Source + ")");
            sb.AppendLine("Records:    " + r.Rows.ToString("N0"));
            sb.AppendLine("Took:       " + r.Elapsed);
            if (r.ElapsedMs > 0 && r.Rows > 0)
                sb.AppendLine("Speed:      " + ((long)(r.Rows / Math.Max(1.0, r.ElapsedMs / 1000.0))).ToString("N0") + " records/s");
            sb.AppendLine("Tables:     " + (r.Tables > 0 ? r.Tables.ToString() : "-"));
            if (!string.IsNullOrEmpty(r.TableList))
                sb.AppendLine("Transferred: " + r.TableList.Replace(" | ", "\r\n             "));
            sb.AppendLine();
            sb.AppendLine("Message:    " + r.Message);
            if (!string.IsNullOrEmpty(r.Detail))
            {
                sb.AppendLine();
                sb.AppendLine("================= statement by statement =================");
                sb.AppendLine(r.Detail);
            }
            _detail.Text = sb.ToString();
            _detail.SelectionStart = 0;
            _detail.ScrollToCaret();
        }

        private void ClearHistory()
        {
            // the job whose name was clicked, otherwise every ticked job
            List<string> sel;
            if (_focusJob != null) { sel = new List<string>(); sel.Add(_focusJob); }
            else sel = CheckedLogs();
            if (sel.Count == 0)
            {
                MessageBox.Show(this, "Click a job name, or tick at least one log on the left.",
                    _archiveMode ? "Delete from archive" : "Clear history");
                return;
            }
            string names = sel.Count <= 6 ? string.Join(", ", sel.ToArray()) : sel.Count + " logs";
            if (_archiveMode)
            {
                if (MessageBox.Show(this,
                    "Permanently delete from archive: " + names + " ?" + "\r\n" + "This cannot be undone.",
                    "Delete from archive", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                foreach (string n in sel) JobHistory.DeleteArchived(n);
                try { Audit.Write("HISTORY_ARCHIVE_DELETE", names); } catch { }
            }
            else
            {
                if (MessageBox.Show(this,
                    "Move history of: " + names + " to archive?" + "\r\n"
                    + "It stays in Archive for " + JobHistory.ArchiveDays + " days, then is removed automatically." + "\r\n"
                    + "You can open Archive and delete it sooner.",
                    "Clear history", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                foreach (string n in sel) JobHistory.Archive(n);
                try { JobHistory.PurgeArchive(); } catch { }
                try { Audit.Write("HISTORY_ARCHIVE", names); } catch { }
            }
            LoadLogList();
            Reload();
        }

        private void ToggleArchiveMode()
        {
            _archiveMode = !_archiveMode;
            _focusJob = null;
            try { JobHistory.PurgeArchive(); } catch { }
            if (_btnArchive != null)
                _btnArchive.Text = _archiveMode ? "Active history" : "Archive";
            Text = _archiveMode
                ? ("Job History — Archive (last " + JobHistory.ArchiveDays + " days)")
                : ("Job History (last " + JobHistory.KeepDays + " days)");
            LoadLogList();
            Reload();
        }

        private void StopRunningJob()
        {
            string job;
            lock (RunTrace.LiveLock) { job = RunTrace.LiveRunning ? RunTrace.LiveJob : null; }
            if (string.IsNullOrEmpty(job)) { MessageBox.Show(this, "No transfer is running.", "Stop"); return; }
            if (MessageBox.Show(this, "Stop the running job \"" + job + "\" ?", "Stop",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            bool done = false;
            if (_config != null && _config.Jobs != null)
                foreach (SyncJob j in _config.Jobs)
                    if (string.Equals(j.Name, job, StringComparison.CurrentCultureIgnoreCase) && Engine.IsRunning(j.Id))
                    { Engine.RequestStop(j.Id); done = true; }
            try { Audit.Write("JOB_STOP", job + " (from Job History)"); } catch { }
            _sticky = done
                ? Lang.T("Stop requested for") + " " + job + " ..."
                : Lang.T("Could not find the running job in the list.");
            _lblLive.Text = _sticky;
        }

        // ------------------------------------------------------------------ live status bar

        private void TickLive()
        {
            try
            {
                bool running;
                lock (RunTrace.LiveLock) { running = RunTrace.LiveRunning; }
                _btnStop.Enabled = running;

                if (running)
                {
                    string line = RunTrace.BuildStatusLine();
                    _lblLive.ForeColor = Color.FromArgb(160, 230, 255);   // status bar is dark
                    _lblLive.Text = string.IsNullOrEmpty(line) ? Lang.T("Transfer is starting ...") : line;
                    _wasRunning = true;
                    _sticky = null;
                }
                else
                {
                    _lblLive.ForeColor = Color.White;
                    if (_wasRunning)
                    {
                        // a run has just finished: the new row must show up straight away
                        _wasRunning = false;
                        LoadLogList();
                        Reload();
                        _sticky = Lang.T("Last transfer finished - the list is up to date.");
                    }
                    _lblLive.Text = _sticky != null ? _sticky : Lang.T("No transfer is running.");
                }
            }
            catch { }
        }
    }
}
