using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SyncDB
{
    /// <summary>Outbox / dead-letter manager: inspect, retry, delete, purge and open payloads.</summary>
    public class OutboxForm : Form
    {
        private readonly OutboxWorker _worker;
        private readonly AppConfig _cfg;
        private readonly ListView _list;
        private readonly ComboBox _filter;
        private readonly Label _summary;
        private readonly Timer _timer;

        public OutboxForm(OutboxWorker worker, AppConfig cfg)
        {
            _worker = worker;
            _cfg = cfg ?? new AppConfig();
            Text = "SyncDB — Outbox / Dead-letter queue";
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(1060, 600);
            MinimumSize = new Size(760, 420);
            ShowInTaskbar = false;

            Panel top = new Panel { Dock = DockStyle.Top, Height = 38, Padding = new Padding(8, 7, 8, 4) };
            Label lf = new Label { Text = "Status:", AutoSize = true, Location = new Point(8, 11) };
            _filter = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(58, 7),
                Width = 130
            };
            _filter.Items.AddRange(new object[] { "All", "Pending", "Failed", "Processing", "Dead", "Sent", "Skipped" });
            _filter.SelectedIndex = 0;
            _filter.SelectedIndexChanged += (s, e) => RefreshList();
            _summary = new Label { AutoSize = true, ForeColor = Theme.Muted, Location = new Point(204, 11) };
            top.Controls.Add(lf);
            top.Controls.Add(_filter);
            top.Controls.Add(_summary);

            _list = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                HideSelection = false,
                MultiSelect = true,
                Font = new Font("Segoe UI", 8.75f)
            };
            _list.Columns.Add("#", 50);
            _list.Columns.Add("Status", 100);
            _list.Columns.Add("Created", 132);
            _list.Columns.Add("Attempts", 64);
            _list.Columns.Add("Next attempt", 132);
            _list.Columns.Add("Job", 150);
            _list.Columns.Add("Step", 130);
            _list.Columns.Add("Transport", 90);
            _list.Columns.Add("Last error", 260);
            _list.DoubleClick += (s, e) => ShowDetails();
            _list.SelectedIndexChanged += (s, e) => UpdateButtons();

            FlowLayoutPanel bar = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 46,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(6, 7, 6, 4)
            };
            bar.Controls.Add(Button("Refresh", (s, e) => RefreshList()));
            bar.Controls.Add(Button("Retry selected", (s, e) => RetrySelected()));
            bar.Controls.Add(Button("Force replay…", (s, e) => ForceReplay()));
            bar.Controls.Add(Button("Retry all dead", (s, e) => RetryAllDead()));
            bar.Controls.Add(Button("Delete", (s, e) => DeleteSelected()));
            bar.Controls.Add(Button("Purge sent", (s, e) => PurgeSent()));
            bar.Controls.Add(Button("Details", (s, e) => ShowDetails()));
            bar.Controls.Add(Button("Open payload", (s, e) => OpenPayload()));
            bar.Controls.Add(Button("Process now", (s, e) => ProcessNow()));

            Controls.Add(_list);
            Controls.Add(bar);
            Controls.Add(top);

            _timer = new Timer { Interval = 5000 };
            _timer.Tick += (s, e) => RefreshList();
            _timer.Start();
            FormClosed += (s, e) => { try { _timer.Stop(); _timer.Dispose(); } catch { } };
            Theme.Apply(this);
            RefreshList();
        }

        private static Button Button(string text, EventHandler handler)
        {
            Button b = new Button { Text = text, AutoSize = true, Margin = new Padding(3, 3, 3, 3) };
            b.Click += handler;
            return b;
        }

        private void RefreshList()
        {
            try
            {
                // Use the index, not the caption: in Persian the ComboBox items are translated.
                string[] statuses = new string[] { "All", "Pending", "Failed", "Processing", "Dead", "Sent", "Skipped" };
                int idx = _filter.SelectedIndex;
                string status = idx >= 0 && idx < statuses.Length ? statuses[idx] : "All";
                List<OutboxStore.OutboxItem> rows = OutboxStore.ListByStatus(status, 2000);
                _list.BeginUpdate();
                try
                {
                    _list.Items.Clear();
                    foreach (OutboxStore.OutboxItem x in rows)
                    {
                        ListViewItem li = new ListViewItem(x.Id.ToString());
                        li.SubItems.Add(x.StatusText ?? "");
                        li.SubItems.Add(Local(x.CreatedUtc));
                        li.SubItems.Add(x.Attempts.ToString());
                        li.SubItems.Add(Local(x.NextAttemptUtc));
                        li.SubItems.Add(x.JobName ?? "");
                        li.SubItems.Add(x.StepName ?? "");
                        li.SubItems.Add((x.Kind ?? "") + " / " + (x.Transport ?? ""));
                        string error = (x.Status == "Dead" && !string.IsNullOrEmpty(x.DeadReason)) ? x.DeadReason : (x.LastError ?? "");
                        li.SubItems.Add(OneLine(error));
                        li.Tag = x;
                        if (x.Status == "Dead") li.ForeColor = Theme.Red;
                        else if (x.Status == "Sent") li.ForeColor = Theme.Green;
                        else if (x.Status == "Failed") li.ForeColor = Color.DarkOrange;
                        else if (x.Status == "Processing") li.ForeColor = Theme.Blue;
                        _list.Items.Add(li);
                    }
                }
                finally { _list.EndUpdate(); }

                OutboxStore.OutboxCounts c = OutboxStore.Counts();
                _summary.Text = "pending=" + c.Pending + "  failed=" + c.Failed + "  processing=" + c.Processing +
                                "  dead=" + c.Dead + "  sent=" + c.Sent + "  skipped=" + c.Skipped +
                                "   |   " + OutboxStore.DbPath;
                UpdateButtons();
            }
            catch (Exception ex)
            {
                _summary.Text = "Outbox error: " + ex.Message;
            }
        }

        private void UpdateButtons()
        {
            // Kept simple: all actions validate the selection themselves.
        }

        private List<OutboxStore.OutboxItem> Selected()
        {
            List<OutboxStore.OutboxItem> result = new List<OutboxStore.OutboxItem>();
            foreach (ListViewItem li in _list.SelectedItems)
            {
                OutboxStore.OutboxItem x = li.Tag as OutboxStore.OutboxItem;
                if (x != null) result.Add(x);
            }
            return result;
        }

        private void RetrySelected()
        {
            List<OutboxStore.OutboxItem> sel = Selected();
            if (sel.Count == 0) { MessageBox.Show("Select at least one outbox row.", "Outbox"); return; }
            if (MessageBox.Show("Retry " + sel.Count + " selected row(s) with attempts reset?", "Outbox",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            int n = 0;
            foreach (OutboxStore.OutboxItem x in sel)
                if (OutboxStore.Requeue(x.Id, true)) n++;
            Audit.Write("OUTBOX_RETRY", n + " selected row(s) retried");
            if (_worker != null) _worker.ProcessNow();
            RefreshList();
            MessageBox.Show(n + " row(s) queued for retry.", "Outbox");
        }

        private void ForceReplay()
        {
            List<OutboxStore.OutboxItem> sel = Selected();
            if (sel.Count == 0) { MessageBox.Show("Select one or more Local (SQL replay) rows.", "Outbox"); return; }
            foreach (OutboxStore.OutboxItem x in sel)
            {
                if (!string.Equals(x.Transport, "Local", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Force replay is only for Local/SQL-replay rows. Use Retry for HTTP rows.", "Outbox");
                    return;
                }
            }
            if (MessageBox.Show(
                "Force SQL replay of " + sel.Count + " item(s)?\r\n\r\n" +
                "This is normally blocked for Append mode because rows may already have been copied.\r\n" +
                "Only continue if you have checked the destination (or the destination is empty).",
                "Outbox — duplicate risk", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            int n = 0;
            foreach (OutboxStore.OutboxItem x in sel)
            {
                OutboxStore.SetReplaySafe(x.Id, true);
                if (OutboxStore.Requeue(x.Id, true)) n++;
            }
            Audit.Write("OUTBOX_FORCE_REPLAY", n + " Append item(s) forced; duplicate risk accepted");
            if (_worker != null) _worker.ProcessNow();
            RefreshList();
            MessageBox.Show(n + " item(s) forced to Pending.", "Outbox");
        }

        private void RetryAllDead()
        {
            int n = OutboxStore.RequeueDead(1000);
            if (_worker != null) _worker.ProcessNow();
            RefreshList();
            MessageBox.Show(n + " dead row(s) queued for retry.", "Outbox");
        }

        private void DeleteSelected()
        {
            List<OutboxStore.OutboxItem> sel = Selected();
            if (sel.Count == 0) { MessageBox.Show("Select at least one outbox row.", "Outbox"); return; }
            if (MessageBox.Show("Delete " + sel.Count + " selected row(s) and their payload files?\r\n" +
                "This cannot be undone.", "Outbox", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            int n = 0;
            foreach (OutboxStore.OutboxItem x in sel)
                if (OutboxStore.Delete(x.Id)) n++;
            Audit.Write("OUTBOX_DELETE", n + " row(s) deleted");
            RefreshList();
            MessageBox.Show(n + " row(s) deleted.", "Outbox");
        }

        private void PurgeSent()
        {
            int days = _cfg.OutboxSentRetentionDays > 0 ? _cfg.OutboxSentRetentionDays : 7;
            if (MessageBox.Show("Delete Sent/Skipped rows older than " + days + " day(s)?", "Outbox",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            int n = OutboxStore.PurgeCompleted(DateTime.UtcNow.AddDays(-days));
            Audit.Write("OUTBOX_PURGE", n + " completed row(s), older than " + days + " day(s)");
            RefreshList();
            MessageBox.Show(n + " completed row(s) purged.", "Outbox");
        }

        private void ProcessNow()
        {
            if (_worker == null || !_worker.IsRunning)
            {
                MessageBox.Show("Outbox worker is not running. Enable the local outbox and save settings.", "Outbox");
                return;
            }
            _worker.ProcessNow();
            _summary.Text = "Processing now…";
        }

        private void OpenPayload()
        {
            List<OutboxStore.OutboxItem> sel = Selected();
            if (sel.Count == 0) { MessageBox.Show("Select one row.", "Outbox"); return; }
            string path = sel[0].PayloadPath;
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                MessageBox.Show("No payload file for this row.\r\n\r\n" + (path ?? ""), "Outbox");
                return;
            }
            try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Outbox"); }
        }

        private void ShowDetails()
        {
            List<OutboxStore.OutboxItem> sel = Selected();
            if (sel.Count == 0) { MessageBox.Show("Select one row.", "Outbox"); return; }
            OutboxStore.OutboxItem x = sel[0];
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Outbox item #" + x.Id);
            sb.AppendLine("MessageId      : " + x.MessageId);
            sb.AppendLine("Kind           : " + x.Kind);
            sb.AppendLine("Status         : " + x.Status + "   attempts=" + x.Attempts);
            sb.AppendLine("Transport      : " + x.Transport + "   topic=" + x.TopicOrSubject);
            sb.AppendLine("Job            : " + x.JobName + "   [" + x.JobId + "]");
            sb.AppendLine("Step           : " + x.StepName + "   id=" + x.StepId);
            sb.AppendLine("Origin         : " + x.OriginId + "   target=" + x.TargetOriginId);
            sb.AppendLine("Created (UTC)  : " + Utc(x.CreatedUtc));
            sb.AppendLine("Next try (UTC) : " + Utc(x.NextAttemptUtc));
            sb.AppendLine("Completed (UTC): " + Utc(x.CompletedUtc));
            sb.AppendLine("Processing from: " + Utc(x.ProcessingStartedUtc));
            sb.AppendLine("Payload        : " + x.PayloadPath);
            if (!string.IsNullOrEmpty(x.DestinationUrl)) sb.AppendLine("Destination URL: " + x.DestinationUrl);
            if (!string.IsNullOrEmpty(x.HttpHeaders)) sb.AppendLine("HTTP headers   :\r\n" + x.HttpHeaders);
            sb.AppendLine();
            sb.AppendLine("Last error:");
            sb.AppendLine(x.LastError ?? "");
            if (!string.IsNullOrEmpty(x.DeadReason))
            {
                sb.AppendLine();
                sb.AppendLine("Dead reason:");
                sb.AppendLine(x.DeadReason);
            }
            if (!string.IsNullOrEmpty(x.PayloadPath) && File.Exists(x.PayloadPath))
            {
                sb.AppendLine();
                sb.AppendLine("Payload content:");
                try
                {
                    string body = File.ReadAllText(x.PayloadPath, Encoding.UTF8);
                    if (body.Length > 12000) body = body.Substring(0, 12000) + "\r\n... (truncated)";
                    sb.AppendLine(body);
                }
                catch (Exception ex) { sb.AppendLine("(cannot read: " + ex.Message + ")"); }
            }

            Form f = new Form
            {
                Text = "Outbox #" + x.Id + " — " + x.Status,
                StartPosition = FormStartPosition.CenterParent,
                Size = new Size(760, 600),
                MinimumSize = new Size(520, 400),
                ShowInTaskbar = false,
                Font = Font
            };
            TextBox box = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Both,
                WordWrap = false,
                Font = new Font("Consolas", 9f),
                Text = sb.ToString()
            };
            Button close = new Button { Text = "Close", Dock = DockStyle.Bottom, Height = 32 };
            close.Click += (s, e) => f.Close();
            f.Controls.Add(box);
            f.Controls.Add(close);
            Theme.Apply(f);
            f.ShowDialog(this);
        }

        private static string Local(DateTime? utc)
        {
            return utc.HasValue && utc.Value != DateTime.MinValue
                ? utc.Value.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss")
                : "";
        }

        private static string Utc(DateTime? utc)
        {
            return utc.HasValue && utc.Value != DateTime.MinValue
                ? utc.Value.ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")
                : "";
        }

        private static string OneLine(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            s = s.Replace("\r", " ").Replace("\n", " ");
            return s.Length > 300 ? s.Substring(0, 300) + "…" : s;
        }
    }
}
