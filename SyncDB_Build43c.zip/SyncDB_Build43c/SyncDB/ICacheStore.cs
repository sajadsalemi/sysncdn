using System;
using System.Collections.Generic;
using System.IO;
using LiteDB;

namespace SyncDB
{
    /// <summary>
    /// Lightweight local state for watermarks, row hashes, last success, and origin tracking.
    /// Backed by LiteDB (same stack as Outbox). Used by Delta / bidirectional sync / Outbox Worker.
    /// All methods are safe to call from multiple threads.
    /// </summary>
    public interface ICacheStore : IDisposable
    {
        long GetWatermark(string jobId, string table);
        void SetWatermark(string jobId, string table, long value, DateTime utc);

        string GetRowHash(string jobId, string table, string pk);
        void SetRowHash(string jobId, string table, string pk, string hash);
        int DeleteRowHashes(string jobId, string table);

        SyncStateInfo GetLastSuccess(string jobId);
        SyncStateInfo GetLastSuccess(string jobId, string table);
        void SetLastSuccess(string jobId, SyncStateInfo state);
        void SetLastSuccess(string jobId, string table, SyncStateInfo state);

        bool IsOriginLocal(string changeId);
        bool IsOriginLocal(string changeId, string originId);
        void MarkOrigin(string changeId, string originId, DateTime utc);
        void MarkOrigin(string changeId, string originId, string jobId, DateTime utc);

        void ClearJob(string jobId);

        /// <summary>Deletes old origin/hash records. Watermarks and last-success state are kept.</summary>
        int PurgeBefore(DateTime utc);
    }

    public class SyncStateInfo
    {
        public string JobId { get; set; }
        public string Table { get; set; }
        public DateTime LastSuccessUtc { get; set; }
        public string LastMessage { get; set; }
        public long RowsAffected { get; set; }
        public string Direction { get; set; } // Forward | Reverse | Both
        public string OriginId { get; set; }
    }

    /// <summary>LiteDB implementation. File: %APPDATA%\SyncDB\cache.db</summary>
    public sealed class LiteCacheStore : ICacheStore
    {
        private readonly LiteDatabase _db;
        private readonly string _path;
        private readonly object _gate = new object();
        private bool _disposed;

        private class WmDoc
        {
            public string Id { get; set; }          // jobId|table
            public string JobId { get; set; }
            public string Table { get; set; }
            public long Value { get; set; }
            public DateTime UpdatedUtc { get; set; }
        }

        private class HashDoc
        {
            public string Id { get; set; }          // jobId|table|pk
            public string JobId { get; set; }
            public string Table { get; set; }
            public string Pk { get; set; }
            public string Hash { get; set; }
            public DateTime UpdatedUtc { get; set; }
        }

        private class OriginDoc
        {
            public string Id { get; set; }          // changeId (MessageId)
            public string JobId { get; set; }
            public string OriginId { get; set; }
            public DateTime Utc { get; set; }
        }

        // This document has an explicit Id, so LiteDB can really Upsert/FindById it.
        // (Build 33 stored SyncStateInfo directly; it had no Id and GetLastSuccess always returned null.)
        private class StateDoc
        {
            public string Id { get; set; }          // jobId|table
            public string JobId { get; set; }
            public string Table { get; set; }
            public DateTime LastSuccessUtc { get; set; }
            public string LastMessage { get; set; }
            public long RowsAffected { get; set; }
            public string Direction { get; set; }
            public string OriginId { get; set; }
            public DateTime UpdatedUtc { get; set; }
        }

        public static string DbPath
        {
            get { return Path.Combine(AppConfig.DataDir, "cache.db"); }
        }

        public LiteCacheStore() : this(null) { }

        /// <summary>Optional path is used by the self-test; the app always uses <see cref="DbPath"/>.</summary>
        public LiteCacheStore(string path)
        {
            string file = string.IsNullOrWhiteSpace(path) ? DbPath : path;
            _path = file;
            string dir = Path.GetDirectoryName(file);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            _db = new LiteDatabase("Filename=" + file + ";Connection=shared");
            _db.GetCollection<WmDoc>("watermarks").EnsureIndex(x => x.JobId);
            _db.GetCollection<WmDoc>("watermarks").EnsureIndex(x => x.Table);
            _db.GetCollection<HashDoc>("row_hashes").EnsureIndex(x => x.JobId);
            _db.GetCollection<HashDoc>("row_hashes").EnsureIndex(x => x.Table);
            _db.GetCollection<StateDoc>("sync_state").EnsureIndex(x => x.JobId);
            _db.GetCollection<OriginDoc>("origins").EnsureIndex(x => x.JobId);
            _db.GetCollection<OriginDoc>("origins").EnsureIndex(x => x.Utc);
        }

        private void Check()
        {
            if (_disposed) throw new ObjectDisposedException("LiteCacheStore");
        }

        private static string Key(params string[] parts)
        {
            return string.Join("|", parts);
        }

        public long GetWatermark(string jobId, string table)
        {
            lock (_gate)
            {
                Check();
                var col = _db.GetCollection<WmDoc>("watermarks");
                var d = col.FindById(Key(jobId ?? "", table ?? ""));
                return d != null ? d.Value : 0L;
            }
        }

        public void SetWatermark(string jobId, string table, long value, DateTime utc)
        {
            lock (_gate)
            {
                Check();
                var col = _db.GetCollection<WmDoc>("watermarks");
                col.Upsert(new WmDoc
                {
                    Id = Key(jobId ?? "", table ?? ""),
                    JobId = jobId ?? "",
                    Table = table ?? "",
                    Value = value,
                    UpdatedUtc = utc.ToUniversalTime()
                });
            }
        }

        public string GetRowHash(string jobId, string table, string pk)
        {
            lock (_gate)
            {
                Check();
                var col = _db.GetCollection<HashDoc>("row_hashes");
                var d = col.FindById(Key(jobId ?? "", table ?? "", pk ?? ""));
                return d != null ? d.Hash : null;
            }
        }

        public void SetRowHash(string jobId, string table, string pk, string hash)
        {
            lock (_gate)
            {
                Check();
                var col = _db.GetCollection<HashDoc>("row_hashes");
                col.Upsert(new HashDoc
                {
                    Id = Key(jobId ?? "", table ?? "", pk ?? ""),
                    JobId = jobId ?? "",
                    Table = table ?? "",
                    Pk = pk ?? "",
                    Hash = hash ?? "",
                    UpdatedUtc = DateTime.UtcNow
                });
            }
        }

        public int DeleteRowHashes(string jobId, string table)
        {
            lock (_gate)
            {
                Check();
                var col = _db.GetCollection<HashDoc>("row_hashes");
                if (string.IsNullOrEmpty(table))
                    return col.DeleteMany(x => x.JobId == jobId);
                return col.DeleteMany(x => x.JobId == jobId && x.Table == table);
            }
        }

        public SyncStateInfo GetLastSuccess(string jobId)
        {
            lock (_gate)
            {
                Check();
                string jid = jobId ?? "";
                var col = _db.GetCollection<StateDoc>("sync_state");
                var all = col.Query().Where(x => x.JobId == jid).ToList();
                StateDoc best = null;
                foreach (StateDoc d in all)
                    if (best == null || d.LastSuccessUtc.ToUniversalTime() > best.LastSuccessUtc.ToUniversalTime()) best = d;
                return ToInfo(best);
            }
        }

        public SyncStateInfo GetLastSuccess(string jobId, string table)
        {
            lock (_gate)
            {
                Check();
                var col = _db.GetCollection<StateDoc>("sync_state");
                return ToInfo(col.FindById(Key(jobId ?? "", table ?? "")));
            }
        }

        public void SetLastSuccess(string jobId, SyncStateInfo state)
        {
            SetLastSuccess(jobId, state != null ? state.Table : null, state);
        }

        public void SetLastSuccess(string jobId, string table, SyncStateInfo state)
        {
            if (state == null) return;
            string jid = jobId ?? "";
            string tbl = table ?? state.Table ?? "";
            lock (_gate)
            {
                Check();
                DateTime utc = state.LastSuccessUtc == default(DateTime) ? DateTime.UtcNow : state.LastSuccessUtc.ToUniversalTime();
                var col = _db.GetCollection<StateDoc>("sync_state");
                col.Upsert(new StateDoc
                {
                    Id = Key(jid, tbl),
                    JobId = jid,
                    Table = tbl,
                    LastSuccessUtc = utc,
                    LastMessage = state.LastMessage ?? "",
                    RowsAffected = state.RowsAffected,
                    Direction = state.Direction ?? "",
                    OriginId = state.OriginId ?? "",
                    UpdatedUtc = DateTime.UtcNow
                });
                state.JobId = jid;
                state.Table = tbl;
                state.LastSuccessUtc = utc;
            }
        }

        private static SyncStateInfo ToInfo(StateDoc d)
        {
            if (d == null) return null;
            return new SyncStateInfo
            {
                JobId = d.JobId,
                Table = d.Table,
                LastSuccessUtc = d.LastSuccessUtc.ToUniversalTime(),
                LastMessage = d.LastMessage,
                RowsAffected = d.RowsAffected,
                Direction = d.Direction,
                OriginId = d.OriginId
            };
        }

        public bool IsOriginLocal(string changeId)
        {
            if (string.IsNullOrEmpty(changeId)) return false;
            lock (_gate)
            {
                Check();
                return _db.GetCollection<OriginDoc>("origins").FindById(changeId) != null;
            }
        }

        public bool IsOriginLocal(string changeId, string originId)
        {
            if (string.IsNullOrEmpty(changeId)) return false;
            lock (_gate)
            {
                Check();
                OriginDoc d = _db.GetCollection<OriginDoc>("origins").FindById(changeId);
                return d != null && string.Equals(d.OriginId ?? "", originId ?? "", StringComparison.OrdinalIgnoreCase);
            }
        }

        public void MarkOrigin(string changeId, string originId, DateTime utc)
        {
            MarkOrigin(changeId, originId, "", utc);
        }

        public void MarkOrigin(string changeId, string originId, string jobId, DateTime utc)
        {
            if (string.IsNullOrEmpty(changeId)) return;
            lock (_gate)
            {
                Check();
                _db.GetCollection<OriginDoc>("origins").Upsert(new OriginDoc
                {
                    Id = changeId,
                    JobId = jobId ?? "",
                    OriginId = originId ?? "",
                    Utc = utc.ToUniversalTime()
                });
            }
        }

        public void ClearJob(string jobId)
        {
            if (string.IsNullOrEmpty(jobId)) return;
            lock (_gate)
            {
                Check();
                _db.GetCollection<WmDoc>("watermarks").DeleteMany(x => x.JobId == jobId);
                _db.GetCollection<HashDoc>("row_hashes").DeleteMany(x => x.JobId == jobId);
                _db.GetCollection<StateDoc>("sync_state").DeleteMany(x => x.JobId == jobId);
                _db.GetCollection<OriginDoc>("origins").DeleteMany(x => x.JobId == jobId);
            }
        }

        public int PurgeBefore(DateTime utc)
        {
            DateTime cutoff = utc.ToUniversalTime();
            lock (_gate)
            {
                Check();
                int n = 0;
                // Normalize before comparing (LiteDB 4 returns Local-kind DateTimes).
                var origins = _db.GetCollection<OriginDoc>("origins");
                List<OriginDoc> oldOrigins = new List<OriginDoc>(origins.FindAll());
                foreach (OriginDoc d in oldOrigins)
                    if (d.Utc.ToUniversalTime() < cutoff && origins.Delete(d.Id)) n++;
                var hashes = _db.GetCollection<HashDoc>("row_hashes");
                List<HashDoc> oldHashes = new List<HashDoc>(hashes.FindAll());
                foreach (HashDoc d in oldHashes)
                    if (d.UpdatedUtc.ToUniversalTime() < cutoff && hashes.Delete(d.Id)) n++;
                return n;
            }
        }

        /// <summary>
        /// Merges the write-ahead log into cache.db. Deleting documents does NOT shrink a LiteDB file and
        /// the "-log.db" side file keeps growing until a checkpoint, so this runs on every cleanup pass.
        /// </summary>
        public long Checkpoint()
        {
            lock (_gate)
            {
                if (_disposed) return 0;
                long before = LogBytes();
                try { _db.Checkpoint(); }
                catch { return 0; }
                long after = LogBytes();
                return before > after ? before - after : 0;
            }
        }

        /// <summary>Rebuilds cache.db so the space of purged row hashes / origin marks is really released.</summary>
        public long Compact()
        {
            lock (_gate)
            {
                if (_disposed) return 0;
                long before = FileBytes() + LogBytes();
                try
                {
                    _db.Checkpoint();
                    _db.Rebuild(null);
                }
                catch (Exception ex)
                {
                    AppLog.Warn("-", "cache.db rebuild skipped: " + ex.Message);
                    return 0;
                }
                long after = FileBytes() + LogBytes();
                return before > after ? before - after : 0;
            }
        }

        private long FileBytes()
        {
            try { return File.Exists(_path) ? new FileInfo(_path).Length : 0; }
            catch { return 0; }
        }

        private long LogBytes()
        {
            try
            {
                string log = Path.Combine(Path.GetDirectoryName(_path) ?? "",
                    Path.GetFileNameWithoutExtension(_path) + "-log" + Path.GetExtension(_path));
                return File.Exists(log) ? new FileInfo(log).Length : 0;
            }
            catch { return 0; }
        }

        public void Dispose()
        {
            lock (_gate)
            {
                if (_disposed) return;
                _disposed = true;
                try { _db.Dispose(); } catch { }
            }
        }
    }

    /// <summary>Used when the user disables the local cache. Keeps call sites simple and allocation-free.</summary>
    public sealed class NullCacheStore : ICacheStore
    {
        public long GetWatermark(string jobId, string table) { return 0; }
        public void SetWatermark(string jobId, string table, long value, DateTime utc) { }
        public string GetRowHash(string jobId, string table, string pk) { return null; }
        public void SetRowHash(string jobId, string table, string pk, string hash) { }
        public int DeleteRowHashes(string jobId, string table) { return 0; }
        public SyncStateInfo GetLastSuccess(string jobId) { return null; }
        public SyncStateInfo GetLastSuccess(string jobId, string table) { return null; }
        public void SetLastSuccess(string jobId, SyncStateInfo state) { }
        public void SetLastSuccess(string jobId, string table, SyncStateInfo state) { }
        public bool IsOriginLocal(string changeId) { return false; }
        public bool IsOriginLocal(string changeId, string originId) { return false; }
        public void MarkOrigin(string changeId, string originId, DateTime utc) { }
        public void MarkOrigin(string changeId, string originId, string jobId, DateTime utc) { }
        public void ClearJob(string jobId) { }
        public int PurgeBefore(DateTime utc) { return 0; }
        public void Dispose() { }
    }

    /// <summary>Single process-wide cache store, configured from AppConfig (only LiteDB is implemented).</summary>
    public static class CacheStoreFactory
    {
        private static ICacheStore _instance;
        private static bool _useLite = true;
        private static readonly object Gate = new object();

        /// <summary>Call after config load/save. LevelDB/FASTER flags are accepted but fall back to LiteDB.</summary>
        public static void Configure(AppConfig cfg)
        {
            bool lite = true;
            if (cfg != null)
            {
                lite = cfg.CacheUseLiteDb || cfg.CacheUseLevelDb || cfg.CacheUseFaster;
                if (!cfg.CacheUseLiteDb && (cfg.CacheUseLevelDb || cfg.CacheUseFaster))
                    AppLog.Warn("-", "Cache: LevelDB/FASTER providers are not bundled in this build; using LiteDB.");
            }
            lock (Gate)
            {
                if (_instance != null && lite != _useLite)
                {
                    try { _instance.Dispose(); } catch { }
                    _instance = null;
                }
                _useLite = lite;
            }
        }

        public static ICacheStore Current
        {
            get
            {
                lock (Gate)
                {
                    if (_instance == null)
                        _instance = _useLite ? (ICacheStore)new LiteCacheStore() : new NullCacheStore();
                    return _instance;
                }
            }
        }

        public static void Reset()
        {
            lock (Gate)
            {
                if (_instance != null)
                {
                    try { _instance.Dispose(); } catch { }
                    _instance = null;
                }
            }
        }
    }
}
