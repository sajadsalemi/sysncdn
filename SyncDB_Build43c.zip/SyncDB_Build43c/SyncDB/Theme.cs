﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace SyncDB
{
    /// <summary>UI skins: 6 presets. Colors are mutable so ApplyPreset can restyle the whole app.</summary>
    public static class Theme
    {
        public static Color Navy = Color.FromArgb(31, 58, 95);
        public static Color Blue = Color.FromArgb(47, 109, 181);
        public static Color Green = Color.FromArgb(46, 125, 91);
        public static Color Red = Color.FromArgb(179, 67, 59);
        public static Color Surface = Color.FromArgb(244, 246, 249);
        public static Color Border = Color.FromArgb(205, 212, 224);
        public static Color Text = Color.FromArgb(31, 41, 51);
        public static Color Muted = Color.FromArgb(107, 119, 133);

        public static Color RowDisabledBack = Color.FromArgb(250, 218, 214);
        public static Color RowDisabledText = Color.FromArgb(150, 35, 35);
        public static Color RowRunningBack = Color.FromArgb(255, 244, 205);
        public static Color RowOkBack = Color.FromArgb(200, 235, 210);
        public static Color RowOkText = Color.FromArgb(20, 90, 50);
        public static Color RowFailBack = Color.FromArgb(255, 240, 238);

        public static int CurrentId = 0;
        public static readonly string[] PresetNames = new string[] {
            "Navy (default)", "Ocean Teal", "Forest Green", "Graphite Dark", "Sunset Orange", "Royal Purple"
        };

        /// <summary>0..5 — restyle global palette then call Theme.Apply(root).</summary>
        public static void ApplyPreset(int id)
        {
            if (id < 0) id = 0;
            if (id > 5) id = 5;
            CurrentId = id;
            switch (id)
            {
                case 1: // Ocean Teal
                    Navy = Color.FromArgb(15, 76, 92); Blue = Color.FromArgb(0, 150, 168);
                    Green = Color.FromArgb(34, 140, 110); Red = Color.FromArgb(200, 80, 70);
                    Surface = Color.FromArgb(236, 247, 248); Border = Color.FromArgb(180, 210, 215);
                    Text = Color.FromArgb(20, 45, 52); Muted = Color.FromArgb(90, 120, 128);
                    break;
                case 2: // Forest
                    Navy = Color.FromArgb(27, 67, 50); Blue = Color.FromArgb(45, 122, 78);
                    Green = Color.FromArgb(56, 142, 90); Red = Color.FromArgb(170, 60, 55);
                    Surface = Color.FromArgb(240, 247, 242); Border = Color.FromArgb(190, 210, 195);
                    Text = Color.FromArgb(25, 40, 30); Muted = Color.FromArgb(95, 115, 100);
                    break;
                case 3: // Graphite Dark
                    Navy = Color.FromArgb(40, 44, 52); Blue = Color.FromArgb(70, 110, 180);
                    Green = Color.FromArgb(60, 140, 100); Red = Color.FromArgb(190, 75, 70);
                    Surface = Color.FromArgb(232, 234, 238); Border = Color.FromArgb(175, 180, 190);
                    Text = Color.FromArgb(28, 30, 36); Muted = Color.FromArgb(100, 105, 115);
                    break;
                case 4: // Sunset Orange
                    Navy = Color.FromArgb(120, 55, 30); Blue = Color.FromArgb(220, 110, 40);
                    Green = Color.FromArgb(80, 140, 70); Red = Color.FromArgb(190, 50, 45);
                    Surface = Color.FromArgb(252, 244, 236); Border = Color.FromArgb(230, 200, 175);
                    Text = Color.FromArgb(55, 35, 25); Muted = Color.FromArgb(130, 100, 80);
                    break;
                case 5: // Royal Purple
                    Navy = Color.FromArgb(55, 35, 90); Blue = Color.FromArgb(110, 70, 180);
                    Green = Color.FromArgb(50, 130, 100); Red = Color.FromArgb(175, 55, 80);
                    Surface = Color.FromArgb(245, 240, 250); Border = Color.FromArgb(205, 190, 220);
                    Text = Color.FromArgb(35, 25, 50); Muted = Color.FromArgb(110, 95, 130);
                    break;
                default: // Navy default
                    Navy = Color.FromArgb(31, 58, 95); Blue = Color.FromArgb(47, 109, 181);
                    Green = Color.FromArgb(46, 125, 91); Red = Color.FromArgb(179, 67, 59);
                    Surface = Color.FromArgb(244, 246, 249); Border = Color.FromArgb(205, 212, 224);
                    Text = Color.FromArgb(31, 41, 51); Muted = Color.FromArgb(107, 119, 133);
                    break;
            }
            RowDisabledBack = Color.FromArgb(250, 218, 214);
            RowDisabledText = Color.FromArgb(150, 35, 35);
            RowRunningBack = Color.FromArgb(255, 244, 205);
            RowOkBack = Color.FromArgb(200, 235, 210);
            RowOkText = Color.FromArgb(20, 90, 50);
            RowFailBack = Color.FromArgb(255, 240, 238);
        }

        private static Icon _appIcon;
        /// <summary>Built-in window icon (drawn in code, same design as app.ico): two databases + sync arrows on a navy tile.</summary>
        public static Icon AppIcon
        {
            get
            {
                if (_appIcon != null) return _appIcon;
                try   // use the icon embedded in SyncDB.exe (app.ico) - same quality as the file icon
                {
                    Icon ex = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                    if (ex != null) { _appIcon = ex; return _appIcon; }
                }
                catch { }
                using (Bitmap bmp = new Bitmap(256, 256))
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    g.Clear(Color.Transparent);
                    // Clean icon: two DB cylinders + sync arrows only (no outer frame/border)
                    DrawCylinderHi(g, 28, 40, 80, 160);
                    DrawCylinderHi(g, 148, 40, 80, 160);
                    // top green arrow  left -> right
                    using (SolidBrush gb = new SolidBrush(Color.FromArgb(40, 190, 80)))
                    {
                        g.FillRectangle(gb, 110, 88, 36, 18);
                        g.FillPolygon(gb, new Point[] { new Point(142, 70), new Point(180, 97), new Point(142, 124) });
                    }
                    // bottom amber arrow  right -> left
                    using (SolidBrush ab = new SolidBrush(Color.FromArgb(235, 160, 30)))
                    {
                        g.FillRectangle(ab, 110, 150, 36, 18);
                        g.FillPolygon(ab, new Point[] { new Point(114, 132), new Point(76, 159), new Point(114, 186) });
                    }
                    using (Bitmap small = new Bitmap(bmp, 64, 64))
                        _appIcon = Icon.FromHandle(small.GetHicon());
                }
                return _appIcon;
            }
        }

        private static void DrawCylinderHi(Graphics g, int x, int y, int w, int h)
        {
            // stacked disk database cylinder (white/light blue)
            Color body = Color.FromArgb(160, 200, 240);
            Color top = Color.FromArgb(220, 240, 255);
            Color rim = Color.FromArgb(50, 120, 190);
            int eh = Math.Max(10, h / 8);
            using (SolidBrush b = new SolidBrush(body))
            {
                g.FillRectangle(b, x, y + eh / 2, w, h - eh);
                g.FillEllipse(b, x, y + h - eh, w, eh);
            }
            using (SolidBrush t = new SolidBrush(top))
                g.FillEllipse(t, x, y, w, eh);
            using (Pen p = new Pen(rim, 2f))
            {
                g.DrawEllipse(p, x, y, w, eh);
                g.DrawArc(p, x, y + h / 3, w, eh, 0, 180);
                g.DrawArc(p, x, y + 2 * h / 3, w, eh, 0, 180);
                g.DrawArc(p, x, y + h - eh, w, eh, 0, 180);
            }
        }


        /// <summary>Navy menu bar with white text; highlighted hover like a modern toolbar.</summary>
        public class MenuRenderer : ToolStripProfessionalRenderer
        {
            public MenuRenderer() : base(new MenuColorTable())
            {
                RoundedEdges = false;
            }

            protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
            {
                if (e.ToolStrip is MenuStrip)
                {
                    // full navy bar
                    using (SolidBrush br = new SolidBrush(Navy))
                        e.Graphics.FillRectangle(br, e.AffectedBounds);
                    // clear white separator line under the menu (2px)
                    int y = e.AffectedBounds.Bottom - 2;
                    using (Pen p = new Pen(Color.White, 2f))
                        e.Graphics.DrawLine(p, e.AffectedBounds.Left, y, e.AffectedBounds.Right, y);
                    return;
                }
                base.OnRenderToolStripBackground(e);
            }

            protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
            {
                Rectangle rc = new Rectangle(Point.Empty, e.Item.Size);
                if (e.Item.Selected || e.Item.Pressed)
                {
                    using (SolidBrush br = new SolidBrush(Blue))
                        e.Graphics.FillRectangle(br, rc);
                }
                else if (e.Item.Owner is MenuStrip)
                {
                    using (SolidBrush br = new SolidBrush(Navy))
                        e.Graphics.FillRectangle(br, rc);
                }
                else
                    base.OnRenderMenuItemBackground(e);
            }

            protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
            {
                // Keep menu captions left-aligned (also when form is RTL / Persian)
                TextFormatFlags flags = TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPadding;
                if (e.Item.Owner is MenuStrip)
                {
                    TextRenderer.DrawText(e.Graphics, e.Text, e.TextFont, e.TextRectangle, Color.White, flags);
                    return;
                }
                if (e.Item.Selected)
                {
                    flags = TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.HidePrefix;
                    TextRenderer.DrawText(e.Graphics, e.Text, e.TextFont, e.TextRectangle, Color.White, flags);
                    return;
                }
                base.OnRenderItemText(e);
            }

            protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
            {
                // border drawn in background (white line)
            }
        }

        private class MenuColorTable : ProfessionalColorTable
        {
            public override Color MenuStripGradientBegin { get { return Navy; } }
            public override Color MenuStripGradientEnd { get { return Navy; } }
            public override Color MenuItemSelected { get { return Blue; } }
            public override Color MenuItemSelectedGradientBegin { get { return Blue; } }
            public override Color MenuItemSelectedGradientEnd { get { return Blue; } }
            public override Color MenuItemBorder { get { return Blue; } }
            public override Color MenuBorder { get { return Navy; } }
            public override Color ImageMarginGradientBegin { get { return Color.White; } }
            public override Color ImageMarginGradientMiddle { get { return Color.White; } }
            public override Color ImageMarginGradientEnd { get { return Color.White; } }
            public override Color ToolStripDropDownBackground { get { return Color.White; } }
            public override Color MenuItemPressedGradientBegin { get { return Blue; } }
            public override Color MenuItemPressedGradientEnd { get { return Blue; } }
        }

        private static readonly Dictionary<Button, Color[]> _btn = new Dictionary<Button, Color[]>();

        public static void Apply(Control root)
        {
            Lang.Apply(root);          // translate captions + right-to-left when Persian is selected
            Form fm = root as Form;
            if (fm != null)
            {
                root.BackColor = Surface; try { fm.Icon = AppIcon; } catch { }
                // never taller / wider than the screen (buttons at the bottom must stay visible)
                fm.Shown += (s2, e2) =>
                {
                    try
                    {
                        Rectangle wa = Screen.FromControl(fm).WorkingArea;
                        int w = Math.Min(fm.Width, wa.Width), h = Math.Min(fm.Height, wa.Height);
                        if (w != fm.Width || h != fm.Height) fm.Size = new Size(w, h);
                        int x = Math.Max(wa.Left, Math.Min(fm.Left, wa.Right - fm.Width));
                        int y = Math.Max(wa.Top, Math.Min(fm.Top, wa.Bottom - fm.Height));
                        if (x != fm.Left || y != fm.Top) fm.Location = new Point(x, y);
                    }
                    catch { }
                };
            }
            Walk(root);
        }

        private static void Walk(Control c)
        {
            ApplyOne(c);
            foreach (Control ch in c.Controls) Walk(ch);
        }

        private static void ApplyOne(Control c)
        {
            Button b = c as Button;
            if (b != null) { StyleButton(b); return; }

            TabPage tp = c as TabPage;
            if (tp != null) { tp.UseVisualStyleBackColor = false; tp.BackColor = Surface; return; }

            ListView lv = c as ListView;
            if (lv != null) { StyleList(lv); return; }

            DataGridView g = c as DataGridView;
            if (g != null) { StyleGrid(g); return; }

            MenuStrip ms = c as MenuStrip;
            if (ms != null)
            {
                ms.BackColor = Navy;
                ms.ForeColor = Color.White;
                if (!(ms.Renderer is MenuRenderer)) ms.Renderer = new MenuRenderer();
                foreach (ToolStripItem it in ms.Items) it.ForeColor = Color.White;
                return;
            }

            StatusStrip ss = c as StatusStrip;
            if (ss != null)
            {
                ss.BackColor = Navy;
                ss.SizingGrip = false;
                foreach (ToolStripItem it in ss.Items) it.ForeColor = Color.White;
                return;
            }

            Label l = c as Label;
            if (l != null && l.Font.Bold && l.ForeColor == SystemColors.ControlText) l.ForeColor = Navy;
        }

        // ---------------- buttons ----------------
        private static void StyleButton(Button b)
        {
            if (_btn.ContainsKey(b)) return;
            Color bc = b.BackColor;
            bool custom = bc != SystemColors.Control && bc != Color.Transparent && !bc.IsEmpty;
            Color back, fore, border;
            if (custom)
            {
                if (bc.G > bc.R + 15 && bc.G >= bc.B) back = Green;
                else if (bc.R > bc.G + 40 && bc.R > bc.B + 40) back = Red;
                else if (bc.B > bc.R) back = Blue;
                else back = bc;
                fore = Color.White; border = back;
            }
            else { back = Color.White; fore = Text; border = Border; }

            b.UseVisualStyleBackColor = false;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 1;
            b.Cursor = Cursors.Hand;
            b.MinimumSize = new Size(0, 30);
            if (b.AutoSize) { b.AutoSizeMode = AutoSizeMode.GrowAndShrink; b.Padding = new Padding(8, 2, 8, 2); }
            b.FlatAppearance.MouseOverBackColor = custom ? Shade(back, 0.12f) : Color.FromArgb(232, 238, 247);
            b.FlatAppearance.MouseDownBackColor = custom ? Shade(back, -0.12f) : Color.FromArgb(214, 224, 240);

            _btn[b] = new Color[] { back, fore, border };
            Paint(b);
            b.EnabledChanged += (s, e) => Paint((Button)s);
            b.Disposed += (s, e) => _btn.Remove((Button)s);
        }

        private static void Paint(Button b)
        {
            Color[] c;
            if (!_btn.TryGetValue(b, out c)) return;
            if (b.Enabled)
            {
                b.BackColor = c[0]; b.ForeColor = c[1]; b.FlatAppearance.BorderColor = c[2];
            }
            else
            {
                b.BackColor = Color.FromArgb(228, 232, 239);
                b.ForeColor = Color.FromArgb(150, 158, 170);
                b.FlatAppearance.BorderColor = Border;
            }
        }

        private static Color Shade(Color c, float f)
        {
            Func<int, int> adj = v => Math.Max(0, Math.Min(255, f >= 0 ? (int)(v + (255 - v) * f) : (int)(v * (1 + f))));
            return Color.FromArgb(adj(c.R), adj(c.G), adj(c.B));
        }

        // ---------------- list view ----------------
        private static void StyleList(ListView lv)
        {
            if (lv.View != View.Details) return;
            lv.BorderStyle = BorderStyle.FixedSingle;
            lv.Font = new Font("Segoe UI", 9.5f);
            if (lv.SmallImageList == null)
            {
                ImageList il = new ImageList();
                il.ImageSize = new Size(1, 26);          // taller rows
                lv.SmallImageList = il;
            }
            lv.OwnerDraw = true;
            lv.DrawColumnHeader += (s, e) =>
            {
                using (SolidBrush br = new SolidBrush(Navy)) e.Graphics.FillRectangle(br, e.Bounds);
                using (Pen p = new Pen(Color.FromArgb(70, 100, 145))) e.Graphics.DrawLine(p, e.Bounds.Right - 1, e.Bounds.Top + 4, e.Bounds.Right - 1, e.Bounds.Bottom - 4);
                using (Font f = new Font("Segoe UI", 9.5f, FontStyle.Bold))
                    TextRenderer.DrawText(e.Graphics, e.Header.Text, f, Rectangle.Inflate(e.Bounds, -8, 0), Color.White,
                        TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
            };
            lv.DrawItem += (s, e) => { };
            lv.DrawSubItem += (s, e) =>
            {
                if (!lv.CheckBoxes) { e.DrawDefault = true; return; }
                bool sel = e.Item.Selected;
                Color back = sel ? Blue : e.SubItem.BackColor;
                Color fore = sel ? Color.White : e.SubItem.ForeColor;
                using (SolidBrush br = new SolidBrush(back)) e.Graphics.FillRectangle(br, e.Bounds);
                Rectangle tb = e.Bounds;
                if (e.ColumnIndex == 0)
                {
                    CheckBoxState cst = e.Item.Checked ? CheckBoxState.CheckedNormal : CheckBoxState.UncheckedNormal;
                    Size cs = CheckBoxRenderer.GetGlyphSize(e.Graphics, cst);
                    CheckBoxRenderer.DrawCheckBox(e.Graphics, new Point(e.Bounds.Left + 4, e.Bounds.Top + (e.Bounds.Height - cs.Height) / 2), cst);
                    tb = new Rectangle(e.Bounds.Left + 24, e.Bounds.Top, Math.Max(0, e.Bounds.Width - 24), e.Bounds.Height);
                }
                TextRenderer.DrawText(e.Graphics, e.SubItem.Text, lv.Font, Rectangle.Inflate(tb, -3, 0), fore,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
            };
        }

        // ---------------- data grid ----------------
        private static void StyleGrid(DataGridView g)
        {
            g.EnableHeadersVisualStyles = false;
            g.BorderStyle = BorderStyle.None;
            g.BackgroundColor = Color.White;
            g.GridColor = Border;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            g.ColumnHeadersHeight = 32;
            g.ColumnHeadersDefaultCellStyle.BackColor = Navy;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = Navy;
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            g.ColumnHeadersDefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            g.DefaultCellStyle.Font = new Font("Segoe UI", 9.5f);
            g.DefaultCellStyle.SelectionBackColor = Blue;
            g.DefaultCellStyle.SelectionForeColor = Color.White;
            g.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(246, 248, 252);
            g.RowTemplate.Height = 26;
        }
    }
}
