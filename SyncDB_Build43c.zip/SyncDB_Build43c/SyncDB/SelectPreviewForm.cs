﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SyncDB
{
    /// <summary>Run a read-only SELECT on a connection and view the result grid (preview / export).</summary>
    public class SelectPreviewForm : Form
    {
        private static readonly Regex Forbidden = new Regex(
            @"\b(INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER|CREATE|EXEC|EXECUTE|MERGE|GRANT|REVOKE|DENY|SHUTDOWN|BACKUP|RESTORE|INTO)\b",
            RegexOptions.IgnoreCase);

        private readonly string connStr;
        private readonly List<string[]> objs;
        private readonly bool startPreview;

        private TabControl tabs;
        private TabPage pPrev, pGen;
        private ComboBox cbObj;
        private NumericUpDown numTop;
        private TextBox txtSql;
        private DataGridView grid;
        private Label lblInfo;
        private Button btnRun, btnCancel, btnCsv;
        private SplitContainer split;
        private volatile SqlCommand current;
        private volatile bool cancelRequested;
        private DataTable lastTable;
        private string lastAuto = "";
        private bool suppress;

        public SelectPreviewForm(string connName, string cs, string generatedSql, List<string[]> objects, bool preview)
        {
            connStr = cs;
            objs = objects ?? new List<string[]>();
            startPreview = preview;

            Text = "Select / Preview — " + connName;
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(1020, 700);
            MinimumSize = new Size(760, 480);
            ShowInTaskbar = false;
            KeyPreview = true;
            KeyDown += (s, e) => { if (e.KeyCode == Keys.F5 || (e.Control && e.KeyCode == Keys.Enter)) { e.Handled = true; RunQuery(); } };

            tabs = new TabControl { Dock = DockStyle.Fill };
            pPrev = new TabPage("Preview / Run SELECT");
            pGen = new TabPage("Generated SQL (linked-server style)");

            // ---- generated tab ----
            TextBox gen = new TextBox
            {
                Dock = DockStyle.Fill, Multiline = true, ScrollBars = ScrollBars.Both, WordWrap = false,
                Font = new Font("Consolas", 10f), Text = generatedSql ?? ""
            };
            Button copy = new Button { Text = "Copy to clipboard", Dock = DockStyle.Bottom, Height = 36 };
            copy.Click += (s, e) => { try { Clipboard.SetText(gen.Text); lblInfo.Text = "Copied."; } catch { } };
            pGen.Controls.Add(gen);
            pGen.Controls.Add(copy);

            // ---- preview tab ----
            FlowLayoutPanel bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 46, WrapContents = false, Padding = new Padding(4, 6, 4, 0) };
            bar.Controls.Add(new Label { Text = "Object:", AutoSize = true, Margin = new Padding(3, 8, 4, 0) });
            cbObj = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 330 };
            foreach (string[] o in objs) cbObj.Items.Add(o[0] + "." + o[1]);
            bar.Controls.Add(cbObj);
            bar.Controls.Add(new Label { Text = "Rows:", AutoSize = true, Margin = new Padding(10, 8, 4, 0) });
            numTop = new NumericUpDown { Minimum = 1, Maximum = 100000, Value = 100, Width = 80, Margin = new Padding(3, 4, 3, 0) };
            bar.Controls.Add(numTop);
            btnRun = new Button { Text = "▶ Run (F5)", AutoSize = true, BackColor = Color.FromArgb(30, 120, 60), ForeColor = Color.White };
            btnCancel = new Button { Text = "■ Cancel", AutoSize = true, BackColor = Color.FromArgb(160, 50, 40), ForeColor = Color.White, Enabled = false };
            btnCsv = new Button { Text = "Export CSV", AutoSize = true };
            btnRun.Click += (s, e) => RunQuery();
            btnCancel.Click += (s, e) => { cancelRequested = true; SqlCommand c = current; if (c != null) { try { c.Cancel(); } catch { } } };
            btnCsv.Click += (s, e) => ExportCsv();
            bar.Controls.Add(btnRun);
            bar.Controls.Add(btnCancel);
            bar.Controls.Add(btnCsv);

            split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, Panel1MinSize = 60, Panel2MinSize = 120 };
            txtSql = new TextBox
            {
                Dock = DockStyle.Fill, Multiline = true, ScrollBars = ScrollBars.Both, WordWrap = false,
                AcceptsReturn = true, AcceptsTab = true, Font = new Font("Consolas", 10f)
            };
            split.Panel1.Controls.Add(txtSql);

            grid = new DataGridView
            {
                Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
                RowHeadersVisible = false, AutoGenerateColumns = true
            };
            grid.DefaultCellStyle.NullValue = "NULL";
            grid.DataError += (s, e) => { e.ThrowException = false; };
            lblInfo = new Label { Dock = DockStyle.Bottom, Height = 26, Padding = new Padding(6, 5, 0, 0), ForeColor = Theme.Muted, Text = "Read-only: only SELECT / WITH queries can be run here." };
            split.Panel2.Controls.Add(grid);
            split.Panel2.Controls.Add(lblInfo);

            pPrev.Controls.Add(split);
            pPrev.Controls.Add(bar);

            tabs.TabPages.Add(pPrev);
            tabs.TabPages.Add(pGen);
            Controls.Add(tabs);

            cbObj.SelectedIndexChanged += (s, e) => { if (!suppress) RebuildAuto(true); };
            numTop.ValueChanged += (s, e) => { if (!suppress) RebuildAuto(false); };

            suppress = true;
            if (cbObj.Items.Count > 0) cbObj.SelectedIndex = 0;
            suppress = false;
            RebuildAuto(true);

            Theme.Apply(this);

            Load += (s, e) =>
            {
                try { split.SplitterDistance = 130; } catch { }
                tabs.SelectedTab = startPreview ? pPrev : pGen;
            };
            Shown += async (s, e) =>
            {
                if (startPreview && objs.Count > 0) await RunQueryAsync();
            };
        }

        private void RebuildAuto(bool force)
        {
            if (cbObj.SelectedIndex < 0) return;
            if (!force && txtSql.Text != lastAuto && txtSql.Text.Trim().Length > 0) return;   // user edited the query
            string[] o = objs[cbObj.SelectedIndex];
            lastAuto = "SELECT TOP (" + (int)numTop.Value + ") * FROM [" + o[0].Replace("]", "]]") + "].[" + o[1].Replace("]", "]]") + "];";
            txtSql.Text = lastAuto;
        }

        private static string Validate(string sql)
        {
            string t = Regex.Replace(sql, @"--.*?$", "", RegexOptions.Multiline);
            t = Regex.Replace(t, @"/\*.*?\*/", "", RegexOptions.Singleline).Trim();
            if (!(t.StartsWith("SELECT", StringComparison.OrdinalIgnoreCase) || t.StartsWith("WITH", StringComparison.OrdinalIgnoreCase)))
                return "Only SELECT queries are allowed here (read-only preview).";
            string noStr = Regex.Replace(t, @"'(?:[^']|'')*'", "''");
            Match m = Forbidden.Match(noStr);
            if (m.Success) return "Not allowed in the read-only preview: " + m.Value.ToUpperInvariant();
            return null;
        }

        private async void RunQuery() { await RunQueryAsync(); }

        private async Task RunQueryAsync()
        {
            if (!btnRun.Enabled) return;
            string sql = (txtSql.Text ?? "").Trim();
            if (sql.Length == 0) return;
            string err = Validate(sql);
            if (err != null) { MessageBox.Show(err, "SELECT", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (string.IsNullOrWhiteSpace(connStr)) { MessageBox.Show("Connection string is empty.", "SELECT"); return; }

            int limit = (int)numTop.Value;
            Audit.Write("SELECT_PREVIEW", Text + " | " + sql);
            cancelRequested = false;
            btnRun.Enabled = false; btnCancel.Enabled = true; btnCsv.Enabled = false;
            lblInfo.Text = "Running…";
            Stopwatch sw = Stopwatch.StartNew();
            try
            {
                DataTable dt = await Task.Run(() => Fetch(sql, limit + 1));
                sw.Stop();
                bool trunc = dt.Rows.Count > limit;
                while (dt.Rows.Count > limit) dt.Rows.RemoveAt(dt.Rows.Count - 1);
                lastTable = dt;
                grid.DataSource = dt;
                grid.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.DisplayedCells);
                foreach (DataGridViewColumn c in grid.Columns) if (c.Width > 320) c.Width = 320;
                lblInfo.Text = dt.Rows.Count + " row(s)" + (trunc ? " (limited to " + limit + ")" : "") +
                               "  ·  " + dt.Columns.Count + " column(s)  ·  " + JobHistory.FormatSeconds(sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                if (cancelRequested) lblInfo.Text = "Cancelled.";
                else
                {
                    lblInfo.Text = "Error: " + ex.Message;
                    MessageBox.Show(ex.Message, "SELECT error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            finally
            {
                current = null;
                btnRun.Enabled = true; btnCancel.Enabled = false; btnCsv.Enabled = true;
            }
        }

        private DataTable Fetch(string sql, int max)
        {
            DataTable dt = new DataTable();
            using (SqlConnection c = new SqlConnection(connStr))
            {
                c.Open();
                using (SqlCommand cmd = new SqlCommand(sql, c))
                {
                    cmd.CommandTimeout = 120;
                    current = cmd;
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        int fc = rd.FieldCount;
                        HashSet<string> used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                        for (int i = 0; i < fc; i++)
                        {
                            string name = rd.GetName(i);
                            if (string.IsNullOrEmpty(name)) name = "Column" + (i + 1);
                            string u = name; int k = 1;
                            while (!used.Add(u)) u = name + "_" + (++k);
                            Type t;
                            try { t = rd.GetFieldType(i); } catch { t = typeof(object); }
                            if (t == null) t = typeof(object);
                            dt.Columns.Add(u, t);
                        }
                        object[] vals = new object[fc];
                        int n = 0;
                        dt.BeginLoadData();
                        while (n < max && rd.Read())
                        {
                            rd.GetValues(vals);
                            dt.LoadDataRow(vals, true);
                            n++;
                        }
                        dt.EndLoadData();
                        if (n >= max) { try { cmd.Cancel(); } catch { } }   // don't drain the rest of a huge result
                    }
                }
            }
            return dt;
        }

        private void ExportCsv()
        {
            if (lastTable == null || lastTable.Rows.Count == 0) { MessageBox.Show("Nothing to export. Run a SELECT first."); return; }
            using (SaveFileDialog sf = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = "select_result.csv" })
            {
                if (sf.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < lastTable.Columns.Count; i++)
                    { if (i > 0) sb.Append(','); sb.Append(Csv(lastTable.Columns[i].ColumnName)); }
                    sb.AppendLine();
                    foreach (DataRow r in lastTable.Rows)
                    {
                        for (int i = 0; i < lastTable.Columns.Count; i++)
                        {
                            if (i > 0) sb.Append(',');
                            object v = r[i];
                            sb.Append(v == null || v == DBNull.Value ? "" : Csv(Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture)));
                        }
                        sb.AppendLine();
                    }
                    File.WriteAllText(sf.FileName, sb.ToString(), new UTF8Encoding(true));
                    lblInfo.Text = "Exported: " + sf.FileName;
                    Audit.Write("CSV_EXPORT", Text + " | rows=" + lastTable.Rows.Count + " | file=" + sf.FileName);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "Export"); }
            }
        }

        private static string Csv(string s)
        {
            if (s == null) return "";
            if (s.IndexOfAny(new char[] { ',', '"', '\r', '\n' }) >= 0) return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }
    }
}
