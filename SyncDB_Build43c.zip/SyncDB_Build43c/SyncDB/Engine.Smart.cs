﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SyncDB
{
    // NOTE: Engine.cs must be changed to "public static partial class Engine"
    public static partial class Engine
    {
        // =====================================================================
        //  1) Linked-server bypass: SELECT..INTO  AND  [DELETE..;] INSERT INTO .. SELECT .. FROM [srv].[db].[sch].[tbl]
        // =====================================================================

        private static readonly Regex LinkedInsertSelect = new Regex(
            @"^\s*(?<pre>[\s\S]*?;\s*)??INSERT\s+INTO\s+(?<dest>[\w\[\]\.]+)\s*(\((?<dcols>[^)]*)\))?\s*SELECT\s+(?<cols>.+?)\s+FROM\s+\[(?<srv>[^\]]+)\]\s*\.\s*(?<db>\[[^\]]+\]|\w+)\s*\.\s*(?<sch>\[[^\]]*\]|\w*)\s*\.\s*(?<tbl>\[[^\]]+\]|\w+)(?<rest>[\s\S]*?)\s*;?\s*$",
            RegexOptions.IgnoreCase | RegexOptions.Singleline);

        private sealed class LinkedHit { public Match M; public bool Insert; }

        private static bool IsOurSource(Match m, string host, string srcDb)
        {
            bool sameHost = string.Equals(m.Groups["srv"].Value.Trim(), host, StringComparison.OrdinalIgnoreCase);
            bool sameDb = srcDb.Length > 0 && string.Equals(Unbracket(m.Groups["db"].Value), srcDb, StringComparison.OrdinalIgnoreCase);
            if ((sameHost || sameDb) && !sameHost)
                AppLog.Warn("-", "Linked server name '" + m.Groups["srv"].Value + "' differs from Source server '" + host
                    + "' - reading from the Source connection because the database name matches.");
            return sameHost || sameDb;
        }

        /// <summary>Split "a, f(x,y), [b]" on top-level commas.</summary>
        private static List<string> SplitTop(string s)
        {
            List<string> r = new List<string>();
            StringBuilder cur = new StringBuilder();
            int depth = 0; bool q = false, br = false;
            foreach (char ch in s)
            {
                if (q) { cur.Append(ch); if (ch == '\'') q = false; continue; }
                if (br) { cur.Append(ch); if (ch == ']') br = false; continue; }
                if (ch == '\'') { q = true; cur.Append(ch); continue; }
                if (ch == '[') { br = true; cur.Append(ch); continue; }
                if (ch == '(') depth++;
                if (ch == ')') depth--;
                if (ch == ',' && depth == 0) { r.Add(cur.ToString()); cur.Length = 0; continue; }
                cur.Append(ch);
            }
            if (cur.ToString().Trim().Length > 0) r.Add(cur.ToString());
            return r;
        }

        private sealed class LinkRef
        {
            public string Srv = "", Db = "", Sch = "dbo", Tbl = "";
            public string Key { get { return (Srv + "|" + Db + "|" + Sch + "|" + Tbl).ToLowerInvariant(); } }
            public string SrcObj { get { return "[" + Db.Replace("]", "]]") + "].[" + Sch.Replace("]", "]]") + "].[" + Tbl.Replace("]", "]]") + "]"; } }
        }

        private sealed class BatchPlan
        {
            public string Raw = "";
            public string Clean = "";
            public string Title = "";
            public bool Empty;
            public string UseDb;      // "USE [db]" (alone or together with SET lines)
            public bool Hit;          // simple "INSERT..SELECT / SELECT..INTO from [srv].[db].[sch].[tbl]" - streamed by SyncDB
            public bool Insert;
            public Match M;
            public string Pre = "";   // DELETE / TRUNCATE written in front of the INSERT in the same batch
            public bool Staging;      // complex statement that touches a linked server: tables are copied by SyncDB first
            public string Why = "";   // why Staging was needed
            public List<LinkRef> Refs = new List<LinkRef>();
            /// <summary>Table this batch empties completely ("DELETE FROM t" with no WHERE / "TRUNCATE TABLE t"), else null.</summary>
            public string Empties;
            /// <summary>Table this batch inserts into ("INSERT INTO t ..."), else null.</summary>
            public string Fills;
        }

        // "DELETE FROM t" / "DELETE t" / "TRUNCATE TABLE t" alone in the batch - no WHERE, no other statement
        private static readonly Regex EmptyTableRx = new Regex(
            @"^\s*(?:DELETE\s+(?:FROM\s+)?|TRUNCATE\s+TABLE\s+)(?<t>(?:\[[^\]]+\]|\w+)(?:\s*\.\s*(?:\[[^\]]*\]|\w*))*)\s*;?\s*$",
            RegexOptions.IgnoreCase);

        // "INSERT INTO t ..." at the start of the batch
        private static readonly Regex InsertIntoRx = new Regex(
            @"^\s*INSERT\s+(?:INTO\s+)?(?<t>(?:\[[^\]]+\]|\w+)(?:\s*\.\s*(?:\[[^\]]*\]|\w*))*)",
            RegexOptions.IgnoreCase);

        // table hints that may follow the table name: WITH (NOLOCK) / WITH(NOLOCK, INDEX(1)) / (NOLOCK)
        private static readonly Regex TableHintRx = new Regex(@"(?:\bWITH\s*)?\(\s*(?:NOLOCK|READUNCOMMITTED|READPAST|ROWLOCK|TABLOCK|TABLOCKX|UPDLOCK|XLOCK|HOLDLOCK|SERIALIZABLE|REPEATABLEREAD|READCOMMITTED|NOEXPAND|FORCESEEK|FORCESCAN|INDEX\s*\([^)]*\)|INDEX\s*=\s*[\w\[\]]+)(?:\s*,\s*(?:NOLOCK|READUNCOMMITTED|READPAST|ROWLOCK|TABLOCK|TABLOCKX|UPDLOCK|XLOCK|HOLDLOCK|SERIALIZABLE|REPEATABLEREAD|READCOMMITTED|NOEXPAND|FORCESEEK|FORCESCAN|INDEX\s*\([^)]*\)|INDEX\s*=\s*[\w\[\]]+))*\s*\)",
            RegexOptions.IgnoreCase);

        /// <summary>Removes "WITH (NOLOCK)"-style table hints so they cannot be mistaken for a CTE or a column list.</summary>
        private static string StripTableHints(string s)
        {
            return string.IsNullOrEmpty(s) ? (s ?? "") : TableHintRx.Replace(s, " ");
        }

        /// <summary>"[HRWarehouse02].[dbo].[person_employment]" and "person_employment" compare equal (last name part, no brackets).</summary>
        private static string TableKey(string name)
        {
            if (string.IsNullOrEmpty(name)) return "";
            string[] parts = name.Split('.');
            string last = parts[parts.Length - 1];
            return Unbracket(last.Trim()).Trim().ToUpperInvariant();
        }

        // [server].[db].[schema].[table]  (schema may be empty:  [server].[db]..[table])
        private static readonly Regex FourPartRx = new Regex(
            @"\[(?<srv>[^\]]+)\]\s*\.\s*(?<db>\[[^\]]+\]|\w+)\s*\.\s*(?<sch>\[[^\]]*\]|\w*)\s*\.\s*(?<tbl>\[[^\]]+\]|\w+)",
            RegexOptions.IgnoreCase);

        /// <summary>
        /// Known connection hosts (FQDNs that contain dots). Used to recognize a source table written
        /// as an unbracketed or single-bracketed dotted name, e.g.
        ///   HRWAREHOUSE01.DBS.BEHDASHT.GOV.IR.HRWarehouse01.employment_salary_item
        /// and rewrite it into a proper 4-part name so the linked-server bypass / staging path can handle it
        /// (including WHILE loops and other complex batches).
        /// </summary>
        private static List<string> KnownDottedHosts()
        {
            List<string> hosts = new List<string>();
            AppConfig cfg = _currentConfig;
            if (cfg != null && cfg.Connections != null)
                foreach (ConnectionProfile p in cfg.Connections)
                {
                    if (p == null) continue;
                    string h = HostOf(p.Server ?? "");
                    if (h.IndexOf('.') >= 0 && !hosts.Contains(h)) hosts.Add(h);
                }
            return hosts;
        }

        /// <summary>
        /// Rewrite dotted-server table references into bracketed 4-part names so FourPartRx and the
        /// staging path can see them. Handles:
        ///   HRWAREHOUSE01.DBS.BEHDASHT.GOV.IR.HRWarehouse01.employment_salary_item
        ///   [HRWAREHOUSE01.DBS.BEHDASHT.GOV.IR.HRWarehouse01.employment_salary_item]
        ///   [HRWAREHOUSE01.DBS.BEHDASHT.GOV.IR].[HRWarehouse01].[dbo].[employment_salary_item]
        /// </summary>
        private static string NormalizeDottedServerRefs(string sql)
        {
            if (string.IsNullOrEmpty(sql)) return sql ?? "";
            List<string> hosts = KnownDottedHosts();
            if (hosts.Count == 0) return sql;

            string result = sql;
            foreach (string host in hosts)
            {
                string he = Regex.Escape(host);
                // Case 1: whole name inside one pair of brackets:
                //   [host.db.schema.table]  or  [host.db.table]
                Regex single = new Regex(@"\[(?<inner>" + he + @"\.[^\[\]]+)\]", RegexOptions.IgnoreCase);
                result = single.Replace(result, m =>
                {
                    string inner = m.Groups["inner"].Value;
                    if (!inner.StartsWith(host, StringComparison.OrdinalIgnoreCase)) return m.Value;
                    string rest = inner.Substring(host.Length).TrimStart('.');
                    string[] bits = rest.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
                    if (bits.Length < 2) return m.Value;
                    string db = bits[0].Trim();
                    string sch = bits.Length >= 3 ? bits[1].Trim() : "dbo";
                    string tbl = bits[bits.Length - 1].Trim();
                    return "[" + host.Replace("]", "]]") + "].[" + db.Replace("]", "]]") + "].[" + sch.Replace("]", "]]") + "].[" + tbl.Replace("]", "]]") + "]";
                });

                // Case 2: unbracketed or partially bracketed:
                //   host.db.schema.table   or  [host].db.schema.table
                Regex multi = new Regex(
                    @"(?<!\w)(?:\[)?" + he + @"(?:\])?(?:\s*\.\s*(?:\[?[A-Za-z_]\w*\]?|\[[^\]]+\])){2,3}(?!\w)",
                    RegexOptions.IgnoreCase);
                result = multi.Replace(result, m =>
                {
                    string raw = m.Value.Trim().Trim('[', ']');
                    if (!raw.StartsWith(host, StringComparison.OrdinalIgnoreCase)) return m.Value;
                    string rest = raw.Substring(host.Length).TrimStart('.').Replace("[", "").Replace("]", "");
                    string[] bits = rest.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
                    if (bits.Length < 2) return m.Value;
                    string db = bits[0].Trim();
                    string sch = bits.Length >= 3 ? bits[1].Trim() : "dbo";
                    string tbl = bits[bits.Length - 1].Trim();
                    return "[" + host.Replace("]", "]]") + "].[" + db.Replace("]", "]]") + "].[" + sch.Replace("]", "]]") + "].[" + tbl.Replace("]", "]]") + "]";
                });
            }
            return result;
        }

        private static readonly Regex UdfCallRx = new Regex(
            @"(?:\b[A-Za-z_]\w*|\[[^\]]+\])\s*\.\s*(?:[A-Za-z_]\w*|\[[^\]]+\])\s*\(", RegexOptions.IgnoreCase);

        private static readonly Regex TranRx = new Regex(@"\bBEGIN\s+TRAN(?:SACTION)?\b", RegexOptions.IgnoreCase);
        private static readonly Regex SetUseOnlyRx = new Regex(@"^(?:\s*(?:SET\b[^;\r\n]*|USE\s+(?:\[[^\]]+\]|\w+))\s*;?)+\s*$", RegexOptions.IgnoreCase);
        private static readonly Regex UseAnyRx = new Regex(@"USE\s+(\[[^\]]+\]|\w+)", RegexOptions.IgnoreCase);

        /// <summary>"tcp:Server\Inst,1433" -> "server"</summary>
        internal static string HostOf(string server)
        {
            string s = (server ?? "").Trim();
            if (s.StartsWith("tcp:", StringComparison.OrdinalIgnoreCase)) s = s.Substring(4);
            int c = s.IndexOf(',');
            if (c >= 0) s = s.Substring(0, c);
            int b = s.IndexOf('\\');
            if (b >= 0) s = s.Substring(0, b);
            return s.Trim().ToLowerInvariant();
        }

        // ---------------------------------------------------------------------
        //  Which saved connection stands for [srv] in a four-part name?
        //  A script may spell the server as an IP (172.21.61.105) while the saved
        //  connection holds the DNS name (sql.company.local), or the other way
        //  round. A plain string compare then matches nothing, SyncDB falls back
        //  to the Source connection's credentials on that server, and the read
        //  usually fails with "Invalid object name" because that login cannot see
        //  the object. The two spellings are compared by address as well.
        // ---------------------------------------------------------------------
        private sealed class DnsEntry { public string[] Addr; public DateTime ExpUtc; }
        private static readonly Dictionary<string, DnsEntry> _dnsCache = new Dictionary<string, DnsEntry>(StringComparer.OrdinalIgnoreCase);
        private static readonly object _dnsLock = new object();

        /// <summary>Addresses of a host name; [] when it does not resolve. Cached, never throws, never blocks longer than 3 s.</summary>
        private static string[] AddressesOf(string host)
        {
            string h = (host ?? "").Trim();
            if (h.Length == 0) return new string[0];
            DateTime now = DateTime.UtcNow;
            lock (_dnsLock)
            {
                DnsEntry hit;
                if (_dnsCache.TryGetValue(h, out hit) && hit.ExpUtc > now) return hit.Addr;
            }
            string[] res = new string[0];
            try
            {
                System.Net.IPAddress ip;
                if (System.Net.IPAddress.TryParse(h, out ip))
                {
                    res = new string[] { ip.ToString() };
                }
                else
                {
                    IAsyncResult ar = System.Net.Dns.BeginGetHostAddresses(h, null, null);
                    if (ar.AsyncWaitHandle.WaitOne(3000))
                    {
                        System.Net.IPAddress[] all = System.Net.Dns.EndGetHostAddresses(ar);
                        List<string> l = new List<string>();
                        if (all != null)
                            foreach (System.Net.IPAddress a in all) l.Add(a.ToString());
                        res = l.ToArray();
                    }
                }
            }
            catch { res = new string[0]; }
            DnsEntry e = new DnsEntry();
            e.Addr = res;
            // a name that did not resolve is retried after 2 minutes, so one DNS hiccup
            // does not silently send the whole day's runs to the wrong login
            e.ExpUtc = DateTime.UtcNow.AddMinutes(res.Length > 0 ? 30 : 2);
            lock (_dnsLock) { _dnsCache[h] = e; }
            return res;
        }

        /// <summary>Same machine? "172.21.61.105" and "sql.company.local" match when they resolve to the same address.</summary>
        internal static bool HostsMatch(string a, string b)
        {
            string ha = HostOf(a), hb = HostOf(b);
            if (ha.Length == 0 || hb.Length == 0) return false;
            if (ha == hb) return true;
            string[] aa = AddressesOf(ha);
            if (aa.Length == 0) return false;
            string[] bb = AddressesOf(hb);
            if (bb.Length == 0) return false;
            for (int i = 0; i < aa.Length; i++)
                for (int j = 0; j < bb.Length; j++)
                    if (string.Equals(aa[i], bb[j], StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        /// <summary>The saved connection that stands for [srv]: by connection NAME, by server name, or by address.</summary>
        private static ConnectionProfile FindConnectionFor(string srv, string dbn, out string why)
        {
            why = "";
            AppConfig cfg = _currentConfig;
            if (cfg == null || cfg.Connections == null) return null;
            string s = (srv ?? "").Trim();
            if (s.Length == 0) return null;
            string h = HostOf(s);
            string db = (dbn ?? "").Trim();
            ConnectionProfile byName = null, hostDb = null, hostOnly = null, addrDb = null, addrOnly = null;
            foreach (ConnectionProfile p in cfg.Connections)
            {
                if (p == null) continue;
                if (byName == null && string.Equals((p.Name ?? "").Trim(), s, StringComparison.OrdinalIgnoreCase)) { byName = p; continue; }
                if ((p.Server ?? "").Trim().Length == 0) continue;
                bool dbSame = db.Length > 0 && string.Equals((p.Database ?? "").Trim(), db, StringComparison.OrdinalIgnoreCase);
                if (HostOf(p.Server) == h)
                {
                    if (dbSame) { if (hostDb == null) hostDb = p; }
                    else if (hostOnly == null) hostOnly = p;
                }
                else if (HostsMatch(p.Server, s))
                {
                    if (dbSame) { if (addrDb == null) addrDb = p; }
                    else if (addrOnly == null) addrOnly = p;
                }
            }
            if (byName != null) { why = "connection '" + byName.Name + "' (matched by connection name)"; return byName; }
            if (hostDb != null) { why = "connection '" + hostDb.Name + "' (" + hostDb.Server + ")"; return hostDb; }
            if (hostOnly != null) { why = "connection '" + hostOnly.Name + "' (" + hostOnly.Server + ")"; return hostOnly; }
            if (addrDb != null) { why = "connection '" + addrDb.Name + "' (" + addrDb.Server + " = " + s + ")"; return addrDb; }
            if (addrOnly != null) { why = "connection '" + addrOnly.Name + "' (" + addrOnly.Server + " = " + s + ")"; return addrOnly; }
            return null;
        }

        /// <summary>" as login 'sa'" - so the log and the error say WHICH login read the source.</summary>
        private static string LoginOf(string cs)
        {
            try
            {
                SqlConnectionStringBuilder b = new SqlConnectionStringBuilder(cs);
                if (b.IntegratedSecurity) return " as the Windows account of this program";
                string u = (b.UserID ?? "").Trim();
                return u.Length > 0 ? " as login '" + u + "'" : "";
            }
            catch { return ""; }
        }

        /// <summary>Added to a failed linked-server read: which connection was used, and what to do when the object was not found.</summary>
        private static string ReadHint(string how, string srcObj, string msg)
        {
            string s = "  >> SyncDB read the source itself via " + (string.IsNullOrEmpty(how) ? "?" : how) + ".";
            string m = msg ?? "";
            if (m.IndexOf("Invalid object name", StringComparison.OrdinalIgnoreCase) >= 0
                && (how ?? "").IndexOf("no saved connection matches", StringComparison.OrdinalIgnoreCase) >= 0)
                s += " That login is probably not the one that can see " + srcObj
                   + " - add a connection for this server in tab 1 (Connections), or write the server part of the four-part name"
                   + " exactly as that connection's Name or Server. | "
                   + "هیچ اتصال ذخیره‌شده‌ای برای این سرور پیدا نشد و SyncDB با یوزر اتصال مبدأ وصل شد؛ در تب Connections یک اتصال برای این سرور بسازید"
                   + " یا نام سرور را دقیقاً مطابق Name/Server همان اتصال بنویسید.";
            return s;
        }

        /// <summary>Does [srv].[db] look like a real linked server (and not a column reference like [db].[dbo].[t].[col])?</summary>
        private static bool IsLinkedRef(string srv, string db, string fallbackSrcConn)
        {
            string s = (srv ?? "").Trim();
            if (s.Length == 0) return false;
            if (s.IndexOf('.') >= 0 || s.IndexOf('\\') >= 0 || s.IndexOf(',') >= 0) return true;
            string h = HostOf(s);
            AppConfig cfg = _currentConfig;
            string global = cfg != null ? cfg.ResolveSourceConnectionString() : "";
            if (string.IsNullOrEmpty(global)) global = fallbackSrcConn ?? "";
            if (global.Length > 0)
            {
                if (SourceHost(global).ToLowerInvariant() == h) return true;
                if (string.Equals(SourceDatabase(global), Unbracket(db), StringComparison.OrdinalIgnoreCase)) return true;
            }
            if (cfg != null && cfg.Connections != null)
                foreach (ConnectionProfile p in cfg.Connections)
                    if (p != null && HostOf(p.Server) == h) return true;
            // the same machine can be saved under its connection NAME or under another
            // spelling (IP <-> DNS name) - that is still a reference SyncDB reads itself
            string whyRef;
            if (FindConnectionFor(s, Unbracket(db), out whyRef) != null) return true;
            return false;
        }

        /// <summary>
        /// The linked server is not used at all (it may be closed by the network team): SyncDB connects to the server
        /// named in [srv].[db]... itself - first a saved connection for that server, otherwise the job's Source connection
        /// (its credentials, pointed at that server and database).
        /// </summary>
        internal static string ResolveLinkedSource(string srv, string db, string fallbackSrcConn, out string how)
        {
            how = "";
            AppConfig cfg = _currentConfig;
            string dbn = Unbracket(db);
            string why;
            ConnectionProfile best = FindConnectionFor(srv, dbn, out why);
            if (best != null)
            {
                string cs = best.BuildConnectionString();
                if (cs.Length > 0)
                {
                    how = why + LoginOf(cs);
                    return WithDatabase(cs, dbn);
                }
            }
            string global = cfg != null ? cfg.ResolveSourceConnectionString() : "";
            if (string.IsNullOrEmpty(global)) global = fallbackSrcConn ?? "";
            if (!string.IsNullOrEmpty(global))
            {
                try
                {
                    SqlConnectionStringBuilder b = new SqlConnectionStringBuilder(global);
                    if (!HostsMatch(b.DataSource, srv))
                    {
                        b.DataSource = srv.Trim();
                        how = "the Source connection's credentials on server '" + srv.Trim() + "' (no saved connection matches that server)";
                        AppLog.Warn("-", "No saved connection matches server '" + srv.Trim()
                            + "' - SyncDB is reading it with the Source connection's credentials. If the read fails with 'Invalid object name', "
                            + "add a connection for this server in tab 1 (Connections) or write the server part exactly as that connection's Name or Server.");
                    }
                    else how = "Source connection (" + b.DataSource + ")";
                    b.InitialCatalog = dbn;
                    string cs2 = b.ConnectionString;
                    how += LoginOf(cs2);
                    return cs2;
                }
                catch { }
            }
            how = "no connection found";
            return fallbackSrcConn ?? "";
        }

        private static List<LinkRef> FindLinkRefs(string clean, string fallbackSrcConn)
        {
            List<LinkRef> refs = new List<LinkRef>();
            Dictionary<string, bool> seen = new Dictionary<string, bool>();
            foreach (Match fm in FourPartRx.Matches(MaskSqlNonCode(clean, false)))
            {
                LinkRef r = new LinkRef();
                r.Srv = fm.Groups["srv"].Value.Trim();
                r.Db = Unbracket(fm.Groups["db"].Value);
                r.Sch = Unbracket(fm.Groups["sch"].Value);
                if (r.Sch.Length == 0) r.Sch = "dbo";
                r.Tbl = Unbracket(fm.Groups["tbl"].Value);
                if (!IsLinkedRef(r.Srv, r.Db, fallbackSrcConn)) continue;
                if (seen.ContainsKey(r.Key)) continue;
                seen[r.Key] = true;
                refs.Add(r);
            }
            return refs;
        }

        private static BatchPlan ClassifyBatch(string raw, bool scriptHasTran, string fallbackSrcConn)
        {
            BatchPlan p = new BatchPlan();
            p.Raw = raw;
            // comments are removed first: a "-- comment" line in front of INSERT must not change how the statement is understood
            p.Clean = StripSqlComments(raw).Trim();
            p.Title = DescribeBatch(p.Clean);
            if (p.Clean.Length == 0) { p.Empty = true; return p; }

            // remember "empties table X" / "fills table X" so a DELETE + INSERT pair can be made atomic
            Match em = EmptyTableRx.Match(p.Clean);
            if (em.Success) p.Empties = TableKey(em.Groups["t"].Value);
            Match im = InsertIntoRx.Match(p.Clean);
            if (im.Success) p.Fills = TableKey(im.Groups["t"].Value);

            Match um = UseRx.Match(p.Clean);
            if (um.Success) { p.UseDb = Unbracket(um.Groups[1].Value); return p; }
            Match m = LinkedSelectInto.Match(p.Clean);
            bool ins = false;
            string pre = "";
            if (!m.Success)
            {
                m = LinkedInsertSelect.Match(p.Clean);
                ins = m.Success;
                if (ins && m.Groups["pre"].Success) pre = m.Groups["pre"].Value;
            }
            if (!m.Success)
            {
                // "DELETE FROM t  INSERT INTO t SELECT ... FROM [srv].[db].[sch].[t]"  (GO / ';' forgotten between them)
                Match pm = PreDeleteRx.Match(p.Clean);
                if (pm.Success && !Regex.IsMatch(pm.Groups["pre"].Value, @"\b(SELECT|INSERT|UPDATE|EXEC|EXECUTE)\b", RegexOptions.IgnoreCase))
                {
                    Match m2 = LinkedInsertSelect.Match(p.Clean.Substring(pm.Groups["pre"].Length));
                    if (m2.Success) { m = m2; ins = true; pre = pm.Groups["pre"].Value; }
                }
            }

            p.Refs = FindLinkRefs(p.Clean, fallbackSrcConn);
            if (p.Refs.Count == 0) return p;            // no linked server inside - ordinary T-SQL on the destination

            if (m.Success && IsLinkedRef(m.Groups["srv"].Value, m.Groups["db"].Value, fallbackSrcConn))
            {
                string rest = MaskSqlNonCode(m.Groups["rest"].Value, true);
                string code = MaskSqlNonCode(p.Clean, true);
                string sourceCode = MaskSqlNonCode(p.Clean, false);
                Match udf = UdfCallRx.Match(MaskSqlNonCode(m.Groups["cols"].Value + " " + m.Groups["rest"].Value, false));
                // The regex is only a candidate finder, NOT a T-SQL parser. In particular, <cols> can
                // span an earlier local INSERT/SELECT and consume its FROM before finding a linked FROM.
                // Keep such batches intact on the destination; only replace their linked table references.
                if (pre.Trim().Length > 0) p.Why = "preceding statements must run in the original batch";
                else if (sourceCode.Substring(m.Groups["srv"].Index, m.Groups["srv"].Length) != m.Groups["srv"].Value)
                    p.Why = "candidate linked FROM is inside a literal";
                else if (Regex.Matches(code, @"\bSELECT\b", RegexOptions.IgnoreCase).Count != 1
                    || Regex.Matches(code, @"\bFROM\b", RegexOptions.IgnoreCase).Count != 1
                    || Regex.Matches(code, @"\bINSERT\b", RegexOptions.IgnoreCase).Count != (ins ? 1 : 0)
                    || code.Trim().TrimEnd(';').IndexOf(';') >= 0
                    || Regex.IsMatch(code, @"\b(DELETE|TRUNCATE|UPDATE|MERGE|EXEC|EXECUTE|DROP|CREATE|ALTER|SET|USE|DECLARE|IF|WHILE|BEGIN|COMMIT|ROLLBACK|PRINT|RAISERROR|THROW|WAITFOR|RETURN)\b", RegexOptions.IgnoreCase))
                    p.Why = "more statements or a subquery in the same batch";
                // "WITH (NOLOCK)" is a TABLE HINT, not a CTE: "\bWITH\b" used to match it and sent the whole
                // statement down the staging path, which copies the FULL source table and loses "TOP n".
                else if (Regex.IsMatch(code, @"\b(JOIN|APPLY|UNION|INTERSECT|EXCEPT)\b|\bWITH\b(?!\s*\()|[@#]", RegexOptions.IgnoreCase)
                    || StripTableHints(rest).IndexOf(',') >= 0) p.Why = "query needs destination joins or session context";
                else if (ins && m.Groups["dcols"].Success) p.Why = "INSERT column mapping must be evaluated by SQL Server";
                else if (udf.Success) p.Why = "uses function " + udf.Value.Trim().TrimEnd((char)40).Trim() + "()";
                else if (scriptHasTran) p.Why = "script uses BEGIN TRAN (the INSERT must stay in the same transaction)";
                else if (p.Refs.Count > 1 || FourPartRx.Matches(sourceCode).Count > 1)
                    p.Why = "more than one linked table reference";
                if (p.Why.Length == 0)
                {
                    p.Hit = true; p.M = m; p.Insert = ins; p.Pre = pre;
                    return p;
                }
            }
            else p.Why = "statement is not a plain INSERT..SELECT";
            p.Staging = true;
            return p;
        }

        private static string RewriteLinkedReferences(string sql, Dictionary<string, string> map)
        {
            // Matches have the same offsets in the mask and the original text. Never replace text
            // in literals/comments (including dynamic SQL, which cannot safely be staged this way).
            StringBuilder rewritten = new StringBuilder();
            int pos = 0;
            foreach (Match fm in FourPartRx.Matches(MaskSqlNonCode(sql, false)))
            {
                LinkRef r = new LinkRef();
                r.Srv = fm.Groups["srv"].Value.Trim();
                r.Db = Unbracket(fm.Groups["db"].Value);
                r.Sch = Unbracket(fm.Groups["sch"].Value);
                if (r.Sch.Length == 0) r.Sch = "dbo";
                r.Tbl = Unbracket(fm.Groups["tbl"].Value);
                string repl;
                rewritten.Append(sql, pos, fm.Index - pos);
                rewritten.Append(map.TryGetValue(r.Key, out repl) ? repl : sql.Substring(fm.Index, fm.Length));
                pos = fm.Index + fm.Length;
            }
            rewritten.Append(sql, pos, sql.Length - pos);
            return rewritten.ToString();
        }

        private static void DropStaging(SqlConnection nat, string connStr, List<string> tables)
        {
            if (tables.Count == 0) return;
            try
            {
                SqlConnection c = nat;
                bool own = false;
                if (c == null || c.State != ConnectionState.Open) { c = new SqlConnection(connStr); c.Open(); own = true; }
                try
                {
                    foreach (string t in tables)
                        using (SqlCommand cmd = new SqlCommand("IF OBJECT_ID(N'" + t.Replace("'", "''") + "', N'U') IS NOT NULL DROP TABLE " + t, c))
                        {
                            cmd.CommandTimeout = 120;
                            cmd.ExecuteNonQuery();
                        }
                }
                finally { if (own) c.Dispose(); }
            }
            catch (Exception ex) { AppLog.Warn("-", "Could not drop staging table(s): " + ex.Message); }
        }

        private static JobStep NewTransferStep(JobStep step, string select, string destTable, string srcObj, WriteMode mode)
        {
            JobStep ts = new JobStep();
            ts.Name = step.Name;
            ts.Type = StepType.Transfer;
            ts.SqlCommand = select;
            ts.DestTable = destTable;
            ts.Mode = mode;
            ts.BatchSize = step.BatchSize > 0 ? step.BatchSize : 1000;
            ts.MaxThreads = step.MaxThreads;
            ts.DelayMs = step.DelayMs;
            ts.Priority = step.Priority;
            ts.Buffer = step.Buffer;
            ts.RamLimitMb = step.RamLimitMb;
            ts.SizeHintTable = srcObj;
            ts.SourceThreads = step.SourceThreads;
            ts.IndexRebuild = step.IndexRebuild;
            ts.IndexRebuildDays = step.IndexRebuildDays;
            ts.IndexLastRebuildUtc = step.IndexLastRebuildUtc;
            ts.RebuildIndexesAfter = step.RebuildIndexesAfter;
            return ts;
        }

        private static readonly string[] SystemDbs = new string[] { "master", "model", "msdb", "tempdb" };

        private static bool IsSystemDb(string db)
        {
            foreach (string s in SystemDbs)
                if (string.Equals(s, (db ?? "").Trim(), StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        /// <summary>Real server (machine\instance) and current database of a connection string. False if it cannot connect.</summary>
        private static bool TryServerDb(string cs, out string server, out string db)
        {
            server = ""; db = "";
            if (string.IsNullOrWhiteSpace(cs)) return false;
            try
            {
                using (SqlConnection c = new SqlConnection(cs))
                {
                    c.Open();
                    using (SqlCommand q = new SqlCommand(
                        "SELECT CAST(SERVERPROPERTY('MachineName') AS nvarchar(256)) + ISNULL(N'\\' + CAST(SERVERPROPERTY('InstanceName') AS nvarchar(256)), N''), DB_NAME()", c))
                    {
                        q.CommandTimeout = 30;
                        using (SqlDataReader rd = q.ExecuteReader())
                        {
                            if (rd.Read())
                            {
                                server = rd.IsDBNull(0) ? "" : rd.GetString(0);
                                db = rd.IsDBNull(1) ? "" : rd.GetString(1);
                            }
                        }
                    }
                }
                return server.Length > 0;
            }
            catch { return false; }
        }

        /// <summary>Row count from sys.partitions (fast, no table scan). -1 = unknown.</summary>
        private static long CountRows(string cs, string table, int timeout)
        {
            try
            {
                using (SqlConnection c = new SqlConnection(cs))
                {
                    c.Open();
                    using (SqlCommand q = new SqlCommand(
                        "SELECT SUM(p.rows) FROM sys.partitions p WHERE p.object_id = OBJECT_ID(@t) AND p.index_id IN (0,1)", c))
                    {
                        q.CommandTimeout = Math.Max(30, Math.Min(timeout, 300));
                        q.Parameters.AddWithValue("@t", table);
                        object o = q.ExecuteScalar();
                        return (o == null || o == DBNull.Value) ? -1 : Convert.ToInt64(o);
                    }
                }
            }
            catch { return -1; }
        }

        private static bool SameName(string a, string b)
        {
            return string.Equals((a ?? "").Trim(), (b ?? "").Trim(), StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>null = OK. Otherwise the reason the script must NOT run (nothing has been executed yet).</summary>
        private static string PreflightLinkedScript(List<BatchPlan> plans, string srcConn, string dstConn)
        {
            string dSrv, dDb;
            if (!TryServerDb(dstConn, out dSrv, out dDb)) return null;   // connection errors are reported by the normal run
            string curDb = dDb;
            bool sawUse = false;
            foreach (BatchPlan p in plans)
            {
                if (p.UseDb != null) { curDb = p.UseDb; sawUse = true; continue; }
                if (!p.Hit || p.M == null) continue;

                string[] dp = p.M.Groups["dest"].Value.Split('.');
                string dTbl = Unbracket(dp[dp.Length - 1]);
                string dSch = dp.Length >= 2 ? Unbracket(dp[dp.Length - 2]) : "";
                string dDbName = dp.Length >= 3 ? Unbracket(dp[dp.Length - 3]) : curDb;
                if (dSch.Length == 0) dSch = "dbo";

                if (!sawUse && dp.Length < 3 && IsSystemDb(curDb))
                    return "Destination connection has no database: it opened [" + dSrv + "].[" + curDb + "], so '" + dTbl
                        + "' would be deleted/written in [" + curDb + "] and not in your database. "
                        + "Fill 'Database' of the destination connection in tab 1 (Connections) or put USE [YourDatabase] + GO at the top of the script. "
                        + "Nothing was executed. | "
                        + "اتصال مقصد دیتابیس ندارد و به [" + curDb + "] وصل شد؛ جدول در آن‌جا نوشته می‌شد نه در دیتابیس شما. "
                        + "در تب Connections فیلد Database اتصال مقصد را پر کنید یا اول اسکریپت USE [نام دیتابیس] و GO بنویسید. هیچ دستوری اجرا نشد.";

                string how;
                string srcCs = ResolveLinkedSource(p.M.Groups["srv"].Value, p.M.Groups["db"].Value, srcConn, out how);
                string sSrv, sDb;
                if (!TryServerDb(srcCs, out sSrv, out sDb)) continue;
                string sSch = Unbracket(p.M.Groups["sch"].Value);
                if (sSch.Length == 0) sSch = "dbo";
                string sTbl = Unbracket(p.M.Groups["tbl"].Value);
                if (SameName(sSrv, dSrv) && SameName(sDb, dDbName) && SameName(sSch, dSch) && SameName(sTbl, dTbl))
                    return "Source and destination are the SAME table [" + sSrv + "].[" + sDb + "].[" + sSch + "].[" + sTbl + "] (source read via " + how + "). "
                        + "A DELETE before the INSERT would empty the source and nothing would be copied. Choose another destination connection/database. "
                        + "Nothing was executed. | "
                        + "مبدأ و مقصد یک جدول هستند؛ DELETE اول جدول مبدأ را خالی می‌کند و چیزی برای کپی نمی‌ماند. اتصال/دیتابیس مقصد را عوض کنید. هیچ دستوری اجرا نشد.";
            }
            return null;
        }

        /// <summary>Says WHY a batch was skipped, so a wrongly commented-out block is easy to spot.</summary>
        private static string SkipPreview(string raw)
        {
            string t = (raw ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
            while (t.IndexOf("  ") >= 0) t = t.Replace("  ", " ");
            if (t.Length == 0) return "the batch was empty";
            return "nothing left after removing comments - batch text: " + (t.Length > 160 ? t.Substring(0, 160) + "..." : t);
        }

        /// <summary>Job setting: make "DELETE t" + "INSERT INTO t" one transaction (SyncJob.AtomicRefill).</summary>
        private static bool _atomicRefill = true;

        /// <summary>Index of the next batch that really runs (comment-only ones are skipped); -1 = none.</summary>
        private static int NextRealBatch(List<BatchPlan> plans, int from)
        {
            for (int k = from + 1; k < plans.Count; k++)
                if (!plans[k].Empty) return k;
            return -1;
        }

        /// <summary>Undoes an open DELETE+INSERT guard; returns the text to append to the error message.</summary>
        private static string RollbackGuard(ref SqlTransaction guard, ref string table, ref int until)
        {
            if (guard == null) return "";
            string t = table ?? "";
            bool done = false;
            try { guard.Rollback(); done = true; }
            catch { }
            try { guard.Dispose(); } catch { }
            guard = null; table = null; until = -1;
            return done
                ? "  >> the DELETE of [" + t + "] was rolled back - the table still has its old rows."
                : "  >> WARNING: [" + t + "] could not be rolled back (the connection was lost) - check the table.";
        }

        /// <summary>Extra hint when a statement died on the command timeout rather than on a SQL error.</summary>
        private static string TimeoutHint(Exception ex, int timeout)
        {
            string m = ex != null ? (ex.Message ?? "") : "";
            SqlException sx = ex as SqlException;
            bool isTimeout = (sx != null && sx.Number == -2) || m.IndexOf("Timeout expired", StringComparison.OrdinalIgnoreCase) >= 0;
            if (!isTimeout) return "";
            return "  >> TIMED OUT after " + timeout + " s. Raise \"Command timeout\" on the job's General page (0 = no limit).";
        }

        private static bool TryRunLinkedServerScript(JobStep step, string srcConn, string dstConn, int timeout, out RunResult result)
        {
            result = null;
            if (string.IsNullOrWhiteSpace(step.SqlCommand)) return false;

            // Normalize dotted-server references (FQDN hosts) so a WHILE loop or other complex
            // batch that mentions the source table is recognized and staged instead of being
            // sent raw to the destination (which then fails with "Invalid object name").
            step.SqlCommand = NormalizeDottedServerRefs(step.SqlCommand);

            List<string> batches = SplitSqlBatches(step.SqlCommand);
            bool hasTran = TranRx.IsMatch(MaskSqlNonCode(step.SqlCommand, true));
            List<BatchPlan> plans = new List<BatchPlan>();
            bool any = false;
            foreach (string b in batches)
            {
                BatchPlan p = ClassifyBatch(b, hasTran, srcConn);
                if (p.Hit || p.Staging) any = true;
                plans.Add(p);
            }
            if (!any) return false;

            // Pre-check BEFORE any statement runs (a DELETE in batch 1 must never run against the wrong place):
            //  - destination connected to master/model/msdb/tempdb (Database left empty in Connections)
            //  - source and destination are the very same table (DELETE would empty the source)
            string pre = PreflightLinkedScript(plans, srcConn, dstConn);
            if (pre != null)
            {
                RunTrace.Add("CHECK", 0, plans.Count, "pre-check before running the script", "FAIL", 0, 0, pre);
                AppLog.Error("-", pre);
                result = new RunResult();
                result.Ok = false;
                result.Message = pre;
                return true;
            }

            bool cont = step.ContinueOnBatchError;
            RunResult total = new RunResult();
            total.Ok = true;
            int ok = 0, failed = 0, warned = 0;
            List<string> failMsgs = new List<string>();
            string curDst = dstConn;           // follows "USE <db>" like SSMS
            SqlConnection nat = null;          // ONE connection for all plain T-SQL batches (USE / temp tables / BEGIN TRAN carry over)

            // "DELETE FROM t" GO "INSERT INTO t ..." is run as ONE transaction, so a failing / timing-out
            // INSERT can never leave the table empty (the DELETE is rolled back with it).
            SqlTransaction guard = null;
            string guardTable = null;
            int guardUntil = -1;

            // "TRUNCATE/DELETE t" whose refill is done by SyncDB itself (APP-READ / STAGE) is HELD BACK:
            // running it straight away left the table empty for the whole time the source was being read
            // (and empty for good if the read failed or was stopped). It is run at write time instead.
            string deferTable = null;
            string deferSql = null;
            bool deferTruncate = false;

            try
            {
                for (int i = 0; i < plans.Count; i++)
                {
                    _tok.ThrowIfCancellationRequested();
                    BatchPlan p = plans[i];
                    int idx = i + 1, n = plans.Count;
                    Stopwatch sw = Stopwatch.StartNew();
                    List<string> staged = new List<string>();
                    RunTrace.SetCurrent(idx, n, p.Title);

                    if (p.Empty)
                    {
                        RunTrace.Add("SKIP", idx, n, "(comments only)", "SKIP", 0, 0, SkipPreview(p.Raw));
                        continue;
                    }

                    try
                    {
                        if (nat == null)
                        {
                            nat = new SqlConnection(curDst);
                            nat.Open();
                        }

                        // USE can appear inside any native batch, not just as a standalone statement.
                        curDst = WithDatabase(dstConn, nat.Database);
                        if (p.UseDb != null)
                        {
                            string info0;
                            RunNativeBatch(nat, p.Raw, timeout, out info0);
                            curDst = WithDatabase(dstConn, nat.Database);
                            RunTrace.Add("USE", idx, n, p.Title, "OK", 0, sw.ElapsedMilliseconds,
                                "following statements and SyncDB transfers now write to [" + p.UseDb + "]");
                            ok++;
                            continue;
                        }

                        // a held-back empty that the current batch does NOT refill must still happen, now
                        if (deferTable != null && p.Fills != deferTable)
                        {
                            string infoLate;
                            RunNativeBatch(nat, guard, deferSql, timeout, out infoLate);
                            deferTable = null; deferSql = null;
                        }

                        if (!p.Hit && !p.Staging)
                        {
                            // SyncDB refills this table itself in the next batch -> empty it at write time
                            if (deferTable == null && _atomicRefill && !hasTran && !string.IsNullOrEmpty(p.Empties))
                            {
                                int jd = NextRealBatch(plans, i);
                                if (jd > 0 && (plans[jd].Hit || plans[jd].Staging) && plans[jd].Fills == p.Empties)
                                {
                                    deferTable = p.Empties;
                                    deferSql = p.Raw;
                                    deferTruncate = Regex.IsMatch(p.Clean, @"^\s*TRUNCATE\b", RegexOptions.IgnoreCase);
                                    RunTrace.Add("SQL", idx, n, p.Title, "OK", 0, sw.ElapsedMilliseconds,
                                        "held back - the table is emptied by SyncDB right before the new rows are written, so it is not left empty while the source is read");
                                    ok++;
                                    continue;
                                }
                            }

                            // open the guard transaction when this batch empties a table that the NEXT
                            // native batch fills again - both then succeed together or neither does
                            if (guard == null && _atomicRefill && !hasTran && !string.IsNullOrEmpty(p.Empties))
                            {
                                int j = NextRealBatch(plans, i);
                                if (j > 0 && plans[j].UseDb == null && !plans[j].Hit && !plans[j].Staging
                                    && plans[j].Empties == null && plans[j].Fills == p.Empties)
                                {
                                    guard = nat.BeginTransaction();
                                    guardTable = p.Empties;
                                    guardUntil = j;
                                }
                            }

                            string info;
                            long rows = RunNativeBatch(nat, guard, p.Raw, timeout, out info);
                            total.Rows += rows;
                            if (guard != null && i == guardUntil)
                            {
                                guard.Commit();
                                try { guard.Dispose(); } catch { }
                                guard = null; guardTable = null; guardUntil = -1;
                                info += "; refill committed";
                            }
                            else if (guard != null)
                            {
                                info += "; held in a transaction until [" + guardTable + "] is refilled";
                            }
                            RunTrace.Add("SQL", idx, n, p.Title, "OK", rows, sw.ElapsedMilliseconds, info);
                            ok++;
                            continue;
                        }

                        if (p.Staging)
                        {
                            // The statement is too complex to stream (function / join / transaction ...). SyncDB copies each linked
                            // table into a temporary table on the destination, the statement runs on the copy, then the copy is dropped.
                            string rewritten = p.Raw;
                            string tag = Guid.NewGuid().ToString("N").Substring(0, 8);
                            int k = 0;
                            Dictionary<string, string> map = new Dictionary<string, string>();
                            foreach (LinkRef lr in p.Refs)
                            {
                                k++;
                                string how;
                                string srcCs = ResolveLinkedSource(lr.Srv, lr.Db, srcConn, out how);
                                // Fully qualify so a USE inside the rewritten batch cannot move the staging table.
                                string stg = "[" + nat.Database.Replace("]", "]]") + "].[dbo].[__syncdb_stg_" + tag + "_" + k + "]";
                                staged.Add(stg);
                                Stopwatch ssw = Stopwatch.StartNew();
                                JobStep sts = NewTransferStep(step, "SELECT * FROM " + lr.SrcObj, stg, lr.SrcObj, WriteMode.TruncateInsert);
                                RunTrace.StartProgress("#" + idx + "/" + n + " copy " + lr.SrcObj);
                                RunResult sr;
                                try { sr = ExecuteTransfer(sts, srcCs, curDst, timeout); }
                                finally { RunTrace.EndProgress(); }
                                if (!sr.Ok) throw new Exception((sr.Message ?? "staging copy failed") + ReadHint(how, lr.SrcObj, sr.Message));
                                RunTrace.Add("STAGE", idx, n, "copy " + lr.SrcObj + " -> temporary " + stg, "OK", sr.Rows, ssw.ElapsedMilliseconds,
                                    "read by SyncDB via " + how + "; linked server not used");
                                map[lr.Key] = stg;
                            }
                            rewritten = RewriteLinkedReferences(rewritten, map);
                            // the staging copies are finished now, so the held-back empty can run in the
                            // same transaction as the statement that refills the table
                            if (deferTable != null && p.Fills == deferTable && guard == null)
                            {
                                guard = nat.BeginTransaction();
                                guardTable = deferTable;
                                guardUntil = i;
                                string infoD;
                                RunNativeBatch(nat, guard, deferSql, timeout, out infoD);
                                deferTable = null; deferSql = null;
                            }
                            string infoS;
                            long rs = RunNativeBatch(nat, guard, rewritten, timeout, out infoS);
                            if (guard != null && i == guardUntil)
                            {
                                guard.Commit();
                                try { guard.Dispose(); } catch { }
                                guard = null; guardTable = null; guardUntil = -1;
                                infoS += "; emptied and refilled in one transaction";
                            }
                            // rows of the copy are not "written rows" - count only what the final statement changed
                            total.Rows += rs;
                            RunTrace.Add("SQL", idx, n, p.Title, "OK", rs, sw.ElapsedMilliseconds, infoS + " (" + p.Why + ": run on the copied table(s))");
                            ok++;
                            continue;
                        }

                        Match m = p.M;

                        // DELETE / TRUNCATE in front of the INSERT (same batch) runs on Dest first
                        if (p.Insert && p.Pre.Trim().Length > 0)
                        {
                            string infoP;
                            long pr = RunNativeBatch(nat, p.Pre, timeout, out infoP);
                            RunTrace.Add("SQL", idx, n, "pre-statement: " + DescribeBatch(p.Pre), "OK", pr, sw.ElapsedMilliseconds, infoP);
                            sw.Restart();
                        }

                        string[] dp = m.Groups["dest"].Value.Split('.');
                        string tbl = Unbracket(dp[dp.Length - 1]);
                        string sch = dp.Length >= 2 ? Unbracket(dp[dp.Length - 2]) : "";
                        string db = dp.Length >= 3 ? Unbracket(dp[dp.Length - 3]) : "";
                        if (sch.Length == 0) sch = "dbo";
                        string destName = (db.Length > 0 ? "[" + db.Replace("]", "]]") + "]." : "")
                            + "[" + sch.Replace("]", "]]") + "].[" + tbl.Replace("]", "]]") + "]";

                        string srcSch = Unbracket(m.Groups["sch"].Value);
                        if (srcSch.Length == 0) srcSch = "dbo";

                        string cols = m.Groups["cols"].Value.Trim();
                        if (p.Insert && m.Groups["dcols"].Success && m.Groups["dcols"].Value.Trim().Length > 0 && cols != "*")
                        {
                            // INSERT INTO t (a,b) SELECT x,y  ->  SELECT x AS [a], y AS [b]   (mapped by name)
                            List<string> sc = SplitTop(cols), dc = SplitTop(m.Groups["dcols"].Value);
                            if (sc.Count != dc.Count)
                                throw new Exception("INSERT column list (" + dc.Count + ") and SELECT list (" + sc.Count + ") have different counts.");
                            StringBuilder cb = new StringBuilder();
                            for (int kk = 0; kk < sc.Count; kk++)
                            {
                                if (kk > 0) cb.Append(", ");
                                cb.Append(sc[kk].Trim()).Append(" AS [").Append(Unbracket(dc[kk]).Replace("]", "]]")).Append("]");
                            }
                            cols = cb.ToString();
                        }

                        string srcObj = "[" + Unbracket(m.Groups["db"].Value).Replace("]", "]]") + "].[" + srcSch.Replace("]", "]]") + "].[" + Unbracket(m.Groups["tbl"].Value).Replace("]", "]]") + "]";
                        // the tail is already comment-free (ClassifyBatch) - nothing can swallow the closing text of a wrapped SELECT
                        string sourceSelect = "SELECT " + cols + " FROM " + srcObj + " " + m.Groups["rest"].Value.Trim();

                        string how1;
                        string srcCs1 = ResolveLinkedSource(m.Groups["srv"].Value, m.Groups["db"].Value, srcConn, out how1);
                        AppLog.Info("-", "Linked-server " + (p.Insert ? "INSERT..SELECT" : "SELECT INTO") + " detected - SyncDB reads it itself (linked server not used) via "
                            + how1 + ": " + sourceSelect + "  ->  " + destName);

                        // the held-back "TRUNCATE/DELETE t" becomes the write mode of this transfer:
                        // SyncDB empties the table itself, immediately before it writes the new rows
                        WriteMode wmode = p.Insert ? WriteMode.Append : WriteMode.TruncateInsert;
                        bool tookDefer = false;
                        if (deferTable != null && p.Fills == deferTable)
                        {
                            wmode = deferTruncate ? WriteMode.TruncateInsert : WriteMode.DeleteInsert;
                            tookDefer = true;
                        }
                        JobStep ts = NewTransferStep(step, sourceSelect, destName, srcObj, wmode);
                        if (tookDefer)
                        {
                            ts.DestDeleteWhere = "";     // the script's statement had no WHERE
                            deferTable = null; deferSql = null;
                        }
                        RunTrace.StartProgress("#" + idx + "/" + n + " " + tbl + " <- " + srcObj);
                        RunResult r1;
                        try { r1 = ExecuteTransfer(ts, srcCs1, curDst, timeout); }
                        catch (OperationCanceledException) { throw; }
                        catch (Exception rex) { throw new Exception(rex.Message + ReadHint(how1, srcObj, rex.Message), rex); }
                        finally { RunTrace.EndProgress(); }
                        step.IndexLastRebuildUtc = ts.IndexLastRebuildUtc;
                        total.Rows += r1.Rows;

                        string title = (p.Insert ? "INSERT " : "SELECT..INTO ") + tbl + "  <-  " + srcObj;
                        if (!r1.Ok)
                            throw new Exception((r1.Message ?? "transfer failed") + ReadHint(how1, srcObj, r1.Message));

                        // Verify on the destination itself: where did the rows go and are they really there?
                        string sSrv, sDb, dSrv, dDb;
                        TryServerDb(srcCs1, out sSrv, out sDb);
                        TryServerDb(curDst, out dSrv, out dDb);
                        long destRows = CountRows(curDst, destName, timeout);
                        string loc = "source [" + sSrv + "].[" + sDb + "] -> destination [" + dSrv + "]." + (db.Length > 0 ? "" : "[" + dDb + "].") + destName
                            + (destRows >= 0 ? " now has " + destRows + " row(s)" : "");
                        AppLog.Info("-", "Linked-server copy: wrote " + r1.Rows + " row(s); " + loc);
                        if (r1.Rows > 0 && destRows == 0)
                            throw new Exception("SyncDB wrote " + r1.Rows + " row(s) but " + loc
                                + ". Another session, a trigger or a later statement removed them, or a different database is being checked.");
                        how1 = how1 + "; " + loc;
                        if (r1.Rows == 0)
                        {
                            RunTrace.Add("APP-READ", idx, n, title, "WARN", 0, sw.ElapsedMilliseconds,
                                "SyncDB read 0 rows from the source table (via " + how1 + ") - destination table " + destName + " is empty now");
                            warned++;
                        }
                        else
                        {
                            RunTrace.Add("APP-READ", idx, n, title, "OK", r1.Rows, sw.ElapsedMilliseconds, "read by SyncDB via " + how1 + "; linked server not used");
                            ok++;
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        RollbackGuard(ref guard, ref guardTable, ref guardUntil);
                        RunTrace.Add("STOP", idx, n, p.Title, "FAIL", 0, sw.ElapsedMilliseconds, "stopped by user while this statement was running");
                        throw;
                    }
                    catch (Exception ex)
                    {
                        // the DELETE that belongs to this INSERT is undone, so the table keeps its rows
                        string undo = RollbackGuard(ref guard, ref guardTable, ref guardUntil);
                        if (deferTable != null && p.Fills == deferTable)
                        {
                            undo += "  >> [" + deferTable + "] was NOT emptied - it still holds the rows from the last successful run.";
                            deferTable = null; deferSql = null;
                        }
                        string msg = ex.Message + TimeoutHint(ex, timeout) + undo;
                        RunTrace.Add(p.Staging ? "STAGE" : (p.Hit ? "APP-READ" : "SQL"), idx, n, p.Title, "FAIL", 0, sw.ElapsedMilliseconds, msg);
                        failed++;
                        failMsgs.Add("#" + idx + " " + p.Title + ": " + msg);
                        // a broken connection cannot be reused for the next batch
                        if (nat != null && nat.State != ConnectionState.Open) { try { nat.Dispose(); } catch { } nat = null; }
                        if (!cont)
                        {
                            string preview = p.Raw.Length > 200 ? p.Raw.Substring(0, 200) + "..." : p.Raw;
                            throw new Exception("Dest batch " + idx + "/" + n + " [" + p.Title + "] error: " + ex.Message
                                + Environment.NewLine + "SQL:" + Environment.NewLine + preview, ex);
                        }
                    }
                    finally
                    {
                        DropStaging(nat, curDst, staged);
                    }
                }

                // a held-back empty left over at the end of the script still has to run
                if (deferTable != null && nat != null && nat.State == ConnectionState.Open)
                {
                    try
                    {
                        string infoEnd;
                        RunNativeBatch(nat, null, deferSql, timeout, out infoEnd);
                        RunTrace.Add("SQL", plans.Count, plans.Count, "empty [" + deferTable + "]", "OK", 0, 0, infoEnd + " (held-back statement, run at the end)");
                    }
                    catch (Exception exEnd)
                    {
                        RunTrace.Add("SQL", plans.Count, plans.Count, "empty [" + deferTable + "]", "FAIL", 0, 0, exEnd.Message);
                    }
                    deferTable = null; deferSql = null;
                }
            }
            finally
            {
                RollbackGuard(ref guard, ref guardTable, ref guardUntil);
                if (nat != null) { try { nat.Dispose(); } catch { } }
            }

            total.Ok = failed == 0;
            total.Message = "Script done: " + ok + " OK, " + failed + " FAILED, " + warned + " warning(s) of " + plans.Count
                + " batches (linked-server tables read by SyncDB, linked server not used). Rows=" + total.Rows
                + (failed > 0 ? " - FAILED: " + string.Join(" | ", failMsgs.ToArray()) : "");
            result = total;
            return true;
        }

        // =====================================================================
        //  2) Destination schema check: compare SOURCE types with DEST columns, fix before writing
        // =====================================================================

        private sealed class ColInfo
        {
            public string Type = "";
            public int Len;       // chars for strings / bytes for binary, -1 = MAX
            public int Prec;
            public int Scale;
            public bool Nullable = true;
        }

        private static ColInfo ParseTypeText(string t)
        {
            ColInfo ci = new ColInfo();
            Match m = Regex.Match((t ?? "").Trim(), @"^(\w+)\s*(?:\(\s*(\w+)\s*(?:,\s*(\d+))?\s*\))?$");
            ci.Type = m.Groups[1].Value.ToLowerInvariant();
            string a = m.Groups[2].Value;
            if (a.Length > 0)
            {
                if (a.Equals("MAX", StringComparison.OrdinalIgnoreCase)) ci.Len = -1;
                else { int v; int.TryParse(a, out v); ci.Len = v; ci.Prec = v; }
                int sc;
                if (m.Groups[3].Success && int.TryParse(m.Groups[3].Value, out sc)) ci.Scale = sc;
                if (ci.Type == "datetime2" || ci.Type == "datetimeoffset" || ci.Type == "time") { ci.Scale = ci.Prec; ci.Prec = 0; }
            }
            if (ci.Type == "money") { ci.Prec = 19; ci.Scale = 4; }
            if (ci.Type == "smallmoney") { ci.Prec = 10; ci.Scale = 4; }
            if (ci.Type == "datetime2" || ci.Type == "datetimeoffset" || ci.Type == "time") { if (a.Length == 0) ci.Scale = 7; }
            return ci;
        }

        private static string Fam(string t)
        {
            switch (t)
            {
                case "tinyint": case "smallint": case "int": case "bigint": case "bit": return "int";
                case "decimal": case "numeric": case "money": case "smallmoney": case "float": case "real": return "num";
                case "char": case "varchar": case "nchar": case "nvarchar": case "text": case "ntext": case "xml": return "str";
                case "date": case "smalldatetime": case "datetime": case "datetime2": case "datetimeoffset": return "dt";
                case "binary": case "varbinary": case "image": case "timestamp": case "rowversion": return "bin";
                default: return t;
            }
        }

        private static int IntRank(string t)
        {
            switch (t) { case "bit": return 0; case "tinyint": return 1; case "smallint": return 2; case "int": return 3; default: return 4; }
        }

        private static int DtRank(string t)
        {
            switch (t) { case "date": return 1; case "smalldatetime": return 2; case "datetime": return 3; case "datetime2": return 4; default: return 5; }
        }

        /// <summary>0 = fine, 1 = fix by ALTER COLUMN (newType), 2 = needs manual attention (dest has data).</summary>
        private static int CompareCol(ColInfo s, ColInfo d, bool destEmpty, out string newType, out string why)
        {
            newType = null; why = null;
            string sf = Fam(s.Type), df = Fam(d.Type);

            if (sf != df)
            {
                if (df == "str" && !destEmpty) return 0;      // text can hold numbers/dates without loss
                why = "type family differs: dest " + d.Type + " vs source " + s.Type;
                newType = null;                              // caller uses the exact source type
                return destEmpty ? 1 : 2;
            }

            if (sf == "int")
            {
                if (IntRank(d.Type) < IntRank(s.Type)) { why = "dest " + d.Type + " is narrower than source " + s.Type; return 1; }
                return 0;
            }
            if (sf == "num")
            {
                bool sFloat = s.Type == "float" || s.Type == "real", dFloat = d.Type == "float" || d.Type == "real";
                if (dFloat)
                {
                    if (d.Type == "real" && s.Type == "float") { why = "dest real is narrower than float"; newType = "FLOAT"; return 1; }
                    return 0;
                }
                if (sFloat) { why = "source " + s.Type + " into dest " + d.Type + " would lose precision"; newType = "FLOAT"; return 1; }
                int sInt = s.Prec - s.Scale, dInt = d.Prec - d.Scale;
                if (dInt >= sInt && d.Scale >= s.Scale) return 0;
                int ni = Math.Max(sInt, dInt), nsc = Math.Max(s.Scale, d.Scale);
                int np = Math.Min(38, ni + nsc);
                if (np < ni + nsc) nsc = Math.Max(0, 38 - ni);
                why = "dest decimal(" + d.Prec + "," + d.Scale + ") cannot hold source (" + s.Prec + "," + s.Scale + ")";
                newType = "DECIMAL(" + np + "," + nsc + ")";
                return 1;
            }
            if (sf == "str" || sf == "bin")
            {
                bool su = s.Type.StartsWith("n"), du = d.Type.StartsWith("n") && sf == "str";
                bool shorter = d.Len != -1 && (s.Len == -1 || s.Len > d.Len);
                bool uniLoss = sf == "str" && su && !du;
                if (!shorter && !uniLoss) return 0;
                int nl = (d.Len == -1 || s.Len == -1) ? -1 : Math.Max(d.Len, s.Len);
                string baseT = sf == "bin" ? "VARBINARY" : ((su || du) ? "NVARCHAR" : "VARCHAR");
                newType = baseT + "(" + (nl == -1 ? "MAX" : nl.ToString()) + ")";
                why = uniLoss ? "dest " + d.Type + " is not Unicode (Persian/Arabic text would become '?')" : "dest length " + d.Len + " < source " + s.Len;
                return 1;
            }
            if (sf == "dt")
            {
                bool lower = DtRank(d.Type) < DtRank(s.Type);
                bool lessScale = (s.Type == "datetime2" || s.Type == "datetimeoffset") && d.Type == s.Type && d.Scale < s.Scale;
                if (!lower && !lessScale) return 0;
                why = "dest " + d.Type + " cannot hold source " + s.Type + " fully";
                return 1;
            }
            if (s.Type != d.Type) { why = "dest " + d.Type + " vs source " + s.Type; return destEmpty ? 1 : 2; }
            return 0;
        }

        private static void EnsureDestSchema(SqlConnection dst, JobStep step, DataTable srcSchema, DataTable shape, int timeout)
        {
            try
            {
                string table = NormalizeTableName(step.DestTable);
                string[] parts = table.Split(new string[] { "]." }, StringSplitOptions.None);
                string dbPrefix = parts.Length >= 3 ? parts[0] + "]." : "";

                Dictionary<string, ColInfo> dest = new Dictionary<string, ColInfo>(StringComparer.OrdinalIgnoreCase);
                using (SqlCommand q = new SqlCommand(
                    "SELECT c.name, TYPE_NAME(c.user_type_id), c.max_length, c.precision, c.scale, c.is_nullable FROM " +
                    dbPrefix + "sys.columns c WHERE c.object_id = OBJECT_ID(@n)", dst))
                {
                    q.CommandTimeout = timeout;
                    q.Parameters.AddWithValue("@n", table);
                    using (SqlDataReader rd = q.ExecuteReader())
                        while (rd.Read())
                        {
                            ColInfo ci = new ColInfo();
                            ci.Type = Convert.ToString(rd.GetValue(1)).ToLowerInvariant();
                            int ml = Convert.ToInt32(rd.GetValue(2));
                            ci.Len = (ci.Type == "nchar" || ci.Type == "nvarchar") && ml > 0 ? ml / 2 : ml;
                            if (ci.Type == "text" || ci.Type == "ntext" || ci.Type == "image" || ci.Type == "xml") ci.Len = -1;
                            ci.Prec = Convert.ToInt32(rd.GetValue(3));
                            ci.Scale = Convert.ToInt32(rd.GetValue(4));
                            ci.Nullable = Convert.ToInt32(rd.GetValue(5)) == 1;
                            dest[Convert.ToString(rd.GetValue(0))] = ci;
                        }
                }
                if (dest.Count == 0) return;

                bool empty;
                using (SqlCommand q = new SqlCommand("SELECT CASE WHEN EXISTS (SELECT 1 FROM " + table + ") THEN 0 ELSE 1 END", dst))
                {
                    q.CommandTimeout = timeout;
                    empty = Convert.ToInt32(q.ExecuteScalar()) == 1;
                }

                foreach (DataColumn dc in shape.Columns)
                {
                    DataRow sr = null;
                    if (srcSchema != null)
                        foreach (DataRow row in srcSchema.Rows)
                            if (string.Equals(Convert.ToString(row["ColumnName"]), dc.ColumnName, StringComparison.OrdinalIgnoreCase)) { sr = row; break; }
                    string desired = SqlTypeFor(sr, dc);
                    ColInfo s = ParseTypeText(desired);

                    ColInfo d;
                    if (!dest.TryGetValue(dc.ColumnName, out d))
                    {
                        if (step.Mode == WriteMode.Append)
                        {
                            AppLog.Warn("-", "Dest " + table + " has no column [" + dc.ColumnName + "] (Append mode: not adding it).");
                            continue;
                        }
                        RunDdl(dst, "ALTER TABLE " + table + " ADD [" + dc.ColumnName.Replace("]", "]]") + "] " + desired + " NULL", timeout);
                        AppLog.Warn("-", "SCHEMA FIX: added missing column [" + dc.ColumnName + "] " + desired + " to " + table);
                        continue;
                    }

                    string nt, why;
                    int res = CompareCol(s, d, empty, out nt, out why);
                    if (res == 0) continue;
                    if (res == 2)
                    {
                        AppLog.Warn("-", "SCHEMA WARNING [" + dc.ColumnName + "]: " + why + ". Dest table has data, so SyncDB did not change it. " +
                                    "Values may be rounded/zeroed/rejected - alter the column manually or use TruncateInsert.");
                        continue;
                    }
                    string newType = nt ?? desired;
                    string sql = "ALTER TABLE " + table + " ALTER COLUMN [" + dc.ColumnName.Replace("]", "]]") + "] " + newType + (d.Nullable ? " NULL" : " NOT NULL");
                    try
                    {
                        RunDdl(dst, sql, timeout);
                        AppLog.Warn("-", "SCHEMA FIX [" + dc.ColumnName + "]: " + why + "  =>  " + d.Type + " -> " + newType);
                    }
                    catch (Exception ex)
                    {
                        AppLog.Warn("-", "SCHEMA FIX FAILED [" + dc.ColumnName + "] (" + why + "): " + ex.Message + "  SQL: " + sql);
                    }
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "Schema check skipped: " + ex.Message);
            }
        }

        private static void RunDdl(SqlConnection c, string sql, int timeout)
        {
            using (SqlCommand cmd = new SqlCommand(sql, c)) { cmd.CommandTimeout = timeout; cmd.ExecuteNonQuery(); }
        }

        // =====================================================================
        //  3) Diagnosis + automatic fallback (RAM -> Stream -> Disk, smaller batch, fewer threads)
        // =====================================================================

        private static SqlException FindSql(Exception ex)
        {
            while (ex != null) { SqlException se = ex as SqlException; if (se != null) return se; ex = ex.InnerException; }
            return null;
        }

        private static string Diagnose(Exception ex, string srcConn, string dstConn, JobStep st, out string kind)
        {
            kind = "other";
            SqlException se = FindSql(ex);
            string msg = ex.Message ?? "";
            string side = "";
            if (se != null && !string.IsNullOrEmpty(se.Server))
            {
                string h = se.Server;
                int c = h.IndexOf(','); if (c > 0) h = h.Substring(0, c);
                if (string.Equals(h, SourceHost(dstConn), StringComparison.OrdinalIgnoreCase)) side = "DESTINATION";
                else if (string.Equals(h, SourceHost(srcConn), StringComparison.OrdinalIgnoreCase)) side = "SOURCE";
            }
            int n = se != null ? se.Number : 0;

            if (ex is OutOfMemoryException || n == 701 || n == 8645 || n == 8628)
            {
                kind = "memory";
                return "Not enough RAM (" + (side.Length > 0 ? side + " server" : "this PC") + "). Use Memory mode = Stream or Disk buffer, lower Batch size (e.g. 1000 -> 500), Threads = 1.";
            }
            if (ex is IOException && (msg.IndexOf("not enough space", StringComparison.OrdinalIgnoreCase) >= 0 || msg.IndexOf("disk is full", StringComparison.OrdinalIgnoreCase) >= 0))
            {
                kind = "local-disk";
                return "The LOCAL disk used for the buffer is full (" + Path.Combine(AppConfig.DataDir, "buffer") + "). Free space or use Memory mode = Stream.";
            }
            if (n == 1105 || n == 1101 || n == 112 || n == 3202)
            {
                kind = "dest-full";
                return (side.Length > 0 ? side : "DESTINATION") + " data file / filegroup / disk is FULL (SQL error " + n + "). A local cache cannot fix this: free disk space, add a file to the filegroup or enable autogrowth on that server, then run the job again.";
            }
            if (n == 9002)
            {
                kind = "log-full";
                return "Transaction log is full on " + (side.Length > 0 ? side : "the destination") + ". Lower Batch size (e.g. 200-500), use Disk buffer, and ask the DBA to back up the log / set recovery to SIMPLE for this DB.";
            }
            if (n == -2 || msg.IndexOf("Timeout expired", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                kind = "timeout";
                return "Timeout. Lower Batch size, set Threads = 1, or increase the job command timeout; check locks/blocking on the table.";
            }
            if (n == 1205)
            {
                kind = "deadlock";
                return "Deadlock victim. Retrying with Threads = 1.";
            }
            if (n == 8152 || msg.IndexOf("invalid column length", StringComparison.OrdinalIgnoreCase) >= 0 || msg.IndexOf("truncated", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                kind = "truncation";
                return "A text value is longer than the destination column. SyncDB already widens columns when it can; check the column named in the error (destination may contain data, or ALTER failed - see SCHEMA lines above).";
            }
            if (n == 8115 || n == 245 || n == 8114 || n == 220 || msg.IndexOf("cannot be converted", StringComparison.OrdinalIgnoreCase) >= 0 || msg.IndexOf("Conversion failed", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                kind = "conversion";
                return "Data type mismatch between source and destination column. Check the SCHEMA FIX / SCHEMA WARNING lines above; if the dest table has data, drop it (TruncateInsert on an empty table lets SyncDB mirror the source type).";
            }
            if (msg.IndexOf("ColumnMapping", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                kind = "mapping";
                return "Source column name does not exist in destination table. Names must match (use AS aliases or an INSERT column list).";
            }
            if (n == 2627 || n == 2601) { kind = "pk"; return "Duplicate key in destination. Use TruncateInsert / DeleteInsert or clear the destination first."; }
            if (n == 515) { kind = "null"; return "NULL into a NOT NULL destination column."; }
            return "Unclassified error" + (n != 0 ? " (SQL " + n + ")" : "") + ": " + msg;
        }

        /// <summary>Change settings for the next attempt. Returns false when retrying makes no sense.</summary>
        private static bool ApplyFallback(JobStep c, string kind)
        {
            // Append may already have written rows -> retry would duplicate them. Only safe modes retry.
            if (c.Mode == WriteMode.Append) return false;

            if (kind == "memory" || kind == "timeout" || kind == "log-full")
            {
                if (c.Buffer == BufferMode.Auto || c.Buffer == BufferMode.Ram) c.Buffer = BufferMode.Stream;
                else if (c.Buffer == BufferMode.Stream && LocalFreeGb() > 2.0) c.Buffer = BufferMode.Disk;
                c.BatchSize = c.BatchSize <= 0 ? 5000 : Math.Max(100, c.BatchSize / 2);
                c.MaxThreads = 1;
                return true;
            }
            if (kind == "local-disk") { c.Buffer = BufferMode.Stream; return true; }
            if (kind == "deadlock") { c.MaxThreads = 1; return true; }
            return false;      // dest-full / conversion / mapping / pk ... cannot be fixed by retrying
        }

        /// <summary>Disk / filegroup / log full: also written to logsyncdb.txt (data folder) and to the normal daily log.</summary>
        private static void WriteSpaceAlert(string kind, JobStep st, Exception ex, string advice)
        {
            string text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  [" + kind.ToUpperInvariant() + "]  step='" + (st.Name ?? "") +
                "'  dest=" + st.DestTable + Environment.NewLine + "    error : " + ex.Message.Replace("\r", " ").Replace("\n", " ") +
                Environment.NewLine + "    advice: " + advice + Environment.NewLine + Environment.NewLine;
            AppLog.Error("-", "SPACE PROBLEM [" + kind + "] -> see logsyncdb.txt. " + advice);
            try
            {
                Directory.CreateDirectory(Audit.LogDir);
                File.AppendAllText(Path.Combine(Audit.LogDir, "logsyncdb.txt"), text, new UTF8Encoding(true));
            }
            catch { }
        }

        private static double LocalFreeGb()
        {
            try { return new DriveInfo(Path.GetPathRoot(Path.GetFullPath(AppConfig.DataDir))).AvailableFreeSpace / 1073741824.0; }
            catch { return 0; }
        }

        [ThreadStatic] private static double _lastEstMb;   // estimated size (MB) of the source table, set by ResolveBufferMode

        /// <summary>Primary key columns of a table on the given connection ("a,b"), "" if none / unknown.</summary>
        public static string GetPrimaryKeyColumns(string conn, string table)
        {
            string key = (conn ?? "") + "|" + (table ?? "");
            lock (SchemaCacheLock)
            {
                string hit;
                if (SchemaCache.TryGetValue(key, out hit)) return hit;
            }
            try
            {
                List<string> cols = new List<string>();
                using (SqlConnection c = new SqlConnection(conn))
                {
                    c.Open();
                    using (SqlCommand q = new SqlCommand(
                        "SELECT c.name FROM sys.indexes i JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id " +
                        "JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id " +
                        "WHERE i.object_id = OBJECT_ID(@n) AND i.is_primary_key = 1 ORDER BY ic.key_ordinal", c))
                    {
                        q.Parameters.AddWithValue("@n", NormalizeTableName(table));
                        using (SqlDataReader rd = q.ExecuteReader())
                            while (rd.Read()) cols.Add(rd.GetString(0));
                    }
                }
                string result = string.Join(",", cols.ToArray());
                lock (SchemaCacheLock)
                {
                    SchemaCache[key] = result;
                }
                return result;
            }
            catch { return ""; }
        }

        /// <summary>Number of parallel SOURCE readers. 0 = Auto (big tables only). Only for RAM mode and a simple SELECT.</summary>
        private static int ResolveSourceThreads(JobStep step, string selectSql)
        {
            if (step.SourceThreads == 1) return 1;
            string t = (selectSql ?? "").Trim().TrimEnd(';');
            if (Regex.IsMatch(t, @"\bORDER\s+BY\b|\bINTO\b|;", RegexOptions.IgnoreCase))
            {
                if (step.SourceThreads > 1) AppLog.Warn("-", "Source threads ignored for '" + (step.Name ?? "") + "': the SELECT has ORDER BY / INTO / several statements (single reader used).");
                return 1;
            }
            int cpu = Math.Max(1, Environment.ProcessorCount);
            if (step.SourceThreads > 1) return Math.Min(step.SourceThreads, Math.Max(cpu * 2, 8));
            return _lastEstMb >= 64 ? Math.Min(cpu, 4) : 1;
        }

        /// <summary>Reads the source with n parallel connections; every row belongs to exactly one partition (hash of the PK, or of the whole row).
        /// Returns null when it is not possible (caller then uses one reader).</summary>
        private static DataTable TryParallelFill(JobStep step, string srcConn, string selectSql, int n, int timeout)
        {
            try
            {
                string inner = selectSql.Trim().TrimEnd(';');
                string keys = "*";
                if (string.IsNullOrWhiteSpace(step.SqlCommand) && !string.IsNullOrWhiteSpace(step.SourceTable))
                {
                    string pk = GetPrimaryKeyColumns(srcConn, step.SourceTable);
                    if (pk.Length > 0)
                    {
                        List<string> q = new List<string>();
                        foreach (string k in pk.Split(',')) q.Add("[" + k.Replace("]", "]]") + "]");
                        keys = string.Join(",", q.ToArray());
                    }
                }
                DataTable[] parts = new DataTable[n];
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = n;
                po.CancellationToken = _tok;
                Parallel.For(0, n, po, k =>
                {
                    using (SqlConnection c = new SqlConnection(srcConn))
                    {
                        c.Open();
                        string sql = "SELECT * FROM (" + inner + ") AS __p WHERE (CHECKSUM(" + keys + ") & 2147483647) % " + n + " = " + k;
                        using (SqlCommand cmd = new SqlCommand(sql, c))
                        {
                            cmd.CommandTimeout = timeout;
                            DataTable dt = new DataTable();
                            using (SqlDataAdapter da = new SqlDataAdapter(cmd)) da.Fill(dt);
                            parts[k] = dt;
                        }
                    }
                });
                DataTable result = parts[0];
                long rows = result.Rows.Count;
                for (int i = 1; i < n; i++) { rows += parts[i].Rows.Count; result.Merge(parts[i]); parts[i] = null; }
                AppLog.Info("-", "Source read with " + n + " parallel readers (" + (keys == "*" ? "row hash" : "PK hash") + "): " + rows + " row(s).");
                return result;
            }
            catch (OperationCanceledException) { throw; }
            catch (AggregateException ae)
            {
                foreach (Exception ie in ae.Flatten().InnerExceptions)
                    if (ie is OperationCanceledException) throw new OperationCanceledException();
                AppLog.Warn("-", "Parallel source read not possible (" + ae.Flatten().InnerExceptions[0].Message + ") - using one reader.");
                return null;
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "Parallel source read not possible (" + ex.Message + ") - using one reader.");
                return null;
            }
        }

        /// <summary>Streams a table / view to a CSV file (UTF-8 with BOM). Returns the number of rows.</summary>
        public static long ExportTableCsv(string conn, string schema, string table, string path, int timeout)
        {
            long n = 0;
            using (SqlConnection c = new SqlConnection(conn))
            {
                c.Open();
                string sql = "SELECT * FROM [" + schema.Replace("]", "]]") + "].[" + table.Replace("]", "]]") + "]";
                using (SqlCommand cmd = new SqlCommand(sql, c))
                {
                    cmd.CommandTimeout = timeout;
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    using (StreamWriter w = new StreamWriter(path, false, new UTF8Encoding(true), 1 << 16))
                    {
                        int fc = rd.FieldCount;
                        for (int i = 0; i < fc; i++) { if (i > 0) w.Write(','); w.Write(CsvCell(rd.GetName(i))); }
                        w.Write("\r\n");
                        while (rd.Read())
                        {
                            for (int i = 0; i < fc; i++)
                            {
                                if (i > 0) w.Write(',');
                                if (rd.IsDBNull(i)) continue;
                                object v = rd.GetValue(i);
                                string t;
                                if (v is byte[]) t = "0x" + BitConverter.ToString((byte[])v).Replace("-", "");
                                else if (v is DateTime) t = ((DateTime)v).ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture);
                                else if (v is IFormattable) t = ((IFormattable)v).ToString(null, System.Globalization.CultureInfo.InvariantCulture);
                                else t = Convert.ToString(v);
                                w.Write(CsvCell(t));
                            }
                            w.Write("\r\n");
                            n++;
                        }
                    }
                }
            }
            return n;
        }

        private static string CsvCell(string s)
        {
            if (s == null) return "";
            if (s.IndexOfAny(new char[] { ',', '"', '\r', '\n' }) >= 0) return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }

        /// <summary>Index policy: Off / after every run / every N days. Returns a message for the result + log ("" = nothing to say).</summary>
        private static string MaybeRebuildIndexes(JobStep c, string dstConn, int timeout)
        {
            IndexRebuildKind mode = c.IndexRebuild;
            if (mode == IndexRebuildKind.Off && c.RebuildIndexesAfter) mode = IndexRebuildKind.AfterEveryRun;
            if (mode == IndexRebuildKind.Off) return "";

            int days = Math.Max(1, c.IndexRebuildDays);
            if (mode == IndexRebuildKind.EveryNDays && c.IndexLastRebuildUtc.HasValue)
            {
                DateTime due = c.IndexLastRebuildUtc.Value.AddDays(days);
                if (DateTime.UtcNow < due)
                {
                    string m = "Index rebuild: not due yet. Last " + c.IndexLastRebuildUtc.Value.ToLocalTime().ToString("yyyy-MM-dd HH:mm") +
                               ", next " + due.ToLocalTime().ToString("yyyy-MM-dd HH:mm") + " (every " + days + " day(s)).";
                    AppLog.Info("-", m);
                    return m;
                }
            }
            try
            {
                System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();
                AppLog.Info("-", "Index rebuild started on " + c.DestTable + " ...");
                int n = RebuildDestIndexes(dstConn, c.DestTable, timeout);
                sw.Stop();
                if (n == 0)
                {
                    string m0 = "Index rebuild: " + c.DestTable + " has no indexes - nothing to rebuild.";
                    AppLog.Info("-", m0);
                    return m0;
                }
                c.IndexLastRebuildUtc = DateTime.UtcNow;
                string m1 = "Indexes rebuilt on " + c.DestTable + ": " + n + " index(es), " + JobHistory.FormatSeconds(sw.ElapsedMilliseconds) + ", finished " +
                            DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +
                            (mode == IndexRebuildKind.EveryNDays ? ". Next rebuild after " + DateTime.Now.AddDays(days).ToString("yyyy-MM-dd HH:mm") : "") + ".";
                AppLog.Info("-", m1);
                Audit.Write("INDEX_REBUILD", c.DestTable + " | " + n + " index(es) | " + JobHistory.FormatSeconds(sw.ElapsedMilliseconds));
                return m1;
            }
            catch (Exception ix)
            {
                string m2 = "Index rebuild FAILED on " + c.DestTable + ": " + ix.Message;
                AppLog.Warn("-", m2);
                return m2;
            }
        }

        /// <summary>Replaces the old ExecuteTransfer (renamed ExecuteTransferCore): diagnose, log advice, retry safely.</summary>
        private static RunResult ExecuteTransfer(JobStep step, string srcConn, string dstConn, int timeout)
        {
            // Source table missing → skip (do not fail the whole multi-table job)
            if (string.IsNullOrWhiteSpace(step.SqlCommand) && !string.IsNullOrWhiteSpace(step.SourceTable))
            {
                try
                {
                    if (!SourceTableExists(srcConn, step.SourceTable, timeout))
                    {
                        string msg = "SKIPPED: source table does not exist: " + step.SourceTable +
                            " (check Database on Source connection / tab 2).";
                        AppLog.Warn("-", msg);
                        return new RunResult { Ok = true, Rows = 0, Message = msg };
                    }
                }
                catch (Exception ex)
                {
                    AppLog.Warn("-", "Source table check: " + ex.Message);
                }
            }

            JobStep c = JsonConvert.DeserializeObject<JobStep>(JsonConvert.SerializeObject(step));
            c.SizeHintTable = step.SizeHintTable;
            long? ctVer = null;
            for (int attempt = 1; ; attempt++)
            {
                try
                {
                    // Smart Delta (RV/COL/HASH + batched merge) for Merge/SyncChanges with keys
                    RunResult smart = TryExecuteSmartDelta(c, srcConn, dstConn, timeout);
                    if (smart != null)
                    {
                        step.IncrementalLastValue = c.IncrementalLastValue;
                        step.LastHashFullUtc = c.LastHashFullUtc;
                        step.DeltaFingerprint = c.DeltaFingerprint;
                        step.ChangeTrackingVersion = c.ChangeTrackingVersion;
                        step.CdcLastLsn = c.CdcLastLsn;
                        string im0 = MaybeRebuildIndexes(c, dstConn, timeout);
                        if (im0.Length > 0) smart.Message = (smart.Message ?? "") + " | " + im0;
                        step.IndexLastRebuildUtc = c.IndexLastRebuildUtc;
                        return smart;
                    }
                    if (c.UseChangeTracking)
                        TryBuildChangeTrackingSelect(c, srcConn, timeout, out ctVer); // refresh version stamp
                    RunResult res = ExecuteTransferCore(c, srcConn, dstConn, timeout);
                    string im = MaybeRebuildIndexes(c, dstConn, timeout);
                    if (im.Length > 0) res.Message = (res.Message ?? "") + " | " + im;
                    step.IndexLastRebuildUtc = c.IndexLastRebuildUtc;
                    step.IncrementalLastValue = c.IncrementalLastValue;
                    if (c.UseChangeTracking && ctVer.HasValue)
                    {
                        CommitChangeTrackingVersion(c, ctVer);
                        step.ChangeTrackingVersion = c.ChangeTrackingVersion;
                    }
                    if (c.UseCdc)
                    {
                        CommitCdcLsn(c);
                        step.CdcLastLsn = c.CdcLastLsn;
                    }
                    return res;
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    // Enrich "Invalid object name" so the UI shows which side/server was queried
                    string msg = ex.Message ?? "";
                    if (msg.IndexOf("Invalid object name", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        string srcInfo = "";
                        string dstInfo = "";
                        try { var b = new System.Data.SqlClient.SqlConnectionStringBuilder(srcConn); srcInfo = (b.DataSource ?? "") + " / " + (b.InitialCatalog ?? ""); } catch { }
                        try { var b = new System.Data.SqlClient.SqlConnectionStringBuilder(dstConn); dstInfo = (b.DataSource ?? "") + " / " + (b.InitialCatalog ?? ""); } catch { }
                        msg = msg + " | SourceTable=" + (c.SourceTable ?? "") + " on [" + srcInfo + "]"
                            + " | DestTable=" + (c.DestTable ?? "") + " on [" + dstInfo + "]";
                        ex = new Exception(msg, ex);
                    }
                    string kind;
                    string advice = Diagnose(ex, srcConn, dstConn, c, out kind);
                    AppLog.Error("-", "Transfer '" + c.Name + "' failed (attempt " + attempt + "): " + ex.Message);
                    AppLog.Warn("-", "DIAGNOSIS [" + kind + "]: " + advice);
                    if (kind == "dest-full" || kind == "log-full" || kind == "local-disk")
                        WriteSpaceAlert(kind, c, ex, advice);
                    if (attempt >= 3 || !ApplyFallback(c, kind))
                    {
                        try
                        {
                            // Durable outbox: a real SQL replay of this one job/step (no passwords stored).
                            // Suppressed while the item is itself being replayed, to avoid an infinite chain.
                            AppConfig cfg = _currentConfig;
                            if (!_suppressOutbox && cfg != null && cfg.OutboxEnabled &&
                                !string.IsNullOrEmpty(_currentJobId))
                            {
                                OutboxStore.EnqueueFailure(_currentJobId, _currentJobName, step, cfg, ex.Message);
                            }
                            string topic = "syncdb.changes";
                            if (cfg != null && !string.IsNullOrWhiteSpace(cfg.LocalStreamTopic))
                                topic = cfg.LocalStreamTopic.Trim();
                            LocalStream.Append(topic, c.DestTable ?? c.Name, "transfer-fail",
                                _currentJobName ?? "-", step.Name, ex.Message);
                        }
                        catch (Exception outboxEx)
                        {
                            AppLog.Warn("-", "Outbox enqueue failed: " + outboxEx.Message);
                        }
                        throw new Exception(ex.Message + "  >> " + advice, ex);
                    }
                    AppLog.Warn("-", "AUTO-RETRY " + (attempt + 1) + ": memory mode=" + c.Buffer + ", batch=" + c.BatchSize + ", threads=" + c.MaxThreads);
                }
            }
        }
    }
}
