using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SyncDB
{
    public sealed class OperationsForm : Form
    {
        private readonly AppConfig _cfg;
        private readonly Action _changed;
        private ComboBox _jobs;
        private TextBox _summary;
        private Label _status;
        private SyncJob SelectedJob { get { return _jobs == null ? null : _jobs.SelectedItem as SyncJob; } }

        public OperationsForm(AppConfig cfg, Action changed)
        {
            _cfg = cfg;
            _changed = changed;
            Text = "SyncDB — Dashboard / Preflight / Reports";
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(980, 650);
            MinimumSize = new Size(820, 500);
            try { Icon = MakeDashboardIcon(); } catch { }
            BuildUi();
            Theme.Apply(this);
            CompactMainButtons(this);
            LoadJobs();
            RefreshDashboard();
        }

        private static Icon MakeDashboardIcon()
        {
            Bitmap bmp = new Bitmap(32, 32);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (SolidBrush bg = new SolidBrush(Color.FromArgb(75, 55, 145)))
                    FillRoundedRect(g, bg, 2, 2, 28, 28, 6);
                using (Pen axis = new Pen(Color.White, 1.6f))
                using (SolidBrush b1 = new SolidBrush(Color.FromArgb(100, 220, 170)))
                using (SolidBrush b2 = new SolidBrush(Color.FromArgb(255, 205, 80)))
                using (SolidBrush b3 = new SolidBrush(Color.FromArgb(100, 190, 255)))
                {
                    g.DrawLine(axis, 7, 24, 26, 24);
                    g.DrawLine(axis, 7, 24, 7, 8);
                    g.FillRectangle(b1, 10, 17, 4, 7);
                    g.FillRectangle(b2, 16, 12, 4, 12);
                    g.FillRectangle(b3, 22, 8, 4, 16);
                }
            }
            IntPtr h = bmp.GetHicon();
            Icon source = Icon.FromHandle(h);
            Icon result = (Icon)source.Clone();
            try { DestroyIcon(h); } catch { }
            bmp.Dispose();
            return result;
        }

        private static void FillRoundedRect(Graphics g, Brush brush, int x, int y, int w, int h, int r)
        {
            using (GraphicsPath p = new GraphicsPath())
            {
                p.AddArc(x, y, r, r, 180, 90);
                p.AddArc(x + w - r, y, r, r, 270, 90);
                p.AddArc(x + w - r, y + h - r, r, r, 0, 90);
                p.AddArc(x, y + h - r, r, r, 90, 90);
                p.CloseFigure();
                g.FillPath(brush, p);
            }
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool DestroyIcon(IntPtr handle);

        private void BuildUi()
        {
            Panel top = new Panel { Dock = DockStyle.Top, Height = 42, Padding = new Padding(8) };
            top.Controls.Add(new Label { Text = "Job:", AutoSize = true, Location = new Point(8, 11) });
            _jobs = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 300, Location = new Point(45, 7), Cursor = Cursors.Hand };
            _jobs.SelectedIndexChanged += (s, e) => RefreshDashboard();
            top.Controls.Add(_jobs);
            Button refresh = new Button { Text = "Refresh", AutoSize = true, Location = new Point(355, 6), Cursor = Cursors.Hand };
            refresh.Click += (s, e) => { LoadJobs(); RefreshDashboard(); };
            top.Controls.Add(refresh);
            Button pause = new Button { Text = "Pause / Resume", AutoSize = true, Location = new Point(435, 6), Cursor = Cursors.Hand };
            pause.Click += (s, e) => TogglePause();
            top.Controls.Add(pause);
            Button preflight = new Button { Text = "Run preflight test", AutoSize = true, Location = new Point(555, 6), Cursor = Cursors.Hand };
            preflight.Click += async (s, e) => await RunPreflight();
            top.Controls.Add(preflight);

            FlowLayoutPanel actions = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 42, Padding = new Padding(8), WrapContents = false };
            Button csv = new Button { Text = "Export Excel CSV", AutoSize = true, Cursor = Cursors.Hand };
            csv.Click += (s, e) => ExportCsv();
            actions.Controls.Add(csv);
            Button pdf = new Button { Text = "Print / PDF", AutoSize = true, Cursor = Cursors.Hand };
            pdf.Click += (s, e) => PrintReport();
            actions.Controls.Add(pdf);
            Button conflict = new Button { Text = "Conflict policy", AutoSize = true, Cursor = Cursors.Hand };
            conflict.Click += (s, e) => EditConflictPolicy();
            actions.Controls.Add(conflict);
            Button warn = new Button { Text = "Check CT / CDC", AutoSize = true, Cursor = Cursors.Hand };
            warn.Click += async (s, e) => await CheckTracking();
            actions.Controls.Add(warn);
            _status = new Label { AutoSize = true, ForeColor = Color.DarkGreen, Margin = new Padding(16, 8, 0, 0) };
            actions.Controls.Add(_status);

            _summary = new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, Font = new Font("Consolas", 10f), BackColor = Color.White };
            Controls.Add(_summary);
            Controls.Add(actions);
            Controls.Add(top);
        }

        /// <summary>Keeps the Dashboard toolbar compact after the global theme is applied.</summary>
        private static void CompactMainButtons(Control root)
        {
            foreach (Control child in root.Controls)
            {
                Button b = child as Button;
                if (b != null)
                {
                    b.MinimumSize = new Size(0, 26);
                    b.Height = 26;
                    b.Padding = new Padding(5, 0, 5, 0);
                }
                if (child.HasChildren) CompactMainButtons(child);
            }
        }

        private void LoadJobs()
        {
            string keep = SelectedJob == null ? "" : SelectedJob.Id;
            _jobs.Items.Clear();
            if (_cfg != null && _cfg.Jobs != null)
                foreach (SyncJob j in _cfg.Jobs) _jobs.Items.Add(j);
            _jobs.DisplayMember = "Name";
            for (int i = 0; i < _jobs.Items.Count; i++)
                if (((SyncJob)_jobs.Items[i]).Id == keep) { _jobs.SelectedIndex = i; return; }
            if (_jobs.Items.Count > 0) _jobs.SelectedIndex = 0;
        }

        private void RefreshDashboard()
        {
            StringBuilder sb = new StringBuilder();
            SyncJob selected = SelectedJob;
            sb.AppendLine("SYNCDB STATISTICAL DASHBOARD");
            sb.AppendLine(new string('=', 76));
            sb.AppendLine("Generated: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine();
            if (_cfg != null && _cfg.Jobs != null)
            {
                foreach (SyncJob j in _cfg.Jobs)
                {
                    List<HistoryRun> runs = JobHistory.Load(j.Name);
                    long rows = 0, errors = 0; DateTime last = DateTime.MinValue; string lastStatus = "Never run";
                    foreach (HistoryRun r in runs)
                    {
                        rows += r.Rows;
                        if (!string.Equals(r.Status, "OK", StringComparison.OrdinalIgnoreCase)) errors++;
                        if (r.Time > last) { last = r.Time; lastStatus = r.Status; }
                    }
                    sb.AppendLine(string.Format("{0,-28} last={1,-19} status={2,-6} rows={3,12:N0} errors={4,4} {5}",
                        Cut(j.Name, 28), last == DateTime.MinValue ? "-" : last.ToString("yyyy-MM-dd HH:mm"), lastStatus, rows, errors,
                        j.Paused ? "[PAUSED]" : (j.Enabled ? "[enabled]" : "[disabled]")));
                }
            }
            if (selected != null)
            {
                sb.AppendLine();
                sb.AppendLine("SELECTED JOB");
                sb.AppendLine("Name: " + selected.Name);
                sb.AppendLine("Schedule: " + selected.Schedule + (selected.Schedule == ScheduleKind.RealtimeAsync ? " / every " + selected.IntervalValue + " sec" : ""));
                sb.AppendLine("Pause: " + (selected.Paused ? "YES — " + selected.PauseReason : "NO"));
                sb.AppendLine("Conflict policy: " + selected.ConflictPolicy + (string.IsNullOrEmpty(selected.ConflictColumn) ? "" : " / " + selected.ConflictColumn));
                sb.AppendLine("Last status: " + (selected.LastStatus ?? "Never run"));
                sb.AppendLine("Last rows: " + selected.LastRows.ToString("N0"));
                sb.AppendLine("Last run: " + (selected.LastRunUtc.HasValue ? selected.LastRunUtc.Value.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss") : "never"));
            }
            _summary.Text = sb.ToString();
        }

        private void TogglePause()
        {
            SyncJob j = SelectedJob;
            if (j == null) return;
            if (!j.Paused)
            {
                string reason, logNote;
                if (!ShowMaintenanceDialog(out reason, out logNote)) return;
                j.Paused = true; j.PauseReason = reason ?? "";
                Audit.Write("JOB_PAUSE", j.Name + " | " + j.PauseReason);
                if (!string.IsNullOrWhiteSpace(logNote))
                {
                    Audit.Write("MANUAL_NOTE", j.Name + " | " + logNote.Trim());
                    try { AppLog.Info(j.Name, "Manual note: " + logNote.Trim()); } catch { }
                }
            }
            else
            {
                j.Paused = false; j.PauseReason = "";
                Audit.Write("JOB_RESUME", j.Name);
            }
            _cfg.Save(); if (_changed != null) _changed(); LoadJobs(); RefreshDashboard();
            _status.Text = j.Paused ? "Job paused." : "Job resumed.";
        }

        /// <summary>Maintenance dialog: clear guide + pause reason + optional manual log note with light placeholders.</summary>
        private bool ShowMaintenanceDialog(out string reason, out string logNote)
        {
            reason = ""; logNote = "";
            using (Form f = new Form { Text = "Maintenance — Pause Job", Size = new Size(500, 360), StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false })
            {
                try { f.Icon = MakeDashboardIcon(); } catch { }

                Label guide = new Label
                {
                    Text = "توقف موقت این Job تا وقتی Resume کنید.\n"
                         + "دلیل توقف در داشبورد ذخیره می‌شود.\n"
                         + "می‌توانید یک یادداشت دستی هم برای لاگ بنویسید (اختیاری).",
                    Left = 12, Top = 10, Width = 460, Height = 50
                };

                Label lblReason = new Label { Text = "دلیل توقف (اختیاری):", Left = 12, Top = 66, AutoSize = true };
                TextBox txtReason = new TextBox { Left = 12, Top = 84, Width = 460 };
                SetWatermark(txtReason, "مثلاً: توقف برای به‌روزرسانی دیتابیس یا تعمیر");

                Label lblNote = new Label { Text = "یادداشت لاگ دستی (اختیاری):", Left = 12, Top = 116, AutoSize = true };
                TextBox txtNote = new TextBox { Left = 12, Top = 134, Width = 460, Height = 56, Multiline = true, ScrollBars = ScrollBars.Vertical };
                SetWatermark(txtNote, "مثلاً: مشکل اتصال موقت / منتظر تأیید مدیر");

                // --- Manual log settings ---
                Label lblLog = new Label { Text = "تنظیم لاگ (نگهداری بر اساس روز):", Left = 12, Top = 198, AutoSize = true };
                NumericUpDown numDays = new NumericUpDown { Left = 12, Top = 216, Width = 70, Minimum = 0, Maximum = 1095, Value = Math.Max(0, Math.Min(1095, _cfg.LogRetentionDays)) };
                Label lblDays = new Label { Text = "روز  (۰ = توقف کامل لاگ)", Left = 88, Top = 218, AutoSize = true };
                CheckBox chkStop = new CheckBox { Text = "Stop — اصلاً لاگ نگیر", Left = 250, Top = 216, AutoSize = true, Checked = _cfg.LogRetentionDays <= 0 };
                chkStop.CheckedChanged += (s, e) => { numDays.Enabled = !chkStop.Checked; if (chkStop.Checked) numDays.Value = 0; };
                numDays.ValueChanged += (s, e) => { if (numDays.Value > 0) chkStop.Checked = false; };

                Button openLog = new Button { Text = "باز کردن پوشه لاگ", Left = 12, Top = 252, Width = 140 };
                openLog.Click += (s, e) =>
                {
                    try
                    {
                        string dir = Audit.LogDir;
                        if (!string.IsNullOrEmpty(dir))
                        {
                            Directory.CreateDirectory(dir);
                            Process.Start("explorer.exe", dir);
                        }
                    }
                    catch { }
                };

                Button ok = new Button { Text = "توقف", DialogResult = DialogResult.OK, Left = 310, Top = 250, Width = 75 };
                Button cancel = new Button { Text = "انصراف", DialogResult = DialogResult.Cancel, Left = 395, Top = 250, Width = 75 };

                f.Controls.Add(guide);
                f.Controls.Add(lblReason); f.Controls.Add(txtReason);
                f.Controls.Add(lblNote); f.Controls.Add(txtNote);
                f.Controls.Add(lblLog); f.Controls.Add(numDays); f.Controls.Add(lblDays); f.Controls.Add(chkStop);
                f.Controls.Add(openLog); f.Controls.Add(ok); f.Controls.Add(cancel);
                f.AcceptButton = ok; f.CancelButton = cancel;

                if (f.ShowDialog(this) != DialogResult.OK) return false;
                reason = GetWatermarkValue(txtReason);
                logNote = GetWatermarkValue(txtNote);

                // Apply manual log setting
                int days = chkStop.Checked ? 0 : (int)numDays.Value;
                _cfg.LogRetentionDays = days;
                try { AppLog.Configure(_cfg.EffectiveLogFolder, days <= 0 ? 0 : days); } catch { }
                _cfg.Save();
                Audit.Write("LOG_SETTING", days <= 0 ? "logging stopped" : "keep " + days + " days");

                return true;
            }
        }

        /// <summary>Shows a light-gray placeholder that disappears when the user clicks/types.</summary>
        private static void SetWatermark(TextBox tb, string watermark)
        {
            tb.ForeColor = Color.Gray;
            tb.Text = watermark;
            tb.Tag = watermark;
            tb.Enter += (s, e) =>
            {
                if (tb.ForeColor == Color.Gray && tb.Text == watermark)
                {
                    tb.Text = "";
                    tb.ForeColor = SystemColors.WindowText;
                }
            };
            tb.Leave += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(tb.Text))
                {
                    tb.Text = watermark;
                    tb.ForeColor = Color.Gray;
                }
            };
        }

        private static string GetWatermarkValue(TextBox tb)
        {
            if (tb.ForeColor == Color.Gray) return "";
            return (tb.Text ?? "").Trim();
        }

        private async Task RunPreflight()
        {
            SyncJob j = SelectedJob;
            if (j == null) return;
            _status.Text = "Running preflight...";
            string result = await Task.Run(() => Preflight(j));
            _summary.Text = result + "\r\n\r\n" + _summary.Text;
            _status.Text = "Preflight complete.";
        }

        private string Preflight(SyncJob j)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("PREFLIGHT TEST — no destination writes were performed");
            sb.AppendLine(new string('-', 76));
            string src = _cfg.ResolveSourceConnectionString();
            string dst = _cfg.ResolveDestConnectionString();
            sb.AppendLine("Source connection: " + Engine.TestConnection(src));
            sb.AppendLine("Destination connection: " + Engine.TestConnection(dst));
            j.EnsureSteps();
            foreach (JobStep st in j.Steps)
            {
                if (st == null || !st.Enabled) continue;
                sb.AppendLine(); sb.AppendLine("Step " + st.StepId + ": " + st.Name + " / " + st.Type);
                if (st.Type != StepType.Transfer) { sb.AppendLine("  SQL/API validation: configured; execution not performed."); continue; }
                if (string.IsNullOrWhiteSpace(st.SourceTable) || string.IsNullOrWhiteSpace(st.DestTable)) { sb.AppendLine("  FAIL: SourceTable or DestTable is empty."); continue; }
                try
                {
                    long n1 = CountRows(src, st.SourceTable);
                    long n2 = CountRows(dst, st.DestTable);
                    sb.AppendLine("  Source rows: " + n1.ToString("N0") + " | Destination rows: " + n2.ToString("N0"));
                    sb.AppendLine("  Mode: " + st.Mode + " | Keys: " + (st.KeyColumns ?? "(none)"));
                    if ((st.Mode == WriteMode.MergeUpsert || st.Mode == WriteMode.SyncChanges) && string.IsNullOrWhiteSpace(st.KeyColumns)) sb.AppendLine("  WARN: merge/sync mode has no key columns.");
                }
                catch (Exception ex) { sb.AppendLine("  FAIL: " + ex.Message); }
            }
            return sb.ToString();
        }

        private static long CountRows(string cs, string table)
        {
            using (SqlConnection c = new SqlConnection(cs)) { c.Open(); using (SqlCommand q = new SqlCommand("SELECT COUNT_BIG(*) FROM " + Normalize(table), c)) { q.CommandTimeout = 60; return Convert.ToInt64(q.ExecuteScalar()); } }
        }
        private static string Normalize(string t) { return t.Replace("'", "''").Trim(); }

        private async Task CheckTracking()
        {
            SyncJob j = SelectedJob;
            if (j == null) return;
            _status.Text = "Checking Change Tracking / CDC...";
            string src = _cfg.ResolveSourceConnectionString();
            string result = await Task.Run(() => TrackingReport(j, src));
            _summary.Text = result + "\r\n\r\n" + _summary.Text;
            _status.Text = "Tracking check complete.";
        }
        private string TrackingReport(SyncJob j, string cs)
        {
            StringBuilder sb = new StringBuilder(); sb.AppendLine("CHANGE TRACKING / CDC HEALTH CHECK"); sb.AppendLine(new string('-', 76));
            j.EnsureSteps();
            foreach (JobStep st in j.Steps)
            {
                if (st == null || st.Type != StepType.Transfer) continue;
                if (!st.UseChangeTracking && !st.UseCdc) continue;
                try
                {
                    using (SqlConnection c = new SqlConnection(cs))
                    {
                        c.Open();
                        if (st.UseChangeTracking)
                        {
                            object db = new SqlCommand("SELECT is_auto_cleanup_on FROM sys.change_tracking_databases WHERE database_id=DB_ID()", c).ExecuteScalar();
                            object table = new SqlCommand("SELECT COUNT(*) FROM sys.change_tracking_tables WHERE object_id=OBJECT_ID('" + Normalize(st.SourceTable) + "')", c).ExecuteScalar();
                            sb.AppendLine(st.Name + " CT: database=" + (db == null ? "OFF / not enabled" : "ON") + " table=" + (Convert.ToInt32(table) > 0 ? "ON" : "OFF"));
                            if (st.ChangeTrackingVersion.HasValue) sb.AppendLine("  watermark=" + st.ChangeTrackingVersion.Value + " (old version can be invalid after retention cleanup)");
                        }
                        if (st.UseCdc)
                        {
                            object db = new SqlCommand("SELECT is_cdc_enabled FROM sys.databases WHERE database_id=DB_ID()", c).ExecuteScalar();
                            sb.AppendLine(st.Name + " CDC: database=" + (Convert.ToInt32(db ?? 0) == 1 ? "ON" : "OFF / not enabled") + " instance depends on source schema/table");
                            if (string.IsNullOrEmpty(st.CdcLastLsn)) sb.AppendLine("  WARN: no saved LSN; next run will establish a baseline.");
                        }
                    }
                }
                catch (Exception ex) { sb.AppendLine(st.Name + " FAIL: " + ex.Message); }
            }
            sb.AppendLine("If CT retention has removed the saved version, the next run should be treated as a fresh baseline.");
            return sb.ToString();
        }

        private void EditConflictPolicy()
        {
            SyncJob j = SelectedJob; if (j == null) return;
            Form f = new Form { Text = "Conflict Resolution", Size = new Size(460, 230), StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false };
            try { f.Icon = MakeDashboardIcon(); } catch { }

            Label guide = new Label
            {
                Text = "اگر یک رکورد هم در مبدأ و هم در مقصد تغییر کرده باشد،\n"
                     + "کدام نسخه نگه داشته شود؟",
                Left = 18, Top = 10, Width = 410, Height = 36
            };

            Label lblPolicy = new Label { Text = "سیاست حل تعارض:", Left = 18, Top = 50, AutoSize = true };
            ComboBox c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Left = 18, Top = 68, Width = 410 };
            c.Items.AddRange(new object[] { "Source wins (مبدأ برنده)", "Destination wins (مقصد برنده)", "Latest by column (جدیدتر بر اساس ستون)", "Manual review (بررسی دستی)" });
            c.SelectedIndex = (int)j.ConflictPolicy;

            Label lblCol = new Label { Text = "نام ستون تاریخ/زمان (فقط برای Latest by column):", Left = 18, Top = 100, AutoSize = true };
            TextBox col = new TextBox { Left = 18, Top = 118, Width = 410 };
            string existing = j.ConflictColumn ?? "";
            if (string.IsNullOrWhiteSpace(existing))
                SetWatermark(col, "مثلاً: ModifiedDate یا UpdatedAt");
            else
                col.Text = existing;

            Button ok = new Button { Text = "ذخیره", DialogResult = DialogResult.OK, Left = 350, Top = 155, Width = 78 };
            f.Controls.Add(guide);
            f.Controls.Add(lblPolicy); f.Controls.Add(c);
            f.Controls.Add(lblCol); f.Controls.Add(col);
            f.Controls.Add(ok); f.AcceptButton = ok;

            if (f.ShowDialog(this) == DialogResult.OK)
            {
                j.ConflictPolicy = (ConflictResolutionPolicy)c.SelectedIndex;
                j.ConflictColumn = GetWatermarkValue(col);
                _cfg.Save(); if (_changed != null) _changed(); RefreshDashboard();
            }
            f.Dispose();
        }

        private void ExportCsv()
        {
            using (SaveFileDialog d = new SaveFileDialog { Filter = "Excel CSV|*.csv", FileName = "syncdb-report.csv" })
                if (d.ShowDialog(this) == DialogResult.OK) { File.WriteAllText(d.FileName, BuildCsv(), Encoding.UTF8); _status.Text = "CSV exported."; }
        }
        private string BuildCsv()
        {
            StringBuilder sb = new StringBuilder(); sb.AppendLine("Job,Time,Status,Rows,ElapsedMs,Source,Tables,TableList,Message");
            if (_cfg != null && _cfg.Jobs != null) foreach (SyncJob j in _cfg.Jobs) foreach (HistoryRun r in JobHistory.Load(j.Name))
                sb.AppendLine(string.Join(",", Q(j.Name), Q(r.Time.ToString("s")), Q(r.Status), r.Rows.ToString(), r.ElapsedMs.ToString(), Q(r.Source), r.Tables.ToString(), Q(r.TableList), Q(r.Message)));
            return sb.ToString();
        }
        private void PrintReport()
        {
            string text = _summary.Text; PrintDocument pd = new PrintDocument(); pd.DocumentName = "SyncDB report"; int line = 0;
            pd.PrintPage += (s, e) => { using (Font f = new Font("Consolas", 9f)) { float y = 40; string[] lines = text.Replace("\r", "").Split('\n'); while (line < lines.Length && y < e.MarginBounds.Bottom) { e.Graphics.DrawString(lines[line++], f, Brushes.Black, e.MarginBounds.Left, y); y += 15; } e.HasMorePages = line < lines.Length; } };
            using (PrintDialog dlg = new PrintDialog { Document = pd }) if (dlg.ShowDialog(this) == DialogResult.OK) pd.Print();
            pd.Dispose();
        }
        private static string Q(string s) { return "\"" + (s ?? "").Replace("\"", "\"\"") + "\""; }
        private static string Cut(string s, int n) { s = s ?? ""; return s.Length <= n ? s : s.Substring(0, n - 1) + "…"; }
        private static string Prompt(string caption, string title)
        {
            Form f = new Form { Text = title, Size = new Size(420, 140), StartPosition = FormStartPosition.CenterScreen };
            try { f.Icon = MakeDashboardIcon(); } catch { }
            TextBox t = new TextBox { Left = 12, Top = 15, Width = 380 }; Button ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Left = 315, Top = 50, Width = 75 };
            f.Controls.Add(t); f.Controls.Add(ok); f.AcceptButton = ok; string v = f.ShowDialog() == DialogResult.OK ? t.Text : ""; f.Dispose(); return v;
        }
    }
}
