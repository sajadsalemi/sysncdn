﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SyncDB
{
    /// <summary>Per-table (per-step): which tables run (checkbox) + order (No) + RAM / CPU / disk / index settings.</summary>
    public class ResourcesForm : Form
    {
        private class Row
        {
            public int Index { get; set; }      // index of the step in job.Steps (never changes)
            public bool Use { get; set; }
            public int No { get; set; }         // execution order (editable)
            public string Step { get; set; }
            public string Table { get; set; }
            public int BatchSize { get; set; }
            public int MaxThreads { get; set; }
            public int SourceThreads { get; set; }
            public int DelayMs { get; set; }
            public ResourcePriority Priority { get; set; }
            public BufferMode Buffer { get; set; }
            public int RamLimitMb { get; set; }
            public IndexRebuildKind IndexMode { get; set; }
            public int IndexDays { get; set; }
            public bool IsApi { get; set; }
            public bool IsSql { get; set; }
        }

        private const int ColUse = 0, ColNo = 1, ColStep = 2, ColTable = 3, ColBatch = 4, ColDestThr = 5, ColSrcThr = 6,
            ColDelay = 7, ColPrio = 8, ColBuffer = 9, ColRamLimit = 10, ColIdxMode = 11, ColIdxDays = 12;

        private readonly SyncJob job;
        private readonly AppConfig cfg;
        private readonly BindingList<Row> rows = new BindingList<Row>();
        private DataGridView grid;

        public ResourcesForm(SyncJob job, AppConfig cfg = null)
        {
            this.job = job;
            this.cfg = cfg;
            Text = "Tables: use + order + RAM / CPU / Disk / Index — " + job.Name;
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(1560, 520);
            MinimumSize = new Size(900, 360);
            MinimizeBox = false;
            ShowInTaskbar = false;

            for (int i = 0; i < job.Steps.Count; i++)
            {
                JobStep s = job.Steps[i];
                if (s.Type != StepType.Transfer && s.Type != StepType.ApiToDest && s.Type != StepType.SqlOnDest) continue;
                IndexRebuildKind ik = s.IndexRebuild;
                if (ik == IndexRebuildKind.Off && s.RebuildIndexesAfter) ik = IndexRebuildKind.AfterEveryRun;
                rows.Add(new Row
                {
                    Index = i,
                    Use = s.Enabled,
                    No = rows.Count + 1,
                    Step = s.Name,
                    Table = (s.Type == StepType.SqlOnDest && string.IsNullOrWhiteSpace(s.DestTable)) ? "(T-SQL: linked SELECT INTO)" : s.DestTable,
                    BatchSize = s.BatchSize,
                    MaxThreads = Math.Max(0, s.MaxThreads),
                    SourceThreads = Math.Max(0, s.SourceThreads),
                    DelayMs = s.DelayMs,
                    Priority = s.Priority,
                    Buffer = s.Buffer,
                    RamLimitMb = s.RamLimitMb > 0 ? s.RamLimitMb : 256,
                    IndexMode = ik,
                    IndexDays = s.IndexRebuildDays < 1 ? 7 : s.IndexRebuildDays,
                    IsApi = s.Type == StepType.ApiToDest,
                    IsSql = s.Type == StepType.SqlOnDest
                });
            }

            Label hint = new Label
            {
                Dock = DockStyle.Top, Height = 104, Padding = new Padding(8, 6, 8, 0),
                Text = "Use: tick = table runs and its settings are ACTIVE; untick = table is skipped and its row is DISABLED (grey). Tick it again to enable.   No: execution order - type a number or use Up / Down.\r\n" +
                       "Batch size: rows per batch (RAM).   DEST threads: parallel writers, 0 = Auto (CPU cores).   SOURCE threads: parallel readers, 0 = Auto, 1 = single reader (RAM mode only).\r\n" +
                       "Memory: Auto / RAM / Stream / Disk (Auto uses RAM MB limit). Cache: LiteDB / LevelDB / FASTER set in Edit job.\r\n" +
                       "Index: Off / After every run / Every N days.   Right-click the grid for Enable / Disable / Select all / Move.   (Web API steps: memory mode and index n/a.)\r\n" +
                       "Dest table: pick from the list (read from the Dest connection) or type a new name."
            };

            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White,
                DataSource = rows
            };
            grid.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName = "Use", HeaderText = "Use", Width = 45 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "No", HeaderText = "No.", Width = 45, ReadOnly = true });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Step", HeaderText = "Step", Width = 170, ReadOnly = true });
            DataGridViewComboBoxColumn tblCol = new DataGridViewComboBoxColumn
            {
                DataPropertyName = "Table", HeaderText = "Dest table *", Width = 260, DropDownWidth = 400,
                ValueType = typeof(string), FlatStyle = FlatStyle.Standard
            };
            tblCol.DefaultCellStyle.BackColor = Color.FromArgb(232, 242, 255);
            tblCol.DefaultCellStyle.ForeColor = Color.FromArgb(20, 55, 110);
            tblCol.DefaultCellStyle.Font = new Font("Segoe UI Semibold", 9.5f);
            tblCol.DefaultCellStyle.SelectionBackColor = Color.FromArgb(47, 109, 181);
            tblCol.DefaultCellStyle.SelectionForeColor = Color.White;
            foreach (Row r0 in rows)
                if (!string.IsNullOrEmpty(r0.Table) && !tblCol.Items.Contains(r0.Table)) tblCol.Items.Add(r0.Table);
            grid.Columns.Add(tblCol);
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "BatchSize", HeaderText = "Batch size (RAM)", Width = 110 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "MaxThreads", HeaderText = "DEST threads (0=Auto)", Width = 120 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "SourceThreads", HeaderText = "SOURCE threads (0=Auto)", Width = 130 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "DelayMs", HeaderText = "Delay (ms)", Width = 75 });
            grid.Columns.Add(new DataGridViewComboBoxColumn
            {
                DataPropertyName = "Priority", HeaderText = "Priority", Width = 80,
                DataSource = Enum.GetValues(typeof(ResourcePriority))
            });
            grid.Columns.Add(new DataGridViewComboBoxColumn
            {
                DataPropertyName = "Buffer", HeaderText = "Memory", Width = 72,
                DataSource = Enum.GetValues(typeof(BufferMode))
            });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "RamLimitMb", HeaderText = "RAM MB", Width = 70 });
            grid.Columns.Add(new DataGridViewComboBoxColumn
            {
                DataPropertyName = "IndexMode", HeaderText = "Rebuild index", Width = 120,
                DataSource = Enum.GetValues(typeof(IndexRebuildKind))
            });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "IndexDays", HeaderText = "Every N days", Width = 85 });
            grid.DataError += (s, e) => { e.ThrowException = false; };
            grid.CurrentCellDirtyStateChanged += (s, e) =>
            {
                // the Dest table cell is committed when you leave it (so typing a name is not cut off)
                if (grid.IsCurrentCellDirty && grid.CurrentCell != null && grid.CurrentCell.ColumnIndex != ColTable)
                    grid.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            grid.CellValueChanged += (s, e) =>
            {
                if (e.RowIndex < 0) return;
                if (e.ColumnIndex == ColUse || e.ColumnIndex == ColIdxMode) RefreshRowStates();
            };
            // No. read-only — reorder only via arrows
            grid.CellEndEdit += (s, e) =>
            {
                if (e.RowIndex < 0) return;
                if (e.ColumnIndex == ColNo) { Renumber(); grid.Invalidate(); }
            };
            grid.DataBindingComplete += (s, e) => RefreshRowStates();
            // Dest table: drop-down with debounced contains-search (type "dep" -> dbo.department_check)
            grid.EditingControlShowing += (s, e) =>
            {
                ComboBox ecb = e.Control as ComboBox;
                if (ecb == null || grid.CurrentCell == null || grid.CurrentCell.ColumnIndex != ColTable) return;
                ecb.DropDownStyle = ComboBoxStyle.DropDown;
                ecb.AutoCompleteMode = AutoCompleteMode.None;
                ecb.AutoCompleteSource = AutoCompleteSource.None;
                ecb.IntegralHeight = true;
                ecb.MaxDropDownItems = 14;
                DataGridViewComboBoxColumn col = grid.Columns[ColTable] as DataGridViewComboBoxColumn;
                List<string> fullList = new List<string>();
                if (col != null)
                    foreach (object o in col.Items)
                        if (o != null) fullList.Add(o.ToString());
                ecb.Tag = fullList;
                // one-shot: attach debounced handler (remove previous first)
                ecb.TextUpdate -= DestTableTextUpdate;
                ecb.TextUpdate += DestTableTextUpdate;
            };
            grid.CellValidating += (s, e) =>
            {
                if (e.ColumnIndex != ColTable || e.RowIndex < 0 || e.FormattedValue == null) return;
                string v = e.FormattedValue.ToString().Trim();
                DataGridViewComboBoxCell cell = grid.Rows[e.RowIndex].Cells[ColTable] as DataGridViewComboBoxCell;
                if (v.Length > 0 && cell != null && !cell.Items.Contains(v)) cell.Items.Add(v);
            };
            Shown += (s, e) => LoadDestTables();
            grid.CellMouseDown += (s, e) =>
            {
                if (e.Button != MouseButtons.Right || e.RowIndex < 0) return;
                if (!grid.Rows[e.RowIndex].Selected) { grid.ClearSelection(); grid.Rows[e.RowIndex].Selected = true; }
                grid.CurrentCell = grid.Rows[e.RowIndex].Cells[ColStep];
            };

            ContextMenuStrip cm = new ContextMenuStrip();
            cm.Items.Add("Enable selected (Use on)", null, (s, e) => SetUseSelected(true));
            cm.Items.Add("Disable selected (Use off)", null, (s, e) => SetUseSelected(false));
            cm.Items.Add(new ToolStripSeparator());
            cm.Items.Add("Select all", null, (s, e) => SetAll(true));
            cm.Items.Add("Select none", null, (s, e) => SetAll(false));
            cm.Items.Add(new ToolStripSeparator());
            cm.Items.Add("Move up", null, (s, e) => MoveCurrent(-1));
            cm.Items.Add("Move down", null, (s, e) => MoveCurrent(1));
            grid.ContextMenuStrip = cm;

            FlowLayoutPanel bar = new FlowLayoutPanel
            { Dock = DockStyle.Bottom, Height = 44, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(6) };
            Button cancel = new Button { Text = "Cancel", Width = 85, DialogResult = DialogResult.Cancel };
            Button ok = new Button { Text = "OK", Width = 85 };
            ok.Click += (s, e) => { if (Apply()) DialogResult = DialogResult.OK; };
            Button exp = new Button { Text = "Export...", Width = 85 };
            exp.Click += (s, e) => ExportSettings();
            Button down = new Button { Text = "▼ Down", Width = 80 };
            Button up = new Button { Text = "▲ Up", Width = 80 };
            down.Click += (s, e) => MoveCurrent(1);
            up.Click += (s, e) => MoveCurrent(-1);
            Button none = new Button { Text = "Select none", Width = 95 };
            Button all = new Button { Text = "Select all", Width = 95 };
            all.Click += (s, e) => SetAll(true);
            none.Click += (s, e) => SetAll(false);
            bar.Controls.Add(cancel);
            bar.Controls.Add(ok);
            bar.Controls.Add(exp);
            bar.Controls.Add(down);
            bar.Controls.Add(up);
            bar.Controls.Add(none);
            bar.Controls.Add(all);
            AcceptButton = ok;
            CancelButton = cancel;

            Controls.Add(grid);
            Controls.Add(hint);
            Controls.Add(bar);
            Theme.Apply(this);
        }


        // debounced filter: wait ~120ms after last key so UI does not hang while typing
        private static System.Windows.Forms.Timer _destFilterTimer;
        private static ComboBox _destFilterBox;
        private static bool _destFilterBusy;

        private static void DestTableTextUpdate(object sender, EventArgs e)
        {
            _destFilterBox = sender as ComboBox;
            if (_destFilterBox == null) return;
            if (_destFilterTimer == null)
            {
                _destFilterTimer = new System.Windows.Forms.Timer();
                _destFilterTimer.Interval = 120;
                _destFilterTimer.Tick += (s2, e2) =>
                {
                    _destFilterTimer.Stop();
                    ApplyDestFilter(_destFilterBox);
                };
            }
            _destFilterTimer.Stop();
            _destFilterTimer.Start();
        }

        private static void ApplyDestFilter(ComboBox box)
        {
            if (box == null || box.IsDisposed || _destFilterBusy) return;
            List<string> all = box.Tag as List<string>;
            if (all == null || all.Count == 0) return;

            // capture exactly what the user typed BEFORE touching Items
            string q = box.Text ?? "";
            int selStart = box.SelectionStart;
            string ql = q.Trim().ToLowerInvariant();

            _destFilterBusy = true;
            try
            {
                List<string> filtered = new List<string>();
                if (ql.Length == 0)
                {
                    int n = Math.Min(all.Count, 150);
                    for (int i = 0; i < n; i++) filtered.Add(all[i]);
                }
                else
                {
                    foreach (string x in all)
                    {
                        if (x != null && x.ToLowerInvariant().IndexOf(ql) >= 0)
                        {
                            filtered.Add(x);
                            if (filtered.Count >= 150) break;
                        }
                    }
                }

                // rebuild list without letting ComboBox auto-pick the first item
                box.BeginUpdate();
                try
                {
                    box.Items.Clear();
                    foreach (string x in filtered) box.Items.Add(x);
                }
                finally { box.EndUpdate(); }

                // CRITICAL: do not select any item — keep the typed text as-is
                try { box.SelectedIndex = -1; } catch { }
                box.Text = q;
                if (selStart < 0) selStart = q.Length;
                if (selStart > q.Length) selStart = q.Length;
                box.SelectionStart = selStart;
                box.SelectionLength = 0;

                // open list only if already open, or first time with matches (without changing text)
                if (filtered.Count > 0)
                {
                    try
                    {
                        if (!box.DroppedDown) box.DroppedDown = true;
                        // after DroppedDown, ComboBox may select an item — force typed text again
                        try { box.SelectedIndex = -1; } catch { }
                        box.Text = q;
                        box.SelectionStart = selStart;
                        box.SelectionLength = 0;
                    }
                    catch { }
                }
            }
            finally { _destFilterBusy = false; }
        }

        /// <summary>Reads the table names of the destination connection(s) in the background and adds them to the Dest table drop-downs.</summary>
        private void LoadDestTables()
        {
            AppConfig c = null;
            try { c = cfg ?? AppConfig.Load(); } catch { }
            if (c == null) return;
            List<string> conns = new List<string>();
            foreach (Row r in rows)
            {
                if (r.IsSql) continue;
                string cs = c.ResolveStepConnectionString(job.Steps[r.Index], false);
                if (!string.IsNullOrEmpty(cs) && !conns.Contains(cs)) conns.Add(cs);
            }
            if (conns.Count == 0) return;
            Task.Run(() =>
            {
                List<string> all = new List<string>();
                foreach (string cs in conns)
                {
                    try
                    {
                        foreach (string x in Engine.ListTablesAndViews(cs))
                            if (x.StartsWith("[TABLE] ")) { string n = x.Substring(8); if (!all.Contains(n)) all.Add(n); }
                    }
                    catch { }
                }
                all.Sort(StringComparer.OrdinalIgnoreCase);
                if (all.Count == 0 || IsDisposed || !IsHandleCreated) return;
                try { BeginInvoke(new Action(() => AddTableItems(all))); } catch { }
            });
        }

        private void AddTableItems(List<string> names)
        {
            if (IsDisposed) return;
            DataGridViewComboBoxColumn col = grid.Columns[ColTable] as DataGridViewComboBoxColumn;
            if (col == null) return;
            foreach (string n in names) if (!col.Items.Contains(n)) col.Items.Add(n);
            foreach (DataGridViewRow gr in grid.Rows)
            {
                DataGridViewComboBoxCell cell = gr.Cells[ColTable] as DataGridViewComboBoxCell;
                if (cell == null) continue;
                foreach (string n in names) if (!cell.Items.Contains(n)) cell.Items.Add(n);
            }
            grid.Invalidate();
        }

        /// <summary>Unticked rows are disabled (grey, read-only) until ticked again. "Every N days" only when Rebuild index = EveryNDays.</summary>
        private void RefreshRowStates()
        {
            if (grid == null) return;
            for (int i = 0; i < grid.Rows.Count && i < rows.Count; i++)
            {
                Row r = rows[i];
                bool everyN = r.IndexMode == IndexRebuildKind.EveryNDays;
                for (int c = ColStep; c <= ColIdxDays; c++)
                {
                    DataGridViewCell cell = grid.Rows[i].Cells[c];
                    bool always = c == ColStep;
                    bool locked;
                    if (always) locked = true;
                    else if (!r.Use) locked = true;
                    else if (c == ColTable && r.IsSql) locked = true;       // T-SQL step: table name is inside the command
                    else if (r.IsApi && (c == ColSrcThr || c == ColBuffer || c == ColRamLimit || c == ColIdxMode || c == ColIdxDays)) locked = true;
                    else if (c == ColIdxDays && !everyN) locked = true;
                    else locked = false;
                    cell.ReadOnly = locked;
                    if (!r.Use || (locked && !always))
                    {
                        cell.Style.ForeColor = Color.Gray;
                        cell.Style.BackColor = Color.FromArgb(240, 240, 244);
                    }
                    else if (c == ColTable)
                    {
                        // Dest table column stays highlighted (easy to spot / edit)
                        cell.Style.ForeColor = Color.FromArgb(20, 55, 110);
                        cell.Style.BackColor = Color.FromArgb(232, 242, 255);
                    }
                    else
                    {
                        cell.Style.ForeColor = Color.Empty;
                        cell.Style.BackColor = Color.Empty;
                    }
                }
            }
        }

        private void Renumber()
        {
            for (int i = 0; i < rows.Count; i++) rows[i].No = i + 1;
        }

        private void MoveRow(int from, int to)
        {
            grid.EndEdit();
            if (from < 0 || from >= rows.Count) return;
            to = Math.Max(0, Math.Min(rows.Count - 1, to));
            if (to == from) return;
            Row r = rows[from];
            rows.RemoveAt(from);
            rows.Insert(to, r);
            Renumber();
            RefreshRowStates();
            grid.ClearSelection();
            grid.Rows[to].Selected = true;
            grid.CurrentCell = grid.Rows[to].Cells[ColStep];
            grid.Invalidate();
        }

        private void MoveCurrent(int delta)
        {
            if (grid.CurrentRow == null) return;
            int i = grid.CurrentRow.Index;
            MoveRow(i, i + delta);
        }

        private void SetUseSelected(bool v)
        {
            grid.EndEdit();
            foreach (DataGridViewRow gr in grid.SelectedRows)
                if (gr.Index >= 0 && gr.Index < rows.Count) rows[gr.Index].Use = v;
            RefreshRowStates();
            grid.Invalidate();
        }

        private void SetAll(bool v)
        {
            grid.EndEdit();
            foreach (Row r in rows) r.Use = v;
            RefreshRowStates();
            grid.Invalidate();
        }

        private void ApplyTo(SyncJob target)
        {
            List<Row> ordered = new List<Row>(rows);
            ordered.Sort((a, b) =>
            {
                int c = a.No.CompareTo(b.No);
                return c != 0 ? c : rows.IndexOf(a).CompareTo(rows.IndexOf(b));
            });
            foreach (Row r in rows)
            {
                JobStep s = target.Steps[r.Index];
                s.Enabled = r.Use;
                if (!r.IsSql && !string.IsNullOrWhiteSpace(r.Table)) s.DestTable = r.Table.Trim();
                s.BatchSize = Math.Max(0, Math.Min(1000000, r.BatchSize));
                s.MaxThreads = Math.Max(0, Math.Min(64, r.MaxThreads));
                if (!r.IsApi) s.SourceThreads = Math.Max(0, Math.Min(64, r.SourceThreads));
                s.DelayMs = Math.Max(0, Math.Min(60000, r.DelayMs));
                s.Priority = r.Priority;
                if (!r.IsApi)
                {
                    s.Buffer = r.Buffer;
                    s.RamLimitMb = Math.Max(16, Math.Min(65536, r.RamLimitMb));
                    s.IndexRebuild = r.IndexMode;
                    s.IndexRebuildDays = Math.Max(1, Math.Min(3650, r.IndexDays));
                    s.RebuildIndexesAfter = r.IndexMode == IndexRebuildKind.AfterEveryRun;
                }
            }
            // new order: the listed steps are placed into the slots they occupied, sorted by No
            List<int> slots = new List<int>();
            foreach (Row r in rows) slots.Add(r.Index);
            slots.Sort();
            List<JobStep> old = new List<JobStep>(target.Steps);
            for (int k = 0; k < ordered.Count; k++) target.Steps[slots[k]] = old[ordered[k].Index];
            target.RenumberSteps();
        }

        private bool Apply()
        {
            grid.EndEdit();
            if (rows.Count == 0) return true;
            ApplyTo(job);
            return true;
        }

        private void ExportSettings()
        {
            grid.EndEdit();
            try
            {
                SyncJob copy = job.Clone();
                ApplyTo(copy);
                bool withConn = MessageBox.Show("Include connections WITH passwords (clear text in the file)?", "Export",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
                using (SaveFileDialog sf = new SaveFileDialog())
                {
                    sf.Filter = "SyncDB export (*.syncdb.json)|*.syncdb.json|JSON (*.json)|*.json";
                    sf.FileName = "SyncDB_export_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".syncdb.json";
                    if (sf.ShowDialog(this) != DialogResult.OK) return;
                    List<SyncJob> list = new List<SyncJob>();
                    list.Add(copy);
                    ProjectIO.Export(sf.FileName, list, cfg ?? AppConfig.Load(), withConn);
                    Audit.Write("EXPORT", "1 job (" + copy.Name + ") from Tables dialog | connections=" + withConn + " | file=" + sf.FileName);
                    MessageBox.Show("Exported:\r\n" + sf.FileName, "Export");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Export failed"); }
        }
    }
}
