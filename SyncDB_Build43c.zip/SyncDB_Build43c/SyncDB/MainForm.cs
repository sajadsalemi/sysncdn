﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SyncDB
{
    public class MainForm : Form
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);
        private const int EM_SETCUEBANNER = 0x1501;

        private AppConfig config;
        private readonly JobScheduler scheduler = new JobScheduler();
        private bool busy;
        private bool serviceRunning;        // something is scheduling jobs (either of the two below)
        private Label lblAsync;             // "Async: next check in 37 s" - read from async_status.txt
        private bool _staleAsked;           // the "service runs an old copy" question is asked once
        private bool winSvcInstalled;       // the Windows service exists (any state)
        private bool winSvcStale;           // ...but is registered to another SyncDB.exe (an older copy)
        private bool winSvcRunning;         // the Windows service "SyncDB"
        private bool appSchedRunning;       // the scheduler inside this window
        private SyncJob editing;
        private ConnectionProfile editingConn;
        private bool connStrVisible;

        private TabControl tabs;
        private ToolStripStatusLabel lblStatus;
        private Label lblServiceState;
        private Button btnServiceStart, btnServiceStop;

        private ListView lvConn;
        private TextBox txtConnName, txtConnServer, txtConnPort, txtConnDb, txtConnUser, txtConnPassword;
        private CheckBox chkTrustCert, chkIntegrated;
        private TextBox txtConnStringPreview;
        private Button btnShowString;

        private ComboBox cbSourceConn, cbDestConn;
        private ComboBox cbSrcDb, cbDstDb;   // database list on the selected server
        private ListBox lstSrcTables, lstDstTables;
        private Label lblSrcInfo, lblDstInfo;

        private ListView lvJobs;
        private bool _jobsLoading;
        private Label lblEditingJob, lblRouteInfo;
        private Button _runButton, _runManyButton;

        private TextBox txtLog;
        private DateTimePicker dtLogDay;

        private NumericUpDown numRetention, numPoll;
        private TextBox txtLogFolder;
        private CheckBox chkScheduler;
        private CheckBox chkOutbox;
        private bool _settingsLoading;
        private Label lblOutboxStats;
        private Label lblOutboxWorker;
        private NumericUpDown numOutboxRetries, numOutboxBatch, numOutboxIdle, numOutboxSentDays;
        private TextBox txtOriginId;
        private TextBox txtStreamTopic;
        private Label lblStreamStats;
        private CheckBox chkBufferClean, chkUseDiskBuffer;
        private NumericUpDown numCacheKeepDays;
        private Label lblDataFolder;
        private Label lblResources;
        private OutboxWorker outboxWorker;
        private bool _liveWasRunning;
        private int _transferAnimationFrame;

        public MainForm()
        {
            try { config = AppConfig.Load(); } catch { config = new AppConfig(); }
            if (config == null) config = new AppConfig();
            try
            {
                AppLog.Configure(config.EffectiveLogFolder, config.LogRetentionDays);
                AppLog.PurgeOldLogs();
                AppLog.Info("-", "SyncDB started. " + AppBuild.Text + " | data folder: " + AppConfig.DataDir +
                                 " | disk buffer: " + (config.UseDiskBuffer ? "ON" : "OFF"));
                try { OutboxStore.EnsureOpen(); } catch { }
                try { LocalStream.EnsureReady("syncdb.changes"); } catch { }
                // Housekeeping: remove orphan disk buffers of previous runs and keep the data folder
                // bounded (buffer / stream / cache.db / outbox.db). Runs now and then once an hour.
                try { RuntimeSettings.Apply(config); } catch { }
                try { Maintenance.Start(config); } catch { }
            }
            catch { }

            BuildUi();
            RefreshConnectionList();
            RefreshSourceDestCombos();
            SelectComboById(cbSourceConn, config.SourceConnectionId);
            SelectComboById(cbDestConn, config.DestConnectionId);
            LoadJobsList();
            ApplySettingsUi();
            StartOutboxWorker();
            try { txtLog.Text = AppLog.ReadLogForDate(DateTime.Today); } catch { }

            scheduler.JobFinished += (job, r) =>
            {
                if (IsDisposed) return;
                BeginInvoke(new Action(() =>
                {
                    LoadJobsList();
                    try { txtLog.Text = AppLog.ReadLogForDate(DateTime.Today); } catch { }
                    lblStatus.Text = job.Name + ": " + job.LastStatus;
                    UpdateManualRunButtons();
                }));
            };
            scheduler.TickStatus += msg =>
            {
                if (IsDisposed) return;
                BeginInvoke(new Action(() => { lblStatus.Text = msg; }));
            };

            // Do not force-stop the Windows service when the GUI starts.
            // Reflect the real Windows service status; keep the in-app scheduler off if the service is already running.
            try
            {
                string svcSt = WinSvc.Status();
                winSvcInstalled = (svcSt != "Not installed");
                winSvcStale = winSvcInstalled && !WinSvc.PointsAtThisExe();
                if (winSvcStale)
                    AppLog.Warn("-", "The Windows service is registered to ANOTHER copy of SyncDB: " + WinSvc.RegisteredExePath() +
                                     " - press \"Start Service\" to switch it to this build.");
                if (svcSt == "Running")
                {
                    SetWinServiceUi(true);
                    // Leave SchedulerEnabled as-is in memory; do not start the in-app scheduler (avoids double runs).
                    // The Windows service is the one executing jobs.
                }
                else
                {
                    SetWinServiceUi(false);
                    // No Windows service. If scheduling was ON when SyncDB was last closed, turn it back
                    // on here - otherwise "automatic" silently died at every restart of the window.
                    // Async jobs are realtime jobs and must not depend on a previous manual
                    // Start-Service click. If no Windows service owns the folder, arm the local
                    // scheduler whenever at least one enabled Async job is configured.
                    if (config.SchedulerEnabled || HasEnabledAsyncJob(config))
                    {
                        scheduler.Start(config);
                        SetAppSchedulerUi(true);
                        AppLog.Info("-", "Scheduler resumed in this window (automatic Async job detected).");
                    }
                }
            }
            catch { try { SetWinServiceUi(false); } catch { } }

            FormClosing += (s, e) =>
            {
                try
                {
                    SaveSelectedRoles();
                    CollectSettingsUi();
                    config.Save();
                    scheduler.Stop();
                    StopOutboxWorker();
                    try { Maintenance.Stop(); } catch { }
                    try { Maintenance.CleanBufferRoot(); } catch { }
                    CacheStoreFactory.Reset();
                    AppLog.Info("-", "SyncDB closed.");
                    Audit.Write("APP_EXIT", "session length " + (DateTime.Now - Audit.Started).ToString(@"hh\:mm\:ss"));
                }
                catch { }
            };

            Timer t = new Timer { Interval = 2000 };
            t.Tick += (s, e) =>
            {
                UpdateResources(); RefreshOutboxUi(); RefreshLiveLog();
                // Pick up status changes written by the Windows service
                try { ReloadJobStatusesFromDisk(); } catch { }
                try { RefreshAsyncLabel(); } catch { }
                try { UpdateManualRunButtons(); } catch { }
                // Keep the Service label in sync with the real Windows service
                try
                {
                    // Only the Windows-service flag is refreshed here. Before, this line reset the
                    // whole state every 2 seconds, so pressing "Start Service" lit the label up and
                    // the next tick switched it straight back to STOPPED - the button looked dead.
                    string st = WinSvc.Status();
                    bool running = (st == "Running");
                    bool installed = (st != "Not installed");
                    bool stale = installed && !WinSvc.PointsAtThisExe();
                    if (stale && !winSvcStale)
                        AppLog.Warn("-", "The Windows service runs ANOTHER copy of SyncDB: " + WinSvc.RegisteredExePath() +
                                         " - it executes the old code. Press \"Start Service\" to switch it to this build.");
                    if (running != winSvcRunning || installed != winSvcInstalled || stale != winSvcStale)
                    {
                        winSvcInstalled = installed;
                        winSvcStale = stale;
                        SetWinServiceUi(running);
                    }
                    // Never let the window and the service schedule the same jobs side by side.
                    if (running && appSchedRunning)
                    {
                        StopService(false);
                        AppLog.Info("-", "The Windows service is running - the in-window scheduler was stopped.");
                    }
                    // The service is running an older copy of SyncDB from another folder: every fix in
                    // this build is invisible until it is switched over. Ask once, in two short lines.
                    if (running && stale && !_staleAsked)
                    {
                        _staleAsked = true;
                        DialogResult dr = MessageBox.Show(this,
                            Lang.T("The Windows service is still running an OLD copy of SyncDB:") + "\r\n" +
                            (WinSvc.RegisteredExePath() ?? "") + "\r\n\r\n" +
                            Lang.T("Switch the service to this version now?"),
                            "SyncDB", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (dr == DialogResult.Yes) OnStartServiceClicked();
                    }
                }
                catch { }
            };
            t.Start();

            // the status bar follows the transfer every second: table, records moving, minutes
            Timer tLive = new Timer { Interval = 1000 };
            tLive.Tick += (s, e) =>
            {
                try { RefreshAsyncLabel(); } catch { }
                try
                {
                    bool running;
                    lock (RunTrace.LiveLock) { running = RunTrace.LiveRunning; }
                    if (running)
                    {
                        string line = RunTrace.BuildStatusLine();
                        if (!string.IsNullOrEmpty(line)) lblStatus.Text = line;
                        _liveWasRunning = true;
                    }
                    else if (_liveWasRunning)
                    {
                        _liveWasRunning = false;
                        long ms = 0;
                        lock (RunTrace.LiveLock)
                        {
                            if (RunTrace.LiveFinishedAt > RunTrace.LiveStartedAt)
                                ms = (long)(RunTrace.LiveFinishedAt - RunTrace.LiveStartedAt).TotalMilliseconds;
                        }
                        lblStatus.Text = "Transfer finished - " + RunTrace.LiveJobRows.ToString("N0")
                            + " records in " + JobHistory.FormatElapsed(ms);
                    }
                }
                catch { }
            };
            tLive.Start();
            UpdateResources();
            RefreshOutboxUi();
        }

        private static void SetCue(TextBox t, string text)
        {
            t.HandleCreated += delegate
            {
                try { SendMessage(t.Handle, EM_SETCUEBANNER, (IntPtr)1, text); } catch { }
            };
            if (t.IsHandleCreated)
            {
                try { SendMessage(t.Handle, EM_SETCUEBANNER, (IntPtr)1, text); } catch { }
            }
        }

        private void BuildUi()
        {
            Text = "SyncDB — Database Transfer & Jobs";
            Font = new Font("Segoe UI", 9f);
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(1200, 800);
            MinimumSize = new Size(900, 600);

            MenuStrip menu = new MenuStrip
            {
                Font = new Font("Segoe UI Semibold", 9.5f),
                BackColor = Theme.Navy,
                ForeColor = Color.White,
                Renderer = new Theme.MenuRenderer(),
                Padding = new Padding(4, 2, 0, 4),
                AutoSize = true
            };
            // Alt+F
            ToolStripMenuItem file = new ToolStripMenuItem("&File");
            file.DropDownItems.Add("&Save all", null, (s, e) =>
            {
                SaveSelectedRoles();
                CollectSettingsUi();
                config.Save();
                scheduler.UpdateConfig(config);
                if (outboxWorker != null) outboxWorker.UpdateConfig(config);
                else StartOutboxWorker();
                RefreshOutboxUi();
                Audit.Write("CONFIG_SAVED", "File > Save all");
                MessageBox.Show("Saved.\r\n" + AppConfig.ConfigPath);
            });
            file.DropDownItems.Add("Change &password...", null, (s, e) => ShowChangePassword());
            file.DropDownItems.Add(new ToolStripSeparator());
            file.DropDownItems.Add("&Export jobs / settings...", null, (s, e) => ExportJobsUi());
            file.DropDownItems.Add("&Import jobs / settings...", null, (s, e) => ImportJobsUi());
            file.DropDownItems.Add(new ToolStripSeparator());
            file.DropDownItems.Add("Job &History...", null, (s, e) => OpenJobHistory());
            file.DropDownItems.Add("Transfer status (live)...", null, (s, e) => OpenLiveStatus());
            file.DropDownItems.Add(new ToolStripSeparator());
            file.DropDownItems.Add("Open &data folder", null, (s, e) =>
            {
                Directory.CreateDirectory(AppConfig.DataDir);
                Process.Start("explorer.exe", AppConfig.DataDir);
            });
            file.DropDownItems.Add("Open &Log folder (audit_syncdb.txt / logsyncdb.txt)", null, (s, e) =>
            {
                Directory.CreateDirectory(Audit.LogDir);
                Process.Start("explorer.exe", Audit.LogDir);
            });
            file.DropDownItems.Add(new ToolStripSeparator());
            file.DropDownItems.Add("E&xit", null, (s, e) => Close());
            menu.Items.Add(file);
            // Alt+S
            ToolStripMenuItem svc = new ToolStripMenuItem("&Service");
            svc.DropDownItems.Add("&Start", null, (s, e) => StartService(true));
            svc.DropDownItems.Add("S&top", null, (s, e) => StopService(true));
            svc.DropDownItems.Add(new ToolStripSeparator());
            svc.DropDownItems.Add("Windows Service: &Install && start (auto-start with Windows)", null, (s, e) => WinSvc.LaunchCommand("/install"));
            svc.DropDownItems.Add("Windows Service: Start", null, (s, e) => WinSvc.LaunchCommand("/svcstart"));
            svc.DropDownItems.Add("Windows Service: Stop", null, (s, e) => WinSvc.LaunchCommand("/svcstop"));
            svc.DropDownItems.Add("Windows Service: &Uninstall", null, (s, e) => WinSvc.LaunchCommand("/uninstall"));
            svc.DropDownItems.Add("Windows Service: Statu&s", null, (s, e) =>
                MessageBox.Show("Windows service '" + SyncDbService.SvcName + "': " + WinSvc.Status(), "SyncDB"));
            menu.Items.Add(svc);
            // Alt+L
            ToolStripMenuItem lng = new ToolStripMenuItem("&Language / زبان");
            ToolStripMenuItem miEn = new ToolStripMenuItem("&English") { Checked = !Lang.Fa };
            ToolStripMenuItem miFa = new ToolStripMenuItem("&فارسی") { Checked = Lang.Fa };
            miEn.Click += (s, e) => ChangeLanguage(false);
            miFa.Click += (s, e) => ChangeLanguage(true);
            lng.DropDownItems.Add(miEn);
            lng.DropDownItems.Add(miFa);
            menu.Items.Add(lng);
            // Theme / پوسته — 6 skins
            ToolStripMenuItem thm = new ToolStripMenuItem("&Theme");
            for (int i = 0; i < Theme.PresetNames.Length; i++)
            {
                int id = i;
                ToolStripMenuItem mi = new ToolStripMenuItem(Theme.PresetNames[i]) { Checked = (config != null && config.ThemeId == id) };
                mi.Click += (s, e) => ApplyTheme(id);
                thm.DropDownItems.Add(mi);
            }
            menu.Items.Add(thm);
            MainMenuStrip = menu;
            Controls.Add(menu);

            StatusStrip ss = new StatusStrip();
            lblStatus = new ToolStripStatusLabel("Ready") { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
            ss.Items.Add(lblStatus);
            Controls.Add(ss);

            Panel topBar = new Panel { Dock = DockStyle.Top, Height = 54, Padding = new Padding(10, 6, 10, 4), BackColor = Color.White };
            topBar.Paint += (s, e) => { using (Pen pn = new Pen(Theme.Border)) e.Graphics.DrawLine(pn, 0, topBar.Height - 1, topBar.Width, topBar.Height - 1); };
            FlowLayoutPanel topFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            lblServiceState = new Label { Text = "Service: STOPPED", AutoSize = true, Font = new Font(Font, FontStyle.Bold), ForeColor = Color.DarkRed, Margin = new Padding(3, 8, 12, 0) };
            btnServiceStart = new Button { Text = "▶ Start Service", AutoSize = true, BackColor = Color.FromArgb(30, 120, 60), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            btnServiceStop = new Button { Text = "■ Stop Service", AutoSize = true, BackColor = Color.FromArgb(160, 50, 40), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            btnServiceStart.Click += (s, e) => OnStartServiceClicked();
            btnServiceStop.Click += (s, e) => OnStopServiceClicked();
            Label lblTitle = new Label { Text = "SyncDB", AutoSize = true, UseMnemonic = false, Font = new Font("Segoe UI Semibold", 14f), ForeColor = Theme.Navy, Margin = new Padding(3, 3, 6, 0) };
            Label lblSub = new Label { Text = "Database Transfer & Jobs", AutoSize = true, UseMnemonic = false, ForeColor = Theme.Muted, Margin = new Padding(0, 10, 28, 0) };
            topFlow.Controls.Add(lblTitle);
            topFlow.Controls.Add(lblSub);
            topFlow.Controls.Add(lblServiceState);
            topFlow.Controls.Add(btnServiceStart);
            topFlow.Controls.Add(btnServiceStop);
            lblAsync = new Label { Text = "", AutoSize = true, UseMnemonic = false, ForeColor = Theme.Muted, Margin = new Padding(14, 10, 0, 0) };
            topFlow.Controls.Add(lblAsync);
            topBar.Controls.Add(topFlow);

            tabs = new TabControl { Dock = DockStyle.Fill };
            tabs.TabPages.Add(BuildConnectionsTab());
            tabs.TabPages.Add(BuildRoleTab(true));
            tabs.TabPages.Add(BuildRoleTab(false));
            tabs.TabPages.Add(BuildJobsListTab());
            tabs.TabPages.Add(BuildJobEditorTab());
            tabs.TabPages.Add(BuildLogsTab());
            tabs.TabPages.Add(BuildSettingsTab());
            tabs.TabPages.Add(BuildGuideTab());

            Controls.Add(tabs);
            Controls.Add(topBar);
            tabs.BringToFront();
            try { Theme.ApplyPreset(config != null ? config.ThemeId : 0); } catch { }
            Theme.Apply(this);
            CompactJobsButtons();
        }

        private FlowLayoutPanel _jobsTopBar, _jobsBar;

        /// <summary>Theme makes every button 30 px high; the Jobs rows are made a little smaller so they fit on one line
        /// on a small screen (called after Theme.Apply).</summary>
        private void CompactJobsButtons()
        {
            CompactBar(_jobsTopBar);
            CompactBar(_jobsBar);
        }

        private static void CompactBar(FlowLayoutPanel bar)
        {
            if (bar == null) return;
            foreach (Control c in bar.Controls)
            {
                Button b = c as Button;
                if (b == null) continue;
                b.MinimumSize = Size.Empty;
                b.AutoSize = true;
                b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                b.Padding = new Padding(4, 0, 4, 0);
                b.Margin = new Padding(2, 1, 2, 1);
                b.Font = new Font(b.Font.FontFamily, 8.25f, b.Font.Style);
                b.Text = b.Text.Trim();
            }
        }

        /// <summary>Saves the language, then closes and re-opens the program (the whole UI is built in the new language).</summary>
        private void ApplyTheme(int id)
        {
            Theme.ApplyPreset(id);
            if (config != null) { config.ThemeId = id; try { config.Save(); } catch { } }
            Theme.Apply(this);
            CompactJobsButtons();
            // refresh menu checkmarks
            try
            {
                foreach (ToolStripItem it in MainMenuStrip.Items)
                {
                    ToolStripMenuItem m = it as ToolStripMenuItem;
                    if (m == null || m.Text == null || m.Text.IndexOf("Theme", StringComparison.OrdinalIgnoreCase) < 0) continue;
                    foreach (ToolStripItem sub in m.DropDownItems)
                    {
                        ToolStripMenuItem sm = sub as ToolStripMenuItem;
                        if (sm != null) sm.Checked = (sm.Text == Theme.PresetNames[Theme.CurrentId]);
                    }
                }
            }
            catch { }
            try { Invalidate(true); Update(); } catch { }
        }

        private void ChangeLanguage(bool fa)
        {
            if (fa == Lang.Fa) return;
            string msg = fa
                ? "زبان برنامه به فارسی تغییر می‌کند.\r\nبرنامه بسته می‌شود و دوباره باز می‌شود (رمز عبور را دوباره وارد کنید).\r\nادامه می‌دهید؟"
                : "Language will change to English.\r\nThe program will close and open again (enter the password again).\r\nContinue?";
            if (MessageBox.Show(msg, "Language / زبان", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                Lang.Save(fa);
                Audit.Write("LANGUAGE", fa ? "Persian (fa)" : "English (en)");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Language"); return; }
            Application.Restart();      // FormClosing saves the config first
        }

        private void StartOutboxWorker()
        {
            try
            {
                if (outboxWorker != null)
                {
                    outboxWorker.UpdateConfig(config);
                    return;
                }
                if (config == null || !config.OutboxEnabled) { RefreshOutboxUi(); return; }
                OutboxWorker w = new OutboxWorker();
                w.Start(config);
                if (w.IsRunning) outboxWorker = w;
                else w.Dispose();
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "Outbox worker could not start: " + ex.Message);
            }
            RefreshOutboxUi();
        }

        private void StopOutboxWorker()
        {
            if (outboxWorker == null) return;
            try { outboxWorker.Stop(); } catch { }
            try { outboxWorker.Dispose(); } catch { }
            outboxWorker = null;
        }

        private void ApplyOutboxSettings()
        {
            CollectSettingsUi();
            config.Save();                       // the service reads config.json, so write it out at once
            RuntimeSettings.Apply(config);
            CacheStoreFactory.Configure(config);
            if (outboxWorker != null) outboxWorker.UpdateConfig(config);
            else StartOutboxWorker();
            RefreshOutboxUi();
        }

        /// <summary>Transfer status is a window of its own now (Jobs tab -> "Transfer status" button).</summary>
        private void OpenLiveStatus()
        {
            LiveStatusForm.ShowWindow(this, config);
        }

        /// <summary>Job History window: every run of every job, with records, minutes and the tables that moved.</summary>
        private void OpenJobHistory()
        {
            try
            {
                using (JobHistoryForm f = new JobHistoryForm(config)) f.ShowDialog(this);
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Job History"); }
        }

        private void OpenOperations()
        {
            try
            {
                using (OperationsForm f = new OperationsForm(config, delegate
                {
                    scheduler.UpdateConfig(config);
                    LoadJobsList();
                })) f.ShowDialog(this);
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Dashboard"); }
        }

        private int _liveLogLen = -1;

        /// <summary>While a job runs, the Log tab follows the daily log so every statement shows up the moment it finishes.</summary>
        private void RefreshLiveLog()
        {
            try
            {
                if (txtLog == null || !(busy || serviceRunning)) { _liveLogLen = -1; return; }
                string txt = AppLog.ReadLogForDate(DateTime.Today);
                if (txt == null || txt.Length == _liveLogLen) return;
                _liveLogLen = txt.Length;
                if (txt.Length > 600000) txt = txt.Substring(txt.Length - 600000);
                txtLog.Text = txt;
                txtLog.SelectionStart = txtLog.TextLength;
                txtLog.ScrollToCaret();
            }
            catch { }
        }

        private void RefreshOutboxUi()
        {
            try
            {
                if (lblOutboxStats != null)
                    lblOutboxStats.Text = OutboxStore.Stats() + "  |  " + OutboxStore.DbPath;
                if (lblOutboxWorker != null)
                {
                    if (config != null && !config.OutboxEnabled)
                        lblOutboxWorker.Text = "Worker: disabled";
                    else if (outboxWorker != null && outboxWorker.IsRunning)
                        lblOutboxWorker.Text = "Worker: enabled - running (batch=" + outboxWorker.BatchSize +
                                               ", max retries=" + outboxWorker.MaxRetries +
                                               ", idle=" + outboxWorker.IdleSleepMs + " ms)";
                    else
                        lblOutboxWorker.Text = "Worker: enabled - not running yet (see log)";
                }
            }
            catch { }
        }

        private void ShowOutboxManager()
        {
            try
            {
                using (OutboxForm f = new OutboxForm(outboxWorker, config))
                    f.ShowDialog(this);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Outbox"); }
            RefreshOutboxUi();
        }

        private static bool HasEnabledAsyncJob(AppConfig cfg)
        {
            if (cfg == null || cfg.Jobs == null) return false;
            foreach (SyncJob j in cfg.Jobs)
                if (j != null && j.Enabled && j.Schedule == ScheduleKind.RealtimeAsync) return true;
            return false;
        }

        private void StartService(bool user)
        {
            if (user && WinSvc.Status() == "Running")
            {
                if (MessageBox.Show("The Windows service 'SyncDB' is already running the jobs.\r\n" +
                    "Starting the scheduler here too would run every job twice.\r\n\r\nStart anyway?",
                    "SyncDB", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            }
            // Order matters: CollectSettingsUi() writes SchedulerEnabled from the current UI state, which
            // is still "stopped" at this point. Setting the flag BEFORE that call (as it used to be) meant
            // the scheduler started with SchedulerEnabled = false, its tick returned at the first line and
            // no scheduled job ever ran - while a manual run worked fine.
            CollectSettingsUi();
            config.SchedulerEnabled = true;
            if (chkScheduler != null) chkScheduler.Checked = true;
            scheduler.Start(config);
            SetAppSchedulerUi(true);
            config.Save();
            if (user) { AppLog.Info("-", "Service STARTED"); Audit.Write("SCHEDULER_START", "scheduler started by user"); lblStatus.Text = "Service started."; }
        }

        private void StopService(bool user)
        {
            scheduler.Stop();
            config.SchedulerEnabled = false;
            if (chkScheduler != null) chkScheduler.Checked = false;
            SetAppSchedulerUi(false);
            config.Save();
            if (user) { AppLog.Info("-", "Service STOPPED"); Audit.Write("SCHEDULER_STOP", "scheduler stopped by user"); lblStatus.Text = "Service stopped."; }
        }

        /// <summary>
        /// The top-bar buttons control the WINDOWS SERVICE whenever it is installed — that is the thing
        /// that actually runs the jobs on this machine. Only when no service is installed do they start
        /// and stop the scheduler inside this window.
        /// </summary>
        private void OnStartServiceClicked()
        {
            // Build 42x: "Start Service" = install (or repair) + start the Windows service, and the
            // elevated helper reports "Service installed successfully". /install is idempotent: it creates
            // the service when missing, otherwise re-points it at THIS SyncDB.exe - so an old copy that is
            // still registered from another folder is replaced instead of silently running old code.
            if (appSchedRunning)
            {
                // The window's own scheduler must let go first, or the service could not take over.
                StopService(false);
                AppLog.Info("-", "In-window scheduler stopped - the Windows service takes over.");
            }
            lblStatus.Text = Lang.T("Installing and starting the Windows service… (allow the administrator prompt)");
            AppLog.Info("-", "Windows service install/start requested from the top bar.");
            Audit.Write("SERVICE_START", "top bar: install + start the Windows service");
            WinSvc.LaunchCommand("/install");
        }

        private void OnStopServiceClicked()
        {
            string st;
            try { st = WinSvc.Status(); }
            catch { st = "Not installed"; }

            // Stop/remove is a destructive service-management action. Ask before stopping
            // either the Windows service or the scheduler running inside this window.
            string confirmText = st != "Not installed"
                ? Lang.T("Are you sure you want to stop and remove the SyncDB service?")
                : Lang.T("Are you sure you want to stop the scheduler in this window?");
            if (MessageBox.Show(this, confirmText, Lang.T("Confirm"),
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                return;

            if (appSchedRunning) StopService(true);      // the scheduler inside this window, if it is on

            if (st != "Not installed")
            {
                // "Stop Service" = stop + remove the Windows service; the elevated helper reports
                // "Service removed successfully". The next "Start Service" installs it again.
                lblStatus.Text = Lang.T("Stopping and removing the Windows service… (allow the administrator prompt)");
                AppLog.Info("-", "Windows service stop/remove requested from the top bar (status was " + st + ").");
                Audit.Write("SERVICE_STOP", "top bar: stop + remove the Windows service");
                WinSvc.LaunchCommand("/uninstall");
            }
            else if (!appSchedRunning)
            {
                lblStatus.Text = Lang.T("Service stopped successfully.");
                MessageBox.Show(this, Lang.T("Service stopped successfully."), Lang.T("SyncDB service"),
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>State of the Windows service (refreshed by the 2-second timer).</summary>
        private void SetWinServiceUi(bool running)
        {
            winSvcRunning = running;
            RefreshServiceUi();
        }

        /// <summary>State of the scheduler running inside this window.</summary>
        private void SetAppSchedulerUi(bool running)
        {
            appSchedRunning = running;
            RefreshServiceUi();
        }

        /// <summary>Top-bar Async status with a small data-flow animation while a transfer is active.</summary>
        private void RefreshAsyncLabel()
        {
            if (lblAsync == null) return;
            string text = "";
            bool transferring = false;
            try
            {
                // This indicator belongs only to enabled Async - Every Change jobs.
                // Do not show it for normal scheduled/manual transfers, and clear stale
                // async_status.txt immediately after the last Async job is deleted/disabled.
                if (!HasEnabledAsyncJob(config))
                {
                    _transferAnimationFrame = 0;
                    lblAsync.ForeColor = Theme.Muted;
                    if (lblAsync.Text.Length > 0) lblAsync.Text = "";
                    return;
                }

                string liveJobName = "";
                lock (RunTrace.LiveLock)
                {
                    if (RunTrace.LiveRunning) liveJobName = RunTrace.LiveJob ?? "";
                }
                if (liveJobName.Length > 0 && config != null && config.Jobs != null)
                    foreach (SyncJob j in config.Jobs)
                        if (j != null && j.Enabled && j.Schedule == ScheduleKind.RealtimeAsync &&
                            string.Equals(j.Name ?? "", liveJobName, StringComparison.OrdinalIgnoreCase))
                        {
                            transferring = true;
                            break;
                        }
                string[] frames = { "●○○○", "○●○○", "○○●○", "○○○●", "○○●○", "○●○○" };
                string flow = frames[_transferAnimationFrame++ % frames.Length];
                if (transferring)
                {
                    text = Lang.T("Transferring data") + "  " + flow;
                }

                string p = JobScheduler.AsyncStatusPath;
                if (!transferring && serviceRunning && File.Exists(p))
                {
                    string[] f = File.ReadAllText(p, Encoding.UTF8).Trim().Split('|');
                    if (f.Length >= 8)
                    {
                        long nextTicks; int interval;
                        long.TryParse(f[6], out nextTicks);
                        int.TryParse(f[4], out interval);
                        DateTime next = new DateTime(nextTicks, DateTimeKind.Utc);
                        double left = (next - DateTime.UtcNow).TotalSeconds;
                        // a status that is long overdue belongs to a program that is no longer running
                        if (left > -3 * Math.Max(30, interval))
                        {
                            text = left > 0
                                ? string.Format(Lang.T("Async: next check in {0} s  (every {1} s)  {2}"), (int)Math.Ceiling(left), interval, flow)
                                : Lang.T("Async: checking now…") + "  " + flow;
                        }
                    }
                }
            }
            catch { text = ""; }
            lblAsync.ForeColor = transferring ? Theme.Green : Theme.Muted;
            if (lblAsync.Text != text) lblAsync.Text = text;
        }

        private void RefreshServiceUi()
        {
            serviceRunning = winSvcRunning || appSchedRunning;
            string text;
            Color col;
            if (winSvcRunning && winSvcStale) { text = "Service: RUNNING - OLD COPY (press Start)"; col = Color.DarkOrange; }
            else if (winSvcRunning) { text = "Service: RUNNING (Windows service)"; col = Theme.Green; }
            else if (appSchedRunning) { text = "Service: RUNNING (this window)"; col = Theme.Green; }
            else { text = "Service: STOPPED"; col = Theme.Red; }
            lblServiceState.Text = Lang.T(text);
            lblServiceState.ForeColor = col;
            // Start stays available while the service runs another (older) copy, so one click repairs it.
            btnServiceStart.Enabled = !winSvcRunning || winSvcStale;
            btnServiceStop.Enabled = serviceRunning || winSvcInstalled;
        }

        private TabPage BuildConnectionsTab()
        {
            TabPage page = new TabPage("1) Connections");
            SplitContainer split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterWidth = 6,
                BorderStyle = BorderStyle.FixedSingle
            };
            EventHandler applySplit = null;
            applySplit = (s, e) =>
            {
                try
                {
                    int w = split.ClientSize.Width;
                    if (w < 100) return;
                    split.Panel1MinSize = 80;
                    split.Panel2MinSize = 120;
                    int dist = w * 28 / 100;
                    int min = split.Panel1MinSize;
                    int max = w - split.Panel2MinSize - split.SplitterWidth;
                    if (max < min) max = min;
                    if (dist < min) dist = min;
                    if (dist > max) dist = max;
                    split.SplitterDistance = dist;
                    split.SizeChanged -= applySplit;
                }
                catch { }
            };
            split.SizeChanged += applySplit;
            page.VisibleChanged += (s, e) => { if (page.Visible) applySplit(s, e); };

            // LEFT
            Panel left = new Panel { Dock = DockStyle.Fill, Padding = new Padding(6) };
            Label l = new Label
            {
                Text = "Connections (drag middle bar)",
                Dock = DockStyle.Top,
                Height = 22,
                Font = new Font(Font.FontFamily, 9f, FontStyle.Bold)
            };
            FlowLayoutPanel lbar = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                WrapContents = true,
                Padding = new Padding(0, 4, 0, 0)
            };
            lvConn = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                HideSelection = false,
                GridLines = true,
                Font = new Font(Font.FontFamily, 9f)
            };
            lvConn.Columns.Add("Name", 80);
            lvConn.Columns.Add("Server", 100);
            lvConn.Columns.Add("DB", 60);
            lvConn.Columns.Add("Role", 70);
            lvConn.SelectedIndexChanged += (s, e) =>
            {
                if (lvConn.SelectedItems.Count == 0) return;
                ConnectionProfile p = lvConn.SelectedItems[0].Tag as ConnectionProfile;
                if (p != null) LoadConnToEditor(p);
            };
            lvConn.SizeChanged += (s, e) =>
            {
                try
                {
                    int w = lvConn.ClientSize.Width - 4;
                    if (w < 80) return;
                    lvConn.Columns[0].Width = Math.Max(50, w * 25 / 100);
                    lvConn.Columns[1].Width = Math.Max(50, w * 35 / 100);
                    lvConn.Columns[2].Width = Math.Max(40, w * 20 / 100);
                    lvConn.Columns[3].Width = Math.Max(50, w * 20 / 100);
                }
                catch { }
            };
            Button btnAdd = MkBtn("Add", (s, e) =>
            {
                ConnectionProfile p = new ConnectionProfile { Name = "SQL " + (config.Connections.Count + 1) };
                config.Connections.Add(p);
                config.Save();
                RefreshConnectionList();
                LoadConnToEditor(p);
                RefreshSourceDestCombos();
                if (lvConn.Items.Count > 0)
                {
                    lvConn.Items[lvConn.Items.Count - 1].Selected = true;
                    lvConn.EnsureVisible(lvConn.Items.Count - 1);
                }
            });
            Button btnDel = MkBtn("Delete", (s, e) =>
            {
                if (editingConn == null) return;
                if (MessageBox.Show("Delete \"" + editingConn.Name + "\"?", "Confirm", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
                Audit.Write("CONN_DELETE", editingConn.Name + " | server=" + editingConn.Server);
                config.Connections.Remove(editingConn);
                if (config.SourceConnectionId == editingConn.Id) { config.SourceConnectionId = ""; config.SourceConnection = ""; }
                if (config.DestConnectionId == editingConn.Id) { config.DestConnectionId = ""; config.DestConnection = ""; }
                editingConn = null;
                config.Save();
                RefreshConnectionList();
                RefreshSourceDestCombos();
                ClearConnEditor();
                if (lstSrcTables != null) lstSrcTables.Items.Clear();
                if (lstDstTables != null) lstDstTables.Items.Clear();
            });
            Button btnUp = MkBtn("↑", (s, e) => MoveConnection(-1));
            Button btnDn = MkBtn("↓", (s, e) => MoveConnection(1));
            btnUp.Width = 36; btnDn.Width = 36;
            Button btnSetSrc = MkBtn("Set SOURCE", (s, e) => SetConnectionRole(true));
            Button btnSetDst = MkBtn("Set DEST", (s, e) => SetConnectionRole(false));
            Button btnClearRole = MkBtn("Clear role", (s, e) => ClearConnectionRole());
            btnSetSrc.BackColor = Color.FromArgb(220, 240, 220);
            btnSetDst.BackColor = Color.FromArgb(220, 230, 250);
            lbar.Controls.Add(btnAdd);
            lbar.Controls.Add(btnDel);
            lbar.Controls.Add(btnUp);
            lbar.Controls.Add(btnDn);
            lbar.Controls.Add(btnSetSrc);
            lbar.Controls.Add(btnSetDst);
            lbar.Controls.Add(btnClearRole);
            left.Controls.Add(lvConn);
            left.Controls.Add(lbar);
            left.Controls.Add(l);
            split.Panel1.Controls.Add(left);

            // RIGHT form
            Panel right = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(12, 8, 12, 8) };
            Label formTitle = new Label
            {
                Text = "Connection properties",
                Dock = DockStyle.Top,
                Height = 26,
                Font = new Font(Font.FontFamily, 10f, FontStyle.Bold)
            };
            TableLayoutPanel t = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2 };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            Func<TextBox> box = () =>
            {
                TextBox tb = new TextBox { Dock = DockStyle.Fill, Font = new Font(Font.FontFamily, 9f), Margin = new Padding(2, 3, 2, 3) };
                return tb;
            };
            int row = 0;
            Action<string, Control, int> addRow = (label, c, h) =>
            {
                t.RowStyles.Add(new RowStyle(SizeType.Absolute, h));
                Label lb = new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(2, 3, 6, 3) };
                c.Margin = new Padding(2, 3, 2, 3);
                if (!(c is CheckBox) && !(c is FlowLayoutPanel)) c.Dock = DockStyle.Fill;
                t.Controls.Add(lb, 0, row);
                t.Controls.Add(c, 1, row);
                row++;
            };

            txtConnName = box(); SetCue(txtConnName, "display name e.g. SyncData-Prod");
            txtConnServer = box(); SetCue(txtConnServer, "host or IP e.g. 192.168.0.10");
            txtConnPort = box(); txtConnPort.Text = "1433";
            txtConnDb = box(); SetCue(txtConnDb, "database name e.g. MyDatabase");
            txtConnUser = box(); SetCue(txtConnUser, "SQL login e.g. sa");
            txtConnPassword = box(); txtConnPassword.UseSystemPasswordChar = true;

            chkTrustCert = new CheckBox { Text = "TrustServerCertificate = yes", AutoSize = true, Checked = true };
            chkIntegrated = new CheckBox { Text = "Windows Authentication", AutoSize = true };
            chkIntegrated.CheckedChanged += (s, e) =>
            {
                txtConnUser.Enabled = !chkIntegrated.Checked;
                txtConnPassword.Enabled = !chkIntegrated.Checked;
            };
            CheckBox chkShowPwd = new CheckBox { Text = "Show password", AutoSize = true };
            chkShowPwd.CheckedChanged += (s, e) => { txtConnPassword.UseSystemPasswordChar = !chkShowPwd.Checked; };

            txtConnStringPreview = new TextBox
            {
                ReadOnly = true, Multiline = true, Height = 52, ScrollBars = ScrollBars.Vertical,
                Font = new Font("Consolas", 8.5f), Dock = DockStyle.Fill
            };

            addRow("Name", txtConnName, 30);
            addRow("Server", txtConnServer, 30);
            addRow("Port", txtConnPort, 30);
            addRow("Database", txtConnDb, 30);
            addRow("User name", txtConnUser, 30);
            addRow("Password", txtConnPassword, 30);
            addRow("", chkTrustCert, 26);
            addRow("", chkIntegrated, 26);
            addRow("", chkShowPwd, 26);
            addRow("Conn. string", txtConnStringPreview, 60);

            FlowLayoutPanel bar = new FlowLayoutPanel { AutoSize = true, WrapContents = true, Dock = DockStyle.Fill };
            bar.Controls.Add(MkBtn("Save connection", (s, e) => SaveConnFromEditor()));
            bar.Controls.Add(MkBtn("Test", async (s, e) =>
            {
                ConnectionProfile tmp = ReadConnFromEditor();
                if (tmp == null) return;
                if (string.IsNullOrWhiteSpace(tmp.Server))
                {
                    MessageBox.Show("Server is empty. Type host/IP in Server box.");
                    return;
                }
                string cs = tmp.BuildConnectionString();
                txtConnStringPreview.Text = MaskPassword(cs);
                connStrVisible = false;
                if (btnShowString != null) btnShowString.Text = Lang.T("Show string");
                string r = await Task.Run(() => Engine.TestConnection(cs));
                MessageBox.Show(r, "Test — " + tmp.Name);
            }));
            btnShowString = MkBtn("Show string", (s, e) =>
            {
                ConnectionProfile tmp = ReadConnFromEditor();
                if (tmp == null) return;
                string full = tmp.BuildConnectionString();
                if (string.IsNullOrEmpty(full)) { MessageBox.Show("Fill Server / Database first."); return; }
                if (!connStrVisible)
                {
                    txtConnStringPreview.Text = full;
                    btnShowString.Text = Lang.T("Hide string");
                    connStrVisible = true;
                }
                else
                {
                    txtConnStringPreview.Text = MaskPassword(full);
                    btnShowString.Text = Lang.T("Show string");
                    connStrVisible = false;
                }
            });
            bar.Controls.Add(btnShowString);
            addRow("Actions", bar, 40);

            Label tip = new Label
            {
                AutoSize = true,
                ForeColor = SystemColors.GrayText,
                Text = "Set SOURCE/DEST: the clicked row takes that colour (green / blue / yellow = both ends). * = the active one."
            };
            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(tip, 0, row);
            t.SetColumnSpan(tip, 2);

            right.Controls.Add(t);
            right.Controls.Add(formTitle);
            split.Panel2.Controls.Add(right);
            page.Controls.Add(split);
            return page;
        }

        private ConnectionProfile ReadConnFromEditor()
        {
            ConnectionProfile p = editingConn ?? new ConnectionProfile();
            p.Name = (txtConnName.Text ?? "").Trim();
            if (p.Name.Length == 0) p.Name = "Connection";
            p.Server = (txtConnServer.Text ?? "").Trim();
            int port;
            if (!int.TryParse((txtConnPort.Text ?? "").Trim(), out port)) port = 1433;
            p.Port = port;
            p.Database = (txtConnDb.Text ?? "").Trim();
            p.User = (txtConnUser.Text ?? "").Trim();
            p.Password = txtConnPassword.Text ?? "";
            p.TrustServerCertificate = chkTrustCert.Checked;
            p.IntegratedSecurity = chkIntegrated.Checked;
            return p;
        }

        private void SaveConnFromEditor()
        {
            if (editingConn == null)
            {
                editingConn = new ConnectionProfile();
                config.Connections.Add(editingConn);
            }
            ConnectionProfile p = ReadConnFromEditor();
            editingConn.Name = p.Name;
            editingConn.Server = p.Server;
            editingConn.Port = p.Port;
            editingConn.Database = p.Database;
            editingConn.User = p.User;
            editingConn.Password = p.Password;
            editingConn.TrustServerCertificate = p.TrustServerCertificate;
            editingConn.IntegratedSecurity = p.IntegratedSecurity;
            config.Save();
            RefreshConnectionList();
            RefreshSourceDestCombos();
            txtConnStringPreview.Text = MaskPassword(editingConn.BuildConnectionString());
            connStrVisible = false;
            if (btnShowString != null) btnShowString.Text = Lang.T("Show string");
            lblStatus.Text = "Connection saved: " + editingConn.Name;
            Audit.Write("CONN_SAVED", editingConn.Name + " | server=" + editingConn.Server + " | db=" + editingConn.Database + " | user=" + editingConn.User);
            MessageBox.Show("Connection saved.");
        }

        private void LoadConnToEditor(ConnectionProfile p)
        {
            editingConn = p;
            txtConnName.Text = p.Name ?? "";
            txtConnServer.Text = p.Server ?? "";
            txtConnPort.Text = p.Port > 0 ? p.Port.ToString() : "1433";
            txtConnDb.Text = p.Database ?? "";
            txtConnUser.Text = p.User ?? "";
            txtConnPassword.Text = p.Password ?? "";
            chkTrustCert.Checked = p.TrustServerCertificate;
            chkIntegrated.Checked = p.IntegratedSecurity;
            txtConnUser.Enabled = !chkIntegrated.Checked;
            txtConnPassword.Enabled = !chkIntegrated.Checked;
            txtConnStringPreview.Text = MaskPassword(p.BuildConnectionString());
            connStrVisible = false;
            if (btnShowString != null) btnShowString.Text = Lang.T("Show string");
        }

        private void ClearConnEditor()
        {
            editingConn = null;
            txtConnName.Text = "";
            txtConnServer.Text = "";
            txtConnPort.Text = "1433";
            txtConnDb.Text = "";
            txtConnUser.Text = "";
            txtConnPassword.Text = "";
            chkTrustCert.Checked = true;
            chkIntegrated.Checked = false;
            txtConnStringPreview.Text = "";
            connStrVisible = false;
            if (btnShowString != null) btnShowString.Text = Lang.T("Show string");
        }

        private static string MaskPassword(string cs)
        {
            if (string.IsNullOrEmpty(cs)) return cs;
            int i = cs.IndexOf("Password=", StringComparison.OrdinalIgnoreCase);
            if (i < 0) return cs;
            int start = i + "Password=".Length;
            int end = cs.IndexOf(';', start);
            if (end < 0) end = cs.Length;
            return cs.Substring(0, start) + "********" + cs.Substring(end);
        }

        /// <summary>"SOURCE" / "DEST" / "SRC+DEST". The active one (the one tabs 2/3 and Transfer use)
        /// gets a plain " *" - no star glyph and no bold font, both looked wrong in some fonts.</summary>
        private static string RoleText(ConnectionProfile p, bool isSrc, bool isDst)
        {
            bool s = p.HasSourceTag(), d = p.HasDestTag();
            if (s && d) return "SRC+DEST" + (isSrc || isDst ? " *" : "");
            if (s) return "SOURCE" + (isSrc ? " *" : "");
            if (d) return "DEST" + (isDst ? " *" : "");
            return "-";
        }

        private void RefreshConnectionList()
        {
            // keep scroll position + selection (the list used to jump to the top after every change)
            int top = 0;
            try { if (lvConn.TopItem != null) top = lvConn.TopItem.Index; } catch { }
            ConnectionProfile sel = lvConn.SelectedItems.Count > 0 ? lvConn.SelectedItems[0].Tag as ConnectionProfile : null;
            bool migrated = false;

            lvConn.BeginUpdate();
            lvConn.Items.Clear();
            foreach (ConnectionProfile p in config.Connections)
            {
                bool isSrc = p.Id == config.SourceConnectionId;
                bool isDst = p.Id == config.DestConnectionId;
                // older configs: the active SOURCE/DEST had no saved colour yet
                if (isSrc && !p.HasSourceTag()) { p.AddRoleTag(true); migrated = true; }
                if (isDst && !p.HasDestTag()) { p.AddRoleTag(false); migrated = true; }

                ListViewItem it = new ListViewItem(p.Name ?? "");
                string srv = p.Server ?? "";
                if (p.Port > 0) srv += "," + p.Port;
                it.SubItems.Add(srv);
                it.SubItems.Add(p.Database ?? "");
                it.SubItems.Add(RoleText(p, isSrc, isDst));
                it.Tag = p;
                if (p.HasSourceTag() && p.HasDestTag()) it.BackColor = Color.FromArgb(255, 255, 200);
                else if (p.HasSourceTag()) it.BackColor = Color.FromArgb(220, 245, 220);
                else if (p.HasDestTag()) it.BackColor = Color.FromArgb(220, 230, 250);
                // no bold any more - the active connection is marked with " *" in the Role column
                lvConn.Items.Add(it);
                if (sel != null && p == sel) it.Selected = true;
            }
            lvConn.EndUpdate();
            if (lvConn.Items.Count > 0)
            {
                if (top >= lvConn.Items.Count) top = lvConn.Items.Count - 1;
                try { lvConn.TopItem = lvConn.Items[top]; } catch { }
            }
            if (migrated) { try { config.Save(); } catch { } }
        }

        private void SetConnectionRole(bool asSource)
        {
            if (lvConn.SelectedItems.Count == 0)
            {
                MessageBox.Show("Select a connection in the list first.");
                return;
            }
            ConnectionProfile p = lvConn.SelectedItems[0].Tag as ConnectionProfile;
            if (p == null) return;
            // An explicit click decides THIS connection's colour: "Set DEST" means DEST.
            // (AddRoleTag only ever ADDED a role, so a connection that had once been the
            //  SOURCE turned yellow SRC+DEST on "Set DEST" and kept showing up in the
            //  Source tab's connection list.) The other half is kept only when this
            //  connection really is the other active end as well.
            bool alsoOther = asSource ? (config.DestConnectionId == p.Id) : (config.SourceConnectionId == p.Id);
            p.RoleTag = alsoOther ? "Both" : (asSource ? "Source" : "Dest");
            if (asSource)
            {
                config.SourceConnectionId = p.Id;
                config.SourceConnection = p.BuildConnectionString();
            }
            else
            {
                config.DestConnectionId = p.Id;
                config.DestConnection = p.BuildConnectionString();
            }
            config.Save();
            RefreshConnectionList();
            RefreshSourceDestCombos();
            // reselect (RefreshConnectionList keeps the scroll position)
            for (int i = 0; i < lvConn.Items.Count; i++)
                if (lvConn.Items[i].Tag == p) { lvConn.Items[i].Selected = true; lvConn.Items[i].Focused = true; break; }
            lblStatus.Text = (asSource ? "SOURCE" : "DEST") + " = " + p.Name;
            Audit.Write(asSource ? "SET_SOURCE" : "SET_DEST", p.Name + " | server=" + p.Server + " | db=" + p.Database);
            UpdateRouteInfo();
        }

        private void ClearConnectionRole()
        {
            if (lvConn.SelectedItems.Count == 0)
            {
                MessageBox.Show("Select a connection first.");
                return;
            }
            ConnectionProfile p = lvConn.SelectedItems[0].Tag as ConnectionProfile;
            if (p == null) return;
            p.RoleTag = "";
            if (config.SourceConnectionId == p.Id)
            {
                config.SourceConnectionId = "";
                config.SourceConnection = "";
            }
            if (config.DestConnectionId == p.Id)
            {
                config.DestConnectionId = "";
                config.DestConnection = "";
            }
            config.Save();
            RefreshConnectionList();
            RefreshSourceDestCombos();
            lblStatus.Text = "Role cleared for " + p.Name;
            UpdateRouteInfo();
        }

        private void MoveConnection(int delta)
        {
            if (lvConn.SelectedItems.Count == 0) return;
            ConnectionProfile p = lvConn.SelectedItems[0].Tag as ConnectionProfile;
            if (p == null) return;
            int idx = config.Connections.IndexOf(p);
            int neu = idx + delta;
            if (idx < 0 || neu < 0 || neu >= config.Connections.Count) return;
            config.Connections.RemoveAt(idx);
            config.Connections.Insert(neu, p);
            config.Save();
            RefreshConnectionList();
            RefreshSourceDestCombos();
            for (int i = 0; i < lvConn.Items.Count; i++)
            {
                if (lvConn.Items[i].Tag == p)
                {
                    lvConn.Items[i].Selected = true;
                    lvConn.EnsureVisible(i);
                    break;
                }
            }
        }

        private void RefreshSourceDestCombos()
        {
            // Source tab: every SOURCE-coloured connection; Dest tab: every DEST-coloured one.
            // Always show the ACTIVE role (config) - the old combo choice used to win and DEST became "(none)".
            FillConnCombo(cbSourceConn, true);
            FillConnCombo(cbDestConn, false);
            SelectComboById(cbSourceConn, config.SourceConnectionId);
            SelectComboById(cbDestConn, config.DestConnectionId);
            try { RefreshDatabaseCombo(true); } catch { }
            try { RefreshDatabaseCombo(false); } catch { }
        }

        /// <param name="forSource">true = only SOURCE role; false = only DEST role</param>
        private void FillConnCombo(ComboBox cb, bool forSource)
        {
            if (cb == null) return;
            cb.Items.Clear();
            cb.Items.Add(new ConnItem("", "(select connection)"));
            int added = 0;
            foreach (ConnectionProfile p in config.Connections)
            {
                bool isSrc = p.Id == config.SourceConnectionId;
                bool isDst = p.Id == config.DestConnectionId;
                if (forSource)
                {
                    if (!isSrc && !p.HasSourceTag()) continue; // only SOURCE-coloured
                }
                else
                {
                    if (!isDst && !p.HasDestTag()) continue; // only DEST-coloured
                }
                bool active = forSource ? isSrc : isDst;
                string mark = (forSource ? "[SOURCE] " : "[DEST] ") + (active ? "(active) " : "");
                cb.Items.Add(new ConnItem(p.Id, mark + p.Name + "  —  " + p.Server));
                added++;
            }
            if (added == 0)
            {
                // nothing marked yet — hint item (not selectable as real connection)
                cb.Items.Add(new ConnItem("", forSource
                    ? "(no SOURCE set — use Connections tab: Set SOURCE)"
                    : "(no DEST set — use Connections tab: Set DEST)"));
            }
        }

        private class ConnItem
        {
            public string Id, Text;
            public ConnItem(string id, string text) { Id = id; Text = text; }
            public override string ToString() { return Text; }
        }

        private static string GetComboId(ComboBox cb)
        {
            if (cb == null || cb.SelectedItem == null) return "";
            ConnItem it = cb.SelectedItem as ConnItem;
            return it != null ? it.Id : "";
        }

        private static void SelectComboById(ComboBox cb, string id)
        {
            if (cb == null) return;
            for (int i = 0; i < cb.Items.Count; i++)
            {
                ConnItem it = cb.Items[i] as ConnItem;
                if (it != null && it.Id == (id ?? "")) { cb.SelectedIndex = i; return; }
            }
            if (cb.Items.Count > 0) cb.SelectedIndex = 0;
        }

        private void SaveSelectedRoles()
        {
            config.SourceConnectionId = GetComboId(cbSourceConn);
            config.DestConnectionId = GetComboId(cbDestConn);
            config.SourceConnection = config.ResolveSourceConnectionString();
            config.DestConnection = config.ResolveDestConnectionString();
        }

        private string GetSelectedDatabase(bool source)
        {
            ComboBox cb = source ? cbSrcDb : cbDstDb;
            if (cb == null || cb.SelectedItem == null) return "";
            return Convert.ToString(cb.SelectedItem).Trim();
        }

        private async void RefreshRoleTables(bool source)
        {
            ListBox list = source ? lstSrcTables : lstDstTables;
            Label info = source ? lblSrcInfo : lblDstInfo;
            if (list == null) return;
            try
            {
                string cs = GetRoleConnectionString(source);
                if (string.IsNullOrWhiteSpace(cs))
                {
                    list.Items.Clear();
                    if (info != null) info.Text = "Connection or database is not selected.";
                    return;
                }
                List<string> tables = await Task.Run(() => Engine.ListTablesAndViews(cs));
                if (IsDisposed) return;
                list.Items.Clear();
                int nT = 0, nV = 0;
                foreach (string x in tables)
                {
                    list.Items.Add(x);
                    if (x.StartsWith("[VIEW]", StringComparison.OrdinalIgnoreCase)) nV++; else nT++;
                }
                string dbName = GetSelectedDatabase(source);
                if (info != null)
                    info.Text = nT + " table(s), " + nV + " view(s)" +
                        (string.IsNullOrEmpty(dbName) ? "" : "  |  DB: " + dbName);
            }
            catch (Exception ex)
            {
                if (info != null) info.Text = "Could not load tables/views: " + ex.Message;
            }
        }

        /// <summary>Connection string for Source/Dest tab using the database chosen in the DB combo.</summary>
        private string GetRoleConnectionString(bool source)
        {
            string baseCs = source ? config.ResolveSourceConnectionString() : config.ResolveDestConnectionString();
            string db = GetSelectedDatabase(source);
            if (string.IsNullOrEmpty(db) || string.IsNullOrWhiteSpace(baseCs)) return baseCs;
            return ConnectionStringWithDatabase(baseCs, db);
        }

        private static string ConnectionStringWithDatabase(string connectionString, string database)
        {
            if (string.IsNullOrWhiteSpace(connectionString) || string.IsNullOrWhiteSpace(database))
                return connectionString;
            try
            {
                System.Text.RegularExpressions.Regex re =
                    new System.Text.RegularExpressions.Regex(@"(Initial Catalog|Database)\s*=\s*[^;]*",
                        System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                if (re.IsMatch(connectionString))
                    return re.Replace(connectionString, "Initial Catalog=" + database.Trim());
                return connectionString.TrimEnd(';') + ";Initial Catalog=" + database.Trim() + ";";
            }
            catch { return connectionString; }
        }

        /// <summary>Fill Database combo from sys.databases on the selected connection's server.</summary>
        // Which connection tab 2 / tab 3 last filled their Database list from. A connection
        // that CHANGED must not keep the previous server's database or its table list.
        private string _dbComboSrcId = null, _dbComboDstId = null;

        private void RefreshDatabaseCombo(bool source)
        {
            ComboBox cbDb = source ? cbSrcDb : cbDstDb;
            if (cbDb == null) return;
            ListBox tlist = source ? lstSrcTables : lstDstTables;
            Label tinfo = source ? lblSrcInfo : lblDstInfo;

            string id = GetComboId(source ? cbSourceConn : cbDestConn);
            string lastId = source ? _dbComboSrcId : _dbComboDstId;
            bool firstFill = lastId == null;                       // startup / tab built: behave as before
            bool connChanged = !firstFill && !string.Equals(lastId, id ?? "", StringComparison.OrdinalIgnoreCase);
            if (source) _dbComboSrcId = id ?? ""; else _dbComboDstId = id ?? "";

            string prev = GetSelectedDatabase(source);
            cbDb.Items.Clear();
            if (string.IsNullOrEmpty(id)) { ClearRoleTables(connChanged, tlist, tinfo); return; }
            ConnectionProfile p = config.FindConnection(id);
            if (p == null) { ClearRoleTables(connChanged, tlist, tinfo); return; }
            // another connection means another server: its own database wins over the name
            // that was selected for the previous one (which may not exist there at all)
            string prefer = connChanged ? (p.Database ?? "").Trim()
                                        : (!string.IsNullOrEmpty(prev) ? prev : (p.Database ?? "").Trim());
            string cs = p.BuildConnectionString();
            if (string.IsNullOrWhiteSpace(cs)) { ClearRoleTables(connChanged, tlist, tinfo); return; }
            try
            {
                List<string> dbs = Engine.ListDatabases(cs);
                foreach (string d in dbs) cbDb.Items.Add(d);
            }
            catch
            {
                if (!string.IsNullOrEmpty(prefer)) cbDb.Items.Add(prefer);
            }
            if (cbDb.Items.Count == 0 && !string.IsNullOrEmpty(prefer))
                cbDb.Items.Add(prefer);
            if (!string.IsNullOrEmpty(prefer))
            {
                int ix = cbDb.Items.IndexOf(prefer);
                if (ix < 0) { cbDb.Items.Insert(0, prefer); ix = 0; }
                cbDb.SelectedIndex = ix;
            }
            else if (cbDb.Items.Count > 0) cbDb.SelectedIndex = 0;

            // SelectedIndex often lands on the SAME index as before (each server's own
            // database can sit at index 0), so SelectedIndexChanged does not fire and the
            // PREVIOUS server's tables stayed on screen. Reload them here instead.
            if (connChanged)
            {
                if (tlist != null) tlist.Items.Clear();
                if (tinfo != null) tinfo.Text = "Loading tables and views...";
                try { BeginInvoke(new Action(() => RefreshRoleTables(source))); } catch { }
            }
        }

        private static void ClearRoleTables(bool connChanged, ListBox list, Label info)
        {
            if (!connChanged || list == null) return;
            list.Items.Clear();
            if (info != null) info.Text = "Connection or database is not selected.";
        }

        /// <summary>Write the chosen database name back onto the connection profile.</summary>
        private void ApplySelectedDatabaseToProfile(bool source)
        {
            string id = GetComboId(source ? cbSourceConn : cbDestConn);
            if (string.IsNullOrEmpty(id)) return;
            ConnectionProfile p = config.FindConnection(id);
            if (p == null) return;
            string db = GetSelectedDatabase(source);
            if (!string.IsNullOrEmpty(db)) p.Database = db;
        }

        private TabPage BuildRoleTab(bool source)
        {
            TabPage page = new TabPage(source ? "2) Database 1 (Source)" : "3) Database 2 (Destination)");
            Panel p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12) };
            Label title = new Label
            {
                Text = source
                    ? "SOURCE — pick connection (data is READ from here)"
                    : "DESTINATION — pick connection (data is WRITTEN here)",
                Dock = DockStyle.Top,
                Height = 28,
                Font = new Font(Font, FontStyle.Bold)
            };
            FlowLayoutPanel row = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, WrapContents = true };
            row.Controls.Add(new Label { Text = "Connection:", AutoSize = true, Margin = new Padding(3, 8, 6, 0) });
            ComboBox cb = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 300 };
            if (source) cbSourceConn = cb; else cbDestConn = cb;
            row.Controls.Add(cb);

            row.Controls.Add(new Label
            {
                Text = source ? "Database (read from):" : "Database (write to):",
                AutoSize = true,
                Margin = new Padding(12, 8, 6, 0)
            });
            ComboBox cbDb = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 200 };
            if (source) cbSrcDb = cbDb; else cbDstDb = cbDb;
            row.Controls.Add(cbDb);

            bool isSrc = source;
            cbDb.SelectedIndexChanged += (s, e) =>
            {
                try { BeginInvoke(new Action(() => RefreshRoleTables(isSrc))); } catch { }
            };
            // when connection changes → reload database list
            cb.SelectedIndexChanged += (s, e) =>
            {
                try { BeginInvoke(new Action(() => RefreshDatabaseCombo(isSrc))); } catch { }
            };

            row.Controls.Add(MkBtn("Save selection", (s, e) =>
            {
                SaveSelectedRoles();
                ApplySelectedDatabaseToProfile(isSrc);
                config.Save();
                RefreshConnectionList();
                MessageBox.Show("Saved.");
            }));
            row.Controls.Add(MkBtn("Test", async (s, e) =>
            {
                string id = GetComboId(isSrc ? cbSourceConn : cbDestConn);
                if (string.IsNullOrEmpty(id)) { MessageBox.Show("No connection selected."); return; }
                SaveSelectedRoles();
                string cs = GetRoleConnectionString(isSrc);
                if (string.IsNullOrWhiteSpace(cs)) { MessageBox.Show("Connection invalid."); return; }
                MessageBox.Show(await Task.Run(() => Engine.TestConnection(cs)));
            }));
            row.Controls.Add(MkBtn("List tables & views", (s, e) =>
            {
                string id = GetComboId(isSrc ? cbSourceConn : cbDestConn);
                if (string.IsNullOrEmpty(id))
                {
                    MessageBox.Show("No connection selected.");
                    return;
                }
                SaveSelectedRoles();
                string cs = GetRoleConnectionString(isSrc);
                if (string.IsNullOrWhiteSpace(cs)) { MessageBox.Show("Connection invalid."); return; }
                RefreshRoleTables(isSrc);
            }));
            row.Controls.Add(MkBtn("▶ Select (preview data)", (s, e) =>
            {
                ListBox lst = isSrc ? lstSrcTables : lstDstTables;
                BuildSelectScripts(isSrc, lst, false, true);
            }));
            if (source)
            {
                row.Controls.Add(MkBtn("Create job: checked tables...", (s, e) => CreateTransferJobsFromSelected()));
            }
            row.Controls.Add(MkBtn("Create SELECT", (s, e) =>
            {
                ListBox lst = isSrc ? lstSrcTables : lstDstTables;
                BuildSelectScripts(isSrc, lst, false);
            }));
            row.Controls.Add(MkBtn("Create SELECT all", (s, e) =>
            {
                ListBox lst = isSrc ? lstSrcTables : lstDstTables;
                BuildSelectScripts(isSrc, lst, true);
            }));

            row.Controls.Add(MkBtn("Select all", (s, e) => CheckAllItems(isSrc ? lstSrcTables : lstDstTables, true, false)));
            row.Controls.Add(MkBtn("Select tables only", (s, e) => CheckAllItems(isSrc ? lstSrcTables : lstDstTables, true, true)));
            row.Controls.Add(MkBtn("Select none", (s, e) => CheckAllItems(isSrc ? lstSrcTables : lstDstTables, false, false)));
            row.Controls.Add(MkBtn("Export checked tables → CSV...", (s, e) => ExportCheckedTablesCsv(isSrc)));
            row.Controls.Add(MkBtn("Export job config...", (s, e) => ExportJobsUi()));
            Button btnLUp = MkBtn("↑", (s, e) => MoveListItem(isSrc ? lstSrcTables : lstDstTables, -1));
            Button btnLDn = MkBtn("↓", (s, e) => MoveListItem(isSrc ? lstSrcTables : lstDstTables, 1));
            btnLUp.Width = 36; btnLDn.Width = 36;
            row.Controls.Add(btnLUp);
            row.Controls.Add(btnLDn);

            CheckedListBox list = new CheckedListBox { Dock = DockStyle.Fill, IntegralHeight = false, CheckOnClick = true, HorizontalScrollbar = true };
            if (source) lstSrcTables = list; else lstDstTables = list;
            list.DoubleClick += (s, e) => BuildSelectScripts(source, list, false, true, true);

            // action buttons are disabled until something is ticked / selected
            Action updBtns = () =>
            {
                bool any = list.CheckedItems.Count > 0 || list.SelectedItems.Count > 0;
                foreach (Control c in row.Controls)
                {
                    Button b = c as Button;
                    if (b == null) continue;
                    foreach (string need in new string[] { "▶ Select (preview data)", "Create job: checked tables...", "Create SELECT", "Export checked tables → CSV..." })
                        if (b.Text == need || b.Text == Lang.T(need)) b.Enabled = any;
                }
            };
            list.ItemCheck += (s, e) => BeginInvoke(updBtns);
            list.SelectedIndexChanged += (s, e) => updBtns();
            updBtns();

            ContextMenuStrip lcm = new ContextMenuStrip();
            lcm.Items.Add("Select all", null, (s, e) => CheckAllItems(list, true, false));
            lcm.Items.Add("Select tables only", null, (s, e) => CheckAllItems(list, true, true));
            lcm.Items.Add("Select none", null, (s, e) => CheckAllItems(list, false, false));
            lcm.Items.Add("Invert", null, (s, e) => { for (int i = 0; i < list.Items.Count; i++) list.SetItemChecked(i, !list.GetItemChecked(i)); });
            lcm.Items.Add(new ToolStripSeparator());
            lcm.Items.Add("Tick highlighted", null, (s, e) => { foreach (int i in new List<int>(list.SelectedIndices.Cast<int>())) list.SetItemChecked(i, true); });
            lcm.Items.Add("Untick highlighted", null, (s, e) => { foreach (int i in new List<int>(list.SelectedIndices.Cast<int>())) list.SetItemChecked(i, false); });
            lcm.Items.Add(new ToolStripSeparator());
            lcm.Items.Add("Preview data", null, (s, e) => BuildSelectScripts(source, list, false, true));
            if (source) lcm.Items.Add("Create job: checked tables...", null, (s, e) => CreateTransferJobsFromSelected());
            lcm.Items.Add("Export checked tables → CSV...", null, (s, e) => ExportCheckedTablesCsv(source));
            list.ContextMenuStrip = lcm;

            Label infoLbl = new Label { Dock = DockStyle.Bottom, Height = 22, ForeColor = SystemColors.GrayText };
            if (source) lblSrcInfo = infoLbl; else lblDstInfo = infoLbl;
            infoLbl.Text = "Tick the tables (checkbox).  Double-click a table to preview its data.  Checked tables -> Create job / Export CSV / Select.";

            p.Controls.Add(list);
            p.Controls.Add(infoLbl);
            p.Controls.Add(row);
            p.Controls.Add(title);
            page.Controls.Add(p);
            page.Enter += (s, e) =>
            {
                RefreshSourceDestCombos();
            };
            return page;
        }

        private TabPage BuildJobsListTab()
        {
            TabPage page = new TabPage("4) Jobs / Transfer");
            Panel p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8) };

            Panel top = new Panel { Dock = DockStyle.Top, Height = 92, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, MinimumSize = new Size(0, 92) };
            lblRouteInfo = new Label { Dock = DockStyle.Top, Height = 54, AutoSize = false, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(8, 3, 8, 2), Font = new Font("Segoe UI", 8.75f), Text = "Source → Dest: (not set)" };
            FlowLayoutPanel topBar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 34, WrapContents = true,
                AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, MinimumSize = new Size(0, 32) };
            Button run = new Button
            {
                Text = "  ▶  Send to Database 2 (Run selected job)  ",
                AutoSize = true, Height = 32,
                BackColor = Color.FromArgb(30, 100, 60), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font(Font, FontStyle.Bold)
            };
            _runButton = run;
            run.Click += btnRun_Click;
            topBar.Controls.Add(run);
            Button runMany = new Button
            {
                Text = "  ▶▶  Run checked jobs (in order)  ",
                AutoSize = true, Height = 32,
                BackColor = Color.FromArgb(20, 90, 140), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font(Font, FontStyle.Bold)
            };
            _runManyButton = runMany;
            runMany.Click += btnRunMany_Click;
            topBar.Controls.Add(runMany);
            Button stopJob = new Button
            {
                Text = "  ■  Stop job (disable)  ",
                AutoSize = true, Height = 32,
                BackColor = Color.FromArgb(160, 50, 40), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font(Font, FontStyle.Bold)
            };
            stopJob.Click += (s, e) => StopSelectedJob();
            topBar.Controls.Add(stopJob);
            topBar.Controls.Add(MkBtn("Refresh route", (s, e) => UpdateRouteInfo()));
            Button btnResTop = new Button
            {
                Text = "Result OK/Error",
                AutoSize = true,
                Height = 28,
                BackColor = Color.FromArgb(40, 90, 160),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnResTop.Click += (s, e) => ShowJobResultDetails();
            topBar.Controls.Add(btnResTop);
            Button btnHistTop = new Button
            {
                Text = "Job History",
                AutoSize = true,
                Height = 28,
                BackColor = Color.FromArgb(40, 90, 160),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnHistTop.Click += (s, e) => OpenJobHistory();
            topBar.Controls.Add(btnHistTop);
            Button btnOpsTop = new Button
            {
                Text = "Dashboard / Preflight",
                AutoSize = true,
                Height = 28,
                BackColor = Color.FromArgb(110, 80, 150),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnOpsTop.Click += (s, e) => OpenOperations();
            topBar.Controls.Add(btnOpsTop);
            Button btnLiveTop = new Button
            {
                Text = "Transfer status (live)",
                AutoSize = true,
                Height = 28,
                BackColor = Color.FromArgb(60, 110, 90),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnLiveTop.Click += (s, e) => OpenLiveStatus();
            topBar.Controls.Add(btnLiveTop);
            _jobsTopBar = topBar;
            top.Controls.Add(topBar);
            top.Controls.Add(lblRouteInfo);

            Label l = new Label
            {
                Text = "Jobs — Transfer uses Source (tab 2) and Dest (tab 3)",
                Dock = DockStyle.Top, Height = 20, Font = new Font(Font.FontFamily, 8.5f, FontStyle.Bold)
            };
            lvJobs = new ListView
            {
                Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true,
                HideSelection = false, GridLines = true, CheckBoxes = true, AllowDrop = true
            };
            ImageList jobIcons = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
            jobIcons.Images.Add("OK", MakeStatusMark(Color.FromArgb(20, 140, 60), true));
            jobIcons.Images.Add("FAIL", MakeStatusMark(Color.FromArgb(200, 40, 40), false));
            jobIcons.Images.Add("NONE", MakeStatusMark(Color.FromArgb(160, 160, 160), false));
            lvJobs.SmallImageList = jobIcons;
            lvJobs.ItemChecked += (s, e) =>
            {
                if (_jobsLoading) return;
                SyncJob jj = e.Item.Tag as SyncJob;
                if (jj == null || jj.Enabled == e.Item.Checked) return;
                bool v = e.Item.Checked;
                BeginInvoke(new Action(() =>
                {
                    editing = jj;
                    if (!v && Engine.IsRunning(jj.Id)) { Engine.RequestStop(jj.Id); Audit.Write("JOB_STOP", jj.Name + " (unticked while running)"); }
                    SetJobEnabled(jj, v);
                }));
            };
            lvJobs.ItemDrag += (s, e) => { ListViewItem di = e.Item as ListViewItem; if (di == null) return; di.Selected = true; lvJobs.DoDragDrop(di, DragDropEffects.Move); };
            lvJobs.DragEnter += (s, e) => { e.Effect = e.Data.GetDataPresent(typeof(ListViewItem)) ? DragDropEffects.Move : DragDropEffects.None; };
            lvJobs.DragOver += (s, e) => { e.Effect = e.Data.GetDataPresent(typeof(ListViewItem)) ? DragDropEffects.Move : DragDropEffects.None; };
            lvJobs.DragDrop += (s, e) =>
            {
                ListViewItem dragged = e.Data.GetData(typeof(ListViewItem)) as ListViewItem;
                if (dragged == null) return;
                Point pt = lvJobs.PointToClient(new Point(e.X, e.Y));
                ListViewItem target = lvJobs.GetItemAt(5, pt.Y);
                SyncJob dj = dragged.Tag as SyncJob;
                int from = config.Jobs.IndexOf(dj);
                int to = target != null ? config.Jobs.IndexOf(target.Tag as SyncJob) : config.Jobs.Count - 1;
                if (dj == null || from < 0 || to < 0 || from == to) return;
                config.Jobs.RemoveAt(from);
                config.Jobs.Insert(to, dj);
                editing = dj;
                config.Save();
                LoadJobsList();
            };
            lvJobs.Columns.Add("Name", 150);
            lvJobs.Columns.Add("Schedule", 110);
            lvJobs.Columns.Add("Enabled", 60);
            lvJobs.Columns.Add("Steps", 60);
            lvJobs.Columns.Add("State", 75);
            lvJobs.Columns.Add("Last status", 320);
            lvJobs.Columns.Add("Run source", 140);
            lvJobs.SelectedIndexChanged += (s, e) =>
            {
                if (lvJobs.SelectedItems.Count == 0) return;
                editing = lvJobs.SelectedItems[0].Tag as SyncJob;
                UpdateManualRunButtons();
            };
            lvJobs.DoubleClick += (s, e) =>
            {
                if (lvJobs.SelectedItems.Count == 0) return;
                editing = lvJobs.SelectedItems[0].Tag as SyncJob;
                OpenJobDesigner(editing);
            };
            BuildJobsContextMenu();

            FlowLayoutPanel bar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 34, WrapContents = true,
                AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, MinimumSize = new Size(0, 32) };

            // the live window button sits on the left of the row (small screens: everything must fit on one line)
            Button btnLive = new Button
            {
                Text = "Transfer status (live)",
                AutoSize = true,
                Height = 26,
                BackColor = Color.FromArgb(60, 110, 90),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font(Font, FontStyle.Bold)
            };
            btnLive.Click += (s, e) => OpenLiveStatus();
            bar.Controls.Add(btnLive);

            bar.Controls.Add(MkBtn("Add job", btnAdd_Click));
            Button btnJUp = MkBtn("↑", (s, e) => MoveJob(-1));
            Button btnJDn = MkBtn("↓", (s, e) => MoveJob(1));
            btnJUp.Width = 36; btnJDn.Width = 36;
            bar.Controls.Add(btnJUp);
            bar.Controls.Add(btnJDn);
            bar.Controls.Add(MkBtn("Duplicate", btnDuplicate_Click));
            // Edit before Delete (user request)
            bar.Controls.Add(MkBtn("Edit job...", (s, e) =>
            {
                if (editing == null) { MessageBox.Show("Select a job first."); return; }
                OpenJobDesigner(editing);
            }));
            bar.Controls.Add(MkBtn("Delete", btnDelete_Click));
            bar.Controls.Add(MkBtn("Tables / Resources...", (s, e) => OpenResources()));
            bar.Controls.Add(MkBtn("Export...", (s, e) => ExportJobsUi()));
            bar.Controls.Add(MkBtn("Import...", (s, e) => ImportJobsUi()));
            Button btnResult = new Button
            {
                Text = "Result OK / Error",
                AutoSize = true,
                Height = 26,
                BackColor = Color.FromArgb(40, 90, 160),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font(Font, FontStyle.Bold)
            };
            btnResult.Click += (s, e) => ShowJobResultDetails();
            bar.Controls.Add(btnResult);

            Button btnHist = new Button
            {
                Text = "Job History",
                AutoSize = true,
                Height = 26,
                BackColor = Color.FromArgb(40, 90, 160),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font(Font, FontStyle.Bold)
            };
            btnHist.Click += (s, e) => OpenJobHistory();
            bar.Controls.Add(btnHist);

            _jobsBar = bar;

            // the jobs list now fills the page - the live status moved into its own window
            lvJobs.Dock = DockStyle.Fill;

            p.Controls.Add(lvJobs);
            p.Controls.Add(bar);
            p.Controls.Add(l);
            p.Controls.Add(top);
            page.Controls.Add(p);
            page.Enter += (s, e) => UpdateRouteInfo();
            return page;
        }

        private ContextMenuStrip jobsMenu;
        private ToolStripMenuItem miJobStart, miJobStop, miJobEnable, miSvcStart, miSvcStop;

        private void BuildJobsContextMenu()
        {
            jobsMenu = new ContextMenuStrip();
            miJobStart = new ToolStripMenuItem("▶  Start job (enable and run now)", null, (s, e) => StartSelectedJob());
            miJobStop = new ToolStripMenuItem("■  Stop job (stop and disable)", null, (s, e) => StopSelectedJob());
            miJobEnable = new ToolStripMenuItem("✔  Enable job (without running)", null, (s, e) => EnableSelectedJob());
            ToolStripMenuItem miRes = new ToolStripMenuItem("⚙  Tables: use / RAM / CPU / Disk / Index...", null, (s, e) => OpenResources());
            ToolStripMenuItem miEdit = new ToolStripMenuItem("Edit job...", null, (s, e) => { if (editing != null) OpenJobDesigner(editing); });
            ToolStripMenuItem miDup = new ToolStripMenuItem("Duplicate", null, btnDuplicate_Click);
            ToolStripMenuItem miDel = new ToolStripMenuItem("Delete", null, btnDelete_Click);
            miSvcStart = new ToolStripMenuItem("▶  Start the scheduler in this window", null, (s, e) => StartService(true));
            miSvcStop = new ToolStripMenuItem("■  Stop the scheduler in this window", null, (s, e) => StopService(true));
            jobsMenu.Items.AddRange(new ToolStripItem[]
            {
                miJobStart, miJobStop, miJobEnable, new ToolStripSeparator(),
                miRes, new ToolStripSeparator(),
                miEdit, miDup, miDel, new ToolStripSeparator(),
                miSvcStart, miSvcStop
            });
            jobsMenu.Items.Add(new ToolStripSeparator());
            jobsMenu.Items.Add("Job History...", null, (s, e) => OpenJobHistory());
            jobsMenu.Items.Add("Transfer status (live)...", null, (s, e) => OpenLiveStatus());
            jobsMenu.Items.Add(new ToolStripSeparator());
            jobsMenu.Items.Add("Move job up", null, (s, e) => MoveJob(-1));
            jobsMenu.Items.Add("Move job down", null, (s, e) => MoveJob(1));
            jobsMenu.Opening += (s, e) =>
            {
                bool has = editing != null && lvJobs.SelectedItems.Count > 0;
                bool run = has && Engine.IsRunning(editing.Id);
                miJobStart.Enabled = has && !run;
                miJobStop.Enabled = has && (run || editing.Enabled);
                miJobEnable.Enabled = has && !editing.Enabled;
                miRes.Enabled = has;
                miEdit.Enabled = miDup.Enabled = miDel.Enabled = has;
                miSvcStart.Enabled = !serviceRunning;
                miSvcStop.Enabled = appSchedRunning;
            };
            lvJobs.ContextMenuStrip = jobsMenu;
            // right-click selects the row under the mouse first
            lvJobs.MouseDown += (s, e) =>
            {
                if (e.Button != MouseButtons.Right) return;
                ListViewItem hit = lvJobs.GetItemAt(e.X, e.Y);
                if (hit != null)
                {
                    lvJobs.SelectedItems.Clear();
                    hit.Selected = true;
                    editing = hit.Tag as SyncJob;
                }
            };

            // keep the State column live while jobs run
            Timer st = new Timer { Interval = 1000 };
            st.Tick += (s, e) => RefreshJobStates();
            st.Start();
        }

        private void MoveJob(int delta)
        {
            if (editing == null) { MessageBox.Show("Select a job first."); return; }
            int i = config.Jobs.IndexOf(editing);
            int j = i + delta;
            if (i < 0 || j < 0 || j >= config.Jobs.Count) return;
            SyncJob x = config.Jobs[i];
            config.Jobs.RemoveAt(i);
            config.Jobs.Insert(j, x);
            config.Save();
            LoadJobsList();
        }

        private static void MoveListItem(ListBox lb, int delta)
        {
            CheckedListBox cl = lb as CheckedListBox;
            if (cl == null) return;
            int i = cl.SelectedIndex, j = i + delta;
            if (i < 0 || j < 0 || j >= cl.Items.Count) return;
            object a = cl.Items[i], b = cl.Items[j];
            bool ca = cl.GetItemChecked(i), cb = cl.GetItemChecked(j);
            cl.Items[i] = b; cl.SetItemChecked(i, cb);
            cl.Items[j] = a; cl.SetItemChecked(j, ca);
            cl.SelectedIndex = j;
        }


        /// <summary>
        /// Reloads LastStatus / LastRunSource / LastRunUtc / LastRows from the config file
        /// so the GUI reflects runs performed by the Windows service.
        /// </summary>
        private void ReloadJobStatusesFromDisk()
        {
            if (config == null || config.Jobs == null || lvJobs == null) return;
            AppConfig fresh = null;
            try { fresh = AppConfig.Load(); } catch { return; }
            if (fresh == null || fresh.Jobs == null) return;

            bool any = false;
            foreach (SyncJob j in config.Jobs)
            {
                if (j == null) continue;
                SyncJob src = null;
                foreach (SyncJob fj in fresh.Jobs)
                {
                    if (fj != null && fj.Id == j.Id) { src = fj; break; }
                }
                if (src == null) continue;

                if (j.LastStatus != src.LastStatus ||
                    j.LastRunSource != src.LastRunSource ||
                    j.LastRunUtc != src.LastRunUtc ||
                    j.LastRows != src.LastRows)
                {
                    j.LastStatus = src.LastStatus;
                    j.LastRunSource = src.LastRunSource;
                    j.LastRunUtc = src.LastRunUtc;
                    j.LastRows = src.LastRows;
                    try { j.LastErrorDetail = src.LastErrorDetail; } catch { }
                    any = true;
                }
            }
            if (any) RefreshJobStates();
        }

        private void RefreshJobStates()
        {
            if (lvJobs == null) return;
            foreach (ListViewItem it in lvJobs.Items)
            {
                SyncJob j = it.Tag as SyncJob;
                if (j == null || it.SubItems.Count < 7) continue;
                if (it.Checked != j.Enabled) { _jobsLoading = true; it.Checked = j.Enabled; _jobsLoading = false; }

                string stateTxt = StateText(j);
                string statusTxt = j.LastStatus ?? "";
                string runSrcTxt = FormatRunSource(j);
                string enabledTxt = Lang.T(j.Enabled ? "Yes" : "No");

                bool changed = false;
                if (it.SubItems[4].Text != stateTxt)
                {
                    it.SubItems[4].Text = stateTxt;
                    changed = true;
                }
                if (it.SubItems[2].Text != enabledTxt)
                {
                    it.SubItems[2].Text = enabledTxt;
                    changed = true;
                }
                if (it.SubItems.Count > 5 && it.SubItems[5].Text != statusTxt)
                {
                    it.SubItems[5].Text = statusTxt;
                    changed = true;
                }
                if (it.SubItems.Count > 6 && it.SubItems[6].Text != runSrcTxt)
                {
                    it.SubItems[6].Text = runSrcTxt;
                    changed = true;
                }
                if (changed)
                    StyleJobItem(it, j);
            }
        }

        private void SetJobEnabled(SyncJob j, bool enabled)
        {
            j.Enabled = enabled;
            Audit.Write(enabled ? "JOB_ENABLED" : "JOB_DISABLED", j.Name);
            if (enabled && j.Schedule != ScheduleKind.Manual)
                j.NextRunUtc = JobScheduler.ComputeNextRunUtc(j, DateTime.UtcNow);
            config.Save();
            scheduler.UpdateConfig(config);
            LoadJobsList();
            RefreshAsyncLabel();
        }

        /// <summary>Stop = cancel if running AND disable the job (row turns light red).</summary>
        private void StopSelectedJob()
        {
            if (editing == null) { MessageBox.Show("Select a job first."); return; }
            SyncJob j = editing;
            bool wasRunning = Engine.IsRunning(j.Id);
            if (wasRunning)
            {
                Engine.RequestStop(j.Id);
                AppLog.Warn(j.Name, "Stop requested by user."); Audit.Write("JOB_STOP", j.Name + " (running job cancelled)");
            }
            SetJobEnabled(j, false);
            AppLog.Warn(j.Name, "Job disabled by user.");
            lblStatus.Text = wasRunning ? "Stopping and disabled: " + j.Name : "Disabled: " + j.Name;
        }

        /// <summary>Start = enable the job (if disabled) and run it now.</summary>
        private void StartSelectedJob()
        {
            if (editing == null) { MessageBox.Show("Select a job first."); return; }
            if (!editing.Enabled)
            {
                SetJobEnabled(editing, true);
                AppLog.Info(editing.Name, "Job enabled by user.");
            }
            btnRun_Click(null, EventArgs.Empty);
        }

        private void EnableSelectedJob()
        {
            if (editing == null) { MessageBox.Show("Select a job first."); return; }
            SetJobEnabled(editing, true);
            AppLog.Info(editing.Name, "Job enabled by user.");
            lblStatus.Text = "Enabled: " + editing.Name;
        }

        private void OpenResources()
        {
            if (editing == null) { MessageBox.Show("Select a job first."); return; }
            editing.EnsureSteps();
            if (editing.Steps.Count == 0) { MessageBox.Show("This job has no steps yet. Use Edit job... to add steps."); return; }
            SyncJob copy = editing.Clone();
            using (ResourcesForm f = new ResourcesForm(copy, config))
            {
                if (f.ShowDialog(this) != DialogResult.OK) return;
            }
            editing.Steps = copy.Steps;
            config.Save();
            scheduler.UpdateConfig(config);
            lblStatus.Text = "Resources saved for " + editing.Name;
        }

        private void UpdateRouteInfo()
        {
            if (lblRouteInfo == null) return;
            try
            {
                SaveSelectedRoles();
                string sName = Lang.Fa ? "(تعیین نشده)" : "(none)", dName = sName;
                var sp = config.FindConnection(config.SourceConnectionId);
                var dp = config.FindConnection(config.DestConnectionId);
                if (sp != null) sName = sp.Name + " / " + sp.Server;
                if (dp != null) dName = dp.Name + " / " + dp.Server;
                lblRouteInfo.Text = Lang.T("TRANSFER ROUTE:") + "\r\n  " + Lang.T("Source (tab 2):") + " " + sName + "\r\n  " + Lang.T("Dest   (tab 3):") + " " + dName;
                lblRouteInfo.ForeColor = (sp == null || dp == null) ? Theme.Red : Theme.Green;
            }
            catch { }
        }

        private TabPage BuildJobEditorTab()
        {
            TabPage page = new TabPage("5) Job Designer");
            Panel p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(24) };
            Label l = new Label
            {
                Text = "Job designer (SQL Server Agent style)",
                Dock = DockStyle.Top, Height = 36,
                Font = new Font(Font.FontFamily, 12f, FontStyle.Bold)
            };
            Label info = new Label
            {
                Dock = DockStyle.Top, Height = 90, AutoSize = false,
                Text = "General / Steps / Schedules\r\nDouble-click a job in Jobs tab, or use the button below."
            };
            FlowLayoutPanel bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 48, WrapContents = true };
            Button btnOpen = new Button
            {
                Text = "Open Job Designer...", AutoSize = true, Height = 34,
                Font = new Font(Font, FontStyle.Bold),
                BackColor = Color.FromArgb(0, 90, 158), ForeColor = Color.White, FlatStyle = FlatStyle.Flat
            };
            btnOpen.Click += (s, e) =>
            {
                if (editing == null)
                {
                    if (config.Jobs.Count == 0) { btnAdd_Click(s, e); return; }
                    MessageBox.Show("Select a job in Jobs tab first.");
                    tabs.SelectedIndex = 3;
                    return;
                }
                OpenJobDesigner(editing);
            };
            bar.Controls.Add(btnOpen);
            bar.Controls.Add(MkBtn("New job...", btnAdd_Click));
            lblEditingJob = new Label { Dock = DockStyle.Top, Height = 28, Text = "No job selected", ForeColor = SystemColors.GrayText };
            p.Controls.Add(bar);
            p.Controls.Add(info);
            p.Controls.Add(lblEditingJob);
            p.Controls.Add(l);
            page.Controls.Add(p);
            return page;
        }

        private TabPage BuildLogsTab()
        {
            TabPage page = new TabPage("6) Logs");
            Panel p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8) };
            FlowLayoutPanel bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, WrapContents = true };
            dtLogDay = new DateTimePicker { Format = DateTimePickerFormat.Short, Value = DateTime.Today, Width = 120 };
            bar.Controls.Add(new Label { Text = "View day:", AutoSize = true, Margin = new Padding(3, 8, 3, 0) });
            bar.Controls.Add(dtLogDay);
            bar.Controls.Add(MkBtn("Load day", (s, e) => { txtLog.Text = AppLog.ReadLogForDate(dtLogDay.Value.Date); }));
            bar.Controls.Add(MkBtn("Open folder", (s, e) =>
            {
                Directory.CreateDirectory(config.EffectiveLogFolder);
                Process.Start("explorer.exe", config.EffectiveLogFolder);
            }));
            bar.Controls.Add(MkBtn("Delete this day", (s, e) =>
            {
                string path = Path.Combine(config.EffectiveLogFolder, dtLogDay.Value.ToString("yyyy-MM-dd") + ".log");
                if (File.Exists(path) && MessageBox.Show("Delete log for this day?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                { File.Delete(path); txtLog.Text = "(deleted)"; Audit.Write("LOG_DELETE_DAY", dtLogDay.Value.ToString("yyyy-MM-dd")); }
            }));
            bar.Controls.Add(MkBtn("Purge old", (s, e) => { AppLog.PurgeOldLogs(); Audit.Write("LOG_PURGE_OLD", "keep days=" + config.LogRetentionDays); MessageBox.Show("Purged."); }));
            bar.Controls.Add(MkBtn("Delete ALL logs", (s, e) =>
            {
                if (MessageBox.Show("Delete ALL logs?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                try
                {
                    if (Directory.Exists(config.EffectiveLogFolder))
                        foreach (string f in Directory.GetFiles(config.EffectiveLogFolder, "*.log"))
                            try { File.Delete(f); } catch { }
                    txtLog.Text = "(all deleted)";
                    Audit.Write("LOG_DELETE_ALL", "all daily log files deleted");
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }));
            txtLog = new TextBox
            {
                Dock = DockStyle.Fill, Multiline = true, ScrollBars = ScrollBars.Both,
                Font = new Font("Consolas", 9f), WordWrap = false, ReadOnly = true
            };
            p.Controls.Add(txtLog);
            p.Controls.Add(bar);
            page.Controls.Add(p);
            return page;
        }

        
        /// <summary>Reference tab: external / cloud methods that are not embedded in SyncDB.exe.</summary>
        private TabPage BuildGuideTab()
        {
            TabPage page = new TabPage(Lang.T("8) Advanced guide"));
            Panel wrap = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(12) };
            Label title = new Label
            {
                AutoSize = true,
                Font = new Font("Segoe UI Semibold", 11f),
                ForeColor = Theme.Navy,
                Text = Lang.T("Advanced options & external tools (reference)")
            };
            TextBox box = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Segoe UI", 9.5f),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                RightToLeft = Lang.Fa ? RightToLeft.Yes : RightToLeft.No
            };
            box.Text = Lang.Fa
                ? "الف) داخل خود SyncDB (بدون نصب اضافه)\r\n" +
                  "   • آخرین تغییرات: ستون افزایشی | Change Tracking | CDC\r\n" +
                  "   • حالت حافظه: خودکار / RAM / Stream / Disk  ·  حد MB خودکار = وقتی Auto به Disk می‌رود\r\n" +
                  "   • LiteDB Outbox: صف محلی پایدار برای دسته‌های ناموفق\r\n" +
                  "   • LocalStream: موضوع و آفست شبیه Kafka روی دیسک (بدون بروکر)\r\n" +
                  "   • کش اسکما: فراداده ستون‌ها برای هر جدول (اجرای مجدد سریع‌تر)\r\n\r\n" +
                  "ب) پلتفرم‌های بیرونی (داخل این EXE نیستند — وقتی زیرساخت دارید)\r\n" +
                  "   • Microsoft Fabric / ADF — پایپ‌لاین ابری، کپی موازی، OneLake\r\n" +
                  "   • Distributed AG — همگام‌سازی بدون قطعی موتور SQL (تنظیم DBA)\r\n" +
                  "   • Kafka / Event Hubs — جریان رویداد سازمانی با بروکر\r\n" +
                  "   • Parquet + PolyBase / COPY INTO — مسیر فایل انبوه در SQL 2022+\r\n\r\n" +
                  "ج) ایده‌هایی که بعداً می‌توانید اضافه کنید\r\n" +
                  "   • کش: SyncDB اسکما را کش می‌کند؛ Redis فقط اگر سرور کش دارید\r\n" +
                  "   • NoSQL: LiteDB گزینهٔ توکار است؛ MongoDB/Redis سرور جدا می‌خواهند\r\n" +
                  "   • کنترل تغییرات: CT یا CDC را روی مبدأ روشن کنید، سپس تیک مرحله را بزنید\r\n" +
                  "   • API دسته‌ای HTTP: نوع مرحله Web API ← مقصد برای همگام‌سازی pull\r\n"
                : "A) Built into SyncDB (no extra install)\r\n" +
                  "   • Last changes: Incremental column | Change Tracking | CDC\r\n" +
                  "   • Memory mode: Auto / RAM / Stream / Disk  ·  Auto threshold MB = when Auto switches to Disk\r\n" +
                  "   • LiteDB Outbox: durable local queue for failed batches\r\n" +
                  "   • LocalStream: Kafka-style topic+offset on disk (no broker)\r\n" +
                  "   • Schema cache: column metadata remembered per table (faster re-runs)\r\n\r\n" +
                  "B) External platforms (not inside this EXE — use when you have that infrastructure)\r\n" +
                  "   • Microsoft Fabric / ADF — cloud pipelines, parallel copy, OneLake\r\n" +
                  "   • Distributed AG — SQL engine zero-downtime sync (DBA setup)\r\n" +
                  "   • Kafka / Event Hubs — enterprise event streaming with a broker\r\n" +
                  "   • Parquet + PolyBase / COPY INTO — bulk file path on SQL 2022+\r\n\r\n" +
                  "C) Ideas you can layer later\r\n" +
                  "   • Caching: SyncDB already caches schema; optional Redis only if you run a cache server\r\n" +
                  "   • NoSQL: LiteDB is the embedded option; MongoDB/Redis need a separate server\r\n" +
                  "   • Change controller: enable CT or CDC on source, then mark the step checkbox\r\n" +
                  "   • HTTP batch API: use step type Web API → Destination for pull-style sync\r\n";
            wrap.Controls.Add(title);
            title.Location = new Point(8, 8);
            box.Location = new Point(8, 36);
            wrap.Resize += (s, e) =>
            {
                box.Width = Math.Max(200, wrap.ClientSize.Width - 24);
                box.Height = Math.Max(200, wrap.ClientSize.Height - 48);
            };
            wrap.Controls.Add(box);
            page.Controls.Add(wrap);
            page.Resize += (s, e) =>
            {
                try
                {
                    box.Width = Math.Max(200, page.ClientSize.Width - 40);
                    box.Height = Math.Max(200, page.ClientSize.Height - 60);
                }
                catch { }
            };
            return page;
        }

        private TabPage BuildSettingsTab()
        {
            TabPage page = new TabPage("7) Settings");
            page.AutoScroll = true;
            TableLayoutPanel t = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2, Padding = new Padding(12) };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            chkScheduler = new CheckBox { Text = "Service is manual only (Start/Stop buttons)", AutoSize = true, Checked = false, Enabled = false };
            numPoll = new NumericUpDown { Minimum = 10, Maximum = 3600, Value = 30 };
            numRetention = new NumericUpDown { Minimum = 0, Maximum = 1095, Value = 30 };
            txtLogFolder = new TextBox();
            int r = 0;
            Action<string, Control> add = (label, c) =>
            {
                t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                t.Controls.Add(new Label { Text = label, AutoSize = true, Margin = new Padding(3, 8, 3, 3) }, 0, r);
                c.Dock = DockStyle.Fill;
                t.Controls.Add(c, 1, r);
                r++;
            };
            add("Service mode", chkScheduler);
            add("Scheduler poll (sec)", numPoll);
            add("Log keep days (0=stop, 1–1095)", numRetention);
            add("Log folder", txtLogFolder);
            chkOutbox = new CheckBox {
                Text = "Local outbox (LiteDB file) — no server install; queue failed batches on disk",
                AutoSize = true, Checked = true
            };
            numOutboxRetries = new NumericUpDown { Minimum = 1, Maximum = 100, Value = 8, Width = 80 };
            numOutboxBatch = new NumericUpDown { Minimum = 1, Maximum = 500, Value = 20, Width = 80 };
            numOutboxIdle = new NumericUpDown { Minimum = 250, Maximum = 600000, Value = 3000, Increment = 250, Width = 100 };
            numOutboxSentDays = new NumericUpDown { Minimum = 1, Maximum = 3650, Value = 7, Width = 80 };
            txtOriginId = new TextBox { Text = Environment.MachineName, Width = 280, MinimumSize = new Size(200, 0) };
            lblOutboxStats = new Label { AutoSize = true, ForeColor = Theme.Muted, Text = "Outbox: …" };
            lblOutboxWorker = new Label { AutoSize = true, ForeColor = Theme.Muted, Text = "Worker: stopped" };
            // Ticking / unticking "Local outbox" is applied immediately: settings are saved, the worker is
            // started or stopped, the dependent fields are enabled / disabled and the Worker label is updated.
            chkOutbox.CheckedChanged += (s, e) => OnOutboxToggled();
            txtStreamTopic = new TextBox { Text = "syncdb.changes" };
            lblStreamStats = new Label { AutoSize = true, ForeColor = Theme.Muted, Text = "LocalStream: …" };
            add("Outbox", chkOutbox);
            add("Outbox worker", lblOutboxWorker);
            add("Outbox max retries", numOutboxRetries);
            add("Outbox batch size", numOutboxBatch);
            add("Outbox idle (ms)", numOutboxIdle);
            add("Keep sent (days)", numOutboxSentDays);
            add("Origin ID (this node)", txtOriginId);
            add("Outbox stats", lblOutboxStats);
            add("LocalStream topic (Kafka-style, no server)", txtStreamTopic);
            add("LocalStream stats", lblStreamStats);

            chkBufferClean = new CheckBox
            {
                Text = "Auto-clean the data folder (disk buffer, stream, cache, outbox) at startup and hourly",
                AutoSize = true, Checked = true
            };
            chkUseDiskBuffer = new CheckBox
            {
                Text = "Use a disk buffer for huge tables (OFF = Stream mode, nothing is written to disk)",
                AutoSize = true, Checked = false
            };
            // Applied the moment it is ticked (and written to config.json), so the user never has to
            // remember "Save settings" for it and the Windows service picks it up within seconds.
            chkUseDiskBuffer.CheckedChanged += (s, e) =>
            {
                if (_settingsLoading) return;
                try
                {
                    config.UseDiskBuffer = chkUseDiskBuffer.Checked;
                    config.Save();
                    RuntimeSettings.Apply(config);
                    Audit.Write("DISK_BUFFER", config.UseDiskBuffer ? "ENABLED" : "DISABLED");
                    AppLog.Info("-", "Disk buffer " + (config.UseDiskBuffer ? "ENABLED" : "DISABLED") + " from Settings.");
                    if (lblStatus != null)
                        lblStatus.Text = Lang.T(config.UseDiskBuffer
                            ? "Disk buffer enabled."
                            : "Disk buffer disabled - transfers use Stream mode.");
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            };
            numCacheKeepDays = new NumericUpDown { Minimum = 1, Maximum = 365, Value = 7, Width = 80 };
            lblDataFolder = new Label { AutoSize = true, ForeColor = Theme.Muted, Text = "data folder: …" };
            add("Auto cleanup", chkBufferClean);
            add("Disk buffer", chkUseDiskBuffer);
            add("Keep cache/stream (days)", numCacheKeepDays);
            add("Data folder", lblDataFolder);
            FlowLayoutPanel fb = new FlowLayoutPanel { AutoSize = true, WrapContents = true };
            fb.Controls.Add(MkBtn("Save settings", (s, e) =>
            {
                ApplyOutboxSettings();
                AppLog.Configure(config.EffectiveLogFolder, config.LogRetentionDays);
                config.Save();
                try { Maintenance.Reconfigure(config); } catch { }
                Audit.Write("SETTINGS_SAVED", "poll=" + config.SchedulerPollSeconds + "s | log keep=" + config.LogRetentionDays +
                    " days | outbox retries=" + config.OutboxMaxRetries + " batch=" + config.OutboxBatchSize +
                    " idle=" + config.OutboxIdleMs + "ms | origin=" + config.OriginId);
                MessageBox.Show("Settings saved.");
            }));
            fb.Controls.Add(MkBtn("Clean buffer/cache now", (s, e) => CleanDataFolderNow()));
            fb.Controls.Add(MkBtn("Open data folder", (s, e) =>
            {
                try
                {
                    Directory.CreateDirectory(AppConfig.DataDir);
                    Process.Start("explorer.exe", AppConfig.DataDir);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }));
            fb.Controls.Add(MkBtn("Manage outbox…", (s, e) => ShowOutboxManager()));
            fb.Controls.Add(MkBtn("Process outbox now", (s, e) =>
            {
                if (outboxWorker == null || !outboxWorker.IsRunning) StartOutboxWorker();
                if (outboxWorker != null && outboxWorker.IsRunning) { outboxWorker.ProcessNow(); lblStatus.Text = "Outbox: processing now…"; }
                else MessageBox.Show("Outbox worker is disabled. Tick “Local outbox” and save settings.", "Outbox");
            }));
            fb.Controls.Add(MkBtn("Browse…", (s, e) =>
            {
                using (FolderBrowserDialog d = new FolderBrowserDialog())
                    if (d.ShowDialog(this) == DialogResult.OK) txtLogFolder.Text = d.SelectedPath;
            }));
            fb.Controls.Add(MkBtn("Change password...", (s, e) => ShowChangePassword()));
            add("", fb);
            lblResources = new Label { AutoSize = true, Margin = new Padding(3, 16, 3, 3), Text = "RAM: …" };
            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Controls.Add(lblResources, 0, r);
            t.SetColumnSpan(lblResources, 2);
            page.Controls.Add(t);
            return page;
        }

        private static Button MkBtn(string text, EventHandler h)
        {
            Button b = new Button { Text = text, AutoSize = true };
            if (h != null) b.Click += h;
            return b;
        }

        private void ApplySettingsUi()
        {
            _settingsLoading = true;
            try { ApplySettingsUiCore(); }
            finally { _settingsLoading = false; }
            UpdateOutboxControlsEnabled();
            RefreshOutboxUi();
        }

        private void ApplySettingsUiCore()
        {
            if (chkScheduler != null) chkScheduler.Checked = false;
            numPoll.Value = Math.Max(numPoll.Minimum, Math.Min(numPoll.Maximum, config.SchedulerPollSeconds));
            int ret = config.LogRetentionDays;
            if (ret < 1) ret = 30;
            if (ret > 1095) ret = 1095;
            numRetention.Value = ret;
            txtLogFolder.Text = config.LogFolder ?? "";
            if (chkOutbox != null) chkOutbox.Checked = config.OutboxEnabled;
            if (numOutboxRetries != null)
                numOutboxRetries.Value = Math.Max(numOutboxRetries.Minimum, Math.Min(numOutboxRetries.Maximum, config.OutboxMaxRetries));
            if (numOutboxBatch != null)
                numOutboxBatch.Value = Math.Max(numOutboxBatch.Minimum, Math.Min(numOutboxBatch.Maximum, config.OutboxBatchSize));
            if (numOutboxIdle != null)
                numOutboxIdle.Value = Math.Max(numOutboxIdle.Minimum, Math.Min(numOutboxIdle.Maximum, config.OutboxIdleMs));
            if (numOutboxSentDays != null)
                numOutboxSentDays.Value = Math.Max(numOutboxSentDays.Minimum, Math.Min(numOutboxSentDays.Maximum, config.OutboxSentRetentionDays));
            if (txtOriginId != null) txtOriginId.Text = config.OriginId;
            RefreshOutboxUi();
            if (chkBufferClean != null) chkBufferClean.Checked = config.BufferAutoClean;
            if (chkUseDiskBuffer != null) chkUseDiskBuffer.Checked = config.UseDiskBuffer;
            if (numCacheKeepDays != null)
            {
                int ck = config.CacheKeepDays;
                if (ck < 1) ck = 7;
                if (ck > 365) ck = 365;
                numCacheKeepDays.Value = ck;
            }
            RefreshDataFolderLabel();
            if (txtStreamTopic != null)
                txtStreamTopic.Text = string.IsNullOrEmpty(config.LocalStreamTopic) ? "syncdb.changes" : config.LocalStreamTopic;
            if (lblStreamStats != null)
            {
                try
                {
                    string tp = txtStreamTopic != null ? txtStreamTopic.Text.Trim() : "syncdb.changes";
                    if (tp.Length == 0) tp = "syncdb.changes";
                    LocalStream.EnsureReady(tp);
                    lblStreamStats.Text = LocalStream.Stats(tp);
                }
                catch { lblStreamStats.Text = "LocalStream: n/a"; }
            }
        }

        /// <summary>Copies only the outbox controls of the Settings tab into the config.</summary>
        private void CollectOutboxUi()
        {
            if (chkOutbox != null) config.OutboxEnabled = chkOutbox.Checked;
            if (numOutboxRetries != null) config.OutboxMaxRetries = (int)numOutboxRetries.Value;
            if (numOutboxBatch != null) config.OutboxBatchSize = (int)numOutboxBatch.Value;
            if (numOutboxIdle != null) config.OutboxIdleMs = (int)numOutboxIdle.Value;
            if (numOutboxSentDays != null) config.OutboxSentRetentionDays = (int)numOutboxSentDays.Value;
            if (txtOriginId != null)
            {
                string origin = (txtOriginId.Text ?? "").Trim();
                config.OriginId = origin.Length > 0 ? origin : (Environment.MachineName ?? "node1");
            }
        }

        /// <summary>Outbox fields are only editable while "Local outbox" is ticked.</summary>
        private void UpdateOutboxControlsEnabled()
        {
            bool on = chkOutbox != null && chkOutbox.Checked;
            if (numOutboxRetries != null) numOutboxRetries.Enabled = on;
            if (numOutboxBatch != null) numOutboxBatch.Enabled = on;
            if (numOutboxIdle != null) numOutboxIdle.Enabled = on;
            if (numOutboxSentDays != null) numOutboxSentDays.Enabled = on;
            if (txtOriginId != null) txtOriginId.Enabled = on;
        }

        private void OnOutboxToggled()
        {
            UpdateOutboxControlsEnabled();
            if (_settingsLoading || chkOutbox == null) return;
            try
            {
                CollectOutboxUi();                      // config.OutboxEnabled = tick state (+ current outbox fields)
                CacheStoreFactory.Configure(config);
                if (outboxWorker != null) outboxWorker.UpdateConfig(config);   // starts or stops the worker
                else StartOutboxWorker();
                config.Save();                          // the Windows service picks the change up from config.json
                Audit.Write("OUTBOX_TOGGLE", "Local outbox " + (config.OutboxEnabled ? "ENABLED" : "DISABLED"));
                if (lblStatus != null)
                    lblStatus.Text = config.OutboxEnabled ? "Outbox worker enabled." : "Outbox worker disabled.";
            }
            catch (Exception ex)
            {
                AppLog.Warn("-", "Outbox toggle failed: " + ex.Message);
            }
            RefreshOutboxUi();
        }

        private void CollectSettingsUi()
        {
            config.SchedulerPollSeconds = (int)numPoll.Value;
            config.LogRetentionDays = (int)numRetention.Value;
            config.LogFolder = (txtLogFolder.Text ?? "").Trim();
            config.SchedulerEnabled = appSchedRunning;
            if (chkBufferClean != null) config.BufferAutoClean = chkBufferClean.Checked;
            if (chkUseDiskBuffer != null) config.UseDiskBuffer = chkUseDiskBuffer.Checked;
            if (numCacheKeepDays != null) config.CacheKeepDays = (int)numCacheKeepDays.Value;
            CollectOutboxUi();
            if (txtStreamTopic != null)
            {
                string tp = (txtStreamTopic.Text ?? "").Trim();
                config.LocalStreamTopic = tp.Length > 0 ? tp : "syncdb.changes";
            }
        }

        /// <summary>Settings -> "Clean buffer/cache now": runs the full housekeeping pass immediately.</summary>
        private void CleanDataFolderNow()
        {
            Cursor old = Cursor;
            Cursor = Cursors.WaitCursor;
            string summary;
            try
            {
                CollectSettingsUi();
                config.Save();
                Maintenance.Reconfigure(config);
                summary = Maintenance.SweepNow(config, true);
            }
            catch (Exception ex) { summary = "Cleanup failed: " + ex.Message; }
            finally { Cursor = old; }
            RefreshDataFolderLabel();
            Audit.Write("DATA_CLEANUP", summary ?? "");
            lblStatus.Text = Lang.T("Cleanup done.");
            MessageBox.Show(Lang.T("Cleanup done.") + "\r\n\r\n" + summary + "\r\n\r\n" +
                            AppConfig.DataDir, Lang.T("Clean buffer/cache now"));
        }

        private void RefreshDataFolderLabel()
        {
            if (lblDataFolder == null) return;
            try { lblDataFolder.Text = Maintenance.DataFolderStats(); }
            catch { lblDataFolder.Text = "data folder: n/a"; }
        }

        private static string StateText(SyncJob j)
        {
            bool run = Engine.IsRunning(j.Id);
            if (run) return Lang.T(j.Enabled ? "Running" : "Stopping");
            return Lang.T(j.Enabled ? "Idle" : "Disabled");
        }

        private static Bitmap MakeStatusMark(Color c, bool check)
        {
            Bitmap bmp = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmp))
            using (Pen p = new Pen(c, 2.4f))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                if (check)
                {
                    g.DrawLine(p, 3, 8, 7, 12);
                    g.DrawLine(p, 7, 12, 13, 3);
                }
                else
                {
                    g.DrawLine(p, 4, 4, 12, 12);
                    g.DrawLine(p, 12, 4, 4, 12);
                }
            }
            return bmp;
        }

        private static void StyleJobItem(ListViewItem it, SyncJob j)
        {
            string ls = j.LastStatus ?? "";
            // Successful run wins over Disabled so a finished job is always green.
            if (ls.StartsWith("OK") || (j.LastRunUtc != null && !ls.StartsWith("FAIL")))
            {
                it.BackColor = Theme.RowOkBack;
                it.ForeColor = Theme.RowOkText;
            }
            else if (Engine.IsRunning(j.Id)) { it.BackColor = Theme.RowRunningBack; it.ForeColor = Theme.Text; }
            else if (ls.StartsWith("FAIL")) { it.BackColor = Theme.RowFailBack; it.ForeColor = Theme.Red; }
            else if (!j.Enabled) { it.BackColor = Theme.RowDisabledBack; it.ForeColor = Theme.RowDisabledText; }
            else { it.BackColor = Color.White; it.ForeColor = Theme.Text; }
        }

        /// <summary>Only the run command for an active job is blocked; the Job itself stays enabled.</summary>
        private void UpdateManualRunButtons()
        {
            try
            {
                bool selectedRunning = editing != null && Engine.IsRunning(editing.Id);
                bool selectedAsync = editing != null && editing.Schedule == ScheduleKind.RealtimeAsync;
                bool anyRunning = false;
                bool anySelectedAsync = false;
                if (config != null && config.Jobs != null)
                    foreach (SyncJob j in config.Jobs)
                        if (j != null && Engine.IsRunning(j.Id)) { anyRunning = true; break; }

                if (lvJobs != null)
                {
                    ListView.SelectedListViewItemCollection selected = lvJobs.SelectedItems;
                    ListView.CheckedListViewItemCollection checkedItems = lvJobs.CheckedItems;
                    if (checkedItems.Count > 0)
                        foreach (ListViewItem it in checkedItems)
                        {
                            SyncJob j = it.Tag as SyncJob;
                            if (j != null && j.Schedule == ScheduleKind.RealtimeAsync) { anySelectedAsync = true; break; }
                        }
                    else
                        foreach (ListViewItem it in selected)
                        {
                            SyncJob j = it.Tag as SyncJob;
                            if (j != null && j.Schedule == ScheduleKind.RealtimeAsync) { anySelectedAsync = true; break; }
                        }
                }

                if (_runButton != null) _runButton.Enabled = !busy && !selectedRunning && !selectedAsync;
                if (_runManyButton != null) _runManyButton.Enabled = !busy && !anyRunning && !anySelectedAsync;
            }
            catch { }
        }

        private void LoadJobsList()
        {
            string selId = editing != null ? editing.Id : null;
            int jobsTop = 0;
            try { if (lvJobs.TopItem != null) jobsTop = lvJobs.TopItem.Index; } catch { }
            _jobsLoading = true;
            lvJobs.BeginUpdate();
            lvJobs.Items.Clear();
            foreach (SyncJob j in config.Jobs)
            {
                j.EnsureSteps();
                ListViewItem it = new ListViewItem(j.Name ?? "");
                it.SubItems.Add(Lang.Sched(ScheduleText(j)));
                it.SubItems.Add(Lang.T(j.Enabled ? "Yes" : "No"));
                it.SubItems.Add(j.Steps != null ? j.Steps.Count.ToString() : "0");
                it.SubItems.Add(StateText(j));
                it.SubItems.Add(j.LastStatus ?? "");
                it.SubItems.Add(FormatRunSource(j));
                it.Tag = j;
                it.Checked = j.Enabled;
                string ls = j.LastStatus ?? "";
                if (ls.StartsWith("OK")) it.ImageKey = "OK";
                else if (ls.StartsWith("FAIL")) it.ImageKey = "FAIL";
                else it.ImageKey = "NONE";
                StyleJobItem(it, j);
                lvJobs.Items.Add(it);
                if (selId != null && j.Id == selId) it.Selected = true;
            }
            lvJobs.EndUpdate();
            // keep the scroll position (the list used to jump to the top)
            if (lvJobs.Items.Count > 0)
            {
                if (jobsTop >= lvJobs.Items.Count) jobsTop = lvJobs.Items.Count - 1;
                try { lvJobs.TopItem = lvJobs.Items[jobsTop]; } catch { }
            }
            _jobsLoading = false;
            UpdateManualRunButtons();
        }

        /// <summary>Text for the "Run source" column: automatic success / manual / failed / etc.</summary>
        private static string FormatRunSource(SyncJob j)
        {
            if (j == null) return "—";
            string src = (j.LastRunSource ?? "").Trim().ToLowerInvariant();
            string ls = j.LastStatus ?? "";
            bool ok = ls.StartsWith("OK", StringComparison.OrdinalIgnoreCase);
            bool fail = ls.StartsWith("FAIL", StringComparison.OrdinalIgnoreCase);

            // Async - Every Change jobs are automatic by definition. Keep the Run source
            // column honest even when an older saved result still says "manual".
            if (j.Schedule == ScheduleKind.RealtimeAsync)
            {
                if (fail) return "async automatic failed";
                if (ok) return "async automatic success";
                return "async automatic";
            }

            if (string.IsNullOrEmpty(src) || src == "never")
                return "—";

            bool isAuto = (src == "schedule" || src == "service");
            if (isAuto)
            {
                if (fail) return "automatic failed";
                if (ok) return "automatic success";
                return "automatic";
            }
            // manual (or unknown)
            if (fail) return "manual failed";
            if (ok) return "manual success";
            return "manual";
        }

        /// <summary>Always Persian: صبح (0-11) or شب (12-23).</summary>
        private static string TimePeriod(int hour)
        {
            hour = ((hour % 24) + 24) % 24;
            return hour < 12 ? "صبح" : "شب";
        }

        private static string ScheduleText(SyncJob j)
        {
            switch (j.Schedule)
            {
                case ScheduleKind.RealtimeAsync: return "Async (" + j.IntervalValue + " s)";
                case ScheduleKind.EveryNMinutes: return "Every " + j.IntervalValue + " min";
                case ScheduleKind.EveryNHours: return "Every " + j.IntervalValue + " h";
                case ScheduleKind.Daily:
                    {
                        string every = j.IntervalValue > 1 ? (" every " + j.IntervalValue + "d") : "";
                        if (j.DailyFreq == DailyFreqKind.EveryNHours)
                            return string.Format("Daily{0} every {1}h {2:00}:{3:00}{4}-{5:00}:{6:00}{7}",
                                every, j.SubIntervalHours < 1 ? 1 : j.SubIntervalHours,
                                j.DailyHour, j.DailyMinute, TimePeriod(j.DailyHour),
                                j.EndHour, j.EndMinute, TimePeriod(j.EndHour));
                        return string.Format("Daily{0} {1:00}:{2:00} {3}", every, j.DailyHour, j.DailyMinute, TimePeriod(j.DailyHour));
                    }

                case ScheduleKind.Weekly:
                    {
                        string[] days = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
                        int mask = j.EffectiveWeekDaysMask();
                        System.Text.StringBuilder sb = new System.Text.StringBuilder();
                        for (int i = 0; i < 7; i++)
                            if ((mask & (1 << i)) != 0)
                            {
                                if (sb.Length > 0) sb.Append(',');
                                sb.Append(days[i]);
                            }
                        if (sb.Length == 0) sb.Append("Mon");
                        string w = j.IntervalValue > 1 ? (" every " + j.IntervalValue + "w") : "";
                        return sb.ToString() + w + string.Format(" {0:00}:{1:00} {2}", j.DailyHour, j.DailyMinute, TimePeriod(j.DailyHour));
                    }
                case ScheduleKind.Monthly:
                    return string.Format("Day {0} every {1} mo {2:00}:{3:00} {4}",
                        j.MonthlyDay < 1 ? 1 : j.MonthlyDay,
                        j.IntervalValue < 1 ? 1 : j.IntervalValue,
                        j.DailyHour, j.DailyMinute, TimePeriod(j.DailyHour));
                default: return "Manual";
            }
        }

        /// <summary>Writes an edited job back into the list and saves config. Used by OK and by
        /// the "Next job" / "Previous job" buttons, so moving on never loses what was typed.</summary>
        private bool SaveEditedJob(SyncJob edited, int idx)
        {
            try
            {
                if (edited == null) return false;
                if (idx < 0 || idx >= config.Jobs.Count)
                {
                    for (int i = 0; i < config.Jobs.Count; i++)
                        if (config.Jobs[i].Id == edited.Id) { idx = i; break; }
                }
                if (idx < 0 || idx >= config.Jobs.Count) return false;

                edited.Id = config.Jobs[idx].Id;
                edited.LastRunUtc = config.Jobs[idx].LastRunUtc;
                edited.LastStatus = config.Jobs[idx].LastStatus;
                edited.LastRunSource = config.Jobs[idx].LastRunSource;
                edited.LastRows = config.Jobs[idx].LastRows;
                config.Jobs[idx] = edited;
                editing = edited;

                config.Save();
                scheduler.UpdateConfig(config);
                scheduler.RearmAsync(edited);
                LoadJobsList();
                RefreshAsyncLabel();
                if (lblEditingJob != null) lblEditingJob.Text = "Selected: " + edited.Name + " (saved)";
                lblStatus.Text = "Job saved: " + edited.Name;
                Audit.Write("JOB_EDIT_SAVED", edited.Name + " | steps=" + edited.Steps.Count + " | schedule=" + ScheduleText(edited) + " | enabled=" + edited.Enabled);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Save job");
                return false;
            }
        }

        private void OpenJobDesigner(SyncJob j)
        {
            if (j == null) return;
            j.EnsureSteps();
            MiniWaitForm wait = null;
            try
            {
                int pos = config.Jobs.IndexOf(j);
                if (pos < 0)
                {
                    for (int i = 0; i < config.Jobs.Count; i++)
                        if (config.Jobs[i].Id == j.Id) { pos = i; break; }
                }

                wait = MiniWaitForm.ShowWait(this, Lang.Fa ? "در حال باز کردن Job…" : "Opening job…");
                JobEditForm f = new JobEditForm(j.Clone(), config.Jobs, pos);
                f.CommitJob = SaveEditedJob;      // also used by "Next job" / "Previous job"
                if (wait != null) { try { wait.Close(); wait.Dispose(); } catch { } wait = null; }
                using (f)
                {
                    if (f.ShowDialog(this) == DialogResult.OK)
                        SaveEditedJob(f.ResultJob, f.JobPos >= 0 ? f.JobPos : pos);
                } // using f
            }
            finally
            {
                if (wait != null) { try { wait.Close(); wait.Dispose(); } catch { } }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SyncJob j = new SyncJob { Name = "Job " + (config.Jobs.Count + 1) };
            Audit.Write("JOB_ADD", j.Name);
            j.EnsureSteps();
            config.Jobs.Add(j);
            config.Save();
            LoadJobsList();
            editing = j;
            OpenJobDesigner(j);
        }

        private void btnDuplicate_Click(object sender, EventArgs e)
        {
            if (editing == null) { MessageBox.Show("Select a job first."); return; }
            SyncJob c = editing.Clone();
            c.Id = Guid.NewGuid().ToString("N");
            c.Name = (editing.Name ?? "Job") + " (copy)";
            Audit.Write("JOB_DUPLICATE", editing.Name + " -> " + c.Name);
            c.LastRunUtc = null;
            c.LastStatus = "Never run";
            c.LastRunSource = "";
            c.LastRows = 0;
            c.NextRunUtc = JobScheduler.ComputeNextRunUtc(c, DateTime.UtcNow);
            config.Jobs.Add(c);
            config.Save();
            LoadJobsList();
            editing = c;
            OpenJobDesigner(c);
        }

        private bool _deleting;

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_deleting) return;                       // no re-entry while we wait for the run to stop
            if (editing == null) { MessageBox.Show(Lang.T("Select a job first.")); return; }

            SyncJob j = editing;
            bool running = Engine.IsRunning(j.Id);

            // Warn BEFORE deleting and say what will happen to the run (all texts go through Lang,
            // so the dialog is English in the English UI and Persian in the Persian UI).
            string question;
            if (running)
            {
                question = Lang.T("This job is running right now.") + "\r\n" +
                           Lang.T("If you delete it, the run is stopped first.") + "\r\n\r\n" +
                           Lang.T("Delete") + " \"" + j.Name + "\"?";
            }
            else
            {
                question = Lang.T("Delete") + " \"" + j.Name + "\"?";
                if (winSvcRunning)
                    question += "\r\n\r\n" + Lang.T("Note: the Windows service may be running this job; " +
                                                      "it stops at the end of its current step.");
            }

            if (MessageBox.Show(this, question, Lang.T("Confirm"), MessageBoxButtons.YesNo,
                                running ? MessageBoxIcon.Warning : MessageBoxIcon.Question,
                                MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;

            _deleting = true;
            Cursor oldCur = Cursor;
            try
            {
                if (running)
                {
                    Engine.RequestStop(j.Id);
                    AppLog.Warn(j.Name, "Delete requested while the job was running - stop requested.");
                    Audit.Write("JOB_STOP", j.Name + " (cancelled because the job is being deleted)");
                    lblStatus.Text = Lang.T("Stopping the job before deleting…");
                    Cursor = Cursors.WaitCursor;

                    // Give the engine up to 15 s to leave its current batch, keeping the window alive.
                    for (int i = 0; i < 150 && Engine.IsRunning(j.Id); i++)
                    {
                        Application.DoEvents();
                        System.Threading.Thread.Sleep(100);
                    }
                    if (Engine.IsRunning(j.Id))
                        AppLog.Warn(j.Name, "The job is still inside a long database call; it is deleted anyway " +
                                            "and the run stays cancelled, so it writes nothing more.");
                    else
                        AppLog.Info(j.Name, "Job stopped before deletion.");
                }

                // Belt and braces: whoever still holds a reference to this job object (a running
                // transfer, the scheduler) must not be able to run or re-arm it.
                j.Enabled = false;
                j.Schedule = ScheduleKind.Manual;
                j.NextRunUtc = null;

                string deletedName = j.Name;
                Audit.Write("JOB_DELETE", deletedName + (running ? " (was running - stopped first)" : ""));
                // History leaves the active list and is kept in archive for ArchiveDays, then auto-removed.
                try { JobHistory.Archive(deletedName); JobHistory.PurgeArchive(); } catch { }
                config.Jobs.Remove(j);
                editing = null;
                if (lblEditingJob != null) lblEditingJob.Text = Lang.T("No job selected.");
                config.Save();
                scheduler.UpdateConfig(config);      // the scheduler must see the job is gone at once
                LoadJobsList();
                RefreshAsyncLabel();
                lblStatus.Text = (running ? Lang.T("Job stopped and deleted: ") : Lang.T("Job deleted: ")) + deletedName;
            }
            finally
            {
                Cursor = oldCur;
                _deleting = false;
            }
        }

        private async void btnRun_Click(object sender, EventArgs e)
        {
            if (editing == null)
            {
                MessageBox.Show("Select a job first.\r\nAdd a job with a Transfer step, then select it.");
                return;
            }
            if (editing.Schedule == ScheduleKind.RealtimeAsync)
            {
                lblStatus.Text = editing.Name + " is Async - Every Change; manual Send is disabled.";
                MessageBox.Show(editing.Name + " is configured for Async - Every Change (Insert/Update/Delete).\r\n\r\n"
                    + "It is monitored and executed by Async automatically. Manual Send is disabled for this Job.",
                    "Async Job", MessageBoxButtons.OK, MessageBoxIcon.Information);
                UpdateManualRunButtons();
                return;
            }
            if (Engine.IsRunning(editing.Id))
            {
                lblStatus.Text = editing.Name + " is already running; manual send is temporarily disabled.";
                UpdateManualRunButtons();
                return;
            }
            SaveSelectedRoles();
            UpdateRouteInfo();
            if (string.IsNullOrEmpty(config.SourceConnectionId) || string.IsNullOrEmpty(config.ResolveSourceConnectionString()))
            {
                MessageBox.Show("Source connection is not selected.\r\nGo to tab 2) Database 1.");
                tabs.SelectedIndex = 1;
                return;
            }
            if (string.IsNullOrEmpty(config.DestConnectionId) || string.IsNullOrEmpty(config.ResolveDestConnectionString()))
            {
                MessageBox.Show("Destination connection is not selected.\r\nGo to tab 3) Database 2.");
                tabs.SelectedIndex = 2;
                return;
            }
            if (config.SourceConnectionId == config.DestConnectionId)
            {
                if (MessageBox.Show("Source and Destination are the SAME connection. Continue?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            }
            if (busy) return;
            busy = true;
            UpdateManualRunButtons();
            lblStatus.Text = "Transferring " + editing.Name + " …";
            Audit.Write("JOB_RUN_START", editing.Name + " (manual run)");
            SyncJob job = editing;
            AppConfig cfg = config;
            OpenLiveStatus();   // the live panel is a window of its own now - show it while the job runs
            RunResult r;
            try { r = await Task.Run(() => Engine.ExecuteJob(job, cfg, "manual")); }
            catch (Exception ex) { r = new RunResult { Ok = false, Message = ex.Message, ElapsedMs = 0 }; }
            job.LastRunUtc = DateTime.UtcNow;
            job.LastRows = r.Rows;
            job.LastStatus = (r.Ok ? "OK" : "FAIL") + " — " + ShortMsg(r.Message) + " (" + JobHistory.FormatSeconds(r.ElapsedMs) + ")";
            job.LastRunSource = "manual";
            job.LastErrorDetail = BuildJobDetailText(job, r);
            if (job.Schedule != ScheduleKind.Manual)
                job.NextRunUtc = JobScheduler.ComputeNextRunUtc(job, DateTime.UtcNow.AddSeconds(1));
            config.Save();
            LoadJobsList();
            try { txtLog.Text = AppLog.ReadLogForDate(DateTime.Today); } catch { }
            busy = false;
            UpdateManualRunButtons();
            Audit.Write("JOB_RUN_END", job.Name + " | " + job.LastStatus);
            lblStatus.Text = job.LastStatus;
            MessageBox.Show(job.LastStatus, r.Ok ? "Success" : "Failed",
                MessageBoxButtons.OK, r.Ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }

        /// <summary>Runs every checked job (or the selected ones if none are checked), in list order, one after another.</summary>
        private async void btnRunMany_Click(object sender, EventArgs e)
        {
            SaveSelectedRoles();
            UpdateRouteInfo();
            if (string.IsNullOrEmpty(config.SourceConnectionId) || string.IsNullOrEmpty(config.ResolveSourceConnectionString()))
            {
                MessageBox.Show("Source connection is not selected.\r\nGo to tab 2) Database 1.");
                tabs.SelectedIndex = 1;
                return;
            }
            if (string.IsNullOrEmpty(config.DestConnectionId) || string.IsNullOrEmpty(config.ResolveDestConnectionString()))
            {
                MessageBox.Show("Destination connection is not selected.\r\nGo to tab 3) Database 2.");
                tabs.SelectedIndex = 2;
                return;
            }
            if (busy) return;

            List<SyncJob> jobs = new List<SyncJob>();
            // Prefer checked items; fall back to selected items.
            if (lvJobs.CheckedItems.Count > 0)
            {
                foreach (ListViewItem it in lvJobs.CheckedItems)
                {
                    SyncJob j = it.Tag as SyncJob;
                    if (j != null) jobs.Add(j);
                }
            }
            else if (lvJobs.SelectedItems.Count > 0)
            {
                foreach (ListViewItem it in lvJobs.SelectedItems)
                {
                    SyncJob j = it.Tag as SyncJob;
                    if (j != null) jobs.Add(j);
                }
            }
            if (jobs.Count == 0)
            {
                MessageBox.Show("Tick the jobs you want to run (or select them), then click this button.\r\nThey will run one after another, in the order shown in the list.");
                return;
            }
            foreach (SyncJob runningJob in jobs)
            {
                if (runningJob != null && runningJob.Schedule == ScheduleKind.RealtimeAsync)
                {
                    MessageBox.Show(runningJob.Name + " is an Async - Every Change Job.\r\n"
                        + "Manual batch Send is disabled for Async Jobs; Async will run it automatically.",
                        "Async Job", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    UpdateManualRunButtons();
                    return;
                }
                if (runningJob != null && Engine.IsRunning(runningJob.Id))
                {
                    MessageBox.Show(runningJob.Name + " is already running. Wait until it finishes before sending jobs.",
                        "Job is running", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    UpdateManualRunButtons();
                    return;
                }
            }

            string names = string.Join("\r\n", jobs.ConvertAll(j => "• " + (j.Name ?? "(unnamed)")).ToArray());
            if (MessageBox.Show("Run these " + jobs.Count + " job(s) in order?\r\n\r\n" + names,
                    "Run checked jobs", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            busy = true;
            UpdateManualRunButtons();
            OpenLiveStatus();
            int okCount = 0, failCount = 0;
            StringBuilder summary = new StringBuilder();
            AppConfig cfg = config;

            for (int i = 0; i < jobs.Count; i++)
            {
                SyncJob job = jobs[i];
                lblStatus.Text = "Running " + (i + 1) + "/" + jobs.Count + ": " + job.Name + " …";
                Audit.Write("JOB_RUN_START", job.Name + " (batch run " + (i + 1) + "/" + jobs.Count + ")");
                RunResult r;
                try
                {
                    r = await Task.Run(() => Engine.ExecuteJob(job, cfg, "manual"));
                }
                catch (Exception ex)
                {
                    r = new RunResult { Ok = false, Message = ex.Message, ElapsedMs = 0 };
                }
                job.LastRunUtc = DateTime.UtcNow;
                job.LastRows = r.Rows;
                job.LastStatus = (r.Ok ? "OK" : "FAIL") + " — " + ShortMsg(r.Message) + " (" + JobHistory.FormatSeconds(r.ElapsedMs) + ")";
                job.LastRunSource = "manual";
                job.LastErrorDetail = BuildJobDetailText(job, r);
                if (job.Schedule != ScheduleKind.Manual)
                    job.NextRunUtc = JobScheduler.ComputeNextRunUtc(job, DateTime.UtcNow.AddSeconds(1));
                if (r.Ok) okCount++; else failCount++;
                summary.AppendLine((r.Ok ? "OK  " : "FAIL") + "  " + job.Name + "  —  " + ShortMsg(r.Message));
                Audit.Write("JOB_RUN_END", job.Name + " | " + job.LastStatus);
                config.Save();
                LoadJobsList();
            }

            busy = false;
            UpdateManualRunButtons();
            try { txtLog.Text = AppLog.ReadLogForDate(DateTime.Today); } catch { }
            string final = "Finished " + jobs.Count + " job(s):  OK=" + okCount + "  FAIL=" + failCount + "\r\n\r\n" + summary.ToString();
            lblStatus.Text = "Batch done: OK=" + okCount + " FAIL=" + failCount;
            MessageBox.Show(final, "Run checked jobs", MessageBoxButtons.OK,
                failCount == 0 ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }


        private const string ExportFilter = "SyncDB export (*.syncdb.json)|*.syncdb.json|JSON (*.json)|*.json";

        private void ExportJobsUi()
        {
            if (config.Jobs.Count == 0) { MessageBox.Show("There are no jobs to export."); return; }
            using (ExportForm f = new ExportForm(config.Jobs, editing))
            {
                if (f.ShowDialog(this) != DialogResult.OK) return;
                using (SaveFileDialog sf = new SaveFileDialog())
                {
                    sf.Filter = ExportFilter;
                    sf.FileName = "SyncDB_export_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".syncdb.json";
                    if (sf.ShowDialog(this) != DialogResult.OK) return;
                    try
                    {
                        List<SyncJob> sel = f.SelectedJobs;
                        ProjectIO.Export(sf.FileName, sel, config, f.IncludeConnections);
                        Audit.Write("EXPORT", sel.Count + " job(s) | connections=" + f.IncludeConnections + " | file=" + sf.FileName);
                        lblStatus.Text = "Exported " + sel.Count + " job(s): " + sf.FileName;
                        MessageBox.Show("Exported " + sel.Count + " job(s).\r\n" + sf.FileName, "Export");
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message, "Export failed"); }
                }
            }
        }

        private void ImportJobsUi()
        {
            using (OpenFileDialog of = new OpenFileDialog())
            {
                of.Filter = ExportFilter;
                if (of.ShowDialog(this) != DialogResult.OK) return;
                DialogResult dr = MessageBox.Show(
                    "YES  = MERGE: add the jobs of the file to the existing ones (your settings stay).\r\n" +
                    "NO   = REPLACE: delete all current jobs and restore jobs + settings of the file.\r\n" +
                    "Cancel = abort.",
                    "Import", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.Cancel) return;
                bool replace = dr == DialogResult.No;
                if (replace && MessageBox.Show("Really replace ALL current jobs?", "Import", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                try
                {
                    string summary = ProjectIO.Import(of.FileName, config, replace);
                    editing = null;
                    config.Save();
                    scheduler.UpdateConfig(config);
                    LoadJobsList();
                    RefreshConnectionList();
                    RefreshSourceDestCombos();
                    ApplySettingsUi();
                    Audit.Write("IMPORT", (replace ? "REPLACE" : "MERGE") + " | file=" + of.FileName);
                    lblStatus.Text = "Import finished.";
                    MessageBox.Show(summary, "Import");
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "Import failed"); }
            }
        }

        private void ShowChangePassword()
        {
            using (Form f = new Form())
            {
                f.Text = "Change password";
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.StartPosition = FormStartPosition.CenterParent;
                f.Size = new Size(360, 200);
                f.MaximizeBox = false;
                f.MinimizeBox = false;
                TableLayoutPanel tlp = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, Padding = new Padding(12) };
                tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
                tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
                TextBox t1 = new TextBox { UseSystemPasswordChar = true, Dock = DockStyle.Fill };
                TextBox t2 = new TextBox { UseSystemPasswordChar = true, Dock = DockStyle.Fill };
                TextBox t3 = new TextBox { UseSystemPasswordChar = true, Dock = DockStyle.Fill };
                tlp.Controls.Add(new Label { Text = "Current", AutoSize = true }, 0, 0);
                tlp.Controls.Add(t1, 1, 0);
                tlp.Controls.Add(new Label { Text = "New", AutoSize = true }, 0, 1);
                tlp.Controls.Add(t2, 1, 1);
                tlp.Controls.Add(new Label { Text = "Confirm new", AutoSize = true }, 0, 2);
                tlp.Controls.Add(t3, 1, 2);
                Button ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Width = 90 };
                Button cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Width = 90 };
                FlowLayoutPanel bf = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 40, FlowDirection = FlowDirection.RightToLeft };
                bf.Controls.Add(cancel);
                bf.Controls.Add(ok);
                f.Controls.Add(tlp);
                f.Controls.Add(bf);
                f.AcceptButton = ok;
                f.CancelButton = cancel;
                Theme.Apply(f);
                if (f.ShowDialog(this) != DialogResult.OK) return;
                if ((t2.Text ?? "") != (t3.Text ?? ""))
                {
                    MessageBox.Show("New passwords do not match.");
                    return;
                }
                if (string.IsNullOrEmpty(t2.Text))
                {
                    MessageBox.Show("New password cannot be empty.");
                    return;
                }
                try
                {
                    if (!Security.ChangePassword(t1.Text ?? "", t2.Text ?? ""))
                    {
                        MessageBox.Show("Current password is wrong.");
                        return;
                    }
                    MessageBox.Show("Password changed.");
                    Audit.Write("PASSWORD_CHANGED", "File > Change password");
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
        }


        private static List<string> PickedItems(ListBox lst, bool onlyHighlighted)
        {
            List<string> r = new List<string>();
            if (lst == null) return r;
            CheckedListBox cl = lst as CheckedListBox;
            if (!onlyHighlighted && cl != null && cl.CheckedItems.Count > 0)
                foreach (object o in cl.CheckedItems) r.Add(o.ToString());
            else
                foreach (object o in lst.SelectedItems) r.Add(o.ToString());
            return r;
        }

        private static void CheckAllItems(ListBox lst, bool check, bool tablesOnly)
        {
            CheckedListBox cl = lst as CheckedListBox;
            if (cl == null) return;
            for (int i = 0; i < cl.Items.Count; i++)
            {
                bool isView = (cl.Items[i].ToString() ?? "").StartsWith("[VIEW]");
                cl.SetItemChecked(i, check && !(tablesOnly && isView));
            }
        }

        private static string[] SplitObjName(string item)
        {
            string name = item ?? "";
            if (name.StartsWith("[TABLE] ")) name = name.Substring(8);
            else if (name.StartsWith("[VIEW] ")) name = name.Substring(7);
            name = name.Trim();
            string schema = "dbo", obj = name;
            int dot = name.IndexOf('.');
            if (dot > 0) { schema = name.Substring(0, dot).Trim(); obj = name.Substring(dot + 1).Trim(); }
            return new string[] { schema, obj };
        }

        private async void ExportCheckedTablesCsv(bool isSrc)
        {
            ListBox lst = isSrc ? lstSrcTables : lstDstTables;
            Label info = isSrc ? lblSrcInfo : lblDstInfo;
            List<string> items = PickedItems(lst, false);
            if (items.Count == 0) { MessageBox.Show("Tick the tables to export (List tables & views first)."); return; }
            SaveSelectedRoles();
            string cs = GetRoleConnectionString(isSrc);
            if (string.IsNullOrWhiteSpace(cs)) { MessageBox.Show("No connection selected."); return; }
            string dir;
            using (FolderBrowserDialog fb = new FolderBrowserDialog())
            {
                fb.Description = "Folder for the CSV files (one file per table)";
                if (fb.ShowDialog(this) != DialogResult.OK) return;
                dir = fb.SelectedPath;
            }
            Audit.Write("TABLE_CSV_EXPORT_START", items.Count + " object(s) | folder=" + dir);
            long total = 0; int ok = 0;
            List<string> errs = new List<string>();
            info.Text = "Exporting " + items.Count + " object(s) to CSV ...";
            await Task.Run(() =>
            {
                foreach (string item in items)
                {
                    string[] o = SplitObjName(item);
                    string fn = o[0] + "." + o[1];
                    foreach (char ch in Path.GetInvalidFileNameChars()) fn = fn.Replace(ch, '_');
                    try
                    {
                        long n = Engine.ExportTableCsv(cs, o[0], o[1], Path.Combine(dir, fn + ".csv"), 3600);
                        total += n; ok++;
                        string msg = "Exported " + ok + "/" + items.Count + ": " + o[0] + "." + o[1] + " (" + n + " rows)";
                        if (!IsDisposed) BeginInvoke(new Action(() => { info.Text = msg; }));
                    }
                    catch (Exception ex) { errs.Add(o[0] + "." + o[1] + ": " + ex.Message); }
                }
            });
            info.Text = "CSV export done: " + ok + " file(s), " + total + " row(s)" + (errs.Count > 0 ? ", " + errs.Count + " error(s)" : "") + ".";
            Audit.Write("TABLE_CSV_EXPORT_END", ok + " file(s) | " + total + " rows | errors=" + errs.Count + " | folder=" + dir);
            MessageBox.Show("CSV files: " + ok + "\r\nRows: " + total + "\r\nFolder: " + dir +
                (errs.Count > 0 ? "\r\n\r\nErrors:\r\n" + string.Join("\r\n", errs.ToArray()) : ""),
                "Export CSV", MessageBoxButtons.OK, errs.Count > 0 ? MessageBoxIcon.Warning : MessageBoxIcon.Information);
        }

        /// <summary>Checked tables of the Source list -> ask dest DB + write mode -> one job (a step per table).</summary>
        private void CreateTransferJobsFromSelected()
        {
            List<string> picked = PickedItems(lstSrcTables, false);
            if (picked.Count == 0)
            {
                MessageBox.Show("In Database 1 (Source): click List tables & views, then tick the tables you want (checkbox).");
                return;
            }
            SaveSelectedRoles();
            ApplySelectedDatabaseToProfile(true);
            ApplySelectedDatabaseToProfile(false);

            // Destination connection must be set (tab 3) so we know which server to list databases on
            string destCs = GetRoleConnectionString(false);
            if (string.IsNullOrWhiteSpace(destCs))
                destCs = config.ResolveDestConnectionString();
            if (string.IsNullOrWhiteSpace(destCs))
            {
                MessageBox.Show("Select Destination connection first (tab 3 — Database 2).");
                return;
            }
            ConnectionProfile destProf = config.FindConnection(config.DestConnectionId);
            if (destProf == null)
            {
                MessageBox.Show("Destination connection not found. Save a Destination connection on tab 3.");
                return;
            }

            string defaultDestDb = GetSelectedDatabase(false);
            if (string.IsNullOrEmpty(defaultDestDb)) defaultDestDb = destProf.Database;

            string destDb;
            WriteMode writeMode;
            bool autoMode;
            if (!AskCreateJobOptions(destCs, defaultDestDb, out destDb, out writeMode, out autoMode))
            {
                lblStatus.Text = "Job creation cancelled.";
                return;
            }

            // Connection profile pointing at the chosen database on the same dest server
            string targetConnId = EnsureDestDatabaseProfile(destProf, destDb);

            // Source CS must use the database selected on tab 2 (for PK lookup etc.)
            string srcCs = GetRoleConnectionString(true);
            if (string.IsNullOrWhiteSpace(srcCs)) srcCs = config.ResolveSourceConnectionString();
            SyncJob job = new SyncJob();
            job.Name = "Transfer " + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + " → " + destDb;
            job.Enabled = true;
            job.Schedule = ScheduleKind.Manual;
            job.Steps.Clear();
            int id = 1, withKey = 0;
            foreach (string item in picked)
            {
                if (item.StartsWith("[VIEW]")) continue; // tables only
                string[] o = SplitObjName(item);
                string srcTable = o[0] + "." + o[1];
                JobStep st = new JobStep();
                st.StepId = id++;
                st.Name = srcTable;
                st.Type = StepType.Transfer;
                st.SourceTable = srcTable;
                st.DestTable = srcTable; // same schema.table name on dest
                st.TargetConnectionId = targetConnId; // dest side uses chosen database
                st.Enabled = true;
                st.MaxThreads = 0;
                st.SourceThreads = 0;
                st.Buffer = BufferMode.Auto;
                st.BatchSize = 1000;
                st.OnFailure = StepAction.GoToNextStep; // missing/one bad table must not stop the rest
                string pk = "";
                try { pk = Engine.GetPrimaryKeyColumns(srcCs, srcTable); } catch { }
                if (autoMode)
                {
                    if (pk.Length > 0)
                    {
                        st.Mode = WriteMode.SyncChanges;
                        st.KeyColumns = pk;
                        st.WriteModeOn = true;
                        st.DeltaMethod = "Auto";
                        st.DeltaChunkRows = 1000000;
                        withKey++;
                    }
                    else
                    {
                        st.Mode = WriteMode.TruncateInsert;
                        st.WriteModeOn = true;
                    }
                }
                else
                {
                    st.Mode = writeMode;
                    st.WriteModeOn = true;
                    if (pk.Length > 0 && (writeMode == WriteMode.MergeUpsert || writeMode == WriteMode.SyncChanges))
                    {
                        st.KeyColumns = pk;
                        st.DeltaMethod = "Auto";
                        st.DeltaChunkRows = 1000000;
                        withKey++;
                    }
                }
                job.Steps.Add(st);
            }
            if (job.Steps.Count == 0)
            {
                MessageBox.Show("No tables ticked (views are skipped).");
                return;
            }
            // Resources dialog (RAM/CPU/threads) — Cancel still creates nothing
            using (ResourcesForm f = new ResourcesForm(job, config))
            {
                if (f.ShowDialog(this) != DialogResult.OK)
                {
                    lblStatus.Text = "Job creation cancelled.";
                    return;
                }
            }
            config.Jobs.Add(job);
            editing = job;
            Audit.Write("JOB_ADD", job.Name + " (tables=" + job.Steps.Count + " | destDB=" + destDb + ")");
            config.Save();
            scheduler.UpdateConfig(config);
            LoadJobsList();
            lblStatus.Text = "Job created: " + job.Name;
            MessageBox.Show(
                "Job \"" + job.Name + "\" created with " + job.Steps.Count + " table(s).\r\n" +
                "Destination database: " + destDb + "\r\n" +
                "Write mode: " + (autoMode ? "Auto (PK → Sync changes / no PK → Truncate+INSERT)" : writeMode.ToString()) + "\r\n" +
                withKey + " step(s) with primary key columns set\r\n\r\n" +
                "If a table does not exist on destination, it is created automatically (columns + data types from source).\r\n\r\n" +
                "Schedule / more options: tab 4, Edit job...",
                "Job created");
        }

        /// <summary>Dialog: pick destination database + write mode before creating the job.</summary>
        private bool AskCreateJobOptions(string destCs, string defaultDb, out string destDb, out WriteMode mode, out bool autoMode)
        {
            destDb = (defaultDb ?? "").Trim();
            mode = WriteMode.TruncateInsert;
            autoMode = true;

            Form dlg = new Form
            {
                Text = "Create job — destination & mode",
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                ShowInTaskbar = false,
                ClientSize = new Size(480, 260),
                Font = Font
            };

            Label lblDb = new Label
            {
                Text = "Destination database (where data will be written):",
                Left = 16, Top = 16, Width = 440, Height = 20
            };
            ComboBox cbDb = new ComboBox
            {
                Left = 16, Top = 40, Width = 440, Height = 28,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            Label lblMode = new Label
            {
                Text = "Write / transfer mode:",
                Left = 16, Top = 80, Width = 440, Height = 20
            };
            ComboBox cbMode = new ComboBox
            {
                Left = 16, Top = 104, Width = 440, Height = 28,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            // index 0 = Auto
            cbMode.Items.Add("Auto — PK → Sync changes; no PK → Truncate + INSERT");
            cbMode.Items.Add("Append (INSERT only)");
            cbMode.Items.Add("Truncate + INSERT");
            cbMode.Items.Add("DELETE + INSERT");
            cbMode.Items.Add("Merge / Upsert (by key)");
            cbMode.Items.Add("Sync changes (insert/update/delete by key)");
            cbMode.Items.Add("Drop into (DROP table + INSERT)");
            cbMode.SelectedIndex = 0;

            Label hint = new Label
            {
                Left = 16, Top = 145, Width = 440, Height = 50,
                ForeColor = SystemColors.GrayText,
                Text = "If a table does not exist in the chosen database, SyncDB creates it automatically\r\n" +
                       "with the same columns and data types as the source table."
            };

            Button ok = new Button { Text = "OK", Left = 260, Top = 210, Width = 90, Height = 30, DialogResult = DialogResult.OK };
            Button cancel = new Button { Text = "Cancel", Left = 360, Top = 210, Width = 90, Height = 30, DialogResult = DialogResult.Cancel };
            dlg.Controls.Add(lblDb);
            dlg.Controls.Add(cbDb);
            dlg.Controls.Add(lblMode);
            dlg.Controls.Add(cbMode);
            dlg.Controls.Add(hint);
            dlg.Controls.Add(ok);
            dlg.Controls.Add(cancel);
            dlg.AcceptButton = ok;
            dlg.CancelButton = cancel;

            // load databases
            try
            {
                List<string> dbs = Engine.ListDatabases(destCs);
                foreach (string d in dbs) cbDb.Items.Add(d);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not list databases on Destination server:\r\n" + ex.Message,
                    "Create job", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (cbDb.Items.Count == 0 && !string.IsNullOrEmpty(destDb))
                cbDb.Items.Add(destDb);
            if (!string.IsNullOrEmpty(destDb))
            {
                int ix = cbDb.Items.IndexOf(destDb);
                if (ix < 0) { cbDb.Items.Insert(0, destDb); ix = 0; }
                cbDb.SelectedIndex = ix;
            }
            else if (cbDb.Items.Count > 0) cbDb.SelectedIndex = 0;

            try { Theme.Apply(dlg); } catch { }
            if (dlg.ShowDialog(this) != DialogResult.OK) return false;
            if (cbDb.SelectedItem == null || string.IsNullOrWhiteSpace(Convert.ToString(cbDb.SelectedItem)))
            {
                MessageBox.Show(this, "Choose a destination database.");
                return false;
            }
            destDb = Convert.ToString(cbDb.SelectedItem).Trim();
            int mi = cbMode.SelectedIndex;
            if (mi <= 0) { autoMode = true; mode = WriteMode.TruncateInsert; }
            else
            {
                autoMode = false;
                // 1=Append … 6=DropInto  → enum 0..5
                mode = (WriteMode)(mi - 1);
            }
            return true;
        }

        /// <summary>Find or create a connection profile = dest server + chosen database.</summary>
        private string EnsureDestDatabaseProfile(ConnectionProfile destProf, string database)
        {
            database = (database ?? "").Trim();
            string server = (destProf.Server ?? "").Trim();
            // reuse existing profile with same server+database
            if (config.Connections != null)
            {
                foreach (ConnectionProfile p in config.Connections)
                {
                    if (p == null) continue;
                    if (string.Equals((p.Server ?? "").Trim(), server, StringComparison.OrdinalIgnoreCase) &&
                        string.Equals((p.Database ?? "").Trim(), database, StringComparison.OrdinalIgnoreCase) &&
                        p.IntegratedSecurity == destProf.IntegratedSecurity &&
                        string.Equals(p.User ?? "", destProf.User ?? "", StringComparison.Ordinal))
                        return p.Id;
                }
            }
            ConnectionProfile n = new ConnectionProfile();
            n.Id = Guid.NewGuid().ToString("N");
            n.Name = (string.IsNullOrEmpty(destProf.Name) ? "Dest" : destProf.Name) + " [" + database + "]";
            n.Server = destProf.Server;
            n.Port = destProf.Port;
            n.Database = database;
            n.IntegratedSecurity = destProf.IntegratedSecurity;
            n.User = destProf.User;
            n.Password = destProf.Password;
            if (config.Connections == null) config.Connections = new List<ConnectionProfile>();
            config.Connections.Add(n);
            return n.Id;
        }

        private void BuildSelectScripts(bool isSource, ListBox lst, bool all, bool preview = false, bool onlyHighlighted = false)
        {
            if (lst == null || lst.Items.Count == 0)
            {
                MessageBox.Show("List is empty. Click List tables & views first.");
                return;
            }
            SaveSelectedRoles();
            string id = isSource ? config.SourceConnectionId : config.DestConnectionId;
            ConnectionProfile prof = config.FindConnection(id);
            if (prof == null) { MessageBox.Show("No connection selected."); return; }
            string serverPart = (prof.Server ?? "").Trim();
            int comma = serverPart.IndexOf(',');
            if (comma > 0) serverPart = serverPart.Substring(0, comma).Trim();
            string db = GetSelectedDatabase(isSource);
            if (string.IsNullOrEmpty(db)) db = (prof.Database ?? "").Trim();
            if (string.IsNullOrEmpty(serverPart) || string.IsNullOrEmpty(db))
            {
                MessageBox.Show("Connection must have Server and Database.");
                return;
            }
            List<string> items = new List<string>();
            if (all) foreach (object o in lst.Items) items.Add(o.ToString());
            else
            {
                items = PickedItems(lst, onlyHighlighted);
                if (items.Count == 0) { MessageBox.Show("Tick (or select) one or more tables/views."); return; }
            }
            List<string[]> objs = new List<string[]>();
            StringBuilder sb = new StringBuilder();
            foreach (string item in items)
            {
                string name = item ?? "";
                if (name.StartsWith("[TABLE] ")) name = name.Substring(8);
                else if (name.StartsWith("[VIEW] ")) name = name.Substring(7);
                name = name.Trim();
                string schema = "dbo", obj = name;
                int dot = name.IndexOf('.');
                if (dot > 0) { schema = name.Substring(0, dot).Trim(); obj = name.Substring(dot + 1).Trim(); }
                objs.Add(new string[] { schema, obj });
                sb.AppendLine("SELECT *");
                // The preview connection already points at the selected database.
                // Use a three-part object name here; this avoids Invalid object name
                // errors caused by server aliases/instances in four-part names.
                sb.Append("FROM [").Append(schema).Append("].[" ).Append(obj).Append("]; ");
                sb.AppendLine();
                sb.AppendLine();
            }
            string sql = sb.ToString();
            try { Clipboard.SetText(sql); } catch { }
            // Preview must connect to the same database selected in the role tab,
            // not to the profile's old/default database.
            using (SelectPreviewForm f = new SelectPreviewForm(prof.Name, GetRoleConnectionString(isSource), sql, objs, preview))
                f.ShowDialog(this);
            lblStatus.Text = "SELECT generated for " + items.Count + " object(s).";
        }

        private static string ShortMsg(string msg)
        {
            if (string.IsNullOrEmpty(msg)) return "";
            string one = msg.Replace("\r\n", " ").Replace("\n", " ");
            if (one.Length > 80) return one.Substring(0, 80) + "...";
            return one;
        }

        private string BuildJobDetailText(SyncJob job, RunResult r)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(r.Ok ? "RESULT: SUCCESS" : "RESULT: FAILED");
            sb.AppendLine("Job: " + (job.Name ?? ""));
            sb.AppendLine("Time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("Elapsed: " + JobHistory.FormatElapsed(r.ElapsedMs));
            sb.AppendLine("Rows: " + r.Rows);
            sb.AppendLine();
            ConnectionProfile sp = config.FindConnection(config.SourceConnectionId);
            ConnectionProfile dp = config.FindConnection(config.DestConnectionId);
            sb.AppendLine("SOURCE connection:");
            if (sp != null)
                sb.AppendLine("  Name=" + sp.Name + "  Server=" + sp.Server + "  DB=" + sp.Database);
            else
                sb.AppendLine("  (not set)");
            sb.AppendLine("DEST connection:");
            if (dp != null)
                sb.AppendLine("  Name=" + dp.Name + "  Server=" + dp.Server + "  DB=" + dp.Database);
            else
                sb.AppendLine("  (not set)");
            sb.AppendLine();
            sb.AppendLine("Message:");
            sb.AppendLine(r.Message ?? "");
            if (!string.IsNullOrEmpty(r.Trace))
            {
                sb.AppendLine();
                sb.AppendLine("=== JOB HISTORY - every statement / table, in order ===");
                sb.AppendLine(r.Trace);
                sb.AppendLine("(also in the Log tab at the moment each statement finished, and in " + JobHistory.Dir + ")");
            }
            return sb.ToString();
        }

        private void ShowJobResultDetails()
        {
            if (editing == null)
            {
                MessageBox.Show("Select a job first.");
                return;
            }
            string detail = editing.LastErrorDetail;
            if (string.IsNullOrWhiteSpace(detail))
                detail = editing.LastStatus ?? "No run result yet.";

            bool ok = (editing.LastStatus ?? "").StartsWith("OK");
            Form f = new Form
            {
                Text = (ok ? "SUCCESS - " : "FAILED - ") + (editing.Name ?? "Job"),
                StartPosition = FormStartPosition.CenterParent,
                Size = new Size(1000, 640),
                Font = Font,
                ShowInTaskbar = false
            };
            Label icon = new Label
            {
                Dock = DockStyle.Top,
                Height = 40,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font(Font.FontFamily, 14f, FontStyle.Bold),
                Padding = new Padding(12, 0, 0, 0),
                Text = ok ? "  SUCCESS" : "  FAILED",
                ForeColor = ok ? Color.FromArgb(0, 128, 0) : Color.DarkRed,
                BackColor = ok ? Color.FromArgb(220, 255, 220) : Color.FromArgb(255, 230, 230)
            };
            TextBox box = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ScrollBars = ScrollBars.Both,
                Font = new Font("Consolas", 9.5f),
                WordWrap = false,
                ReadOnly = true,
                Text = detail
            };
            Button close = new Button { Text = "Close", Dock = DockStyle.Bottom, Height = 32 };
            close.Click += (s, e) => f.Close();
            f.Controls.Add(box);
            f.Controls.Add(close);
            f.Controls.Add(icon);
            Lang.Apply(f);
            f.ShowDialog(this);
        }

        private void UpdateResources()
        {
            try
            {
                if (lblResources == null) return;
                Process p = Process.GetCurrentProcess();
                p.Refresh();
                lblResources.Text = string.Format(
                    "App RAM: {0:0.0} MB | Service: {1} | Connections: {2} | Log keep: {3} days\r\n{4}",
                    p.WorkingSet64 / (1024.0 * 1024.0),
                    serviceRunning ? "RUNNING" : "STOPPED",
                    config.Connections != null ? config.Connections.Count : 0,
                    config.LogRetentionDays,
                    AppConfig.ConfigPath);
            }
            catch { }
        }
    }
}
