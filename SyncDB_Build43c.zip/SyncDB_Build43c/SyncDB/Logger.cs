﻿using System;
using System.IO;
using System.Text;

namespace SyncDB
{
    public static class AppLog
    {
        private static readonly object _lock = new object();
        private static string _folder;
        private static int _retentionDays = 30;
        private static bool _enabled = true;

        public static void Configure(string folder, int retentionDays)
        {
            _folder = folder;
            if (retentionDays <= 0)
            {
                _enabled = false;
                _retentionDays = 0;
            }
            else
            {
                _enabled = true;
                _retentionDays = retentionDays;
            }
            try { if (!string.IsNullOrEmpty(_folder)) Directory.CreateDirectory(_folder); } catch { }
        }

        public static string TodayPath
        {
            get
            {
                string dir = string.IsNullOrEmpty(_folder) ? AppConfig.DefaultLogDir : _folder;
                return Path.Combine(dir, DateTime.Now.ToString("yyyy-MM-dd") + ".log");
            }
        }

        public static void Write(string level, string jobName, string message)
        {
            if (!_enabled) return;
            string line = string.Format("{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}",
                DateTime.Now, level, string.IsNullOrEmpty(jobName) ? "-" : jobName, message);
            lock (_lock)
            {
                try
                {
                    string dir = string.IsNullOrEmpty(_folder) ? AppConfig.DefaultLogDir : _folder;
                    Directory.CreateDirectory(dir);
                    File.AppendAllText(Path.Combine(dir, DateTime.Now.ToString("yyyy-MM-dd") + ".log"),
                        line + Environment.NewLine, new UTF8Encoding(true));
                }
                catch { }
            }
        }

        public static void Info(string job, string msg) { Write("INFO", job, msg); }
        public static void Warn(string job, string msg) { Write("WARN", job, msg); }
        public static void Error(string job, string msg) { Write("ERROR", job, msg); }

        public static void PurgeOldLogs()
        {
            if (!_enabled || _retentionDays <= 0) return;
            try
            {
                string dir = string.IsNullOrEmpty(_folder) ? AppConfig.DefaultLogDir : _folder;
                if (!Directory.Exists(dir)) return;
                DateTime cutoff = DateTime.Now.Date.AddDays(-_retentionDays);
                foreach (string f in Directory.GetFiles(dir, "*.log"))
                {
                    string name = Path.GetFileNameWithoutExtension(f);
                    DateTime d;
                    if (DateTime.TryParse(name, out d) && d < cutoff)
                    {
                        try { File.Delete(f); } catch { }
                    }
                }
            }
            catch { }
        }

        public static string ReadLogForDate(DateTime day)
        {
            try
            {
                string dir = string.IsNullOrEmpty(_folder) ? AppConfig.DefaultLogDir : _folder;
                string path = Path.Combine(dir, day.ToString("yyyy-MM-dd") + ".log");
                if (File.Exists(path)) return File.ReadAllText(path, Encoding.UTF8);
            }
            catch (Exception ex) { return "Error reading log: " + ex.Message; }
            return "(no log for this day)";
        }
    }
}
